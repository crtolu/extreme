IF I FORGOT ANYTHING OR ANYONE PLEASE CONTACT ME ON DISCORD @crtolu or EMAIL toluuuu44@gmail.com

While nothing has been taken from it, this mod is inspired by Reborn Extreme so credits to that for the general idea!

 some elements of extreme are inspired by the great LAWDS mod please check it out its a high quality difficulty mod great experience!!:D 
https://www.rebornevo.com/forums/topic/79422-lawds-mod-v20-an-overhaul-for-rejuvenation/
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
########## Custom Eeveelutions ##########
--Pokemon Reborn--
Bazaro - Pokemon Reborn Eeveelution thread
Fervis - Icons, Spriting (mostly Backsprites)
Badman - Titaneon Sprite (Design unknown)
Eeveelution Community/Aminoapps - Ephemeon (Designer unknown)
Dazed Flame - Toxeon
(Eleanor Brick - Hawkeon)
OnyxBlock, Kriyanceldt (Deviant) - Kitsuneon
Mykel Ryan (Design - Youtube) - Drekeon
Baraayas (Reborn Discord) - Polishing Titaneon, Drekeon, Kitsuneon, Hawkeon
StarWolff(Eeveeexpo)- Sprites; Braveon, Fluffeon (Eeveon), Cloudeon, Sandeon, Boulderon
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Grps Musicpack using AsNKrysis base pack and containing music from: GladioOGG (Gladio.ogg = BlizZar), Shota Kageyama, Haruki Yamada (ATTIC) 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Machobrace mod "Evcooker" ported to Vanilla by Jmedley (original credits to Wingdings).
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SMW QoL Mod COmpilation Pack + Small Bug Fixes 
Alemi,
Jarred B Dank, 
AsNKrysis, 
EvGym, 
Lillietea, 
Waynolt, 
DemICE, 
Anddy 
https://www.rebornevo.com/forums/topic/65994-rejuv-135-qol-mod-compilation-pack-small-bug-fixes/
Please check out their stuff its amazing !
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
starlightarena for mega azumarill and great support in adjusting most of sheets for the sprites special thanks a lot they are amazing!
The 11th Dimension and his amazing thread on rebornevo that offers free to use redesigned sprites e.g. mega blaziken, Venomogon (Fakemon we made with his sheet)
scaryplasma for helping with a few sprite and iconsheets and also the shiny sprite for Venomogon
The amazing Gen 9 shiny sprites + Toucannon made by Skullex	
mightovershades for the delibird and cramorant shiny sheets!
strawberry_bloom for making the icons for our custom mega evo stones for Ray, Devil and Angel and the missing mega stone icons for Vanilla.
PinkPanther providing the amazing shiny Staraptor sprite. 
Samurux for Rift Chandelure icons
MoonPaw for Blonde aevia sprite!
Hexx_Vixtar for Mega Chesnaught
Escav for the INSANE Aevian Arcanine sprite that finally reverted the curse on the type of Arcanine :D
thanks to dr. house (walking plane) for wishiwashi crest and not taking a single vicodin while doing it

wiresegal, they made an amazing fat QoL pack containing all sorts of useful things please have a look: https://github.com/yrsegal/rejuvenation-modpack
(we are using a load mods he did per my request such as refined inspect, improved battle AI and Housing Key as well as highlighted moves for overlay! Thanks for the amazing work please have a look at wiresegal's custom modpack!)

special thanks to O.M.A.R for the very peak Aevian Sigilyph shiny sprite!!

DarkusShadow for Mega Dragonite overworld icons! check out the DeviantArt page a goated artist! https://www.deviantart.com/darkusshadow

scaryplasma who did gods work with the king X's base concept of the mega dragonite sprite and repixeled it bit by bit to a clean look so its usable in essentials goated people!!!!! 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Team Desolation https://www.rebornevo.com/deso/index.php/
shiny sprites of some mons
mega forms
the sprite of Sena that has been turned into a protag here (ty @Moonpaw for this amazing work) and replaces Aevia.
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Wingdings for helping me with a TON of code related questions and providing me the pre status code.
Dred for helping me with a lot RPGX related questions and a few tweaks i managed to got done in the code with his help.
Jarred B Dank for "coaching" me through a lot of things regarding the games code and how basic stuff works.
Mahat for helping me to implement a couple of Gen 9 Items into the Code and modifying their functions further.
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Battlbacks:
Skyfield by HarmonyCenter from Pixabay and evening by Pexels from Pixabay
Frozen dimension  by Noel Bauza from Pixabay
Ashen beach by Pok Rie from Pixabay
beach day by Kanenori from Pixabay evening by SEIMORI from Pixabay night by Bruno from Pixabay
mountain eve by Joe from Pixabay night 
aqua marine by Brigitte Werner from Pixabay
colo by Manuel Reina from Pixabay
corrupted by Hans from Pixabay
desert by Roberto Lee Cortes from Pixabay
city and streets all times by Pexels from Pixabay and  by Karl-Alwin Hiller from Pixabay and by Nina Stock from Pixabay
All the other backgrounds are free-to-use royal images that weren't assigned to a creator!
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Rebornverse characters

I am very grateful for the entire Rebornverse being a thing to begin with, that being said regardless of double mentions:

Rebornverse characters - Reborn

https://www.rebornevo.com/pr/index.html/

I am very grateful for the entire Rebornverse being a thing to begin with that being said:

Amethyst and Team Reborn for Reborn and some of the characters that come from Reborn for the purpose of Major battles only and no story content!

Rebornverse characters - Desolation

https://www.rebornevo.com/deso/index.php/

Posty and Team Desolation for some Desolation characters that are also used for some major battles only and no story content!

And also the sprite for Sena which replaced Aevia and made fully replayable thanks to MoonPaw making the missing sprites !!! 


I have a permission I can show from Posty (Lead Developer Desolation) where i was told its okay to use Desolation Graphics as long as it is credited!


I have swapped some shiny sprites and icons between rebornverse games so i will credit the people who were involved in making these:
Ruby
Amethyst	
Crim
Jan	
--6th Gen Battlers:
Amethyst	Noscium			Quanyails		Zermonious		GeoIsEvil		
Kyle Dove	dDialgaDiamondb		N-kin		Misterreno		Kevfin
Xtreme1992	Vale98PM 		MrDollSteak		Crim

--7th Gen Battlers:
Amethyst		Jan			Zumi			Bazaro			Koyo	
Smeargletail	Alex		Noscium			Leparagon		N-kin	
fishbowlsoul90	princess-phoenix		DatLopunnyTho		Conyjams 	
kaji atsu 		The cynical poet	LuigiPlayer		Pokefan2000
Falgaia of the Smogon S/M sprite project	Lord-Myre 		Crim

--Mega Sprites: 
Amethyst	Bazaro			Gardrow			FlameJow		Minhnerd	
The Cynical Poet			Greyenna		Brylark			Leparagon	
Princess Phoenix			Gnomowladn		Bryancct		Tinivi
Julian	Dante52		Crim

--Icons:
smeargletail	ARandomTalkingBush

--Miscellaneous Sprites:
Will		Veenerick		chasemortier	Mektar (Pokémon Amethyst)	
JoshR691	kidkatt			ShinxLuver		Dr Shellos		Getsuei-H
Kidkatt		Nefalem			Piphybuilder88		SageDeoxys
PurpleZaffre

--Shiny Spriting:
Amethyst	UnprofessionalAmateur	Nefalem		Jacze	Freya
Calvius			Flux	Thirdbird	Mike		Bazaro	Azery
Bakerlite		Gamien	Rielly987	smeargletail	Nsuprem
15gamer2000		dragon in night		Nova		Night Fighter
Serythe		MetalKing1417	roqi	Jan			MMM		Kelazi5
Player_Name_Null	Khrona 		Sir_Bagel	Pixl	Crim 
ghostchanuwu	MoonPaw		MoltenLights	PinkPanther
