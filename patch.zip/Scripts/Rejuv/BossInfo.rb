BOSSINFOHASH = {
##############################
# Boss Template
##############################

    :GODKILLER => {
        :name => "God Killer", # nickname
        :shieldCount => 1, # number of shields
        :barGraphic => "", # what kind of hp bar graphic should be pulled
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :capturable => true, # can you catch this boss after shields are removed?
        :entryText => "Heaven-shaking Godkiller appeared.", # dialogue upon enterring battle as a wild pokemon
        :moninfo => { # bosspokemon details
            :species => :GARCHOMP,
            :level => 5,
            :form => 0,
            :item => :LEFTOVERS,
            :moves => [:DARKPULSE,:PSYSHOCK,:MOONLIGHT,:MOONBLAST],
            :ability => :RKSSYSTEM,
            :gender => "F",
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252,0,4,0,252,0]
            },
        :sosDetails =>  { # sospokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
            :continuous => true,
            :totalMonCount => 3,
            :moninfos => {
                1 => {
                    :species => :GARCHOMP,
                    :level => 5,
                    :form => 0,
                    :item => :LEFTOVERS,
                    :moves => [:DARKPULSE,:PSYSHOCK,:MOONLIGHT,:MOONBLAST],
                    :ability => :RKSSYSTEM,
                    :gender => "F",
                    :nature => :MODEST,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [252,0,4,0,252,0]
                },
                2 => {
                    :species => :GYARADOS,
                    :level => 5,
                    :form => 0,
                    :item => :LEFTOVERS,
                    :moves => [:DARKPULSE,:PSYSHOCK,:MOONLIGHT,:TACKLE],
                    :ability => :RKSSYSTEM,
                    :gender => "F",
                    :nature => :MODEST,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [252,0,4,0,252,0]
                    },
            },
        },
        :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
            :fieldChange => :PSYTERRAIN,
            :fieldChangeMessage => "Gothitelle laughs at how dumb your face looks. So mean!"
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "", # message that plays when shield is broken
                :bossEffect => :MagicCoat, # effect that applies on the boss when breaking shield
                :bossEffectduration => true, # duration of the effect(some effects are booleans, double check)
                :bossEffectMessage => "{1} shrouded itself with Magic Coat!", # message that plays for the effect
                :bossEffectanimation => :MAGICCOAT, # effect animation
                :weatherChange => :RAINDANCE, # weather to apply
                :formchange => 0, # formchanges
                :abilitychange => :DOWNLOAD, # ability to change to upon shieldbreaker
                :fieldChange => :SWAMP, # field changes
                :fieldChangeMessage => "", # message that plays when the field is changes
                :weatherCount => 5, # weather turncount
                :weatherChangeMessage => "Rain began to fall!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
                :typeChange => [:FIRE,:ROCK], # any given type changes
                :movesetUpdate => [:EARTHQUAKE,:OUTRAGE,:ROCKSLIDE,:FIREBLAST], # any given moveset changes
                :speciesUpdate => :FLYGON,
                :statusCure => true, # if status is cured when shield is broken
                :effectClear => true, # if effects are cleared when shield is broken
                :bossSideStatusChanges => [:PARALYSIS,"Paralysis"], # what status gets inflicted on a boss/player pokemon when shield is broken. array has 2 elements, first the status symbol, then a string for the animation
                :playerSideStatusChanges => [:PARALYSIS,"Paralysis"], # what status gets inflicted on a boss/player pokemon when shield is broken. array has 2 elements, first the status symbol, then a string for the animation
                :statDropCure => true, # if statdrops are negated when shield is broken
                :playerEffects => :Curse, # effects applied upon enemies on breaking shield
                :playerEffectsduration => true, # enemy effect durration
                :playerEffectsAnimation => :CURSE, # enemyeffect animation
                :playerEffectsMessage => "A curse was inflicted on the opposing side!", # enemy effect message
                :stateChanges => :TrickRoom, # handles state changes found in the Battle_Global class(in Battle_ActiveSide file + Trick Room
                :stateChangeAnimation => :TRICKROOM, # state change animation
                :stateChangeCount => 5, # state change turncount
                :stateChangeMessage => "The dimensions were changed!", # statechange messages
                :playersideChanges => :ToxicSpikes, # handles side changes found in the Battle_Side class(in Battle_ActiveSide file) 
                :playersideChangeAnimation => :TOXICSPIKES, # side change animation
                :playersideChangeCount => 1, # side change turncount
                :playersideChangeMessage => "Toxic Spikes was set up!", # statechange messages
                :bosssideChanges => :ToxicSpikes, # handles side changes found in the Battle_Side class(in Battle_ActiveSide file) 
                :bosssideChangeAnimation => :TOXICSPIKES, # side change animation
                :bosssideChangeCount => 1, # side change turncount
                :bosssideChangeMessage => "Toxic Spikes was set up!", # statechange messages
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
                :bgmChange => "Battle - Final Endeavor",
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPATK => 1,
                },
                :playerSideStatChanges => { # any statchanges applied to the players side
                    PBStats::SPATK => -1,
                }
            },
        },
    },
    
##############################
# Normal Bosses
##############################
    :BOSSGARBODOR => {
        :name => "Garbage Menace",
        :entryText => "The Garbodor approached!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GARBODOR,
            :level => 12,
            :moves => [:POUND,:ACIDSPRAY,:DOUBLESLAP,:ATTRACT],
            :ability => :STENCH,
            :gender => "M",
            :shiny => true,
            :nature => :NAUGHTY,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 1",
            :totalMonCount => 2,
            :moninfos => {
                1 => {
                    :species => :TRUBBISH,
                    :level => 11,
                    :moves => [:POUND,:POISONGAS,:THIEF,nil],
                    :ability => :STENCH,
                    :iv => 10,
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Garbodor's typing changed!",
                :animation => :NASTYPLOT,
                :typeChange => [:POISON,:DARK],
            },
        }
    },

    :RIFTGYARADOS1 => {
        :name => "Rift Gyarados",
        :entryText => "Rift Gyarados attacked in a rage!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :GYARADOS,
            :level => 20,
            :form => 4,
            :moves => [:SHADOWSNEAK,:BITE,:WATERPULSE,:SCREECH],
            :ability => :INTIMIDATE,
            :gender => "M",
            :nature => :NAUGHTY,
            :iv => 20,
            :happiness => 255,
            :ev => [20,20,20,20,20,20]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Rift Gyarados started acting defensive!",
                :animation => :WITHDRAW,
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1
                }
            }
        }
    },
    
    :BOSSPYROAR => {
        :name => "Pride King",
        :entryText => "The freshly evolved Pyroar attacked!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :PYROAR,
            :level => 20,
            :moves => [:TAKEDOWN,:NOBLEROAR,:FIREFANG,:ROAR],
            :ability => :UNNERVE,
            :gender => "M",
            :nature => :NAUGHTY,
            :iv => 10,
            :happiness => 255,
            :ev => [0,0,0,0,0,0],
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 1",
            :totalMonCount => 2,
            :moninfos => {
                1 => {
                    :species => :LITLEO,
                    :level => 15,
                    :moves => [:EMBER,:HEADBUTT,:LEER,:WORKUP],
                    :ability => :UNNERVE,
                    :iv => 10,
                },
            },
        },
        :onBreakEffects => {
        },
    },
    :RIFTCHANDELURE => {
        :name => "Rift Chandelure",
        :entryText => "Otherworldly wind chimes echo through the air...",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :CHANDELURE,
            :level => 60,
            :item => :FIREGEM,
            :form => 2,
            :moves => [:SHADOWBALL,:AIRSLASH,:FIREBLAST,:WILLOWISP],
            :gender => "M",
            :nature => :TIMID,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,0,252,4,252]
        },
        :onEntryEffects => {
            :message => "A feeling of warmth emanates from Rift Chandelure...",
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :animation => :OMINOUSWIND,
                :message => "The air feels cold and moist...",
                :statDropRefresh => true,
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                },
                :itemchange => :WATERGEM,
                :typeChange => [:GHOST,:WATER],
                :movesetUpdate => [:SHADOWBALL,:AIRSLASH,:SURF,:WHIRLPOOL],
                :abilitychange => :TRACE
            },
            2 => {
                :threshold => 0,
                :animation => :OMINOUSWIND,
                :message => "A sickly sweet scent attacks your nose...",
                :statDropRefresh => true,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                },
                :itemchange => :GRASSGEM,
                :typeChange => [:GHOST,:GRASS],
                :movesetUpdate => [:SHADOWBALL,:AIRSLASH,:ENERGYBALL,:LEECHSEED],
                :abilitychange => :TRACE
            },
            1 => {
                :threshold => 0,
                :animation => :OMINOUSWIND,
                :message => "The feeling of static is all around...",
                :statDropRefresh => true,
                :bossStatChanges => {
                    PBStats::SPEED => 1,
                },
                :itemchange => :ELECTRICGEM,
                :typeChange => [:GHOST,:ELECTRIC],
                :movesetUpdate => [:SHADOWBALL,:AIRSLASH,:THUNDERBOLT,:THUNDERWAVE],
                :abilitychange => :TRACE
            },
        }
    },
    :SHADOWMEWTWO => {
        :name => "Shadow Mewtwo",
        :entryText => "Mewtwo's power is building up!",
        :shieldCount => 1,
        :immunities => {},
        :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
            :message => "KETA: We have to defeat it quickly or else...",
        },
        :chargeAttack => {
            :turns => 10,
            :chargingMessage => "Mewtwo is charging its attack...",
            :continueCharging => true,
            :canAttack => false,
            :canIntermediateAttack => true,
            :intermediateattack => {
                :move => :SHADOWBEAM,
                :type => :SHADOW,
                :basedamage => 40,
                :name => "Shadow Beam",
                :category => 0,
                :target => :AllOpposing,
            }
        },
        :moninfo => {
            :species => :MEWTWO,
            :level => 30,
            :moves => [:SHADOWSNEAK,nil,nil,nil],
            :ability => :PRESSURE,
            :nature => :HARDY,
            :iv => 20,
            :happiness => 0,
            :form => 3,
            :shadow => true,
            :ev => [40,40,40,40,40,40]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Shadow Mewtwo's power grows!",
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => -1
                }
            }
        }
    },
    :RIFTGYARADOS2 => {
        :name => "Rift Gyarados",
        :entryText => "Rift Gyarados is intent on revenge!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GYARADOS,
            :level => 35,
            :form => 4,
            :moves => [:PHANTOMFORCE,:WATERFALL,:GRASSYGLIDE,:SCREECH],
            :ability => :INTIMIDATE,
            :gender => "M",
            :nature => :NAUGHTY,
            :iv => 20,
            :happiness => 255,
            :ev => [40,40,40,40,40,40],
            :BaseStats => [95,145,89,120,110,81]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Rift Gyarados's type changed!",
                :typeChange => [:WATER,:DRAGON],
                :movesetUpdate => [:DRAGONRUSH,:WATERFALL,:THUNDERFANG,:SCREECH],
                :fieldChange => :WATERSURFACE,
                :fieldChangeMessage => "Rift Gyarados dragged the battle to the lake!"
            },
            1 => {
                :threshold => 0,
                :message => "Rift Gyarados's type changed!",
                :typeChange => [:FIRE,:DRAGON],
                :movesetUpdate => [:DRAGONRUSH,:LAVAPLUME,:CRUNCH,:SCREECH],
                :statDropCure => true,
                :fieldChange => :INFERNAL,
                :fieldChangeMessage => "Rift Gyarados conflagarated the arena!"
            }
        }
    },
    :PULSEMUSHARNA => {
        :name => "Pulse+ Musharna",
        :entryText => "The dangerous(?) Musharna attacked(?)!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :MUSHARNA,
            :level => 20,
            :form => 2,
            :moves => [:PSYBEAM,:DISARMINGVOICE,:CHARGEBEAM,:SWEETSCENT],
            :gender => "F",
            :nature => :DOCILE,
            :ability => :PASTELVEIL,
            :iv => 20,
            :happiness => 255,
            :ev => [20,20,20,20,20,20]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :fieldChange => :MISTY,
                :fieldChangeMessage => "Pulse Musharna spread mist everywhere."
            }
        }
    },
    :PULSEMUSHARNA2 => {
        :name => "Pulse+ Musharna",
        :entryText => "The dangerous(?) Musharna attacked(?) again!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :MUSHARNA,
            :level => 91,
            :form => 2,
            :item => :SITRUSBERRY,
            :moves => [:MISTBALL,:DAZZLINGGLEAM,:AURASPHERE,:SWEETSCENT],
            :gender => "F",
            :nature => :MODEST,
            :ability => :PASTELVEIL,
            :iv => 31,
            :happiness => 255,
            :ev => [252,0,4,252,0,0]
        },
        :onEntryEffects => {
            :delayedaction => {
                :delay => 3,
                :playerSideStatChanges => {
                    PBStats::SPEED => -1,
                },
                :message => "The aromatic mist is relaxing...",
                :repeat => true,
                :animation => :FAIRYWIND,
            }
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :bosssideChanges => :Mist,
                :bosssideChangeAnimation => :MIST,
                :bosssideChangeCount => 5,
                :movesetUpdate => [:MISTBALL,:STRANGESTEAM,:PETALDANCE,:STUNSPORE],
                :message => "Pulse Musharna is laying lazily in the flowers...",
                :statusCure => true,
                :statDropCure => true,
                :effectClear => true,
           },
            2 => {
                :threshold => 0,
                :bosssideChanges => :Safeguard,
                :bosssideChangeAnimation => :SAFEGUARD,
                :bosssideChangeCount => 5,
                :message => "Pulse Musharna became one with the bugs...",
                :typeChange => [:BUG,:FAIRY],
                :movesetUpdate => [:BUGBUZZ,:STRANGESTEAM,:MISTBALL,:MYSTICALFIRE],
                :delayedaction => {
                    :delay => 3,
                    :message => "Pulse Musharna issued a defend order!",
                    :animation => :DEFENDORDER,
                    :bossStatChanges => {
                        PBStats::DEFENSE => 2,
                        PBStats::SPDEF => 2,                  
                    },
                    :delayedaction => {
                        :delay => 3,
                        :message => "Pulse Musharna issued an attack order!",
                        :animation => :ATTACKORDER,
                        :bossStatChanges => {
                            PBStats::SPATK => 2,                
                        },
                        :delayedaction => {
                            :delay => 3,
                            :message => "Pulse Musharna issued a heal order!",
                            :animation => :HEALORDER,
                            :itemchange => :LEFTOVERS,
                            :statusCure => true,
                            :statDropCure => true,
                            :effectClear => true,
                            :bossEffect => :Ingrain,
                            :bossEffectduration => true,
                        }
                    }
                }
            },
        }
    },
    :BOSSGOTHITELLE_SHERIDAN => {
        :name => "Gothitelle",
        :entryText => "The mischievous Gothitelle laughs at you!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :GOTHITELLE,
            :level => 35,
            :form => 1,
            :moves => [:FAKETEARS,:PSYCHIC,:FLATTER,:DARKPULSE],
            :gender => "F",
            :nature => :MODEST,
            :ability => :SHADOWTAG,
            :iv => 31,
            :happiness => 255,
            :ev => [252,0,0,252,0,0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                }
            }
        }
    },
    :CRESCGOTHITELLE => {
        :name => "Gothitelle",
        :entryText => "The mischievous Gothitelle laughs at you!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :GOTHITELLE,
            :level => 50,
            :form => 1,
            :moves => [:PLAYNICE,:PSYSHOCK,:FOCUSBLAST,:DARKPULSE],
            :gender => "F",
            :nature => :MODEST,
            :ability => :COMPETITIVE,
            :iv => 31,
            :happiness => 255,
            :ev => [252,0,0,252,0,0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :fieldChange => :PSYTERRAIN,
                :fieldChangeMessage => "Gothitelle laughs at how dumb your face looks. So mean!"
            }
        }
    },
    :KIERANXURK_1 => {
        :name => "Xurkitree",
        :entryText => "Static electricity crackles in the air...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :XURKITREE,
            :level => 70,
            :form => 1,
            :moves => [:THUNDER,:ENERGYBALL,:DAZZLINGGLEAM,:TAILGLOW],
            :nature => :MODEST,
            :ability => :BEASTBOOST,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,0,252,0,252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :fieldChange => :ELECTERRAIN,
                :fieldChangeMessage => "Xurkitree repositions itself."
            }
        }
    },
    :BELIAL => {
        :name => "Belial", # nickname
        :entryText => "A feisty Volcarona appeared!",
        :shieldCount => 5, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :VOLCARONA,
            :level => 50,
            :item => :LEFTOVERS,
            :moves => [:MYSTICALFIRE,:BUGBUZZ,:GIGADRAIN,:SUNNYDAY],
            :ability => :FLAMEBODY,
            :nature => :MODEST,
            :gender => "M",
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,128,252,128,252]
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :totalMonCount => 2,
        :continuous => true,
        :moninfos => {
            1 => {
                :species => :VENUSAUR,
                :level => 40,
                :item => :GRASSGEM,
                :moves => [:PETALDANCE,:HYPERVOICE,:EARTHPOWER,:HELPINGHAND],
                :ability => :TOXIFICATE,
                :nature => :BOLD,
                :iv => 31,
                :happiness => 255,
            },
            2 => {
                :species => :MEGANIUM,
                :level => 40,
                :item => :BIGROOT,
                :moves => [:DRAININGKISS,:GIGADRAIN,:PARABOLICCHARGE,:NATUREPOWER],
                :ability => :SIPHONSOUL,
                :iv => 31,
                :happiness => 255,
            },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            3 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :weatherChange => :SUNNYDAY, # weather to applyes
                :weatherCount => 5, # weather turncount
                :weatherChangeMessage => "The Sun is bright!", # weather message
                :weatherChangeAnimation => "Sunny", # string of "Rain", "Sunny","Hail","Sandstorm"
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
            },
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :bosssideChanges => :Safeguard,
                :bosssideChangeCount => 5,
                :bosssideChangeMessage => "Belial shrouded itself with a Safeguard!", # message that plays for the effect
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
            },
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :abilitychange => :SWARM,
                :fieldChange => :FLOWERGARDEN3, # field changes
                :fieldChangeMessage => "The field is covered in flowers!", # message that plays when the field is changes
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
            },
        }
    },  
    :SEAPRINCE => {
        :name => "Manaphy", # nickname
        :entryText => "ODESSA: Witness the might of the seas!",
        :shieldCount => 2, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :MANAPHY,
            :level => 58,
            :item => :LEFTOVERS,
            :moves => [:SCALD,:SHADOWBALL,:RAINDANCE,:TAKEHEART],
            :ability => :HYDRATION,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,0,252,0,252]
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :PHIONE,
                :level => 50,
                :moves => [:SURF,:ENERGYBALL,:HELPINGHAND,:DAZZLINGGLEAM],
                :ability => :HYDRATION,
                :gender => "F",
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
            },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "ODESSA: The Prince of the Sea's tail shines bright. Be blinded by its glow!", # message that plays when shield is broken
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 5, # weather turncount
                :weatherChangeMessage => "The Rain pours down!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPATK => 3,
                },
                :delayedaction => {
                    :delay => 2,
                    :message => "The Prince's glowing tail starts to dim...",
                    :bossStatChanges => { 
                        PBStats::SPATK => -3,
                    },
                }
            },
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "ODESSA: The Prince can command the sea themselves. As such as a Prince should! Be purged by the sacred waters of Kristiline! ", # message that plays when shield is broken
                :abilitychange => :PRESSURE,
                :fieldChange => :WATERSURFACE, # field changes
                :fieldChangeMessage => "The battlefield was plunged underwater!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
            },
        }
    },  
    :RIFTGALVANTULA => {
        :name => "Rift Galvantula",
        :shieldCount => 2,
        :entryText => "Joltik swarm the egg...",
        :immunities => {},
        :moninfo => {
            :species => :GALVANTULA,
            :level => 25,
            :form => 2,
            :moves => [:ELECTROWEB,:BUGBITE,:CROSSPOISON,:TOXICTHREAD],
            :gender => "F",
            :nature => :HASTY,
            :iv => 20,
            :happiness => 255,
            :ev => [32,32,32,32,32,32]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 2",
            :continuous => true,
            :moninfos => {
                1 => {
                    :species => :JOLTIK,
                    :level => 20,
                    :moves => [:ELECTROWEB,:STRINGSHOT,:STRUGGLEBUG,nil],
                    :ability => :COMPOUNDEYES,
                    :form => 1,
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :formchange => 1,
                :message => "Rift Galvantula hatched out of the egg!",
                :abilitychange => :UNNERVE,
                :movesetUpdate => [:ELECTROWEB,:LUNGE,:CROSSPOISON,:VENOSHOCK],
                :statDropCure => true,
                :playersideChanges => :ToxicSpikes,
                :playersideChangeAnimation => :TOXICPSIKES,
                :playersideChangeMessage => "Broken eggshell was strewn everywhere!",
            },
        }
    },
    :RIFTVOLCANION => {
        :name => "Rift Volcanion",
        :entryText => "Rift Volcanion let out a languid grumble...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :VOLCANION,
            :level => 28,
            :form => 1,
            :moves => [:STEAMERUPTION,:FLAMETHROWER,:SCORCHINGSANDS,:ROCKSLIDE],
            :gender => "F",
            :nature => :LONELY,
            :iv => 20,
            :happiness => 255,
            :ev => [40,40,40,40,40,40]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Volcanion is losing motivation…",
                :movesetUpdate => [:SCALD,:INCINERATE,:MUDSHOT,:ROCKTOMB],
                :bossStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1                    
                }
            },
            1 => {
                :threshold => 0,
                :message => "Volcanion is losing motivation…",
                :movesetUpdate => [:WATERGUN,:EMBER,:MUDSLAP,:ROCKTHROW],
                :bossStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1                    
                }
            },
        }
    },
    :BOSSDUSKNOIR => {
        :name => "Dusknoir",
        :entryText => "The Dusknoir is threatening you.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :DUSKNOIR,
            :level => 30,
            :moves => [:SHADOWPUNCH,:WILLOWISP,:INFESTATION,:PAYBACK],
            :gender => "M",
            :nature => :ADAMANT,
            :iv => 31,
            :form => 1,
            :ev => [100,100,32,32,32,32]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Dusknoir is about to throw hands!",
                :movesetUpdate => [:SHADOWPUNCH,:WILLOWISP,:ICEPUNCH,:THUNDERPUNCH],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,                 
                }
            },
        }
    },
    :WISPYGIRATINA => {
        :name => "Renegade Giratina",
        :entryText => "GEARA: Destroy them, Giratina! Show them the might of a Legendary Pokémon!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GIRATINA,
            :level => 35,
            :moves => [:SHADOWCLAW,:DRAGONBREATH,:SLASH,:ICYWIND],
            :nature => :HARDY,
            :iv => 31,
            :form => 1,
            :ev => [52,80,32,80,32,32]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Giratina's ghastly aura lowered offenses!",
                :statDropCure => true,
                :playerSideStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::SPATK => -1,                 
                }
            },
            1 => {
                :threshold => 0,
                :message => "Giratina's aura enveloped the battlefield!",
                :bossStatChanges => {
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,                 
                },
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,                 
                }
            }
        }
    },
    :BOSSCROBAT => {
        :name => "Furious Bat",
        :entryText => "The Crobat attacked with furor!",
        :shieldCount => 5,
        :immunities => {},
        :moninfo => {
            :species => :CROBAT,
            :level => 50,
            :moves => [:SLUDGEWAVE,:GIGADRAIN,:UPROAR,:PROTECT],
            :ability => :INFILTRATOR,
            :gender => "F",
            :nature => :MODEST,
            :item => :FLYINGGEM,
            :iv => 31,
            :happiness => 255,
            :ev => [252,0,0,252,0,252],
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 10",
            :continuous => true,
            :moninfos => {
                1 => {
                    :species => :ZUBAT,
                    :level => 45,
                    :moves => [:TAUNT,:POISONFANG,:TORMENT,:THIEF],
                    :ability => :INNERFOCUS,
                    :iv => 31,
                },
                2 => {
                    :species => :WOOBAT,
                    :level => 45,
                    :moves => [:NIGHTSHADE,:CHARM,:HELPINGHAND,:AIRSLASH],
                    :ability => :UNAWARE,
                    :iv => 31,
                },
                3 => {
                    :species => :NOIBAT,
                    :level => 45,
                    :moves => [:SUPERFANG,:FAKETEARS,:AIRSLASH,:DRAGONRUSH],
                    :ability => :INFILTRATOR,
                    :iv => 31,
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :bosssideChanges => :Tailwind,
                :bosssideChangeAnimation => :TAILWIND,
                :bosssideChangeCount => 3,
                :movesetUpdate => [:BRAVEBIRD,:CROSSPOISON,:PROTECT,:LEECHLIFE],
                :statDropCure => true,
                :itemchange => :SITRUSBERRY,
            },
        },
    },
    :MADAMEXYVELTAL => {
        :name => "Yveltal",
        :entryText => "Yveltal looms above.",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :YVELTAL,
            :level => 75,
            :moves => [:DECIMATION,:HURRICANE,:FOCUSBLAST,nil],
            :nature => :MODEST,
            :iv => 31,
            :ev => [48,48,48,48,48,48]
        },
    },
    :TAPUKOKOJUNGLE=> {
        :name => "Thunder Warrior",
        :shieldCount => 5,
        :immunities => {},
        :moninfo => {
            :species => :TAPUKOKO,
            :level => 50,
            :shiny => true,
            :moves => [:STEELWING,:NATURESMADNESS,:ELECTRICTERRAIN,:DISCHARGE],
            :nature => :TIMID,
            :ability => :ELECTRICSURGE,
            :iv => 20,
            :happiness => 255,
            :ev => [0,252,0,252,0,252]
        },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :message => "Tapu Koko is putting in its all!!",
                :movesetUpdate => [:CHARGEBEAM,:AIRSLASH,:ROOST,:DAZZLINGGLEAM],
                :statDropCure => true,
            },
            3 => {
                :threshold => 0,
                :message => "Tapu Koko is putting in its all!!",
                :movesetUpdate => [:BRAVEBIRD,:FLASHCANNON,:THUNDERBOLT,:DAZZLINGGLEAM],
                :statDropCure => true,
            },
            2 => {
                :threshold => 0,
                :message => "Tapu Koko is putting in its all!!",
                :movesetUpdate => [:WILDCHARGE,:PLAYROUGH,:BRAVEBIRD,:CLOSECOMBAT],
                :statDropCure => true,
            },
        }
    },
    :BOSSCONKELDURR => {
        :name => "Strained Worker",
        :entryText => "Conkeldurr is agitated!",
        :shieldCount => 5,
        :immunities => {},
        :moninfo => {
            :species => :CONKELDURR,
            :level => 50,
            :moves => [:CLOSECOMBAT,:ICEPUNCH,:FIREPUNCH,:THUNDERPUNCH],
            :ability => :IRONFIST,
            :gender => "M",
            :nature => :ADAMANT,
            :iv => 31,
            :happiness => 0,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 1",
            :continuous => true,
            :moninfos => {
                1 => {
                    :species => :TIMBURR,
                    :level => 40,
                    :moves => [:COACHING,:HELPINGHAND,:ROCKSLIDE,:HAMMERARM],
                    :ability => :IRONFIST,
                    :nature => :ADAMANT
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Conkeldurr built a miniature city in anger!",
                :fieldChange => :CITY,
                :bossStatChanges => {
                    PBStats::ATTACK => 2,             
                },
            },
            1 => {
                :threshold => 0,
                :message => "The miniature city was destroyed...",
                :fieldChange => :FOREST,
                :bossStatChanges => {
                    PBStats::ATTACK => -2,             
                },
            },
        },
    },
    :RIFTCARNIVINE => {
        :name => "Corrupted Carnivine",
        :entryText => "Carnivine is dancing the samba!",
        :shieldCount => 5,
        :immunities => {},
        :moninfo => {
            :species => :CARNIVINE,
            :level => 50,
            :form => 1,
            :moves => [:DRAGONDANCE,:POWERWHIP,:DRAGONPULSE,:FLAMETHROWER],
            :ability => :OWNTEMPO,
            :gender => "M",
            :nature => :NAUGHTY,
            :item => :YACHEBERRY,
            :iv => 31,
            :happiness => 255,
            :ev => [252,40,40,252,40,252],
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 2",
            :continuous => true,
            :totalMonCount => 4,
            :moninfos => {
                1 => {
                    :species => :TANGELA,
                    :level => 40,
                    :form => 1,
                    :item => :LEFTOVERS,
                    :moves => [:FOLLOWME,:HELPINGHAND,:POLLENPUFF,:PETALDANCE],
                    :ability => :DANCER,
                    :gender => "F",
                    :nature => :MODEST,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [0,128,0,128,0,252]
                },
                2 => {
                    :species => :TANGROWTH,
                    :level => 40,
                    :form => 1,
                    :item => :LEFTOVERS,
                    :moves => [:FOLLOWME,:QUASH,:POLLENPUFF,:ROCKTOMB],
                    :ability => :DANCER,
                    :gender => "M",
                    :nature => :MODEST,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [252,128,0,128,0,0]
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :animation => :SHIFTGEAR,
                :message => "The rhythm of the music has changed!",
                :bossEffectMessage => "Carnivine did the robot and became Steel-type!",
                :typeChange => [:GRASS,:STEEL],
                :movesetUpdate => [:SHIFTGEAR,:POWERWHIP,:IRONHEAD,:FIRELASH],
                :statDropRefresh => true,
                :itemchange => :OCCABERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1               
                },
                :playerSideStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1                
                }
            },
            1 => {
                :threshold => 0,
                :animation => :QUIVERDANCE,
                :message => "The rhythm of the music has changed!",
                :bossEffectMessage => "Carnivine did the jitterbug and became Bug-type!",
                :typeChange => [:GRASS,:BUG],
                :movesetUpdate => [:QUIVERDANCE,:LEAFSTORM,:POLLENPUFF,:FIERYDANCE],
                :statDropRefresh => true,
                :itemchange => :BUGGEM,
                :bossStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1             
                },
                :playerSideStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1                
                }
            }
        }
    },
    :TAPUKOKOMAGRODAR=> {
        :name => "Thunder Warrior",
        :entryText => "The Thunder Warrior is ready to rumble!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :TAPUKOKO,
            :level => 60,
            :shiny => true,
            :item => :SITRUSBERRY,
            :moves => [:LIGHTSCREEN,:NATURESMADNESS,:BRAVEBIRD,:REFLECT],
            :nature => :TIMID,
            :ability => :ELECTRICSURGE,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
            :weatherChange => nil,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount <= 1",
            :refreshingRequirement => [0],
            :entryMessage => ["Charizard charged into the fight!","The Thunder Warrior revitalized Charizard's energy!"],
            :totalMonCount => 2,
            :moninfos => {
                1 => {
                    :species => :CHARIZARD,
                    :level => 52,
                    :item => :CHARTIBERRY,
                    :moves => [:HEATWAVE,:AIRSLASH,:FOCUSBLAST,:ROOST],
                    :ability => :BLAZE,
                    :shiny => true,
                    :nature => :TIMID,
                    :iv => 31,
                    :ev => [252, 252, 252, 252, 252, 252],
                },
                2 => {
                    :species => :CHARIZARD,
                    :level => 59,
                    :item => :CHARIZARDITEX,
                    :moves => [:EARTHQUAKE,:DRAGONRUSH,:HEATWAVE,:THUNDERPUNCH],
                    :ability => :BLAZE,
                    :shiny => true,
                    :nature => :BRAVE,
                    :iv => 15,
                    :ev => [252, 252, 252, 252, 252, 252],
                },
            },
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :ability => :TELEPATHY,
                :itemchange => :ELEMENTALSEED,
                :message => "Tapu Koko is putting in its all!!",
                :movesetUpdate => [:THUNDERBOLT,:GRASSKNOT,:ROOST,:DAZZLINGGLEAM],
            },
        }
    },
    :BOSS_CHAOTICFUSION => {
        :name => "Chaotic Fusion",
        :entryText => "The fused Pokémon suddenly attacked!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :SOLROCK,
            :level => 52,
            :moves => [:WILLOWISP,:MATRIXSHOT,:SOLARFLARE,:MORNINGSUN],
            :nature => :QUIRKY,
            :iv => 31,
            :form => 1,
            :ability => :SOLARIDOL,
            :item => :SITRUSBERRY,
            :ev => [252,252,252,252,252,252]
        },
        :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
            :weatherChange => :SUNNYDAY,
            :weatherChangeAnimation => "Sunny",
            :weatherCount => 5,
        },
        :onBreakEffects => {
            3 => {
                :animation => :FLASH,
                :weatherChange => :HAIL,
                :weatherChangeAnimation => "Hail",
                :weatherCount => 5,
                :threshold => 0,
                :message => "Lunatone gained control!",
                :itemchange => :SITRUSBERRY,
                :speciesUpdate => :LUNATONE,
                :abilitychange => :LUNARIDOL,
                :form => 1,
                :movesetUpdate => [:PSYCHIC,:ANCIENTPOWER,:HOARFROSTMOON,:MOONLIGHT],
            },
            2 => {
                :animation => :FLASH,
                :weatherChange => :SUNNYDAY,
                :weatherChangeAnimation => "Sunny",
                :weatherCount => 5,
                :threshold => 0,
                :message => "Solrock is leading the charge!",
                :itemchange => :FLAMEPLATE,
                :speciesUpdate => :SOLROCK,
                :abilitychange => :SOLARIDOL,
                :form => 1,
                :statDropCure => true,
                :statusCure => true,
                :movesetUpdate => [:ZENHEADBUTT,:STONEEDGE,:SOLARFLARE,:MORNINGSUN],
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                }
            },
            1 => {
                :animation => :FLASH,
                :weatherChange => :HAIL,
                :weatherChangeAnimation => "Hail",
                :weatherCount => 5,
                :threshold => 0,
                :message => "Lunatone is desperate!",
                :itemchange => :ICICLEPLATE,
                :speciesUpdate => :LUNATONE,
                :abilitychange => :LUNARIDOL,
                :form => 1,
                :movesetUpdate => [:PSYCHIC,:MOONBLAST,:HOARFROSTMOON,:MOONLIGHT],
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                }
            },
        }
    },
    :AMETHYSTREGIROCK => {
        :name => "Stone Guardian",
        :entryText => "The Guardian is watching your every move.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :REGIROCK,
            :level => 50,
            :moves => [:CURSE,:BODYPRESS,:ROCKSLIDE,:EARTHQUAKE],
            :nature => :IMPISH,
            :iv => 31,
            :shiny => true,
            :item => :SITRUSBERRY,
            :ev => [100,52,252,0,100,0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Regirock hardened up!",
                :statDropCure => true,
                :playersideChanges => :StealthRock,
                :playersideChangeCount => true,
                :playersideChangeAnimation => :STEALTHROCK,
                :playersideChangeMessage => "Floating rocks were deployed!",
                :itemchange => :SITRUSBERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 2,
                    PBStats::SPDEF => 2,                 
                },
            }
        }
    },
    :AMETHYSTREGISTEEL => {
        :name => "Iron Guardian",
        :entryText => "The Guardian is watching your every move.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :REGISTEEL,
            :level => 50,
            :moves => [:CURSE,:BODYPRESS,:IRONHEAD,:EARTHQUAKE],
            :nature => :IMPISH,
            :iv => 31,
            :shiny => true,
            :item => :SITRUSBERRY,
            :ev => [100,52,252,0,100,0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Registeel hardened up!",
                :statDropCure => true,
                :playersideChanges => :Spikes,
                :playersideChangeAnimation => :SPIKES,
                :playersideChangeCount => 1,
                :playersideChangeMessage => "Spikes were deployed!",
                :itemchange => :SITRUSBERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 2,
                    PBStats::SPDEF => 2,                 
                },
            }
        }
    },
    :BOSSKYOGRE => {
        :name => "Leviathan Kyogre",
        :entryText => "Kyogre's power is overwhelming!",
        :shieldCount => 5,
        :immunities => {},
        :moninfo => {
            :species => :KYOGRE,
            :level => 60,
            :moves => [:SURF,:ICEBEAM,:ANCIENTPOWER,:THUNDERBOLT],
            :nature => :MODEST,
            :iv => 31,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "Kyogre summoned a storm and flooded the arena!",
                :weatherChange => :RAINDANCE,
                :weatherChangeAnimation => "Rain",
                :fieldChange => :WATERSURFACE,
                :moves => [:SURF,:ICEBEAM,:ANCIENTPOWER,:THUNDERBOLT],
                :delayedaction => {
                    :delay => 1,
                    :message => "Whirlpools are forming...",
                    :playerSideStatChanges => {
                        PBStats::SPEED => -1,
                    },
                    :delayedaction => {
                        :delay => 1,
                        :message => "Whirlpools have fully formed!",
                        :playerEffects => :Whirlpool,
                        :playerEffectsAnimation => :WHIRLPOOL,
                        :playerEffectsduration => 8,
                    },
                },
            },
            2 => {
                :threshold => 0,
                :message => "Kyogre dragged the battle underwater!",
                :fieldChange => :UNDERWATER,
                :animation => :DIVE,
                :moves => [:SURF,:ICEBEAM,:ANCIENTPOWER,:THUNDERBOLT],
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                }
            },
            1 => {
                :threshold => 0,
                :message => "Kyogre let out a terrifying roar!",
                :animation => :NOBLEROAR,
                :playerSideStatChanges => {
                    PBStats::ATTACK => -2,
                    PBStats::SPATK => -2,
                },
            }
        }
    },
    :BOSSGROUDON => {
        :name => "Behemoth Groudon",
        :entryText => "Groudon attacked under command!",
        :shieldCount => 5,
        :immunities => {
            :fieldEffectDamage => [:VOLCANIC]
        },
        :moninfo => {
            :species => :GROUDON,
            :level => 65,
            :moves => [:EARTHQUAKE,:POISONJAB,:HEAVYSLAM,:HEATCRASH],
            :nature => :ADAMANT,
            :iv => 31,
            :item => :SITRUSBERRY,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Groudon summoned fierce eruptions!",
                :weatherChange => :SUNNYDAY,
                :weatherChangeAnimation => "Sunny",
                :fieldChange => :VOLCANIC,
                :movesetUpdate => [:EARTHQUAKE,:STONEEDGE,:SWORDSDANCE,:HEATWAVE],
                :statDropCure => true,
            }
        }
    },
    :VALORGIRATINA => {
        :name => "Renegade Giratina",
        :entryText => "Giratina is blocking the way forward!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GIRATINA,
            :level => 55,
            :moves => [:SHADOWFORCE,:AURASPHERE,:EARTHPOWER,:DRAGONCLAW],
            :nature => :NAUGHTY,
            :form => 1,
            :iv => 31,
            :ev => [85,85,85,85,85,85]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Giratina drew power from the Distortion World!",
                :statDropCure => true,
                :formchange => 1,
                :itemchange => :GRISEOUSORB,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1                 
                },
            }
        }
    },
    :DARCHGIRATINA => {
        :name => "Clown Caricature",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :GIRATINA,
            :level => 68,
            :moves => [:SLUDGEWAVE,:DRAGONPULSE,:DARKPULSE,:FIREBLAST],
            :nature => :NAUGHTY,
            :iv => 31,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :speciesUpdate => :PORYGONZ,
                :message => "a Vir us in  d e  ed ",
                :abilitychange => :WONDERGUARD,
                :itemchange => :TOXICORB,
            },
            2 => {
                :threshold => 0,
                :speciesUpdate => :BLACEPHALON,
                :movesetUpdate => [:MINDBLOWN,:SHADOWBALL,:NASTYPLOT,:PRESENT],
                :message => "F u n t i m e s w i t h e v e r y o n e ' s b a d e n d i n g",
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED =>1                        
                },
            },
            1 => {
                :threshold => 0,
                :speciesUpdate => :PIDGEY,
                :message => "Can you even beat a Pidgey? Likely not.",
            }
        }
    },
    :LAVALAKAZAM => {
        :name => "Alakazam",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :ALAKAZAM,
            :level => 65,
            :gender => "M",
            :moves => [:CALMMIND,:REFLECT,:LIGHTSCREEN,:NIGHTSHADE],
            :nature => :TIMID,
            :iv => 31,
            :ev => [85,85,85,85,85,85]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :formchange => 1,
                :message => "Alakazam is pulling all of its psychic energy to its core!",
                :statDropCure => true,
                :movesetUpdate => [:PSYCHIC,:SHADOWBALL,:FOCUSBLAST,:COUNTER],
                :itemchange => :TWISTEDSPOON,
                :bossStatChanges => {
                    PBStats::SPDEF => 2,
                    PBStats::SPEED => 2                 
                },
            },
            1 => {
                :threshold => 0,
                :bosssideChanges => :Reflect, # effect that applies on the boss when breaking shield
                :bosssideChangeCount => 5, # duration of the effect(some effects are booleans, double check)
                :statDropCure => true,
            },
        }
    },
    :DARKGARDEVOIR => {
        :name => "Dark Gardevoir",
        :entryText => "Gardevoir is staring you down.",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :GARDEVOIR,
            :level => 63,
            :item => :LUMBERRY,
            :moves => [:DARKPULSE,:MOONBLAST,:CALMMIND,:PSYSHOCK],
            :nature => :TIMID,
            :form => 2,
            :iv => 31,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :bosssideChanges => [:Reflect,:Safeguard],
                :bosssideChangeCount => [5,5],
                :bosssideChangeAnimation => [:REFLECT,:SAFEGUARD],
                :message => "Gardevoir quickly set up protection!",
                :statDropCure => true,
            }
        }
    },
    :RIFTGARBODOR => {
        :name => "Rift Garbodor",
        :entryText => "The rampaging Rift Garbodor attacked!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :GARBODOR,
            :level => 60,
            :item => :BLACKSLUDGE,
            :moves => [:DRAINPUNCH,:GIGADRAIN,:DARKESTLARIAT,:SLUDGEWAVE],
            :nature => :SASSY,
            :form => 2,
            :shiny => true,
            :iv => 31,
            :ev => [252,0,128,0,128,0]
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "Garbodor gorged itself on rotten berries!",
                :typeChange => [:POISON,:GRASS],
                :movesetUpdate => [:DRAINPUNCH,:GIGADRAIN,:DARKESTLARIAT,:BELCH],
                :itemchange => :SITRUSBERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,                
                },
                :statDropCure => true,
            },
            2 => {
                :threshold => 0,
                :message => "Garbodor gorged itself on scrap metal!",
                :typeChange => [:POISON,:STEEL],
                :movesetUpdate => [:DRAINPUNCH,:GIGADRAIN,:GYROBALL,:BELCH],
                :itemchange => :METALCOAT,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,                
                },
                :statDropCure => true,
            },
            1 => {
                :threshold => 0,
                :message => "Garbodor desperately gorged itself on nearby rocks!",
                :typeChange => [:POISON,:ROCK],
                :movesetUpdate => [:ROCKBLAST,:GIGADRAIN,:GYROBALL,:BELCH],
                :itemchange => :ROCKYHELMET,
                :bossStatChanges => {
                    PBStats::ATTACK => 2,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => 2,   
                    PBStats::SPDEF => -1,                
                },
                :statDropCure => true,
            },
        }
    },
    :RIFTAELITA => {
        :name => "Rift Aelita",
        :entryText => "Rift Aelita is taking aim...",
        :shieldCount => 6,
        :immunities => {},
        :moninfo => {
            :species => :REGIROCK,
            :level => 83,
            :item => :LIFEORB,
            :moves => [:ROCKBLAST,:CLOSECOMBAT,:BULLETSEED,:BARRAGE],
            :nature => :NAUGHTY,
            :form => 2,
            :iv => 31,
            :ev => [252,252,0,252,0,4]
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "Rift Aelita is cocking her gun...",
                :animation => :LASERFOCUS,
                :bossEffect => :LaserFocus,
                :bossEffectduration => 1,
                :movesetUpdate => [:ROCKBLAST,:EARTHQUAKE,:POLLENPUFF,:SHADOWBALL],
                :bossStatChanges => {
                    PBStats::ACCURACY => 1,              
                },
                :fieldChange => :ROCKY,
                :fieldChangeMessage => "The field became littered with rocks!",
                :delayedaction => {
                    :delay => 3,
                    :message => "Rift Aelita is cocking her gun...",
                    :animation => :LASERFOCUS,
                    :bossEffect => :LaserFocus,
                    :bossEffectduration => 1,
                    :repeat => true,
                },
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
            },
            2 => {
                :threshold => 0,
                :message => "Rift Aelita let out a piercing screech!",
                :movesetUpdate => [:ROCKSLIDE,:TRIPLEARROWS,:SLUDGEBOMB,:ENERGYBALL],
                :bossStatChanges => {
                    PBStats::ATTACK => 2,
                    PBStats::DEFENSE => 2,
                    PBStats::SPATK => 2,   
                    PBStats::SPDEF => 2, 
                },
            },
            1 => {
                :threshold => 0,
                :message => "Rift Aelita is cornered...",
                :movesetUpdate => [:ROCKSLIDE,:TRIPLEARROWS,:ACCELEROCK,:ZAPCANNON],
                :bosssideChanges => :AreniteWall,
                :bosssideChangeCount => 8,
                :bosssideChangeAnimation => :ARENITEWALL,
            },
        }
    },
    :VIVIANREGIROCK => {
        :name => "Stone Guardian",
        :entryText => "The Stone Guardian attacked!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :REGIROCK,
            :level => 70,
            :moves => [:DRAINPUNCH,:BODYPRESS,:ROCKSLIDE,:EARTHQUAKE],
            :nature => :IMPISH,
            :iv => 31,
            :shiny => true,
            :item => :LEFTOVERS,
            :ev => [100,52,252,0,100,0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :effect => nil,
                :bossEffectduration => nil,
                :message => "Regirock drew power from the earth...",
                :itemchange => :ROCKIUMZ,
                :sideChanges => :StealthRock,
                :sideChangeAnimation => :STEALTHROCK,
                :sideChangesSide => 0,
                :sideChangeMessage => "Floating rocks were deployed!",
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,   
                    PBStats::SPDEF => 1, 
                    PBStats::SPEED => 1,                
                },
            }
        }
    },
    :ADMIN => {
        :name => "ADMIN",
        :shieldCount => 1,
        :immunities => {},
        :canrun => true,
        :moninfo => {
            :species => :REGIROCK,
            :level => 70,
            :moves => [:DRAINPUNCH,:BODYPRESS,:ROCKSLIDE,:EARTHQUAKE],
            :nature => :IMPISH,
            :iv => 31,
            :form => 1,
            :item => :LEFTOVERS,
            :ev => [100,52,252,0,100,0]
        },
        :onEntryEffects => {
            :message => "ADMIN drew power from the earth...",
            :itemchange => :ROCKIUMZ,
            :sideChanges => :StealthRock,
            :sideChangeAnimation => :STEALTHROCK,
            :bossEffectduration => nil,
            :sideChangesSide => 0,
            :sideChangeMessage => "Floating rocks were deployed!",
            :bossStatChanges => {
                PBStats::ATTACK => 1,
                PBStats::DEFENSE => 1,
                PBStats::SPATK => 1,   
                PBStats::SPDEF => 1, 
                PBStats::SPEED => 1,                
            },
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0.1,
                :effect => nil,
                :thresholdmessage => "ADMIN reconstructed itself.",
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,   
                    PBStats::SPDEF => 1, 
                    PBStats::SPEED => 1,                
                },
            }
        }
    },
    :RIFTFERROTHORN => {
        :name => "Rift Ferrothorn",
        :entryText => "Rift Ferrothorn is readying to attack!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :FERROTHORN,
            :level => 75,
            :moves => [:POWERWHIP,:LEECHSEED,:GYROBALL,:FIRELASH],
            :nature => :BRAVE,
            :form => 1,
            :iv => 31,
            :item => :LEFTOVERS,
            :ev => [100,52,252,0,100,0]
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :bosssideChanges => [:Reflect,:LightScreen],
                :bosssideChangeAnimation => :REFLECT,
                :bosssideChangeCount => [5,5],
                :message => "Rift Ferrothorn put up defenses!",
            },
            2 => {
                :threshold => 0,
                :effect => nil,
                :bossEffectduration => nil,
                :message => "Rift Ferrothorn became unrestrained!",
                :movesetUpdate => [:FLAREBLITZ,:ENERGYBALL,:IRONHEAD,:SHIFTGEAR],
                :bgmChange => "Battle - Pseudo Contribution",
                :formchange => 2,
                :itemchange => :WHITEHERB,
                :statDropCure => true,
            },
            1 => {
                :threshold => 0,
                :effect => nil,
                :bossEffectduration => nil,
                :message => "Rift Ferrothorn is out of control!",
                :bossStatChanges => {
                    PBStats::ATTACK => 2,
                    PBStats::DEFENSE => -2,
                    PBStats::SPATK => 2,   
                    PBStats::SPDEF => -2, 
                    PBStats::SPEED => 2,                
                },
            }
        }
    },
    :RIFTHIPPOWDON => {
        :name => "Rift Hippowdon",
        :entryText => "Rift Hippowdon is filling the arena with sand!",
        :shieldCount => 4,
        :immunities => {},
        :moninfo => {
            :species => :HIPPOWDON,
            :level => 87,
            :form => 1,
            :moves => [:SPITUP,:HEATWAVE,:EARTHPOWER,:SLUDGEWAVE],
            :gender => "F",
            :nature => :RELAXED,
            :item => :LEFTOVERS,
            :iv => 31,
            :happiness => 0,
            :ev => [252,252,252,252,252,252]
        },
        :onEntryEffects => {
            :animation => :HEATWAVE,
            :message => "The whirling sands are scorching!",
            :delayedaction => {
                :delay => 4,
                :message => "The searing sands inflicted burns!",
                :playerSideStatusChanges => [:BURN,"Burn"],
                :repeat => true,
            }
        },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :message => "Rift Hippowdon shot sand everywhere!",
                :movesetUpdate => [:SPITUP,:EARTHQUAKE,:GUNKSHOT,:HEATWAVE],
                :weatherChange => :SANDSTORM,
                :weatherChangeAnimation => "Sandstorm",
                :weatherChangeMessage => "Sandstorms keep brewing...",
                :playersideChanges => :StealthRock,
                :playersideChangeAnimation => :STEALTHROCK,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,
                }
            },
            3 => {
                :threshold => 0,
                :message => "A shelter of sand is protecting Rift Hippowdon!",
                :movesetUpdate => [:SPITUP,:EARTHQUAKE,:GUNKSHOT,:BODYPRESS],
                :weatherChange => :SANDSTORM,
                :weatherChangeAnimation => "Sandstorm",
                :weatherChangeMessage => "Sandstorms keep brewing...",
                :bossEffect => :Shelter,
                :bossEffectanimation => :SHELTER,
                :bossEffectduration => true,
                :playersideChanges => :Spikes,
                :playersideChangeAnimation => :SPIKES,
                :playersideChangeCount => 1,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                }
            },
            2 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :message => "The arena is heating up more!",
                :animation => :INFERNO,
                :movesetUpdate => [:SPITUP,:EARTHPOWER,:DRAGONPULSE,:HEATWAVE],
                :weatherChange => :SANDSTORM,
                :weatherChangeAnimation => "Sandstorm",
                :weatherChangeMessage => "Sandstorms keep brewing...",
                :typeChange => [:GROUND,:FIRE],
                :itemchange => :SITRUSBERRY,
                :playersideChanges => :Spikes,
                :playersideChangeAnimation => :SPIKES,
                :playersideChangeCount => 1,
                :delayedaction => {
                    :delay => 5,
                    :message => "Rift Hippowdon is burning up!",
                    :bossStatChanges => {
                        PBStats::ATTACK => 1,
                        PBStats::SPATK => 1,
                    }
                }
            },
            1 => {
                :threshold => 0,
                :message => "Rift Hippowdon expelled tonnes of sand!",
                :movesetUpdate => [:SPITUP,:DIG,:BODYPRESS,:HEATWAVE],
                :weatherChange => :SANDSTORM,
                :weatherChangeAnimation => "Sandstorm",
                :weatherChangeMessage => "Sandstorms keep brewing...",
                :bosssideChanges => :AreniteWall,
                :bosssideChangeCount => 5,
                :bosssideChangeAnimation => :ARENITEWALL,
                :itemchange => :SITRUSBERRY,
                :delayedaction => {
                    :delay => 4,
                    :message => "The sandstorm is weakening your Pokemon!",
                    :playerSideStatChanges => {
                        PBStats::ATTACK => -1,
                        PBStats::DEFENSE => -1,
                        PBStats::SPATK => -1,
                        PBStats::SPDEF => -1,
                        PBStats::SPEED => -1,
                    }
                },
                :fieldChange => :DESERT,
            },
        }
    },
    :ANGELOFDEATH => {
        :name => "Angel of Death",
        :entryText => "The Angel of Death appears with bloodlust...",
        :shieldCount => 5,
        :immunities => {},
        :moninfo => {
            :species => :GARDEVOIR,
            :level => 82,
            :form => 3,
            :moves => [:DARKPULSE,:GILDEDHELIX,:DAZZLINGGLEAM,:MYSTICALFIRE],
            :gender => "F",
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,0,252,0,252]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 2",
            :continuous => true,
            :totalMonCount => 4,
            :moninfos => {
                1 => {
                    :species => :DEVIL,
                    :level => 75,
                    :moves => [:TORMENT,:HELPINGHAND,:CLOSECOMBAT,:PLAYROUGH],
                    :gender => "M",
                    :iv => 31,
                    :ev => [0,252,0,252,0,0]
                },
                2 => {
                    :species => :ANGEL,
                    :level => 75,
                    :moves => [:QUASH,:HELPINGHAND,:SECRETSWORD,:GILDEDHELIX],
                    :gender => "F",
                    :iv => 31,
                    :ev => [0,0,0,252,0,0]
                },
            },
        },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :animation => :SECRETSWORD,
                :message => "The Angel of Death drew its scythe.",
                :movesetUpdate => [:NIGHTSLASH,:LOVELYKISS,:SPIRITBREAK,:PSYCHOCUT],
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -1,
                }
            },
            3 => {
                :threshold => 0,
                :animation => :CHARGE,
                :itemchange => :LEFTOVERS,
                :message => "The Angel of Death is drawing power.",
                :movesetUpdate => [:NIGHTSLASH,:PROTECT,:LAVAPLUME,:SACREDSWORD],
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,
                     PBStats::SPEED => 1,
                }
            },
            2 => {
                :threshold => 0,
                :animation => :DAZZLINGGLEAM,
                :message => "The Angel of Death summoned minions.",
                :movesetUpdate => [:DARKPULSE,:PSYCHOCUT,:NIGHTSLASH,:AURASPHERE],
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                }
            },
            1 => {
                :threshold => 0,
                :animation => :DARKPULSE,
                :message => "The Angel of Death has fury.",
                :itemchange => :DARKINIUMZ,
                :movesetUpdate => [:HYPERSPACEFURY,:MOONBLAST,:EARTHQUAKE,:BOOMBURST],
            },
        }
    },
    :FALLENANGEL => {
        :name => "Fallen Angel",
        :entryText => "The Angel is on its last legs...",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :GARDEVOIR,
            :level => 75,
            :form => 4,
            :moves => [:LASHOUT,:BURNINGJEALOUSY,:HYPERSPACEHOLE,:THRASH],
            :gender => "F",
            :nature => :LONELY,
            :iv => 31,
            :happiness => 255,
            :ev => [85,85,85,85,85,85]
        },
        :onBreakEffects => {
        }
    },
    :BOSSARCEUS_CASINO => {
        :name => "Casino Bouncer",
        :entryText => "STOP! You've violated the law! Pay the court a fine or serve your sentence. Your stolen goods are now forfeit.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :ARCEUS,
            :level => 75,
            :moves => [:JUDGMENT,:PUNISHMENT,:EXTREMESPEED,:LIQUIDATION],
            :gender => "F",
            :nature => :LONELY,
            :ability => :MULTITYPE,
            :item => :FISTPLATE,
            :iv => 31,
            :happiness => 255,
            :ev => [0,252,0,4,0,252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "STOP! You've violated the law! Pay the court a fine or serve your sentence. Your stolen goods are now forfeit.",
                :animation => :COSMICPOWER,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                }
            }
        }
    },
    :NIGHTMAREREMIX => {
        :name => "Nightmare Remix",
        :entryText => "The... Puppet Master? Attacks?",
        :shieldCount => 5,
        :immunities => {},
        :moninfo => {
            :species => :DARKRAI,
            :level => 75,
            :form => 7,
            :moves => [:SPIRITBREAK,:PSYCHIC,:AURORAVEIL,:THROATCHOP],
            :gender => "M",
            :nature => :BRAVE,
            :item => :PSYCHICGEM,
            :iv => 31,
            :happiness => 0,
            :ev => [4,252,0,252,0,0]
        },
        :onEntryEffects => {
            :fieldChange => :STARLIGHT,
            :message => "Twinkle twinkle little star...",
            :delayedaction => {
                :delay => 4,
                :fieldChange => :NEWWORLD,
                :playerSideStatusChanges => [:SLEEP,"Sleep"],
                :message => "All fall to the Puppet Master's sway...",
                :playerEffects => :Nightmare,
                :playerEffectsAnimation => :NIGHTMARE,
                :playerEffectsduration => true,
                :playerEffectsMessage => "Now, sleep with this trauma that will leave you sleepless!",
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1,
                }
            }
        },
        :onBreakEffects => {
            5 => {
                :threshold => 0,
                :message => "No fairy tale...",
                :movesetUpdate => [:DARKPULSE,:FLAMETHROWER,:PSYSHOCK,:MOONLIGHT],
                :itemchange => :ROSELIBERRY,
                :bosssideChanges => :Safeguard,
                :bosssideChangeAnimation => :SAFEGUARD,
                :bosssideChangeCount => 5
            },
            4 => {
                :threshold => 0,
                :message => "Grow weary...",
                :movesetUpdate => [:MOONBLAST,:ICEBEAM,:KNOCKOFF,:PROTECT],
                :itemchange => :LEFTOVERS,
                :animation => :HYPNOSIS,
                :playerSideStatChanges => {
                    PBStats::ATTACK => -3,
                    PBStats::SPATK=> -3
                }
            },
            3 => {
                :threshold => 0,
                :message => "Nightmare...",
                :movesetUpdate => [:DAZZLINGGLEAM,:SACREDSWORD,:ZENHEADBUTT,:DARKVOID],
                :itemchange => :FAIRYGEM,
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::DEFENSE => 2,
                    PBStats::SPDEF => 2,
                }
            },
            2 => {
                :threshold => 0,
                :message => "Don't sleep... Don't wake up...",
                :movesetUpdate => [:DOOMDESIRE,:VACUUMWAVE,:DARKPULSE,:ANCIENTPOWER],
                :itemchange => :FIGHTINGGEM,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,
                }
            },
            1 => {
                :threshold => 0,
                :message => "Welcome the end...",
                :itemchange => :STEELGEM,
                :movesetUpdate => [:METEORMASH,:COMETPUNCH,:THROATCHOP,:PSYSTRIKE],
                :statDropCure => true,
            },
        }
    },
    :KKING => {
        :name => "Klinklang King",
        :entryText => "The gears are grinding!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :KLINKLANG,
            :level => 100,
            :form => 1,
            :moves => [:THUNDERCAGE,:ZINGZAP,:PROTECT,:BULLDOZE],
            :gender => "M",
            :nature => :BRAVE,
            :item => :LEFTOVERS,
            :ability => :SPEEDBOOST,
            :shiny => false,
            :iv => 31,
            :happiness => 0,
            :ev => [4,252,0,252,0,0]
        },
        :onBreakEffects => {
        }
    },
    :BIGBETTY => {
        :name => "Big Betty",
        :entryText => "Big Betty stands her ground!",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :EMBOAR,
            :level => 78,
            :moves => [:EARTHQUAKE,:HEADSMASH,:FLAREBLITZ,:WILLOWISP],
            :ability => :BLAZE,
            :gender => "F",
            :form => 1,
            :nature => :ADAMANT,
            :iv => 31,
        },
        :onBreakEffects => {
        }
    },
    :BIGBETTYTWO => {
        :name => "Big Betty",
        :entryText => "Big Betty stands her ground... again!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :EMBOAR,
            :level => 80,
            :moves => [:EARTHQUAKE,:HEADSMASH,:FLAREBLITZ,:WILLOWISP],
            :ability => :BLAZE,
            :gender => "F",
            :form => 1,
            :nature => :ADAMANT,
            :iv => 31,
        },
        :onEntryEffects => {
            :fieldChange => :FAIRYTALE,
            :fieldChangeMessage => "Goomink's resolve manifested!"
        },
        :onBreakEffects => {
        }
    },
    :BOSSZEKROM => {
        :name => "Fanciful Ideals",
        :entryText => "Zekrom is crackling with electricity!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :ZEKROM,
            :level => 90,
            :item => :LUMBERRY,
            :moves => [:FOCUSBLAST,:REFLECT,:BOLTSTRIKE,:OUTRAGE],
            :ability => :TERAVOLT,
            :gender => "M",
            :nature => :NAIVE,
            :iv => 31,
            :ev => [252, 252, 0, 0, 0, 0]
        },
        :onBreakEffects => {
        }
    },
    :BOSSRESHIRAM => {
        :name => "Imaginary Truths",
        :entryText => "Reshiram is blazing with fire!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :RESHIRAM,
            :level => 90,
            :item => :WISEGLASSES,
            :moves => [:DRAGONCLAW,:FUSIONFLARE,:EARTHPOWER,:CRUNCH],
            :ability => :TURBOBLAZE,
            :gender => "M",
            :nature => :TIMID,
            :iv => 31,
            :ev => [252, 0, 0, 252, 0, 0]
        },
        :onBreakEffects => {
        }
    },
    :BOSSNAGANADEL => {
        :name => "Naganadel",
        :entryText => "Naganadel is ready to kill!",
        :shieldCount => 1,
        :immunities => {
             :moves => [:FAKEOUT,:SUCKERPUNCH,:EXTREMESPEED,:EARTHPOWER,:ANCIENTPOWER,:PYROKINESIS,:LEECHSEED,:TOXIC,:THUNDERWAVE,:DRACOMETEOR,:CURSE,:THUNDER,:FIRESPIN,:THUNDERBOLT,:EARTHQUAKE,:SCALD,:GILDEDHELIX,:GILDEDARROW,:HYPERVOICE],
        },
        :moninfo => {
            :species => :NAGANADEL,
            :level => 95,
            :item => :FIRIUMZ,
            :moves => [:TOXICSTORM,:DRAGONBREATH,:MYSTICALFIRE,:PSYSHOCK],
            :ability => :BEASTBOOST,
            :nature => :HASTY,
            :form => 1,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :DRAGONSDEN, # field changes
                :fieldChangeMessage => "Dragonic energy is bursting out!", # message that plays when the field is changes
                :abilitychange => :PUREPOWER, # ability to change to upon shieldbreaker
                :movesetUpdate => [:XSCISSOR,:DRACOMETEOR,:VENAMSKISS,:SUCKERPUNCH],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :LIFEORB,
            },
        }
    },
        :NITEMARE => {
        :name => "MoN",
        :entryText => "The master of nightmares approaches!",
        :shieldCount => 1,
        :immunities => {
            :moves => [:HAZE,:TOXIC,:SPORE,:THUNDERWAVE,:GLARE,:STUNSPORE,:SLEEPPOWDER,:POISONPOWDER,:POISONGAS,:WILLOWISP,:SOAK,:FORESTSCURSE,:TRICKORTREAT,:POWERSWAP,:SPEEDSWAP,:GUARDSWAP,:PSYCHUP,:CURSE,:DISABLE,:LEECHSEED],
        },
        :moninfo => {
	    :species => :DARKRAI,
        :level => 97,
        :item => :LEFTOVERS,
        :moves => [:BUNRAKUBEATDOWN,:FIERYWRATH,:MOONGEISTBEAM,:THUNDERCAGE],
        :ability => :WORLDOFNIGHTMARES,
        :nature => :QUIET,
        :form => 1,
        :iv => 31,
        :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :DARKNESS3, # field changes
                :fieldChangeMessage => "The collapsing world gets plunged into darkness!", # message that plays when the field is changes
                :abilitychange => :EXECUTION, # ability to change to upon shieldbreaker
                :movesetUpdate => [:PSYSHOCK,:WICKEDBLOW,:DRAINPUNCH,:HEATWAVE],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :LIFEORB,
            },
        }
    },

    :SHERIDANNAGANADEL => {
        :name => "Naganadel",
        :shieldCount => 0,
        :immunities => {
        :moves => [:FAKEOUT,:SUCKERPUNCH,:MACHPUNCH,:EARTHPOWER,:ANCIENTPOWER,:SOAK,:TRICKORTREAT,:LEAFSTORM,:PSYCHIC,:PYROKINESIS,:GILDEDHELIX,:GILDEDARROW,:LEECHSEED,:TOXIC,:THUNDERWAVE,:SOLARBEAM,:CURSE,:THUNDER,:FIRESPIN,:THUNDERBOLT,:HIGHHORSEPOWER,:DRILLRUN,:EARTHQUAKE,:SCALD],
        },
        :moninfo => {
            :species => :NAGANADEL,
            :level => 90,
            :item => :DRAGONGEM,
            :moves => [:SPACIALREND,:TOXICSTORM,:EARTHPOWER,:METEORBEAM],
            :ability => :POWERSPOT,
            :gender => "M",
            :nature => :TIMID,
            :form => 1,
            :iv => 31,
            :happiness => 0,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
        }
    },
    :SHERIDANXURKITREE => {
        :name => "Xurkitree",
        :shieldCount => 0,
        :immunities => {
        :moves => [:FAKEOUT,:SUCKERPUNCH,:MACHPUNCH,:EARTHPOWER,:ANCIENTPOWER,:LEAFSTORM,:LEECHSEED,:TOXIC,:THUNDERWAVE,:SOAK,:TRICKORTREAT,:SOLARBEAM,:PSYCHIC,:PYROKINESIS,:GILDEDHELIX,:GILDEDARROW,:CURSE,:THUNDER,:FIRESPIN,:THUNDERBOLT,:HIGHHORSEPOWER,:DRILLRUN,:EARTHQUAKE,:SCALD],
        },
        :moninfo => {
            :species => :XURKITREE,
            :level => 95,
            :item => :LIFEORB,
            :moves => [:THUNDERPULSE,:DAZZLINGGLEAM,:FOCUSBLAST,:AURORABEAM],
            :ability => :VICTORYSTAR,
            :gender => "M",
            :nature => :TIMID,
            :form => 1,
            :iv => 31,
            :happiness => 0,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
        }
    },
    :BOSSGOTHITELLE => {
        :name => "Gothitelle",
        :entryText => "Gothitelle is looking serious!",
        :shieldCount => 1,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:DARKPULSE,:DOOMSDAY,:BUGBUZZ,:MEGAHORN,:GUILLOTINE,:FIRSTIMPRESSION,:WICKEDBLOW,:FUSIONBOLT,:STOKEDSPARKSURFER,:SUPERFANG,:PLASMAVOLT,:AXEKICK,:THUNDERRAID,:WILDBOLTSTORM,:SANDSEARSTORM,:BOLTSTRIKE,:WARCRY,:AIRCUTTER,:WAKEUPSHOCK,:VOLTTACKLE,:BOLTBEAK,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:DRILLRUN,:GIGAQUAKE,:FISSURE,:RAGINGTHUNDER,:RAGINGFLAMES,:CLOUDBURST,:ERUPTION,:WATERSPOUT,:GILDEDHELIX,:GILDEDARROW,:BONERUSH,:EXTREMESPEED,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO,:RISINGVOLTAGE,:ZAPCANNON,:THUNDER,:GLIDINGBOLTSTORM,:ALLOUTPUMMELING,:TECTONICRAGE,:GIGAVOLTHAVOC,:BREAKATTACK,:FOCUSPUNCH,:HIJUMPKICK,:CLOSECOMBAT,:CHISTRIKE,:DYNAMICPUNCH,:MACHPUNCH,:GALESTRIKE],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :GOTHITELLE,
            :level => 110,
            :item => :ASSAULTVEST,
            :moves => [:DARKPULSE,:PSYSHOCK,:ENERGYBALL,:MYSTICALFIRE],
            :ability => :FURCOAT,
            :gender => "F",
            :nature => :MODEST,
            :form => 1,
            :iv => 31,
            :ev => [252,0,252,252,252,252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :effectClear => true,
                :abilitychange => :ICESCALES, # ability to change to upon shieldbreaker
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :SOLIDVEST,
            },
        }
    },
    :STORMNINE => {
        :name => "STORM | Wind",
        :entryText => "Erratic weather begets a disaster...",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :XERNEAS,
            :level => 85,
            :item => :LIFEORB,
            :moves => [:WEATHERBALL,:HURRICANE,:THUNDER,:PSYSHOCK],
            :ability => :TEMPEST,
            :nature => :MODEST,
            :form => 1,
            :iv => 31,
            :ev => [252,0,4,252,0,0]
        },
        :onBreakEffects => {
        }
    },
    :BOSSCOFAGRIGUS => {
        :name => "Totem Cofagrigus",
        :entryText => "The menacing Cofagrigus attacked!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :COFAGRIGUS,
            :level => 85,
            :moves => [:SHADOWBALL,:TOXICSPIKES,:WILLOWISP,:ENERGYBALL],
            :ability => :MUMMY,
            :gender => "M",
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,0,252,252,0],
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 3",
            :totalMonCount => 3,
            :moninfos => {
                1 => {
                    :species => :STANTLER,
                    :level => 80,
                    :item => :STANTCREST,
                    :moves => [:HYPNOSIS,:MEGAHORN,:JUMPKICK,:ZENHEADBUTT],
                    :ability => :INTIMIDATE,
                    :gender => "F",
                    :nature => :JOLLY,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [0,252,0,0,0,252]
                },
                2 => {
                    :species => :MAGCARGO,
                    :level => 80,
                    :item => :MAGCREST,
                    :moves => [:FLAMEBURST,:YAWN,:EARTHPOWER,:WILLOWISP],
                    :ability => :FLAMEBODY,
                    :gender => "M",
                    :nature => :BOLD,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [0,0,252,252,0,0]
                },
                3 => {
                    :species => :LEAFEON,
                    :level => 80,
                    :item => :LEAFCREST,
                    :moves => [:SWORDSDANCE,:NATUREPOWER,:LEAFBLADE,:XSCISSOR],
                    :ability => :LEAFGUARD,
                    :gender => "F",
                    :nature => :ADAMANT,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [252,128,0,0,252,0]
                },
            },
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :bosssideChanges => :AreniteWall,
                :bosssideChangeAnimation => :ARENITEWALL,
                :bosssideChangeCount => 5,
                :message => "Sand swarms all around!",
                :movesetUpdate => [:SHADOWBALL,:BODYPRESS,:CALMMIND,:PSYCHIC],
                :itemchange => :SITRUSBERRY,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,             
                },
            },
            2 => {
                :threshold => 0,
                :movesetUpdate => [:SHADOWBALL,:PROTECT,:ENERGYBALL,:HIDDENPOWERFIG],
                :itemchange => :LEFTOVERS,
                :delayedaction => {
                    :delay => 3,
                    :message => "Beware the Pharaoh's curse!",
                    :playerEffects => :Curse,
                    :playerEffectsAnimation => :CURSE,
                    :playerEffectsduration => true,
                    :repeat => true,            
                },
            },
            1 => {
                :threshold => 0,
                :itemchange => :COFCREST,
                :statDropCure => true,
                :effectClear => true,
            },
        }
    },
    :COFFEEGREGUS => {
        :name => "COFFEE GREGUS",
        :entryText => "COFFEE GREGUS!",
        :shieldCount => 4,
        :immunities => {},
        :moninfo => {
            :species => :COFAGRIGUS,
            :level => 85,
            :moves => [:SHADOWPUNCH,:COMETPUNCH,:BULLETPUNCH,:BULKUP],
            :item => :FOCUSSASH,
            :gender => "M",
            :nature => :MODEST,
            :form => 1,
            :iv => 31,
            :happiness => 255,
            :ev => [0,252,0,0,0,252],
        },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :movesetUpdate => [:SHADOWPUNCH,:SCORCHINGSANDS,:AURASPHERE,:BULKUP],
                :itemchange => :SITRUSBERRY,
                :message => "COFFEE GREGUS!",
                :animation => :BULKUP,
                :bossStatChanges => {
                    PBStats::DEFENSE => 2,
                    PBStats::SPDEF => 2,             
                },
                :fieldChange => :BIGTOP,
                :fieldChangeMessage => "CLOWN FIESTA!"
            },
            3 => {
                :threshold => 0,
                :movesetUpdate => [:SHADOWPUNCH,:CROSSCHOP,:ICEPUNCH,:BULKUP],
                :itemchange => :GHOSTGEM,
                :bossEffect => :LaserFocus,
                :bossEffectanimation => :LASERFOCUS,
                :bossEffectduration => 1,
                :message => "COFFEE GREGUS!",
                :animation => :BULKUP,
            },
            2 => {
                :threshold => 0,
                :movesetUpdate => [:SHADOWPUNCH,:DYNAMICPUNCH,:BODYPRESS,:BULKUP],
                :itemchange => :SITRUSBERRY,
                :message => "COFFEE GREGUS!",
                :animation => :BULKUP,
                :statDropCure => true,
                :effectClear => true,
                :delayedaction => {
                    :delay => 1,
                    :repeat => true,
                    :playerEffects => :Foresight,
                    :playerEffectsAnimation => :FORESIGHT,
                    :message => "THERE IS NO ESCAPE FROM COFFEE GREGUS!",
                    :playerSideStatChanges => {
                        PBStats::EVASION => -1
                    }
                }
            },
        }
    },
    :KAWOPUDUNGA => {
        :name => "Kawopudunga",
        :entryText => "Kawopudunga is ready to feast!",
        :shieldCount => 4,
        :immunities => {},
        :moninfo => {
            :species => :WAILORD,
            :level => 75,
            :form => 1,
            :moves => [:DIVE,:DARKESTLARIAT,:AQUARING,:FRUSTRATION],
            :gender => "F",
            :nature => :HARDY,
            :item => :SITRUSBERRY,
            :iv => 31,
            :happiness => 0,
            :ev => [4,252,0,252,0,0]
        },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :itemchange => :SITRUSBERRY,
                :message => "Kawopudunga changed its type!",
                :movesetUpdate => [:DIVE,:HEAVYSLAM,:NOBLEROAR,:BODYPRESS],
                :typeChange => [:WATER,:STEEL],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::DEFENSE => 2,
                }
            },
            3 => {
                :threshold => 0,
                :itemchange => :SITRUSBERRY,
                :message => "Kawopudunga changed its type!",
                :movesetUpdate => [:DIVE,:ICICLECRASH,:ENCORE,:FREEZEDRY],
                :typeChange => [:WATER,:ICE],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::SPDEF => 2,
                }
            },
            2 => {
                :threshold => 0,
                :itemchange => :SITRUSBERRY,
                :message => "Kawopudunga changed its type!",
                :movesetUpdate => [:DIVE,:OUTRAGE,:DRAGONDANCE,:HEAVYSLAM],
                :typeChange => [:WATER,:DRAGON],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 2,
                }
            },
            1 => {
                :threshold => 0,
                :itemchange => :SITRUSBERRY,
                :message => "Kawopudunga changed its type!",
                :movesetUpdate => [:DIVE,:DARKPULSE,:RECOVER,:TOXIC],
                :typeChange => [:WATER,:DARK],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::SPATK => 2,
                }
            },
        }
    },
    :BOSSKECLEON => {
        :name => "Wacky Lizard",
        :entryText => "Wacky Lizard's staring into space.",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :KECLEON,
            :level => 85,
            :form => 0,
            :moves => [:PLAYROUGH,:THUNDERPUNCH,:BOUNCE,:EARTHQUAKE],
            :gender => "F",
            :ability => :SHEERFORCE,
            :nature => :BRAVE,
            :item => :SITRUSBERRY,
            :iv => 31,
            :happiness => 0,
            :ev => [0,252,4,252,0,0]
        },
        :onEntryEffects => {
            :delayedaction => {
                :delay => 1,
                :repeat => true,
                :loopingsetchanges => true,
                :itemchange => :LIFEORB,
                :setwinvariable => true,
                :message => "Wacky Lizard's type shifted!",
                :typeSequence => {
                    1 => {
                            :typeChange => [:FLYING,:FLYING],
                         },
                    2 => {
                            :typeChange => [:ELECTRIC,:FLYING],
                         },
                    3 => {
                            :typeChange => [:GROUND,:FLYING],
                         },
                    4 => {
                            :typeChange => [:FAIRY,:FLYING],
                         },
                },
            },
        },
        :onBreakEffects => {
            2 => {
            :threshold => 0,
            :itemchange => :LIFEORB,
            :movesetUpdate => [:THUNDER,:HURRICANE,:MOONBLAST,:EARTHPOWER],
            :statDropCure => true,
            :bossStatChanges => {
                PBStats::SPATK => 2,
                PBStats::ACCURACY => 1, 
                }
            },
        },
    },
    :BOSSGOURGEIST => {
        :name => "Jack-o'-lantern",
        :entryText => "A large pumpkin suddenly attacked!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :GOURGEIST,
            :level => 80,
            :form => 1,
            :moves => [:WILLOWISP,:SEEDBOMB,:LEECHSEED,:CURSE],
            :gender => "F",
            :ability => :INSOMNIA,
            :nature => :BRAVE,
            :item => :SITRUSBERRY,
            :iv => 31,
            :happiness => 0,
            :ev => [252,252,4,0,0,0]
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "The Jack-o'-lantern was lit up!",
                :movesetUpdate => [:FIREBLAST,:ENERGYBALL,:TRICKROOM,:ROCKSLIDE],
                :typeChange => [:GRASS,:FIRE],
                :abilitychange => :FLASHFIRE,
                :itemchange => :ELEMENTALSEED,
                :fieldChange => :GRASSY,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :bossStatChanges => {
                    PBStats::SPATK => 2,
                }
            },
            2 => {
                :threshold => 0,
                :itemchange => :BIGROOT,
                :movesetUpdate => [:GIGADRAIN,:LEECHSEED,:MYSTICALFIRE,:PHANTOMFORCE],
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                }
            },
            1 => {
                :threshold => 0,
                :movesetUpdate => [:GRASSYGLIDE,:ROCKSLIDE,:SYNTHESIS,:SHADOWSNEAK],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 2,
                }
            },
        }
    },
    :DUFAUX => {
        :name => "Dufaux",
        :entryText => "Dufaux is approaching!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :FROSLASS,
            :level => 98,
            :form => 2,
            :moves => [:HEX,:IRRITATION,:COLDTRUTH,:RISINGVOLTAGE],
            :gender => "F",
            :nature => :MODEST,
            :item => :ICIUMZ,
            :iv => 31,
            :happiness => 0,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Dufaux broke out of its shell!",
                :formchange => 3,
                :effectClear => true,
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :LIFEORB,
                }
            },
        },
    :MECHAGYARADOS => {
        :name => "GYARA-01",
        :entryText => "WARNING! WARNING! WARNING!",
        :shieldCount => 6,
        :immunities => {},
        :moninfo => {
            :species => :GYARADOS,
            :level => 90,
            :form => 3,
            :moves => [:THUNDERBOLT,:HYPERBEAM,:FLAMETHROWER,:SCALD],
            :gender => "F",
            :nature => :HARDY,
            :iv => 31,
            :happiness => 0,
            :ev => [4,252,0,252,0,0]
        },
        :onBreakEffects => {
            5 => {
                :threshold => 0,
                :message => "DESTRUCTION MODE ENGAGED!",
                :movesetUpdate => [:STEELBEAM,:MINDBLOWN,nil,nil],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                }
            },
            3 => {
                :threshold => 0,
                :message => "COOLING DOWN...",
                :movesetUpdate => [:HYPERVOICE,:ICEBEAM,:IRONHEAD,:DOUBLEEDGE],
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPEED => -1,
                }
            },
            1 => {
                :threshold => 0,
                :message => "SELF-DESTRUCT SEQUENCE ACTIVATED!",
                :movesetUpdate => [:EXPLOSION,nil,nil,nil],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 6,
                }
            }
        }
    },
    :MASTEROFNIGHTMARES => {
        :name => "Master of Nightmares",
        :entryText => "The battle against nightmares has begun.",
        :shieldCount => 5,
        :immunities => {},
        :moninfo => {
            :species => :DARKRAI,
            :level => 91,
            :form => 2,
            :moves => [:THUNDERCAGE,:CROSSCHOP,:BUNRAKUBEATDOWN,:NIGHTMARE],
            :gender => "M",
            :nature => :BRAVE,
            :item => :LEFTOVERS,
            :iv => 31,
            :happiness => 0,
            :ev => [252,252,0,252,0,0]
        },
        :onEntryEffects => {
            :animation => :IONDELUGE,
            :fieldChange => :ELECTERRAIN,
            :fieldChangeMessage => "Aelita's nightmares manifest into reality...",
            :delayedaction => {
                :delay => 1,
                :playerSideStatusChanges => [:PARALYSIS,"Paralysis"],
                :delayedaction => {
                    :delay => 3,
                    :repeat => true,
                    :playerEffects => :GastroAcid,
                    :playerEffectsAnimation => :EMBARGO,
                    :playerEffectsMessage => "Abilities have been suppressed!"
                }
            }
        },
        :onBreakEffects => {
            5 => {
                :threshold => 0,
                :message => "Memories of being burned alive pass by...",
                :movesetUpdate => [:ERUPTION,:EARTHQUAKE,:BUNRAKUBEATDOWN,:NIGHTMARE],
                :formchange => 3,
                :statDropCure => true,
                :animation => :ERUPTION,
                :playerSideStatusChanges => [:BURN,"Burn"],
                :playerEffects => :TarShot,
                :playerEffectsAnimation => :TARSHOT,
                :playerEffectsMessage => "You feel highly flammable...",
                :fieldChange => :VOLCANICTOP,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,
                }
            },
            4 => {
                :threshold => 0,
                :message => "The feeling of an explosion creeps up your spine...",
                :movesetUpdate => [:MOONBLAST,:SACREDSWORD,:BUNRAKUBEATDOWN,:NIGHTMARE],
                :formchange => 4,
                :statDropCure => true,
                :animation => :EXPLOSION,
                :fieldChange => :DIMENSIONAL,
                :bossStatChanges => {
                    PBStats::SPDEF => 1,
                },
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -2,
                    PBStats::SPDEF => -2
                }
            },
            3 => {
                :threshold => 0,
                :message => "You feel death incarnate staring you down...",
                :movesetUpdate => [:OBLIVIONWING,:DARKPULSE,:BUNRAKUBEATDOWN,:NIGHTMARE],
                :formchange => 5,
                :statDropCure => true,
                :fieldChange => :CHESS,
                :animation => :DECIMATION,
                :playerEffects => :PerishSong,
                :playerEffectsduration => 3,
                :playerEffectsAnimation => :PERISHSONG,
                :playerEffectsMessage => "Death is imminent...",
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                }
            },
            2 => {
                :threshold => 0,
                :message => "The true nightmare begins.",
                :movesetUpdate => [:BUNRAKUBEATDOWN,:FIERYWRATH,:MOONGEISTBEAM,:THUNDERCAGE],
                :formchange => 1,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :fieldChange => :NEWWORLD,
                :animation => :NIGHTDAZE,
                :delayedaction => {
                    :delay => 1,
                    :playerEffects => :Yawn,
                    :playerEffectsAnimation => :YAWN,
                    :playerEffectsduration => 1,
                    :playerEffectsMessage => "A strong feeling of drowsiness...",
                    :delayedaction => {
                        :delay => 4,
                        :repeat => true,
                        :playerEffects => :Yawn,
                        :playerEffectsAnimation => :YAWN,
                        :playerEffectsduration => 1,
                        :playerEffectsMessage => "A strong feeling of drowsiness...",
                    },
                },
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1,
                },
                :itemchange => :GHOSTIUMZ
            },
        }
    },
    :MASTEROFNIGHTMARES2 => {
        :name => "Master of Nightmares",
        :entryText => "The nightmare will end soon.",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :DARKRAI,
            :level => 90,
            :moves => [:BUNRAKUBEATDOWN,:NIGHTMARE,:TAUNT,:SHADOWCLAW],
            :gender => "F",
            :nature => :MODEST,
            :form => 6,
            :iv => 31,
        },
        :onBreakEffects => {
        }
    },
    :BOSSKLINKLANG => {
        :name => "Klinklang Queen",
        :entryText => "KLINKLANG: Ohohoho!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :KLINKLANG,
            :level => 85,
            :form => 1,
            :moves => [:SHIFTGEAR,:GEARGRIND,:FACADE,:WILDCHARGE],
            :nature => :ADAMANT,
            :item => :LEFTOVERS,
            :iv => 31,
            :happiness => 0,
            :ev => [252,252,0,0,0,4]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "The Klinklang Queen revs up!",
                :statusCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1
                }
            },
            1 => {
                :threshold => 0,
                :message => "Gears appear all around!",
                :movesetUpdate => [:SUBSTITUTE,:GEARGRIND,:FACADE,:WILDCHARGE],
                :fieldChange => :FACTORY,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPEED => 2
                }
            },
        }
    },
    #extreme ice demon
     :ANGIESPET => {
        :name => "Frozen Belial", # nickname
        :entryText => "Volcarona attacked you!",
        :shieldCount => 4, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:FLAMETHROWER,:ROCKSLIDE,:DIAMONDSTORM,:STONEEDGE,:LAVAPLUME,:HIDDENPOWERFIR,:HIDDENPOWER,:BLUEFLARE,:ANCIENTPOWER,:SOAK,:FORESTSCURSE,:LEECHSEED,:STUNSPORE,:TOXIC,:POISONPOWDER,:SLEEPPOWDER,:SPORE,:GRASSWHISTLE,:HYPNOSIS,:GLARE,:TRICKORTREAT,:FLAREBLITZ,:FIREPUNCH,:BLAZINGFANGS,:OVERHEAT,:FIREBLAST,:BLASTBURN,:MYSTICALFIRE,:BURSTRUSH,:ACCELEROCK,:HURRICANE,:ROCKBLAST,:HEATWAVE,:GILDEDHELIX,:GILDEDARROW,:BOOMBURST,:HYPERVOICE],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :VOLCARONA,
            :level => 59,
            :form => 2,
            :item => :LIFEORB,
            :moves => [:ICEBEAM,:SIGNALBEAM,:FREEZINGGLARE,:GIGADRAIN],
            :ability => :TINTEDLENS,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252,0,128,252,0,0]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 10",
        :continuous => true,
        :totalMonCount => 4,
        :moninfos => {
            1 => {
                :species => :MAGNETON,
                :level => 58,
                :item => :EVIOLITE,
                :moves => [:REFLECT,:LIGHTSCREEN,:THUNDERBOLT,:PARTINGSHOT],
                :ability => :POWERSPOT,
                :nature => :BOLD,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
            },
            2 => {
                :species => :SABLEYE,
                :level => 57,
                :item => :SABLENITE,
                :moves => [:KNOCKOFF,:WILLOWISP,:TORMENT,:TAILWIND],
                :ability => :PRANKSTER,
                :nature => :IMPISH,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                
                },
            3 => {
                :species => :LATIAS,
                :level => 55,
                :item => :LEPPABERRY,
                :moves => [:HELPINGHAND,:FOLLOWME,:AROMATICMIST,:REFLECT],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                4 => {
                :species => :LATIAS,
                :level => 57,
                :item => :LEPPABERRY,
                :moves => [:HELPINGHAND,:FOLLOWME,:AROMATICMIST,:REFLECT],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                },
              },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :SNOWYMOUNTAIN, # field changes
                :fieldChangeMessage => "The cold intensifies!", # message that plays when the field is changes
                :abilitychange => :SNOWCLOAK, # ability to change to upon shieldbreaker
                :movesetUpdate => [:ICEBEAM,:BUGBUZZ,:HURRICANE,:GIGADRAIN],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ICIUMZ,
                :weatherChange => :HAIL, # weather to apply
                :weatherCount => 90, # weather turncount
                :weatherChangeMessage => "The hail intensifies!", # weather message
                :weatherChangeAnimation => "Hail", # string of "Rain", "Sunny","Hail","Sandstorm"
                :bossStatChanges => { # any statboosts that are given
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                },
            },
            3 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :FROZENDIMENSION, # field changes
                :fieldChangeMessage => "The cold intensifies further!", # message that plays when the field is changes
                :abilitychange => :FROSTREALM, # ability to change to upon shieldbreaker
                :movesetUpdate => [:BLIZZARD,:BUGBUZZ,:FREEZINGGLARE,:GIGADRAIN],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ICEGEM,
            },
           2 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :ICY, # field changes
                :fieldChangeMessage => "The cold intensifies further!", # message that plays when the field is changes
                :abilitychange => :SUCCESSOR, # ability to change to upon shieldbreaker
                :movesetUpdate => [:GLACIALGUNGNIR,:BUGBUZZ,:FREEZINGGLARE,:GIGADRAIN],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ELEMENTALSEED,
            },
            1  => {
                :threshold => 0,
                :effectClear => true,
                :abilitychange => :TINTEDLENS, # ability to change to upon shieldbreaker
                :movesetUpdate => [:COLDTRUTH,:BUGBUZZ,:FREEZINGGLARE,:GIGADRAIN],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :LIFEORB,
            },
        }
    },
    #extreme emperor
     :EMPEROR => {
        :name => "The Emperor", # nickname
        :entryText => "The Emperor attacked you!",
        :shieldCount => 4, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:INFERNO,:EXTREMESPEED,:THUNDERRAID,:WAKEUPSHOCK,:PLASMAVOLT,:CHARGEDWHIP,:THUNDER,:VOLTTACKLE,:ZAPCANNON,:FUSIONBOLT,:THUNDERBOLT,:WILDCHARGE,:SPARK,:ELECTROWEB,:CHARGEBEAM,:ELECTROBALL,:AIRCUTTER,:FURYSWIPES,:WRAP,:PARABOLICCHARGE,:NUZZLE,:ZINGZAP,:PLASMAFISTS,:BOLTBEAK,:AURAWHEEL,:OVERDRIVE,:THUNDERCAGE,:HIJUMPKICK,:CLOSECOMBAT,:FOCUSBLAST,:SUPERPOWER,:CROSSCHOP,:DYNAMICPUNCH,:JUMPKICK,:HAMMERARM,:AURASPHERE,:SACREDSWORD,:SECRETSWORD,:SKYUPPERCUT,:SUBMISSION,:VITALTHROW,:CIRCLETHROW,:LOWSWEEP,:ROLLINGKICK,:WAKEUPSLAP,:KARATECHOP,:MACHPUNCH,:VACUUMWAVE,:STORMTHROW,:ARMTHRUST,:TRIPLEKICK,:LOWKICK,:REVERSAL,:POWERUPPUNCH,:BODYPRESS,:METEORASSAULT,:THUNDEROUSKICK,:TRIPLEARROWS,:AXEKICK,:GALESTRIKE,:STACKINGSHOT],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :EMPOLEON,
            :level => 58,
            :item => :ELEMENTALSEED,
            :moves => [:FREEZEDRY,:WATERPULSE,:GRASSKNOT,:HIDDENPOWERELE],
            :ability => :MOLDBREAKER,
            :nature => :RASH,
            :form => 1,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :ICY, # field changes
                :fieldChangeMessage => "The cold intensifies!", # message that plays when the field is changes
                :abilitychange => :SNOWCLOAK, # ability to change to upon shieldbreaker
                :movesetUpdate => [:ICEBEAM,:OCEANDASH,:AIRSLASH,:FLASHCANNON],
                :typeChange => [:WATER,:ICE],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :EMPCREST,
                :weatherChange => :HAIL, # weather to apply
                :weatherCount => 90, # weather turncount
                :weatherChangeMessage => "The hail intensifies!", # weather message
                :weatherChangeAnimation => "Hail", # string of "Rain", "Sunny","Hail","Sandstorm"
                :bossStatChanges => { # any statboosts that are given
                    PBStats::ATTACK => 1,
                },
            },
            3 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :ASHENBEACH, # field changes
                :fieldChangeMessage => "Focus and relax to the sound of waves!", # message that plays when the field is changes
                :movesetUpdate => [:HIDDENPOWERWAT,:BULLETPUNCH,:GALESTRIKE,:ICYWIND],
                :statDropCure => true,
                :statusCure => true,
            },
           2 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :WATERSURFACE, # field changes
                :fieldChangeMessage => "The water took over again!", # message that plays when the field is changes
                :movesetUpdate => [:AQUAJET,:IRONHEAD,:FREEZINGGLARE,:ICEPUNCH],
                :statDropCure => true,
                :statusCure => true,
            },
            1  => {
                :threshold => 0,
                :effectClear => true,
                :statDropCure => true,
                :statusCure => true,
            },
        }
    },
    #extreme honec hell
     :HONECVESPI => {
        :name => "Honec Queen", # nickname
        :entryText => "The Queen approaches you!",
        :shieldCount => 3, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:INFERNO,:EXTREMESPEED,:THUNDERRAID,:WAKEUPSHOCK,:PLASMAVOLT,:CHARGEDWHIP,:THUNDER,:VOLTTACKLE,:ZAPCANNON,:FUSIONBOLT,:THUNDERBOLT,:WILDCHARGE,:SPARK,:ELECTROWEB,:CHARGEBEAM,:ELECTROBALL,:AIRCUTTER,:FURYSWIPES,:WRAP,:PARABOLICCHARGE,:NUZZLE,:ZINGZAP,:PLASMAFISTS,:BOLTBEAK,:AURAWHEEL,:OVERDRIVE,:THUNDERCAGE,:ROCKCLIMB,:HEADSMASH,:ROCKWRECKER,:STONEEDGE,:ROCKSLIDE,:POWERGEM,:ANCIENTPOWER,:ROCKTOMB,:SMACKDOWN,:SACREDSWORD,:ROLLOUT,:ROCKBLAST,:DIAMONDSTORM,:ACCELEROCK,:METEORBEAM,:STONEAXE,:MATRIXSHOT,:ANCIENTFANGS,:METEORSHOWER,:HIDDENPOWER,:ROCKTHROW,:GEMBURST,:TAILSMASH],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :VESPIQUEN,
            :level => 70,
            :item => :BLKPRISM,
            :moves => [:INFESTATION,:MUDDYWATER,:HORNLEECH,:SLUDGEWAVE],
            :ability => :BATTLEARMOR,
            :nature => :NAUGHTY,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 10",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :COMBEE,
                :level => 65,
                :item => :EVIOLITE,
                :moves => [:REFLECT,:LIGHTSCREEN,:GLARE,:RAGEPOWDER],
                :ability => :POWERSPOT,
                :nature => :BOLD,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
            },
            2 => {
                :species => :COMBEE,
                :level => 65,
                :item => :EVIOLITE,
                :moves => [:POISONGAS,:RAGEPOWDER,:REFLECT,:POLLENPUFF],
                :ability => :POWERSPOT,
                :nature => :BOLD,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                },
              },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :FOREST, # field changes
                :movesetUpdate => [:ATTACKORDER,:DEFENDORDER,:HORNLEECH,:HIGHHORSEPOWER],
                :fieldChangeMessage => "The field got manipulated!", # message that plays when the field is changes
                :statDropCure => true,
                :itemchange => :VESPICREST,
                :statusCure => true,
            },
           2 => {
                :threshold => 0,
                :effectClear => true,
                :statDropCure => true,
                :statusCure => true,
            },
            1  => {
                :threshold => 0,
                :effectClear => true,
                :statDropCure => true,
                :statusCure => true,
            },
        }
    },
    #Extreme Mecha Ray 
        :MECHARAY => {
        :name => "RMX-9000", # nickname
        :entryText => "The mechanism is aiming towards you!",
        :shieldCount => 4, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:FAKEOUT,:SUCKERPUNCH,:MACHPUNCH,:EXTREMESPEED,:GILDEDHELIX,:GILDEDARROW,:PERISHSONG,:DESTINYBOND,:FINALFLAME,:BUNRAKUBEATDOWN,:MIRRORBEAM,:HEADLONGRUSH,:GIGAQUAKE,:EARTHQUAKE,:FISSURE,:FOCUSBLAST,:AURASPHERE,:QUICKATTACK,:SOAK,:FORESTSCURSE,:SCALD,:TRICKORTREAT,:LEECHSEED,:CURSE,:WILLOWISP,:THUNDERWAVE,:GLARE,:CLOSECOMBAT,:HIJUMPKICK,:DYNAMICPUNCH,:CHISTRIKE,:BREAKATTACK,:BEATUP,:GIGAIMPACT,:HYPERBEAM],
             :fieldEffectDamage => [:INFERNAL]
        },
        :moninfo => { # pokemon details
            :species => :RAYQUAZA,
            :level => 85,
            :item => :LIFEORB,
            :moves => [:STEELBEAM,:MOONGEISTBEAM,:FLASHCANNON,:DECIMATION],
            :ability => :STEELWORKER,
            :nature => :QUIET,
            :form => 2,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 10",
        :continuous => true,
        :totalMonCount => 4,
        :moninfos => {
            1 => {
                :species => :CLAYDOL,
                :level => 80,
                :item => :LIGHTCLAY,
                :moves => [:STEELBEAM,:REFLECT,:LIGHTSCREEN,:MEMENTO],
                :ability => :PRANKSTER,
                :nature => :BOLD,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [0,0,0,252,0,0]
                },
            2 => {
                :species => :SIGILYPH,
                :level => 80,
                :item => :THROATSPRAY,
                :moves => [:HYPERVOICE,:UPROAR,:HEATWAVE,:CLANGINGSCALES],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 2,
                :iv => 31,
                :happiness => 255,
                :ev => [252,0,0,252,0,252]                
                },
            3 => {
                :species => :LAIRON,
                :level => 80,
                :item => :METALCOAT,
                :moves => [:BODYPRESS,:EXTREMESPEED,:HYPERBEAM],
                :ability => :STEELSHROUD,
                :nature => :NAUGHTY,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [0,252,252,252,0,252]
                },
            4 => {
                :species => :METANG,
                :level => 80,
                :item => :PUNCHINGGLOVE,
                :moves => [:DOUBLEIRONBASH,:POWERUPPUNCH,:ICEPUNCH,:CHISTRIKE],
                :ability => :POWERSPOT,
                :nature => :JOLLY,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                },
              },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :SHORTCIRCUIT, # field changes
                :fieldChangeMessage => "BZZZAP!", # message that plays when the field is changes
                :abilitychange => :DOWNLOAD, # ability to change to upon shieldbreaker
                :movesetUpdate => [:STEELBEAM,:THUNDERPULSE,:DRAGONBREATH,:LANDSHAKING],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :STEELIUMZ,
            },
            3 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :INFERNAL, # field changes
                :fieldChangeMessage => "The battle got dragged into a burning dimension!", # message that plays when the field is changes
                :abilitychange => :MOLDBREAKER, # ability to change to upon shieldbreaker
                :movesetUpdate => [:STEELBEAM,:BUBBLEBOIL,:STEAMERUPTION,:HEX],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ROCKYHELMET,
            },
           2 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :MIRROR, # field changes
                :fieldChangeMessage => "Mirrors cover the battlefield!", # message that plays when the field is changes
                :abilitychange => :SIPHONSOUL, # ability to change to upon shieldbreaker
                :movesetUpdate => [:DREAMEATER,:OBLIVIONWING,:GIGADRAIN,:PARABOLICCHARGE],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :BIGROOT,
            },
            1  => {
                :threshold => 0,
                :statusCure => true,
                :effectClear => true,
                :message => "The mechanism loses strength! Now is your chance to fend it off!",
                :movesetUpdate => [:STEELBEAM],
                :itemchange => :WIKIBERRY,
                :abilitychange => :MAGICGUARD, # ability to change to upon shieldbreaker
                :bossStatChanges => { # any statboosts that are given
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,
                    PBStats::ATTACK => -1,
                    PBStats::SPATK => -1,
                },
            },
        }
    },
    :GERBIL1 => {
        :name => "Entei", # nickname
        :entryText => "Entei appeared before you!",
        :shieldCount => 4, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:SUCKERPUNCH,:MACHPUNCH,:EARTHPOWER,:ANCIENTPOWER,:LEAFSTORM,:LEECHSEED,:TOXIC,:THUNDERWAVE,:SOLARBEAM,:CURSE,:THUNDER,:FIRESPIN,:THUNDERBOLT,:EARTHQUAKE,:SCALD],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :ENTEI,
            :level => 60,
            :form => 0,
            :item => :LIFEORB,
            :moves => [:SACREDFIRE,:EARTHQUAKE,:CLOSECOMBAT,:BRANDISHBUSTER],
            :ability => :TINTEDLENS,
            :nature => :BRAVE,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 10",
        :continuous => true,
        :totalMonCount => 4,
        :moninfos => {
            1 => {
                :species => :ALCREMIE,
                :level => 56,
                :item => :LIGHTCLAY,
                :moves => [:REFLECT,:AROMATICMIST,:MOONBLAST],
                :ability => :POWERSPOT,
                :nature => :BOLD,
                :form => 3,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
            },
            2 => {
                :species => :SABLEYE,
                :level => 55,
                :item => :SABLENITE,
                :moves => [:KNOCKOFF,:WILLOWISP,:TORMENT,:TAILWIND],
                :ability => :PRANKSTER,
                :nature => :IMPISH,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                
                },
            3 => {
                :species => :LATIAS,
                :level => 57,
                :item => :LEPPABERRY,
                :moves => [:DECORATE,:FOLLOWME,:AROMATICMIST,:REFLECT],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                4 => {
                :species => :LATIAS,
                :level => 57,
                :item => :LEPPABERRY,
                :moves => [:DECORATE,:FOLLOWME,:AROMATICMIST,:REFLECT],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                },
              },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :SUPERHEATED, # field changes
                :fieldChangeMessage => "The heat intensifies!", # message that plays when the field is changes
                :abilitychange => :MOLDBREAKER, # ability to change to upon shieldbreaker
                :movesetUpdate => [:VCREATE,:STEAMROLLER,:CLOSECOMBAT,:BRANDISHBUSTER],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :WHITEHERB,
                :weatherChange => :SUNNYDAY, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The sunlight intensifies!", # weather message
                :weatherChangeAnimation => "Sunny", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
            3 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :VOLCANICTOP, # field changes
                :fieldChangeMessage => "The heat is bursting out!", # message that plays when the field is changes
                :abilitychange => :GALEWINGS, # ability to change to upon shieldbreaker
                :movesetUpdate => [:FLAREBLITZ,:STONEEDGE,:SKYATTACK,:SUCKERPUNCH],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :POWERHERB,
                :weatherChange => :SUNNYDAY, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The sunlight intensifies!", # weather message
                :weatherChangeAnimation => "Sunny", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
           2 => {
                :threshold => 0,
                :formchange => 1,
                :effectClear => true,
                :fieldChange => :GRASSY, # field changes
                :fieldChangeMessage => "The fire needs more space to spread!", # message that plays when the field is changes
                :abilitychange => :PROTEAN, # ability to change to upon shieldbreaker
                :movesetUpdate => [:FLAREBLITZ,:STONEEDGE,:GRASSYGLIDE,:SUCKERPUNCH],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :DARKGEM,
                :weatherChange => :SUNNYDAY, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The sunlight intensifies!", # weather message
                :weatherChangeAnimation => "Sunny", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
            1  => {
                :threshold => 0,
                :effectClear => true,
                :movesetUpdate => [:PYROBALL,:CRUNCH,:GUNKSHOT,:GALESTRIKE],
                :statusCure => true,
                :itemchange => :FIREGEM,
                :weatherChange => :SUNNYDAY, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The sunlight intensifies!", # weather message
                :weatherChangeAnimation => "Sunny", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
        }
    },
    :GERBIL2 => {
        :name => "Suicune", # nickname
        :entryText => "Suicune appeared before you!",
        :shieldCount => 4, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:SUCKERPUNCH,:MACHPUNCH,:EARTHPOWER,:ANCIENTPOWER,:LEAFSTORM,:LEECHSEED,:TOXIC,:THUNDERWAVE,:SOLARBEAM,:CURSE,:THUNDER,:FIRESPIN,:THUNDERBOLT,:EARTHQUAKE,:SCALD],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :SUICUNE,
            :level => 60,
            :form => 0,
            :item => :WACANBERRY,
            :moves => [:FREEZEDRY,:PSYSHOCK,:SCALD,:ICYWIND],
            :ability => :WATERBUBBLE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 10",
        :continuous => true,
        :totalMonCount => 3,
        :moninfos => {
            1 => {
                :species => :ALCREMIE,
                :level => 56,
                :item => :LIGHTCLAY,
                :moves => [:REFLECT,:AROMATICMIST,:MOONBLAST,:LIGHTSCREEN],
                :ability => :POWERSPOT,
                :nature => :BOLD,
                :form => 3,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
            },
            2 => {
                :species => :SABLEYE,
                :level => 55,
                :item => :SABLENITE,
                :moves => [:KNOCKOFF,:WILLOWISP,:TORMENT,:TAILWIND],
                :ability => :PRANKSTER,
                :nature => :IMPISH,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                
                },
            3 => {
                :species => :LATIAS,
                :level => 57,
                :item => :LEPPABERRY,
                :moves => [:DECORATE,:FOLLOWME,:AROMATICMIST,:REFLECT],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
            4 => {
                :species => :LATIAS,
                :level => 57,
                :item => :LEPPABERRY,
                :moves => [:DECORATE,:FOLLOWME,:AROMATICMIST,:REFLECT],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                },
              },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :UNDERWATER, # field changes
                :fieldChangeMessage => "The battle goes deep down!", # message that plays when the field is changes
                :abilitychange => :SWIFTSWIM, # ability to change to upon shieldbreaker
                :movesetUpdate => [:FREEZEDRY,:PSYSHOCK,:SCALD,:ICYWIND],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :WHITEHERB,
            },
            3 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :STORMY, # field changes
                :fieldChangeMessage => "A storm breaks out!", # message that plays when the field is changes
                :abilitychange => :WINDDRIVEN, # ability to change to upon shieldbreaker
                :movesetUpdate => [:RAZORWIND,:TWISTER,:HYDROCANNON,:COLDTRUTH],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :EXPERTBELT,
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The rain intensifies!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
           2 => {
                :threshold => 0,
                :formchange => 1,
                :effectClear => true,
                :fieldChange => :SWAMP, # field changes
                :fieldChangeMessage => "The field conjures into a swamp!", # message that plays when the field is changes
                :abilitychange => :CLEARBODY, # ability to change to upon shieldbreaker
                :movesetUpdate => [:GUST,:MUDDYWATER,:ICEBEAM,:HURRICANE],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ASSAULTVEST,
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The rain intensifies!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
            1  => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :SNOWYMOUNTAIN, # field changes
                :fieldChangeMessage => "The field conjures into a swamp!", # message that plays when the field is changes
                :abilitychange => :CLEARBODY, # ability to change to upon shieldbreaker
                :movesetUpdate => [:ICYWIND,:SURF,:FREEZEDRY,:AIRSLASH],
                :statusCure => true,
                :itemchange => :ICEGEM,
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The rain intensifies!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
        }
    },
    :GERBIL3 => {
        :name => "Raikou", # nickname
        :entryText => "Raikou appeared before you!",
        :shieldCount => 4, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:SUCKERPUNCH,:MACHPUNCH,:EARTHPOWER,:ANCIENTPOWER,:LEAFSTORM,:LEECHSEED,:TOXIC,:THUNDERWAVE,:SOLARBEAM,:CURSE,:THUNDER,:FIRESPIN,:THUNDERBOLT,:EARTHQUAKE,:SCALD],
            :fieldEffectDamage => [:UNDERWATER]
        },
        :moninfo => { # pokemon details
            :species => :RAIKOU,
            :level => 60,
            :form => 0,
            :item => :LIFEORB,
            :moves => [:THUNDERBOLT,:SHADOWBALL,:SCALD,:DARKPULSE],
            :ability => :SURGESURFER,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
         },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 10",
        :continuous => true,
        :totalMonCount => 3,
        :moninfos => {
            1 => {
                :species => :ALCREMIE,
                :level => 56,
                :item => :LIGHTCLAY,
                :moves => [:REFLECT,:AROMATICMIST,:MOONBLAST,:LIGHTSCREEN],
                :ability => :POWERSPOT,
                :nature => :BOLD,
                :form => 3,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
            },
            2 => {
                :species => :SABLEYE,
                :level => 55,
                :item => :SABLENITE,
                :moves => [:KNOCKOFF,:WILLOWISP,:TORMENT,:TAILWIND],
                :ability => :PRANKSTER,
                :nature => :IMPISH,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                
                },
            3 => {
                :species => :LATIAS,
                :level => 57,
                :item => :LEPPABERRY,
                :moves => [:DECORATE,:FOLLOWME,:AROMATICMIST,:REFLECT],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                4 => {
                :species => :LATIAS,
                :level => 57,
                :item => :LEPPABERRY,
                :moves => [:DECORATE,:FOLLOWME,:AROMATICMIST,:REFLECT],
                :ability => :FRIENDGUARD,
                :nature => :TIMID,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                },
              },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :UNDERWATER, # field changes
                :fieldChangeMessage => "The battle goes deep down!", # message that plays when the field is changes
                :abilitychange => :MOLDBREAKER, # ability to change to upon shieldbreaker
                :movesetUpdate => [:THUNDER,:WATERPULSE,:SCALD,:GIGADRAIN],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :CHOICESPECS,
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The rain intensifies!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
            3 => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :STORMY, # field changes
                :fieldChangeMessage => "A storm breaks out!", # message that plays when the field is changes
                :abilitychange => :ELECTRICSURGE, # ability to change to upon shieldbreaker
                :movesetUpdate => [:RISINGVOLTAGE,:RAZORWIND,:TWISTER,:AIRSLASH],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ELECTRICGEM,
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The rain intensifies!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
           2 => {
                :threshold => 0,
                :effectClear => true,
                :formchange => 1,
                :fieldChange => :FACTORY, # field changes
                :fieldChangeMessage => "Machines are whiring!", # message that plays when the field is changes
                :abilitychange => :TRANSISTOR, # ability to change to upon shieldbreaker
                :movesetUpdate => [:THUNDER,:FLASHCANNON,:DAZZLINGGLEAM,:AURASPHERE],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ASSAULTVEST,
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The rain intensifies!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
            1  => {
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :ELECTERRAIN, # field changes
                :fieldChangeMessage => "A burst of electricity runs over the field!", # message that plays when the field is changes
                :abilitychange => :STEADFAST, # ability to change to upon shieldbreaker
                :movesetUpdate => [:AURORABEAM,:SURF,:MAGMADRIFT,:THUNDERCAGE],
                :statusCure => true,
                :itemchange => :AIRBALLOON,
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The rain intensifies!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
            },
        }
    },
    :ICESOLDIER => {
        :name => "Ice Soldier", # nickname
        :entryText => "En Garde!",
        :shieldCount => 2, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :REGICE,
            :level => 90,
            :form => 1,
            :moves => [:HAIL,:SURF,:PSYCHIC,:COLDTRUTH],
            :ability => :LEVITATE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,4,252,0,252]
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :SABLEYE,
                :level => 85,
                :item => :SABLENITE,
                :moves => [:CONFUSERAY,:WILLOWISP,:PROTECT,:RECOVER],
                :ability => :MAGICBOUNCE,
                :nature => :CAREFUL,
                :form => 1,
                :iv => 31,
                :happiness => 255,
                :ev => [252,0,4,0,252,0]
            },
            2 => {
                :species => :SPIRITOMB,
                :level => 80,
                :item => :LEFTOVERS,
                :moves => [:SUCKERPUNCH,:FOULPLAY,:WILLOWISP,:SPITE],
                :ability => :INFILTRATOR,
                :nature => :ADAMANT,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,4,0,0,0]
                },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "ALICE: Soldier! Protect your Queen! Use everything you have!", # message that plays when shield is broken
                :bosssideChanges => :Safeguard,
                :bosssideChangeCount => 5,
                :bosssideChangeMessage => "Ice Soldier shrouded itself with a Safeguard!", # message that plays for the effect
                :abilitychange => :REFRIGERATE,
                :typeChange => [:ICE,:GHOST],
                :fieldChange => :GLITCH,
                :movesetUpdate => [:HYPERBEAM,nil,nil,nil],
                :fieldChangeMessage => "The ice castle is crumbling!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
                :statBoosts => { # any statboosts that are given
                    PBStats::SPATK => 6,
                    PBStats::SPEED => 1,
                },
            },
        }
    },
    :TIEMPAGOOD => {
        :name => "Tiempa", # nickname
        :entryText => "Tiempa is looking ready to attack!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :DIALGA,
            :level => 100,
            :item => :ADAMANTORB,
            :moves => [:STEELBEAM,:DRAGONBREATH,:DOOMSDAY,:THUNDER],
            :ability => :DAZZLING,
            :nature => :RASH,
            :iv => 31,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
             1=> {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :statDropCure => true, # if statdrops are negated when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :movesetUpdate => [:GUILLOTINE,:DRAGONBREATH,:DOOMSDAY,:CLOSECOMBAT],
                :formchange => 1, # formchanges
                :abilitychange => :JUSTICE,
            },
        }
    }, 
    :SPACEAGOOD => {
        :name => "Spacea", # nickname
        :entryText => "Spacea is looking ready to attack!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:INFERNO,:NUZZLE],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :PALKIA,
            :level => 100,
            :item => :CLEARAMULET,
            :moves => [:BOOMBURST,:SPACIALREND,:THUNDER,:FREEZEDRY],
            :ability => :HARMONIA,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
             1=> {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :statDropCure => true, # if statdrops are negated when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :movesetUpdate => [:HYDROPUMP,:SPACIALREND,:DECIMATION,:FREEZEDRY],
                :abilitychange => :UNAWARE,
                :formchange => 1, # formchanges
                :itemchange => :LUSTROUSORB, # item that is given upon breaking shield
            },
        }
    },
    :SPACEABAD => {
        :name => "Spacehoe", # nickname
        :entryText => "Spacea is looking ready to attack!",
        :shieldCount => 5, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :PALKIA,
            :level => 100,
            :form => 0,
            :item => :LUSTROUSORB,
            :moves => [:SURF,:SPACIALREND,:FLAMETHROWER,:HEAVYSLAM],
            :ability => :OBLIVIOUS,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 2",
            :continuous => true,
            :totalMonCount => 2,
            :moninfos => {
                1 => {
                    :species => :ARCEUS,
                    :level => 90,
                    :item => :COVERTCLOAK,
                    :moves => [:FOLLOWME],
                    :ability => :FRIENDGUARD,
                    :ev => [252, 0, 128, 128, 128, 128],
                },
                2 => {
                    :species => :DIALGA,
                    :level => 93,
                    :item => :ASSAULTVEST,
                    :moves => [:ROAROFTIME,:STEELBEAM,:THUNDER,:FIREBLAST],
                    :ability => :MAGICIAN,
                    :ev => [252, 0, 4, 252, 0, 128],
                },
            },
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            3 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :statDropCure => true, # if statdrops are negated when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :LUSTROUSORB, # item that is given upon breaking shield
                :abilitychange => :CONTRARY,
                :stateChanges => :WonderRoom, # handles state changes found in the Battle_Global class(in Battle_ActiveSide file + Trick Room
                :stateChangeAnimation => :WONDERROOM, # state change animation
                :stateChangeCount => 99, # state change turncount
                :stateChangeMessage => "The dimensions were changed!", # statechange messages
                :bossStatChanges => {
                    PBStats::SPDEF => 1,
                },
            },
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :statDropCure => true, # if statdrops are negated when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :LUSTROUSORB, # item that is given upon breaking shield
                :abilitychange => :GODSPEED,
                :stateChanges => :WonderRoom, # handles state changes found in the Battle_Global class(in Battle_ActiveSide file + Trick Room
                :stateChangeAnimation => :WONDERROOM, # state change animation
                :stateChangeCount => 99, # state change turncount
                :stateChangeMessage => "The dimensions were changed!", # statechange messages
                :bossStatChanges => {
                    PBStats::SPDEF => 1,
                },
            },
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Spacea twisted the space around the field!", # message that plays when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :effectClear => true,
                :itemchange => :LUSTROUSORB, # item that is given upon breaking shield
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPATK => 1,
                },
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,
                }
            },
        }
    }, 
    :TIEMPABAD => {
        :name => "Timehoe", # nickname
        :entryText => "Tiempa is finishing what Spacea started!",
        :shieldCount => 6, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :DIALGA,
            :level => 100,
            :form => 0,
            :item => :TELLURICSEED,
            :moves => [:STEELBEAM,:BODYPRESS,:MATRIXSHOT,:DRAGONRUSH],
            :ability => :LIGHTMETAL,
            :nature => :BRAVE,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 4",
            :totalMonCount => 4,
            :moninfos => {
                1 => {
                    :species => :CELEBI,
                    :level => 95,
                    :form => 0,
                    :item => :ASSAULTVEST,
                    :moves => [:ROAROFTIME,:ZENHEADBUTT,:MATRIXSHOT,:HIGHHORSEPOWER],
                    :ability => :FRIENDGUARD,
                    :nature => :HASTY,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [252,252,252,252,252,252]
                    },
                2 => {
                    :species => :JIRACHI,
                    :level => 95,
                    :form => 0,
                    :item => :LEFTOVERS,
                    :moves => [:MOONBLAST,:STEELBEAM,:FOLLOWME,:PSYCHIC],
                    :ability => :POWERSPOT,
                    :nature => :BOLD,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [252,252,252,252,252,252]
                    },
                    3 => {
                    :species => :VICTINI,
                    :level => 95,
                    :form => 0,
                    :item => :ASSAULTVEST,
                    :moves => [:BOLTSTRIKE,:PYROBALL,:CLOSECOMBAT,:HELPINGHAND],
                    :ability => :FRIENDGUARD,
                    :nature => :ADAMANT,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [252,252,252,252,252,252]
                },
                4 => {
                    :species => :DONPHAN,
                    :level => 95,
                    :form => 0,
                    :item => :LEFTOVERS,
                    :moves => [:HEADLONGRUSH,:TRIPLEAXEL,:ZENHEADBUTT,:COACHING],
                    :ability => :POWERSPOT,
                    :nature => :IMPISH,
                    :iv => 31,
                    :happiness => 255,
                    :ev => [252,252,252,252,252,252]
                    },
            },
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
               4 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :fieldChange => :FACTORY, # field changes
                :movesetUpdate => [:FLASHCANNON,:DRACOMETEOR,:FISSURE,:PSYSTRIKE],
                :itemchange => :WHITEHERB, # item that is given upon breaking shield
                :statDropCure => true, # if statdrops are negated when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                },
            },
            3 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                 :fieldChange => :ICY, # field changes
                :movesetUpdate => [:BLIZZARD,:DRAGONBREATH,:FISSURE,:SHEERCOLD],
                :itemchange => :LIFEORB, # item that is given upon breaking shield
                :statDropCure => true, # if statdrops are negated when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,
                },
            },
            2 => {
                :CustomMethod => "battlesnapshot(battler,1,1)",
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :itemchange => :ADAMANTORB, # item that is given upon breaking shield
                :statDropCure => true, # if statdrops are negated when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :playerSideStatChanges => { # any statboosts that are given
                    PBStats::DEFENSE => -2,
                    PBStats::SPDEF => -2,
                    PBStats::SPEED => -2,
                },
            },
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :itemchange => :ADAMANTORB, # item that is given upon breaking shield
                :statDropCure => true, # if statdrops are negated when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                },
            },
            0 => {
                :CustomMethod => "timewarp(battler,1)",
                :movesetUpdate => [:BLIZZARD,:DRAGONBREATH,:FISSURE,:SHEERCOLD],
                :delayedaction => {
                    :delay => 1,
                    :CustomMethod => "battlesnapshot(battler,2,-1)",
                    :message => "Tiempa is focusing on the flow of time!",
                    :playerEffects => [:FutureSight,:FutureSightMove],
                    :playerEffectsduration => [2,:DOOMDESIRE],
                    :playerEffectsAnimation => :DOOMDESIRE,
                    :delayedaction => {
                        :delay => 5,
                        :message => "TIEMPA: You are wasting your time, Interceptor...",
                        :CustomMethod => "timewarp(battler,2)",
                    },
                },
                :message => "TIEMPA: No more... NO... MORE!!!!!!!", # message that plays when shield is broken
                :animation => :FLASH, # effect animation
                :bgmChange => "Battle - End of Night",
                :fieldChange => :NEWWORLD, # field changes
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :formchange => 1, # formchanges
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :ADAMANTORB, # item that is given upon breaking shield
                :bossStatChanges => { # any statboosts that are given
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                },
            },
            -2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :itemchange => :ADAMANTORB, # item that is given upon breaking shield
                :playerSideStatChanges => { # any statboosts that are given
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1,
                },
            },
            -1 => {
                :CustomMethod => "battlesnapshot(battler,3,-1)",
                :message => "Tiempa's concentration was broken!",
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :ADAMANTORB, # item that is given upon breaking shield
                :delayedaction => {
                    :delay => 5,
                    :message => "TIEMPA: Just one mistake is all it takes...",
                    :CustomMethod => "timewarp(battler,3)",
                },
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPATK => 1,
                },
            },
        }
    },
    :BOSSRATICATE => {
        :name => "Monstrosity",
        :entryText => "The grotesque rodent attacked!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :RATICATE,
            :level => 18,
            :form => 2,
            :moves => [:POISONFANG,:BITE,:TAILWHIP,:SECRETPOWER],
            :ability => :NOGUARD,
            :nature => :NAUGHTY,
            :iv => 20,
            :happiness => 255,
            :ev => [20,20,20,20,20,20]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "The Monstrosity started acting desperate!",
                :statDropCure => true,
                :movesetUpdate => [:DIRECLAW,:BITE,:TAILWHIP,:SECRETPOWER],
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => 1,
                }
            }
        }
    },  
    :STARMIEGOD => {
        :name => "Shooting Star",
        :entryText => "You can't look away from the Star...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :STARMIE,
            :level => 88,
            :moves => [:SURF,:THUNDERBOLT,:RECOVER,:PSYCHIC],
            :ability => :ANALYTIC,
            :nature => :MODEST,
            :item => :PETAYABERRY,
            :iv => 31,
            :happiness => 255,
            :shiny => true,
            :ev => [0,0,0,252,0,252]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "The Shooting Star is sparkling!",
                :statDropCure => true,
                :itemchange => :PETAYABERRY,
                :fieldChange => :RAINBOW,
                :fieldChangeMessage => "A prismatic luminance buries the surroundings!",
                :movesetUpdate => [:TRIATTACK,:DAZZLINGGLEAM,:COSMICPOWER,:PSYSHOCK],
                :abilitychange => :PRISMARMOR,
            }
        }
    }, 
    :UXIEBAD => {
        :name => "Uxie", # nickname
        :entryText => "Uxie is defending itself!",
        :shieldCount => 2, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :UXIE,
            :level => 90,
            :form => 0,
            :moves => [:AMNESIA,:MYSTICALPOWER,:DRAININGKISS,:YAWN],
            :ability => :LEVITATE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,4,252,0,252]
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :MESPRIT,
                :level => 80,
                :item => :MAGICALSEED,
                :moves => [:CHARM,:PSYSHOCK,:SHADOWBALL,:CONFUSERAY],
                :ability => :LEVITATE,
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
                :ev => [252,0,4,0,252,0]
            },
            2 => {
                :species => :AZELF,
                :level => 80,
                :item => :MAGICALSEED,
                :moves => [:THUNDERWAVE,:ZENHEADBUTT,:PLAYROUGH,:KNOCKOFF],
                :ability => :LEVITATE,
                :nature => :ADAMANT,
                :iv => 31,
                :happiness => 255,
                :ev => [0,252,4,0,0,252]
                },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Uxie drew power from the Starlight!", # message that plays when shield is broken
                :bosssideChanges => :Safeguard,
                :bosssideChangeCount => 5,
                :bosssideChangeMessage => "Uxie shrouded itself with a Safeguard!", # message that plays for the effect
                :abilitychange => :VICTORYSTAR,
                :typeChange => [:PSYCHIC,:FAIRY],
                :fieldChange => :STARLIGHT,
                :movesetUpdate => [:MYSTICALPOWER,:DRAININGKISS,:YAWN,:SIGNALBEAM],
                :fieldChangeMessage => "The field shines bright!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :MAGICALSEED, # item that is given upon breaking shield
                :statBoosts => { # any statboosts that are given
                    PBStats::DEFENSE => 1,
                    PBStats::SPEED => 1,
                },
            },
        }
    },
    :MESPRITBAD => {
        :name => "Mesprit", # nickname
        :entryText => "Mesprit is defending itself!",
        :shieldCount => 2, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :MESPRIT,
            :level => 90,
            :form => 0,
            :moves => [:WATERPULSE,:CHARGEBEAM,:DRAININGKISS,:MYSTICALPOWER],
            :ability => :LEVITATE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,4,252,0,252]
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :UXIE,
                :level => 80,
                :item => :ELEMENTALSEED,
                :moves => [:YAWN,:PSYCHIC,:THUNDERBOLT,:HELPINGHAND],
                :ability => :LEVITATE,
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
                :ev => [252,0,4,0,252,0]
            },
            2 => {
                :species => :AZELF,
                :level => 80,
                :item => :ELEMENTALSEED,
                :moves => [:THUNDERWAVE,:ZENHEADBUTT,:PLAYROUGH,:KNOCKOFF],
                :ability => :LEVITATE,
                :nature => :ADAMANT,
                :iv => 31,
                :happiness => 255,
                :ev => [0,252,4,0,0,252]
                },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Mesprit surrounded itself in water!", # message that plays when shield is broken
                :bosssideChanges => :Safeguard,
                :bosssideChangeCount => 5,
                :bosssideChangeMessage => "Mesprit shrouded itself with a Safeguard!", # message that plays for the effect
                :abilitychange => :TECHNICIAN,
                :typeChange => [:PSYCHIC,:WATER],
                :fieldChange => :WATERSURFACE,
                :movesetUpdate => [:MYSTICALPOWER,:DRAININGKISS,:CHARGEBEAM,:WATERPULSE],
                :fieldChangeMessage => "The field was flash flooded!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :ELEMENTALSEED, # item that is given upon breaking shield
                :statBoosts => { # any statboosts that are given
                    PBStats::DEFENSE => 1,
                    PBStats::SPEED => 1,
                },
            },
        }
    },
    :AZELFBAD => {
        :name => "Azelf", # nickname
        :entryText => "Azelf is defending itself!",
        :shieldCount => 2, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :AZELF,
            :level => 90,
            :form => 0,
            :moves => [:NASTYPLOT,:FLAMETHROWER,:KNOCKOFF,:MYSTICALPOWER],
            :ability => :LEVITATE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,4,252,0,252]
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :UXIE,
                :level => 80,
                :item => :ELEMENTALSEED,
                :moves => [:YAWN,:PSYCHIC,:THUNDERBOLT,:HELPINGHAND],
                :ability => :LEVITATE,
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
                :ev => [252,0,4,0,252,0]
            },
            2 => {
                :species => :MESPRIT,
                :level => 80,
                :item => :ELEMENTALSEED,
                :moves => [:CHARM,:PSYSHOCK,:SHADOWBALL,:CONFUSERAY],
                :ability => :LEVITATE,
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
                :ev => [252,0,4,0,252,0]
            },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Azelf conflagrated in hellfire!", # message that plays when shield is broken
                :bosssideChanges => :Safeguard,
                :bosssideChangeCount => 5,
                :bosssideChangeMessage => "Azelf shrouded itself with a Safeguard!", # message that plays for the effect
                :abilitychange => :MAGMAARMOR,
                :typeChange => [:PSYCHIC,:DARK],
                :fieldChange => :INFERNAL,
                :movesetUpdate => [:TORMENT,:FLAMETHROWER,:KNOCKOFF,:MYSTICALPOWER],
                :fieldChangeMessage => "The field is burning with anguish!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :ELEMENTALSEED, # item that is given upon breaking shield
                :statBoosts => { # any statboosts that are given
                    PBStats::ATTACK => 2,
                },
            },
        }
    },
    :RIFTTALON => {
        :name => "Karma Beast Talon",
        :entryText => "Talon fumbles toward you...",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :BRAVIARY,
            :level => 90,
            :form => 3,
            :moves => [:SLUDGEWAVE,:ACROBATICS,:ESPERWING,:VENOSHOCK],
            :gender => "M",
            :nature => :BRAVE,
            :item => :TELLURICSEED,
            :iv => 31,
            :happiness => 0,
            :ev => [4,252,0,252,0,0]
        },
        :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
            :fieldChange => :CORRUPTED,
            :fieldChangeMessage => "The arena melted into toxic slag!"
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => ".... stOooP.....",
                :movesetUpdate => [:ACIDARMOR,:BARBBARRAGE,:HURRICANE,:BODYPRESS],
                :playersideChanges => :ToxicSpikes, # handles side changes found in the Battle_Side class(in Battle_ActiveSide file) 
                :playersideChangeAnimation => :TOXICSPIKES, # side change animation
                :playersideChangeCount => 1, # side change turncount
                :playersideChangeMessage => "Toxic Spikes was set up!",
                :itemchange => :BLACKSLUDGE,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,
                }
            },
            2 => {
                :threshold => 0,
                :message => "oUu.... dOn'T.....",
                :typeChange => [:POISON,:DRAGON],
                :movesetUpdate => [:HEXINGSLASH,:DRAGONCLAW,:DRACOMETEOR,:VENOSHOCK],
                :statDropCure => true,
                :statusCure => true,
                :formchange => 4,
                :fieldChange => :CORROSIVEMIST,
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -2,
                    PBStats::SPDEF => -2
                }
            },
            1 => {
                :threshold => 0,
                :message => ".... pLEase.... enD IT....",
                :movesetUpdate => [:VILEASSAULT,:DRAGONRUSH,:HEATWAVE,:DRAGONDANCE],
                :itemchange => :POISONIUMZ,
                :bossStatChanges => {
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => 2,
                }
            },
        }
    },
    :NANODRIVE => {
        :name => "NANO DRIVE",
        :entryText => "The NANO DRIVE is analyzing...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :MAGNEZONE,
            :level => 100,
            :form => 1,
            :moves => [:DOUBLEIRONBASH,:POWERUPPUNCH,:SHELTER,:SUCKERPUNCH],
            :gender => "F",
            :nature => :IMPISH,
            :item => :PROTECTIVEPADS,
            :iv => 31,
            :happiness => 0,
            :ev => [4,252,252,0,0,0]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "The NANO DRIVE is planning...",
                :movesetUpdate => [:DOUBLEIRONBASH,:BRUTALSWING,:BULLETPUNCH,:ELECTROWEB],
                :playersideChanges => :Spikes, # handles side changes found in the Battle_Side class(in Battle_ActiveSide file) 
                :playersideChangeAnimation => :SPIKES, # side change animation
                :playersideChangeCount => 1, # side change turncount
                :playersideChangeMessage => "A layer of Spikes was set up!",
                :itemchange => :ELECTRICGEM,
                :bossStatChanges => {
                    PBStats::SPATK => 2,
                }
            },
            1 => {
                :threshold => 0,
                :message => "The NANO DRIVE is closing out the battle...",
                :movesetUpdate => [:DOUBLEIRONBASH,:STEAMROLLER,:SPIKYSHIELD,:SUBMISSION],
                :itemchange => :STEELIUMZ,
                :bossStatChanges => {
                    PBStats::DEFENSE => 2,
                }
            },
        }
    },
    :NANODRIVE_1 => {
        :name => "NANO DRIVE",
        :entryText => "The NANO DRIVE is analyzing...",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :MAGNEZONE,
            :level => 100,
            :item => :FOCUSSASH,
            :moves => [:HAMMERARM,:WOODHAMMER,:ICEHAMMER,:DRAGONHAMMER],
            :nature => :NAUGHTY,
            :form => 2,
            :iv => 31,
            :happiness => 0,
            :ev => [0,252,0,252,0,4]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Will you... Remember all of this too? ",
                :itemchange => :LIFEORB,
                :movesetUpdate => [:BLIZZARD,:THUNDER,:FIREBLAST,:HYPERBEAM],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1
                }
            },
        }
    },
    #Extreme random boss mons
     :GAHOOH => {
        :name => "Ho-Oh",
        :shieldCount => 1,
        :immunities => {
             :moves => [:RISINGVOLTAGE,:THUNDER,:ROCKSLIDE,:STONEEDGE,:WILLOWISP,:SCALD,:TOXIC,:PYROKINESIS,:GILDEDARROW,:GILDEDHELIX,:STEAMERUPTION,:ICYWIND,:DIAMONDSTORM,:EXTREMESPEED,:SACREDFIRE,:FLAMETHROWER,:FIREBLAST,:INFERNO,:ACCELEROCK],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :HOOH,
	        :level => 85,
	        :item => :SOLIDVEST,
	        :moves => [:EXTREMESPEED,:GIGAIMPACT,:HEADLONGRUSH,:SOLARBLADE],
	        :ability => :FLAMBOYANT,
	        :nature => :JOLLY,
            :form => 1,
            :iv => 31,
            :ev => [252, 252, 252, 252, 252, 252]
        },
         :onBreakEffects => {
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
            },
        }
    },
         :GALUGIA => {
        :name => "Lugia",
        :shieldCount => 1,
        :immunities => {
             :moves => [:RISINGVOLTAGE,:THUNDER,:ROCKSLIDE,:STONEEDGE,:WILLOWISP,:SCALD,:TOXIC,:BLIZZARD,:GILDEDARROW,:GILDEDHELIX,:ICYWIND,:DIAMONDSTORM,:EXTREMESPEED,:FLAMETHROWER,:FIREBLAST,:ZAPCANNON,:ACCELEROCK],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :LUGIA,
	        :level => 85,
	        :item => :SKYEMBLEM,
	        :moves => [:AEROBLAST,:AIRCUTTER,:PSYSHOCK,:ICYWIND],
	        :ability => :WINDDRIVEN,
	        :nature => :TIMID,
            :iv => 31,
            :form => 1,
            :ev => [252, 252, 252, 252, 252, 252]
        },
         :onBreakEffects => {
           1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
            },
        }
    },
    #Extreme for wardens
        :EMILYGOD => {
        :name => "Zekrom",
        :shieldCount => 1,
        :immunities => {
            :moves => [:FAKEOUT,:PRECIPICEBLADES,:EARTHQUAKE,:HEAVENLYWING,:EXTREMESPEED,:GILDEDHELIX,:SUCKERPUNCH,:RISINGVOLTAGE,:THUNDER,:HAZE,:POWERSWAP,:SPEEDSWAP,:GUARDSWAP,:PSYCHUP,:HIGHHORSEPOWER,:DARKPULSE,:NIGHTDAZE,:WICKEDBLOW,:BIND,:CRUNCH,:THUNHDER,:BLIZZARD,:HYDROPUMP,:WILLOWISP,:SCALD,:SOAK,:CURSE,:TRICKORTREAT,:DISABLE,:LEECHSEED,:SACREDFIRE,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :ZEKROM,
            :level => 98,
            :item => :LIFEORB,
            :moves => [:THUNDERPULSE,:OUTRAGE,:CLOSECOMBAT,:MEADOWDRIVE],
            :ability => :TERAVOLT,
            :nature => :ADAMANT,
            :iv => 31,
            :form => 2,
            :ev => [252, 252, 252, 252, 252, 252]
        },
         :onBreakEffects => {
           1 => {
                :threshold => 0,
                :speciesUpdate => :KYUREM,
                :formchange => 2,
                :movesetUpdate => [:THUNDERPULSE,:OUTRAGE,:CLOSECOMBAT,:MEADOWDRIVE],
                :abilitychange => :TRANSISTOR,
                :itemchange => :ELECTRIUMZ,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPEED => 2,
                },
            },
        }
    },
        :THETOPDOG => {
        :name => "The Top Dog",
        :shieldCount => 1,
        :immunities => {
            :moves => [:FAKEOUT,:PRECIPICEBLADES,:EARTHQUAKE,:HEAVENLYWING,:EXTREMESPEED,:GILDEDHELIX,:SUCKERPUNCH,:RISINGVOLTAGE,:THUNDER,:HAZE,:POWERSWAP,:SPEEDSWAP,:GUARDSWAP,:PSYCHUP,:HIGHHORSEPOWER,:DARKPULSE,:NIGHTDAZE,:WICKEDBLOW,:BIND,:CRUNCH,:THUNHDER,:BLIZZARD,:HYDROPUMP,:WILLOWISP,:SCALD,:SOAK,:CURSE,:TRICKORTREAT,:DISABLE,:FLAMETHROWER,:SACREDFIRE,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :DECIDUEYE,
            :level => 99,
            :item => :TELLURICSEED,
            :moves => [:NATURESLANCE,:SPIRITSHACKLE,:FIREARROWS,:BOLTARROWS],
            :ability => :DAZZLING,
            :nature => :JOLLY,
            :iv => 31,
            :ev => [252, 252, 252, 252, 252, 252]
        },
         :onBreakEffects => {
           1 => {
                :threshold => 0,
                :itemchange => :DECIDIUMZ,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPEED => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                },
            },
        }
    },
    #Extreme this is for Poli-Twins
    :TOED => {
        :name => "Politoed",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:SURF,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:INFERNO,:EXTREMESPEED,:THUNDERRAID,:WAKEUPSHOCK,:PLASMAVOLT,:CHARGEDWHIP,:THUNDER,:VOLTTACKLE,:ZAPCANNON,:FUSIONBOLT,:THUNDERBOLT,:WILDCHARGE,:SPARK,:ELECTROWEB,:CHARGEBEAM,:ELECTROBALL,:AIRCUTTER,:FURYSWIPES,:WRAP,:PARABOLICCHARGE,:NUZZLE,:ZINGZAP,:PLASMAFISTS,:BOLTBEAK,:AURAWHEEL,:OVERDRIVE,:THUNDERCAGE,:GRASSYGLIDE,:TWINEEDLE,:LEAFSTORM,:PETALDANCE,:POWERWHIP,:SOLARBEAM,:WOODHAMER,:LEAFBLADE,:ENERGYBALL,:SEEDBOMB,:GIGADRAIN,:HORNLEECH,:LEAFTORNADO,:MAGICALLEAF,:PYROPETALS,:NEEDLEARM,:RAZORLEAF,:GRASSPLEDGE,:MEGADRAIN,:VINEWHIP,:DARKVINE,:BULLETSEED,:ABSORB,:GRASSKNOT,:EGGBOMB,:RAMPANTVINE,:CONSTRICT,:LANDSWRATH,:PETALBLIZZARD,:HIDDENPOWER,:LEAFAGE,:SOLARBLADE,:TROPKICK,:DRUMBEATING,:APPLEACID,:GRAVAPPLE,:GRASSYGLIDE,:CHLOROBLAST,:UPROOT,:SLASHANDBURN,:MULTIATTACK,:MULTIPULSE,:MEADOWDRIVE,:LOGSTRIKE,:FLOWERTRICK],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :POLITOED,
            :level => 53,
            :item => :EXPERTBELT,
            :moves => [:FREEZEDRY,:SCALD,:PSYSHOCK,:ENERGYBALL],
            :ability => :PROTEAN,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
    },
    :WRATH => {
        :name => "Poliwrath",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:SURF,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:INFERNO,:EXTREMESPEED,:THUNDERRAID,:WAKEUPSHOCK,:PLASMAVOLT,:CHARGEDWHIP,:THUNDER,:VOLTTACKLE,:ZAPCANNON,:FUSIONBOLT,:THUNDERBOLT,:WILDCHARGE,:SPARK,:ELECTROWEB,:CHARGEBEAM,:ELECTROBALL,:AIRCUTTER,:FURYSWIPES,:WRAP,:PARABOLICCHARGE,:NUZZLE,:ZINGZAP,:PLASMAFISTS,:BOLTBEAK,:AURAWHEEL,:OVERDRIVE,:THUNDERCAGE,:GRASSYGLIDE,:TWINEEDLE,:LEAFSTORM,:PETALDANCE,:POWERWHIP,:SOLARBEAM,:WOODHAMER,:LEAFBLADE,:ENERGYBALL,:SEEDBOMB,:GIGADRAIN,:HORNLEECH,:LEAFTORNADO,:MAGICALLEAF,:PYROPETALS,:NEEDLEARM,:RAZORLEAF,:GRASSPLEDGE,:MEGADRAIN,:VINEWHIP,:DARKVINE,:BULLETSEED,:ABSORB,:GRASSKNOT,:EGGBOMB,:RAMPANTVINE,:CONSTRICT,:LANDSWRATH,:PETALBLIZZARD,:HIDDENPOWER,:LEAFAGE,:SOLARBLADE,:TROPKICK,:DRUMBEATING,:APPLEACID,:GRAVAPPLE,:GRASSYGLIDE,:CHLOROBLAST,:UPROOT,:SLASHANDBURN,:MULTIATTACK,:MULTIPULSE,:MEADOWDRIVE,:LOGSTRIKE,:FLOWERTRICK],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :POLIWRATH,
            :level => 53,
            :item => :LIFEORB,
            :moves => [:CHISTRIKE,:SURGINGSTRIKES,:KNOCKOFF,:HIDDENPOWERGRA],
            :ability => :MOLDBREAKER,
            :nature => :JOLLY,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
    },


    #Extreme these are for insane mode
    :EISANGIE => {
        :name => "Ice Soldier",
        :shieldCount => 0,
        :immunities => {
             :moves => [:FAKEOUT,:CLOSECOMBAT,:STEAMROLLER,:DOUBLEIRONBASH,:WILLOWISP,:SCALD,:PYROKINESIS,:LAVAPLUME,:SACREDFIRE,:FLAMETHROWER,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :REGICE,
            :level => 52,
            :item => :ICEGEM,
            :moves => [:COLDTRUTH,:THUNDERBOLT,:ICYWIND,:FISSURE],
            :ability => :FILTER,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :form => 1,
            :ev => [252, 252, 252, 252, 252, 252]
        },
    },
    :AMBERINSANE => {
        :name => "Moltres",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:HIDDENPOWER,:LEECHSEED,:INFERNO,:EXTREMESPEED,:THUNDERRAID,:WAKEUPSHOCK,:PLASMAVOLT,:CHARGEDWHIP,:THUNDER,:VOLTTACKLE,:ZAPCANNON,:FUSIONBOLT,:THUNDERBOLT,:WILDCHARGE,:SPARK,:ELECTROWEB,:CHARGEBEAM,:ELECTROBALL,:AIRCUTTER,:FURYSWIPES,:WRAP,:PARABOLICCHARGE,:NUZZLE,:ZINGZAP,:PLASMAFISTS,:BOLTBEAK,:AURAWHEEL,:OVERDRIVE,:THUNDERCAGE,:ROCKCLIMB,:HEADSMASH,:ROCKWRECKER,:STONEEDGE,:ROCKSLIDE,:POWERGEM,:ANCIENTPOWER,:ROCKTOMB,:SMACKDOWN,:SACREDSWORD,:ROLLOUT,:ROCKBLAST,:DIAMONDSTORM,:ACCELEROCK,:METEORBEAM,:STONEAXE,:MATRIXSHOT,:ANCIENTFANGS,:METEORSHOWER,:GEMBURST,:TAILSMASH],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :MOLTRES,
	        :level => 59,
	        :item => :LIFEORB,
	        :moves => [:RAGINGFLAMES,:OUTRAGE,:SOLARBLADE,:BRANDISHBUSTER],
	        :ability => :DESOLATELAND,
	        :nature => :JOLLY,
            :shiny => true,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
    },
    :ERICKINSANE => {
        :name => "Zapdos",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GRAVITY,:DOUBLEEDGE,:HYPERBEAM,:FRIENDBEAM,:RETURN,:GIGAIMPACT,:GLARE,:THUNDERWAVE,:GILDEDHELIX,:GILDEDARROW,:LEECHSEED,:INFERNO,:EXTREMESPEED,:COLDTRUTH,:NORTHERNIMPACT,:FREEZESHOCK,:BLIZZARD,:ICEBEAM,:ICICLECRASH,:ICEPUNCH,:AURORABEAM,:GLACIATE,:AVALANCHE,:ICYWIND,:FROSTBREATH,:ICESHARD,:ICEBALL,:ICICLECSPEAR,:SHEERCOLD,:SPIKECANNON,:FREEZEDRY,:HIDDENPOWERICE,:ICEHAMMER,:TRIPLEAXEL,:GLACIALLANCE,:MOUNTAINGALE,:SMACKDOWN,:SACREDSWORD,:ROLLOUT,:ROCKBLAST,:DIAMONDSTORM,:ACCELEROCK,:METEORBEAM,:STONEAXE,:MATRIXSHOT,:ANCIENTFANGS,:METEORSHOWER,:GEMBURST,:TAILSMASH,:ROCKCLIMB,:HEADSMASH,:ROCKWRECKER,:STONEEDGE,:ROCKSLIDE,:POWERGEM,:ANCIENTPOWER,:ROCKTOMB,:CHARGEDWHIP,:BOLTSTRIKE,:THUNDER,:VOLTTACKLE,:ZAPCANNON,:FUSIONBOLT,:THUNDERBOLT,:WILDCHARGE,:DISCHARGE,:THUNDERPUNCH,:VOLTSWITCH,:SPARK,:THUNDERFANG,:SHOCKWAVE,:ELECTROWEB,:CHARGEBEAM,:THUNDERSHOCK,:ELECTROBALL,:BOOMSHOUT,:AIRCUTTER,:FURYSWIPES,:WRAP,:ENDURINGSHOCK,:NUZZLE,:PARABOLICCHARGE,:THUNDERCHARGE,:HIDDENPOWER,:ZINGZAP,:PLASMAFISTS,:BOLTBEAK,:AURAWHEEL,:OVERDRIVE,:RISINGVOLTAGE,:THUNDERCAGE,:WILDBOLTSTORM,:THUNDERRAID,:WAKEUPSHOCK,:BOLTARROWS,:GLIDINGBOLTSTORM,:RAGINGTHUNDER,:CLOUDBURST,:PLASMAVOLT,:NORTHERNIMPACT,:FREEZESHOCK,:ICEBURN,:BLIZZARD,:ICEBEAM,:ICICLECRASH,:ICEPUNCH,:AURORABEAM,:GLACIATE,:ICEFANG,:AVALANCHE,:ICYWIND,:FROSTBREATH,:ICESHARD,:POWDERSNOW,:ICEBALL,:ICICLESPEAR,:SHEERCOLD],

            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :ZAPDOS,
        	:level => 64,
        	:item => :SKYEMBLEM,
        	:moves => [:HEATWAVE,:HURRICANE,:LEAFTORNADO,:THUNDERPULSE],
            :ability => :OVERLOAD,
	        :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
    },
    :SPECTORINSANE => {
        :name => "Roaring Moon",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:SPIRITBREAK,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:GILDEDHELIX,:GILDEDARROW,:LEECHSEED,:INFERNO,:EXTREMESPEED,:COLDTRUTH,:NORTHERNIMPACT,:FREEZESHOCK,:BLIZZARD,:ICEBEAM,:ICICLECRASH,:ICEPUNCH,:AURORABEAM,:GLACIATE,:AVALANCHE,:ICYWIND,:FROSTBREATH,:ICESHARD,:ICEBALL,:ICICLECSPEAR,:SHEERCOLD,:SPIKECANNON,:FREEZEDRY,:HIDDENPOWERICE,:ICEHAMMER,:TRIPLEAXEL,:GLACIALLANCE,:MOUNTAINGALE,:HYPERVOICE,:HYPERBEAM,:DOUBLEEDGE,:BOOMBURST,:HIJUMPKICK,:CLOSECOMBAT,:FOCUSBLAST,:SUPERPOWER,:CROSSCHOP,:DYNAMICPUNCH,:JUMPKICK,:HAMMERARM,:AURASPHERE,:SACREDSWORD,:SECRETSWORD,:SKYUPPERCUT,:SUBMISSION,:VITALTHROW,:CIRCLETHROW,:LOWSWEEP,:ROLLINGKICK,:WAKEUPSLAP,:KARATECHOP,:MACHPUNCH,:VACUUMWAVE,:STORMTHROW,:ARMTHRUST,:TRIPLEKICK,:LOWKICK,:REVERSAL,:POWERUPPUNCH,:BODYPRESS,:METEORASSAULT,:THUNDEROUSKICK,:TRIPLEARROWS,:AXEKICK,:GALESTRIKE,:STACKINGSHOT],
            :fieldEffectDamage => [:INFERNAL]
        },
        :moninfo => {
            :species => :ROARINGMOON,
	        :level => 68,
	        :item => :WIKIBERRY,
	        :moves => [:WICKEDBLOW,:DRAGONRUSH,:SPIRITBREAK,:STEELWING],
	        :ability => :MOLDBREAKER,
	        :nature => :ADAMANT,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
    },
    :FLORAINSANE => {
        :name => "Celebi",
        :shieldCount => 1,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:SPIRITBREAK,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:LEECHSEED,:GILDEDHELIX,:GILDEDARROW,:INFERNO,:EXTREMESPEED,:COLDTRUTH,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :CELEBI,
	        :level => 68,
	        :item => :SYNTHETICSEED,
	        :moves => [:NATURALGIFT,:ZENHEADBUTT,:ACROBATICS,:DRAINPUNCH],
	        :ability => :FLORAFORGE,
	        :nature => :ADAMANT,    
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :typeChange => [:PSYCHIC,:BUG],
                :itemchange => :FLYINIUMZ,
                :bossEffect => :WaterSport, # effect that applies on the boss when breaking shield
                :bossEffectduration => 3, # duration of the effect(some effects are booleans, double check)
                :bossEffectanimation => :WATERSPORT, # effect animation
            },
        }
    },
    :FLORININSANE => {
        :name => "Dark Venusaur",
        :shieldCount => 1,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:SPIRITBREAK,:TOXIC,:TRICKORTREAT,:SUCKERPUNCH,:DISABLE,:GLARE,:THUNDERWAVE,:GILDEDHELIX,:GILDEDARROW,:LEECHSEED,:INFERNO,:EXTREMESPEED,:COLDTRUTH,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :VENUSAUR,
	        :level => 72,
	        :item => :CLEARAMULET,
	        :moves => [:RAMPANTVINE,:HORRIDPOLLEN,:FLOWERFEVER,:FAKETEARS],
	        :ability => :FLOWERVEIL,
	        :nature => :MODEST,    
            :form => 3,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :itemchange => :MARANGABERRY,
                :abilitychange => :VINEBURST,
                :bossEffect => :FocusEnergy, # effect that applies on the boss when breaking shield
                :bossEffectduration => 2, # duration of the effect(some effects are booleans, double check)
                :bossEffectanimation => :LASERFOCUS, # effect animation
            },
        }
    },
 :SOUTAINSANE => {
        :name => "INSANESouta",
        :shieldCount => 1,
        :immunities => {
             :moves => [:FAKEOUT,:PRECIPICEBLADES,:BLIZZARD,:COLDTRUTH,:WILLOWISP,:SCALD,:SOAK,:SUPERFANG,:CURSE,:TRICKORTREAT,:GILDEDHELIX,:GILDEDARROW,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:PYROKINESIS,:LAVAPLUME,:SACREDFIRE,:FLAMETHROWER,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
            :moninfo => {
            :species => :RAYQUAZA,
        	:level => 81,
	        :item => :LIFEORB,
        	:moves => [:EXTREMESPEED,:DRACOMETEOR,:DRAGONASCENT,:FOCUSBLAST],
        	:ability => :DELTASTREAM,
        	:shiny => true,
        	:nature => :NAUGHTY,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :formchange => 1,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :movesetUpdate => [:DRAGONRUSH,:SKYATTACK,:EXTREMESPEED,:VCREATE],
                :itemchange => :WHITEHERB,
                :abilitychange => :GALEFORCE,
            },
        }
    },
    :ADAMINSANE => {
        :name => "Camerupt",
        :shieldCount => 1,
        :immunities => {
             :moves => [:FAKEOUT,:SURF,:SCALD,:HYDROCANNON,:MUDDYWATER,:GILDEDHELIX,:SUPERFANG,:HURRICANE,:WATERPULSE,:SUCKERPUNCH,:GILDEDHELIX,:GILDEDARROW,:HYDROPUMP,:GILDEDARROW,:HYDRODASH,:SOAK,:CURSE,:TRICKORTREAT,:DISABLE,:LEECHSEED,:EXTREMESPEED,:GIGAIMPACT,:BOOMBURST,:EARTHQUAKE,:GIGAQUAKE,:FISSURE,:HIGHHORSEPOWER,:RAZORWIND,:GUST,:WATERSPOUT,:AQUATAIL,:CRABHAMMER,:DIVE,:WATERFALL,:RAZORSHELL,:AQUAJET,:CLAMP,:OCEANDASH,:WATERSHURIKEN,:ORIGINPULSE,:STEAMERUPTION,:LIQUIDATION,:SPARKLINGARIA,:SNIPESHOT,:FISHIOUSREND,:SURGINGSTRIKES,:WAVECRASH,:AQUACUTTER,:POWERDIVE],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :CAMERUPT,
	        :level => 87,
	        :item => :COBABERRY,
	        :moves => [:GIGADRAIN,:ERUPTION,:LANDSHAKING,:HELLFIRESTORM],
	        :ability => :BERSERK,
	        :nature => :QUIET,
            :iv => 32,
            :ev => [252, 252, 252, 252, 252, 0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :movesetUpdate => [:FLAMETHROWER,:LANDSHAKING,:BUBBLEBOIL,:DRAGONBREATH],
                :itemchange => :KEEBERRY,
                :abilitychange => :MOLDBREAKER,
            },
        }
    },
     :RYLANDINSANE => {
        :name => "Eternatus",
        :shieldCount => 1,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:FUSIONBOLT,:STOKEDSPARKSURFER,:SUPERFANG,:PLASMAVOLT,:GILDEDHELIX,:GILDEDARROW,:AXEKICK,:THUNDERRAID,:WILDBOLTSTORM,:SANDSEARSTORM,:BOLTSTRIKE,:WARCRY,:AIRCUTTER,:WAKEUPSHOCK,:VOLTTACKLE,:BOLTBEAK,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:DRILLRUN,:GIGAQUAKE,:FISSURE,:RAGINGTHUNDER,:RAGINGFLAMES,:CLOUDBURST,:ERUPTION,:WATERSPOUT,:GILDEDHELIX,:GILDEDARROW,:BONERUSH,:EXTREMESPEED,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO,:RISINGVOLTAGE,:ZAPCANNON,:THUNDER,:GLIDINGBOLTSTORM,:ALLOUTPUMMELING,:TECTONICRAGE,:GIGAVOLTHAVOC,:BREAKATTACK,:FOCUSPUNCH,:HIJUMPKICK,:CLOSECOMBAT,:CHISTRIKE,:DYNAMICPUNCH,:MACHPUNCH,:GALESTRIKE],
            :fieldEffectDamage => []
        },

        
        :moninfo => {
            :species => :ETERNATUS,
            :level => 91,
	        :moves => [:IRRITATION,:HEX,:ECHOEDVOICE,:DRAGONBREATH],
            :ability => :TOXIFICATE,
            :nature => :MODEST,
            :item => :WEAKNESSPOLICY,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252],
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :formchange => 1,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :movesetUpdate => [:IRRITATION,:HEX,:TOXICSTORM,:DRAGONBREATH],
                :itemchange => :SITRUSBERRY,
                :abilitychange => :CORROSION,
            },
        }
    },
    :SAKIINSANE => {
        :name => "ANYTHING GOES",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:FUSIONBOLT,:STOKEDSPARKSURFER,:SUPERFANG,:PLASMAVOLT,:GILDEDHELIX,:GILDEDARROW,:AXEKICK,:FOCUSBLAST,:THUNDERRAID,:WILDBOLTSTORM,:SANDSEARSTORM,:BOLTSTRIKE,:WARCRY,:AIRCUTTER,:WAKEUPSHOCK,:VOLTTACKLE,:BOLTBEAK,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:DRILLRUN,:GIGAQUAKE,:FISSURE,:RAGINGTHUNDER,:RAGINGFLAMES,:CLOUDBURST,:ERUPTION,:WATERSPOUT,:GILDEDHELIX,:GILDEDARROW,:BONERUSH,:EXTREMESPEED,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO,:RISINGVOLTAGE,:ZAPCANNON,:THUNDER,:GLIDINGBOLTSTORM,:ALLOUTPUMMELING,:TECTONICRAGE,:GIGAVOLTHAVOC,:BREAKATTACK,:FOCUSPUNCH,:HIJUMPKICK,:CLOSECOMBAT,:CHISTRIKE,:DYNAMICPUNCH,:MACHPUNCH,:GALESTRIKE],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :GX3810,
        	:level => 103,
	        :item => :ASSAULTVEST,
            :moves => [:HYDROCANNON,:SUNSTEELSTRIKE,:GIGAQUAKE,:SLASHANDBURN],
            :ability => :MOLDBREAKER,
	        :nature => :CAREFUL,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
        }
    },
    #Extreme end of insane mode
    #Extreme begin of ember village
    :VENAMSEVIPER => {
        :name => "Seviper",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:PYROKINESIS,:JUDGMENT,:HEAVENLYWING,:CLEARSMOG,:BODYSLAM,:TAILSLAP,:EXPLOSION,:FLAMETHROWER,:VCREATE,:BLASTBURN,:ERUPTION,:OVERHEAT,:BLUEFLARE,:FIREBLAST,:FLAREBLITZ,:DIVEBOMB,:MAGMASTORM,:FUSIONFLARE,:HEATWAVE,:INFERNO,:SACREDFIRE,:SEARINGSHOT,:BLAZEKICK,:FIERYDANCE,:LAVAPLUME,:FIREPUNCH,:FLAMEBURST,:FIREFANG,:FLAMEWHEEL,:FIREPLEDGE,:FLAMECHARGE,:EMBER,:FIRESPIN,:INCINERATE,:HEATCRASH,:WILLOWISP,:MYSTICALFIRE,:HIDDENPOWER,:BEAKBLAST,:BURNUP,:FIRELASH,:SHELLTRAP,:CRIMSONBLADE,:MINDBLOWN,:HEATPRESS,:PYROBALL,:BURNINGJEALOUSY,:INFERNALPARADE,:RAGINGFURY,:FEVERPITCH,:FINALFLAME,:MAGMADRIFT,:SOLARFLARE,:INFERNOOVERDRIVE,:BURSTRUSH,:FIREARROWS,:BRANDISHBUSTER,:GRANDFIRE,:RAGINGFLAMES,:RAGINGTHUNDER,:BLAZINGFANG,:PYROGLARE,:IGNISCRUSHER,:FOXFIRE,:BUBBLEBOIL,:SELFDESTRUCT,:GIGAIMPACT,:HYPERBEAM,:LASTRESORT,:DOUBLEEDGE,:HEADCHARGE,:SKULLBASH,:HYPERVOICE,:TAKEDOWN,:BODYSLAM,:TECHNOBLAST,:EXTREMESPEED,:HYPERFANG,:RAZORWIND,:STRENGTH,:TRIATTACK,:CRUSHCLAW,:RELICSONG,:CHIPAWAY,:DIZZYPUNCH,:FACADE,:HEADBUTT,:RETALIATE,:SECRETPOWER,:SLASH,:HORNATTACK,:STOMP,:COVET,:ROUND,:SMELLINGSALTS,:SWIFT,:TACKLE,:WEATHERBALL,:ECHOEDVOICE,:PAYDAY,:POUND,:QUICKATTACK,:SCRATCH,:DOUBLEHIT,:TAILSLAP,:FRUSTRATION,:FRIENDBEAM,:WONDERTACKLE,:REVELATIONDANCE,:RUSHATTACK,:BOOMBURST,:MEFIRST,:COPYCAT,:TERRAINPULSE,:JUSTICEBLADE,:MULTIATTACK,:MULTIPULSE,:PSYCHIC,:SHATTEREDPSYCHE,:EXPANDINGFORCE,:PSYSWITCH,:FLASH,:DREAMEATER,:FUTURESIGHT,:GILDEDHELIX,:GILDEDARROW,:FUTUREDUMMY,:PSYSTRIKE,:EXTRASENSORY,:LUSTERPURGE,:MISTBALL,:PSYCHOCUT,:SYNCHRONOISE,:PSYBEAM,:HEARTSTAMP,:CONFUSION,:PSYWAVE,:HIDDENPOWER,:HYPERSPACEHOLE,:PSYCHICFANGS,:PHOTONGEYSER,:EXPANDINGFORCE,:FREEZINGGLARE,:EERIESPELL,:PSYSHIELDBASH,:RISINGVOLTAGE,:PSYSHOCK,:ZENHEADBUTT,:PSYCHOBOOST,:PSYBEAM,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:STOKEDSPARKSURFER,:SUPERFANG,:PLASMAVOLT,:AXEKICK,:THUNDERRAID,:WILDBOLTSTORM,:SANDSEARSTORM,:BOLTSTRIKE,:WARCRY,:AIRCUTTER,:WAKEUPSHOCK,:VOLTTACKLE,:BOLTBEAK,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:HEADLONGRUSH,:DRILLRUN,:GIGAQUAKE,:FISSURE,:RAGINGTHUNDER,:RAGINGFLAMES,:CLOUDBURST,:ERUPTION,:WATERSPOUT,:GILDEDHELIX,:GILDEDARROW,:BONERUSH,:EXTREMESPEED,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO,:RISINGVOLTAGE,:ZAPCANNON,:THUNDER,:GLIDINGBOLTSTORM,:ALLOUTPUMMELING,:TECTONICRAGE,:GIGAVOLTHAVOC,:EARTHQUAKE,:EARTHPOWER,:DIG,:DRILLRUN,:BONECLUB,:MUDBOMB,:BULLDOZE,:MUDSHOT,:BONEMERANG,:SANDTOMB,:BONERUSH,:MUDSLAP,:FISSURE,:MAGNITUDE,:PRECIPICEBLADES,:THOUSANDARROWS,:LANDSHAKING,:THOUSANDWAVES,:HIGHHORSEPOWER,:STOMPINGTANTRUM,:SCORCHINGSANDS,:HEADLONGRUSH,:SANDSEARSTORM,:MUDBARRAGE,:TECTONICRAGE,:GIGAQUAKE,:DUSTJAVELIN],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :SEVIPER,
        	:level => 103,
	        :item => :ASSAULTVEST,
            :moves => [:EXTREMESPEED,:VENAMSKISS,:FLAREBLITZ,:HEADLONGRUSH],
            :ability => :MOLDBREAKER,
	        :nature => :BRAVE,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
        }
    },
        :AMBERZARD => {
        :name => "Dark Charizard",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:ACCELEROCK,:STONEEDGE,:JUDGMENT,:BODYSLAM,:HEAVENLYWING,:CLEARSMOG,:TAILSLAP,:EXPLOSION,:SELFDESTRUCT,:GIGAIMPACT,:HYPERBEAM,:LASTRESORT,:DOUBLEEDGE,:HEADCHARGE,:SKULLBASH,:HYPERVOICE,:TAKEDOWN,:BODYSLAM,:TECHNOBLAST,:EXTREMESPEED,:HYPERFANG,:RAZORWIND,:STRENGTH,:TRIATTACK,:CRUSHCLAW,:RELICSONG,:CHIPAWAY,:DIZZYPUNCH,:FACADE,:HEADBUTT,:RETALIATE,:SECRETPOWER,:SLASH,:HORNATTACK,:STOMP,:COVET,:ROUND,:SMELLINGSALTS,:SWIFT,:TACKLE,:WEATHERBALL,:ECHOEDVOICE,:PAYDAY,:POUND,:QUICKATTACK,:SCRATCH,:DOUBLEHIT,:TAILSLAP,:FRUSTRATION,:FRIENDBEAM,:WONDERTACKLE,:REVELATIONDANCE,:RUSHATTACK,:BOOMBURST,:MEFIRST,:COPYCAT,:TERRAINPULSE,:JUSTICEBLADE,:JUDGMENT,:MULTIATTACK,:MULTIPULSE,:EARTHPOWER,:CONTINENTALCRUSH,:SUPERPOWER,:ANCIENTPOWER,:ZENHEADBUTT,:EXPANDINGFORCE,:GILDEDHELIX,:GILDEDARROW,:RISINGVOLTAGE,:PSYCHOBOOST,:PSYBEAM,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:STOKEDSPARKSURFER,:SUPERFANG,:PLASMAVOLT,:AXEKICK,:THUNDERRAID,:WILDBOLTSTORM,:SANDSEARSTORM,:BOLTSTRIKE,:WARCRY,:AIRCUTTER,:WAKEUPSHOCK,:VOLTTACKLE,:BOLTBEAK,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:DRILLRUN,:GIGAQUAKE,:FISSURE,:RAGINGTHUNDER,:RAGINGFLAMES,:CLOUDBURST,:ERUPTION,:WATERSPOUT,:GILDEDHELIX,:GILDEDARROW,:BONERUSH,:EXTREMESPEED,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO,:RISINGVOLTAGE,:ZAPCANNON,:THUNDER,:GLIDINGBOLTSTORM,:ALLOUTPUMMELING,:TECTONICRAGE,:GIGAVOLTHAVOC,:BREAKATTACK,:FOCUSPUNCH,:HIJUMPKICK,:CLOSECOMBAT,:CHISTRIKE,:DYNAMICPUNCH,:MACHPUNCH,:GALESTRIKE,:EXTREMESPEED,:COLDTRUTH,:NORTHERNIMPACT,:FREEZESHOCK,:BLIZZARD,:ICEBEAM,:ICICLECRASH,:ICEPUNCH,:AURORABEAM,:GLACIATE,:AVALANCHE,:ICYWIND,:FROSTBREATH,:ICESHARD,:ICEBALL,:ICICLECSPEAR,:SHEERCOLD,:SPIKECANNON,:FREEZEDRY,:HIDDENPOWERICE,:ICEHAMMER,:TRIPLEAXEL,:GLACIALLANCE,:MOUNTAINGALE,:HYPERVOICE,:HYPERBEAM,:DOUBLEEDGE,:BOOMBURST,:HIJUMPKICK,:CLOSECOMBAT,:FOCUSBLAST,:SUPERPOWER,:CROSSCHOP,:DYNAMICPUNCH,:JUMPKICK,:HAMMERARM,:AURASPHERE,:SACREDSWORD,:SECRETSWORD,:SKYUPPERCUT,:SUBMISSION,:VITALTHROW,:CIRCLETHROW,:LOWSWEEP,:ROLLINGKICK,:WAKEUPSLAP,:KARATECHOP,:MACHPUNCH,:VACUUMWAVE,:STORMTHROW,:ARMTHRUST,:TRIPLEKICK,:LOWKICK,:REVERSAL,:POWERUPPUNCH,:BODYPRESS,:METEORASSAULT,:THUNDEROUSKICK,:TRIPLEARROWS,:AXEKICK,:GALESTRIKE,:STACKINGSHOT,:EARTHQUAKE,:EARTHPOWER,:DIG,:DRILLRUN,:BONECLUB,:MUDBOMB,:BULLDOZE,:MUDSHOT,:BONEMERANG,:SANDTOMB,:BONERUSH,:MUDSLAP,:FISSURE,:MAGNITUDE,:PRECIPICEBLADES,:THOUSANDARROWS,:LANDSHAKING,:THOUSANDWAVES,:HIGHHORSEPOWER,:STOMPINGTANTRUM,:SCORCHINGSANDS,:HEADLONGRUSH,:SANDSEARSTORM,:MUDBARRAGE,:TECTONICRAGE,:GIGAQUAKE,:DUSTJAVELIN,:CHARGEDWHIP,:THUNDER,:VOLTTACKLE,:ZAPCANNON,:FUSIONBOLT,:THUNDERBOLT,:WILDCHARGE,:SPARK,:ELECTROWEB,:CHARGEBEAM,:ELECTROBALL,:AIRCUTTER,:FURYSWIPES,:WRAP,:PARABOLICCHARGE,:NUZZLE,:ZINGZAP,:PLASMAFISTS,:BOLTBEAK,:AURAWHEEL,:OVERDRIVE,:THUNDERCAGE,:ROCKCLIMB,:HEADSMASH,:ROCKWRECKER,:STONEEDGE,:ROCKSLIDE,:POWERGEM,:ANCIENTPOWER,:ROCKTOMB,:SMACKDOWN,:SACREDSWORD,:ROLLOUT,:ROCKBLAST,:DIAMONDSTORM,:ACCELEROCK,:METEORBEAM,:STONEAXE,:MATRIXSHOT,:ANCIENTFANGS,:METEORSHOWER,:GEMBURST,:TAILSMASH],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :CHARIZARD,
            :level => 102,
            :item => :PASSHOBERRY,
            :moves => [:CONTFIREBALL,:CRIMSONBLADE,:THUNDERRAID,:GIGAQUAKE],
            :ability => :INFERNALREIGN,
            :nature => :JOLLY,
            :form => 4,
            :iv => 31,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
        }
    },
    :AELITASCYTHER => {
        :name => "Scyther",
        :shieldCount => 0,
        :immunities => {
             :moves => [:WILLOWISP,:ACCELEROCK,:FLAMETHROWER,:VCREATE,:BLASTBURN,:HEAVENLYWING,:CLEARSMOG,:ERUPTION,:OVERHEAT,:BLUEFLARE,:FIREBLAST,:FLAREBLITZ,:DIVEBOMB,:MAGMASTORM,:FUSIONFLARE,:HEATWAVE,:INFERNO,:SACREDFIRE,:SEARINGSHOT,:BLAZEKICK,:FIERYDANCE,:LAVAPLUME,:FIREPUNCH,:FLAMEBURST,:FIREFANG,:FLAMEWHEEL,:FIREPLEDGE,:FLAMECHARGE,:EMBER,:FIRESPIN,:INCINERATE,:HEATCRASH,:WILLOWISP,:MYSTICALFIRE,:HIDDENPOWER,:BEAKBLAST,:BURNUP,:FIRELASH,:SHELLTRAP,:CRIMSONBLADE,:MINDBLOWN,:HEATPRESS,:PYROBALL,:BURNINGJEALOUSY,:INFERNALPARADE,:RAGINGFURY,:FEVERPITCH,:FINALFLAME,:MAGMADRIFT,:SOLARFLARE,:INFERNOOVERDRIVE,:BURSTRUSH,:FIREARROWS,:BRANDISHBUSTER,:GRANDFIRE,:RAGINGFLAMES,:RAGINGTHUNDER,:BLAZINGFANG,:PYROGLARE,:IGNISCRUSHER,:FOXFIRE,:BUBBLEBOIL,:JUDGMENT,:BODYSLAM,:TAILSLAP,:EXPLOSION,:SELFDESTRUCT,:GIGAIMPACT,:HYPERBEAM,:LASTRESORT,:DOUBLEEDGE,:HEADCHARGE,:SKULLBASH,:HYPERVOICE,:TAKEDOWN,:BODYSLAM,:TECHNOBLAST,:EXTREMESPEED,:HYPERFANG,:RAZORWIND,:STRENGTH,:TRIATTACK,:CRUSHCLAW,:RELICSONG,:CHIPAWAY,:DIZZYPUNCH,:FACADE,:HEADBUTT,:RETALIATE,:SECRETPOWER,:SLASH,:HORNATTACK,:STOMP,:COVET,:ROUND,:SMELLINGSALTS,:SWIFT,:TACKLE,:WEATHERBALL,:ECHOEDVOICE,:PAYDAY,:POUND,:QUICKATTACK,:SCRATCH,:DOUBLEHIT,:TAILSLAP,:FRUSTRATION,:FRIENDBEAM,:WONDERTACKLE,:REVELATIONDANCE,:RUSHATTACK,:BOOMBURST,:MEFIRST,:COPYCAT,:TERRAINPULSE,:JUSTICEBLADE,:FINALFLAME,:JUDGMENT,:MULTIATTACK,:MULTIPULSE,:SEARINGSHOT,:INFERNOOVERDRIVE,:FIREBLAST,:HEATWAVE,:EXPANDINGFORCE,:GILDEDHELIX,:GILDEDARROW,:RISINGVOLTAGE,:PYROBALL,:VCREATE,:BLUEFLARE,:FUSIONFLARE,:STONEEDGE,:ANCIENTPOWER,:ZENHEADBUTT,:PSYCHOBOOST,:PSYBEAM,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:STOKEDSPARKSURFER,:SUPERFANG,:PLASMAVOLT,:AXEKICK,:THUNDERRAID,:WILDBOLTSTORM,:SANDSEARSTORM,:BOLTSTRIKE,:WARCRY,:AIRCUTTER,:WAKEUPSHOCK,:VOLTTACKLE,:BOLTBEAK,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:DRILLRUN,:GIGAQUAKE,:FISSURE,:RAGINGTHUNDER,:RAGINGFLAMES,:CLOUDBURST,:ERUPTION,:WATERSPOUT,:GILDEDHELIX,:GILDEDARROW,:BONERUSH,:EXTREMESPEED,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO,:RISINGVOLTAGE,:ZAPCANNON,:THUNDER,:GLIDINGBOLTSTORM,:ALLOUTPUMMELING,:TECTONICRAGE,:GIGAVOLTHAVOC,:BREAKATTACK,:FOCUSPUNCH,:HIJUMPKICK,:CLOSECOMBAT,:CHISTRIKE,:DYNAMICPUNCH,:MACHPUNCH,:GALESTRIKE],
            :fieldEffectDamage => []
        },
        :moninfo => {
                :species => :SCYTHER,
                :level => 101,
                :item => :EVIOLITE,
                :moves => [:DRILLPECK,:FIRSTIMPRESSION,:XSCISSOR,:CRUSHCLAW],
                :ability => :SHARPNESS,
                :nature => :ADAMANT,
                :form => 1,
                :iv => 31,
                :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
        }
    },

    #Extreme this is the Deoxys fight in Past Aevium 2 
    :DEXOYTHEGOAT => {
        :name => "CODE: Universe",
        :entryText => "Inspects you with a challenging look.",
        :shieldCount => 5,
        :immunities => {
            :moves => [:FAKEOUT,:PRECIPICEBLADES,:EARTHQUAKE,:HEAVENLYWING,:EXTREMESPEED,:GILDEDHELIX,:SUCKERPUNCH,:GILDEDHELIX,:GILDEDARROW,:RISINGVOLTAGE,:THUNDER,:HAZE,:POWERSWAP,:SPEEDSWAP,:GUARDSWAP,:PSYCHUP,:HIGHHORSEPOWER,:DARKPULSE,:NIGHTDAZE,:WICKEDBLOW,:BIND,:CRUNCH,:THUNHDER,:BLIZZARD,:HYDROPUMP,:WILLOWISP,:SCALD,:SOAK,:CURSE,:TRICKORTREAT,:DISABLE,:LEECHSEED,:SACREDFIRE,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :DEOXYS,
            :level => 80,
            :item => :CLEARAMULET,
            :moves => [:WICKEDBLOW,:FOCUSBLAST,:GIGAQUAKE,:PSYCHOBOOST],
            :ability => :MOLDBREAKER,
            :nature => :HASTY,
            :shiny => true,
            :iv => 31,
            :happiness => 255,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 7",
        :continuous => true,
        :totalMonCount => 6,
        :moninfos => {
            1 => {
               :species => :REGIELEKI,
                :level => 70,
                :item => :ABILITYSHIELD,
                :moves => [:MEMENTO,:TAUNT,:TORMENT,:RAGINGTHUNDER],
                :ability => :MOLDBREAKER,
                :nature => :TIMID,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
            },
            2 => {
                :species => :CAMERUPT,
                :level => 70,
                :item => :PASSHOBERRY,
                :moves => [:RAGEPOWDER,:MEMENTO],
                :ability => :POWERSPOT,
                :nature => :BOLD,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                
                },
            3 => {
                :species => :MEW,
                :level => 70,
                :item => :LIGHTCLAY,
                :moves => [:LIGHTSCREEN,:MEMENTO,:REFLECT],
                :ability => :INTIMIDATE,
                :nature => :TIMID,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
               4 => {
                :species => :COSMOEM,
                :level => 70,
                :item => :EVIOLITE,
                :moves => [:HELPINGHAND,:FOULPLAY,:LIGHTSCREEN,:REFLECT],
                :ability => :POWERSPOT,
                :nature => :BOLD,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
               5 => {
                :species => :BLISSEY,
                :level => 70,
                :item => :ROCKYHELMET,
                :moves => [:PAINSPLIT,:HELPINGHAND,:FOLLOWME,:POLLENPUFF],
                :ability => :STAMINA,
                :nature => :BOLD,
                :iv => 31,
                :happiness => 255,
                :ev => [252,252,252,252,252,252]
                },
                },
              },
        :onBreakEffects => {
            5 => {
                :message => "Deoxys reforms its DNA and starts heating up its body!", # message that plays when shield is broken
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :VOLCANICTOP, # field changes
                :fieldChangeMessage => "The heat intensifies!", # message that plays when the field is changes
                :abilitychange => :DNAMATTER, # ability to change to upon shieldbreaker
                :movesetUpdate => [:MAGMADRIFT,:PSYSHOCK,:DYNAMICPUNCH,:STEAMERUPTION],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :AIRBALLOON,
                :stateChanges => :ELECTERRAIN, # handles state changes found in the Battle_Global class(in Battle_ActiveSide file + Trick Room
                :stateChangeAnimation => :ELECTRICTERRAIN, # state change animation
                :stateChangeCount => 3, # state change turncount
                :stateChangeMessage => "The dimensions created a thin layer of electricity!", # statechange messages
                :weatherChange => :SUNNYDAY, # weather to apply
                :weatherCount => 5, # weather turncount
                :weatherChangeMessage => "The sunlight intensifies!", # weather message
                :weatherChangeAnimation => "Sunny", # string of "Rain", "Sunny","Hail","Sandstorm"
                :bossStatChanges => { # any statboosts that are given
                    PBStats::DEFENSE => 3,
                    PBStats::SPDEF => 3,
                    PBStats::ACCURACY => 3,
                },
            },
            4 => {
                :message => "Deoxys resets its DNA and infuses itself with a chunk of meteorite!", # message that plays when shield is broken
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :ROCKY, # field changes
                :fieldChangeMessage => "The solid ground intensifies!", # message that plays when the field is changes
                :abilitychange => :SOLIDROCK, # ability to change to upon shieldbreaker
                :stateChanges => :DESERT, # handles state changes found in the Battle_Global class(in Battle_ActiveSide file + Trick Room
                :stateChangeAnimation => :SANDTOMB, # state change animation
                :stateChangeCount => 3, # state change turncount
                :stateChangeMessage => "The dimensions created a thin layer of sand!", # statechange messages
                :movesetUpdate => [:NEEDLEARM,:DIG,:GALESTRIKE,:SCALD],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :SITRUSBERRY,
                :typeChange => [:PSYCHIC,:ROCK], 
                :weatherChange => :SANDSTORM, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The Sand intensifies!", # weather message
                :weatherChangeAnimation => "Sandstorm", # string of "Rain", "Sunny","Hail","Sandstorm"
                :bossStatChanges => { # any statboosts that are given
                    PBStats::DEFENSE => -3,
                    PBStats::SPDEF => -3,
                },
            },
            3 => {
                :message => "Deoxys reforms its DNA and starts radiating water and electrifying storms!", # message that plays when shield is broken
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :STORMY, # field changes
                :fieldChangeMessage => "The storm intensifies!", # message that plays when the field is changes
                :abilitychange => :DNAMATTER, # ability to change to upon shieldbreaker
                :movesetUpdate => [:THUNDERPULSE,:AURASPHERE,:PSYCHIC,:RAZORWIND],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :EXPERTBELT,
                :stateChanges => :SWAMP, # handles state changes found in the Battle_Global class(in Battle_ActiveSide file + Trick Room
                :stateChangeAnimation => :MUDSHOT, # state change animation
                :stateChangeCount => 3, # state change turncount
                :stateChangeMessage => "The dimensions created a thin layer of electricity!", # statechange messages
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The Rain intensifies!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
                :bossStatChanges => { # any statboosts that are given
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,
                    PBStats::ACCURACY => 1,
                },
            },
            2 => {
                :message => "Deoxys reforms its DNA and unleashes a cold aura!", # message that plays when shield is broken
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :FROZENDIMENSION, # field changes
                :fieldChangeMessage => "The storm intensifies!", # message that plays when the field is changes
                :abilitychange => :DNAMATTER, # ability to change to upon shieldbreaker
                :movesetUpdate => [:SHEERCOLD,:FREEZEDRY,:PSYSTRIKE,:DOOMSDAY],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ICICLEPLATE,
                :weatherChange => :HAIL, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The Hail intensifies!", # weather message
                :weatherChangeAnimation => "Hail", # string of "Rain", "Sunny","Hail","Sandstorm"
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPEED => 3,
                    PBStats::ACCURACY => 1,
                },
            },
            1 => {
                :message => "Deoxys DNA string implodes and it loses control!", # message that plays when shield is broken
                :threshold => 0,
                :effectClear => true,
                :fieldChange => :INFERNAL, # field changes
                :fieldChangeMessage => "The battlefield starts to combust with evil energy!", # message that plays when the field is changes
                :abilitychange => :UNAWARE, # ability to change to upon shieldbreaker
                :movesetUpdate => [:SHADOWSTORM,:VCREATE],
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :LIFEORB,
                :typeChange => [:PSYCHIC,:FLYING], 
                :weatherChange => :SHADOWSKY, # weather to apply
                :weatherCount => 10, # weather turncount
                :weatherChangeMessage => "The weather gets corrupted by Shadow!", # weather message
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPEED => -2,
                },
            },
        } 
    },
    #Extreme this is for .kf regi quests
    :FELS => {
        :name => "Regirock",
        :entryText => "You are wasting your time Interceptor.",
        :shieldCount => 1,
        :immunities => {
             :moves => [:FAKEOUT,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:WILLOWISP,:SCALD,:SOAK,:CURSE,:TRICKORTREAT,:DISABLE,:LEECHSEED,:PYROKINESIS,:LAVAPLUME,:SACREDFIRE,:FLAMETHROWER,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :REGIROCK,
            :level => 120,
            :item => :GROUNDGEM,
            :moves => [:WICKEDBLOW,:FOCUSBLAST,:GIGAQUAKE,:HEADSMASH],
            :ability => :DAUNTLESSSHIELD,
            :nature => :NAUGHTY,
            :iv => 31,
            :happiness => 255,
            :form => 1,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ROCKIUMZ,
                :abilitychange => :ROCKHEAD,
            },
        }
    },
    :EISEN => {
        :name => "Registeel",
        :entryText => "Registeel is ready to take you down.",
        :shieldCount => 1,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:FUSIONBOLT,:STOKEDSPARKSURFER,:SUPERFANG,:PLASMAVOLT,:AXEKICK,:THUNDERRAID,:WILDBOLTSTORM,:SANDSEARSTORM,:BOLTSTRIKE,:WARCRY,:AIRCUTTER,:WAKEUPSHOCK,:VOLTTACKLE,:BOLTBEAK,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:DRILLRUN,:GIGAQUAKE,:FISSURE,:RAGINGTHUNDER,:RAGINGFLAMES,:CLOUDBURST,:ERUPTION,:WATERSPOUT,:GILDEDHELIX,:GILDEDARROW,:BONERUSH,:EXTREMESPEED,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO,:RISINGVOLTAGE,:ZAPCANNON,:THUNDER,:GLIDINGBOLTSTORM,:ALLOUTPUMMELING,:TECTONICRAGE,:GIGAVOLTHAVOC,:BREAKATTACK,:FOCUSPUNCH,:HIJUMPKICK,:CLOSECOMBAT,:CHISTRIKE,:DYNAMICPUNCH,:MACHPUNCH,:GALESTRIKE],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :REGISTEEL,
            :level => 120,
            :item => :STEELGEM,
            :moves => [:WICKEDBLOW,:DOUBLEIRONBASH,:GALESTRIKE,:HEADLONGRUSH],
            :ability => :DAUNTLESSSHIELD,
            :nature => :ADAMANT,
            :iv => 31,
            :happiness => 255,
            :form => 1,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :STEELIUMZ,
                :abilitychange => :FILTER,
            },
        }
    },
    :EIS => {
        :name => "Regice",
        :shieldCount => 1,
        :immunities => {
             :moves => [:WILLOWISP,:SCALD,:SOAK,:CURSE,:TOXIC,:TRICKORTREAT,:FUSIONBOLT,:STOKEDSPARKSURFER,:SUPERFANG,:PLASMAVOLT,:AXEKICK,:THUNDERRAID,:WILDBOLTSTORM,:SANDSEARSTORM,:BOLTSTRIKE,:WARCRY,:AIRCUTTER,:WAKEUPSHOCK,:VOLTTACKLE,:BOLTBEAK,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:DRILLRUN,:GIGAQUAKE,:FISSURE,:RAGINGTHUNDER,:RAGINGFLAMES,:CLOUDBURST,:ERUPTION,:WATERSPOUT,:GILDEDHELIX,:GILDEDARROW,:BONERUSH,:EXTREMESPEED,:SUCKERPUNCH,:DISABLE,:LEECHSEED,:INFERNO,:RISINGVOLTAGE,:ZAPCANNON,:THUNDER,:GLIDINGBOLTSTORM,:ALLOUTPUMMELING,:TECTONICRAGE,:GIGAVOLTHAVOC,:BREAKATTACK,:FOCUSPUNCH,:HIJUMPKICK,:CLOSECOMBAT,:CHISTRIKE,:DYNAMICPUNCH,:MACHPUNCH,:GALESTRIKE],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :REGICE,
            :level => 110,
            :item => :ICEGEM,
            :moves => [:THUNDERBOLT,:DARKPULSE,:PSYCHIC,:COLDTRUTH],
            :ability => :STAMINA,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
            :form => 1,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :ICIUMZ,
                :abilitychange => :ICESCALES,
            },
        }
    },

    :SABERDOG => {
        :name => "Luxray",
        :entryText => "Luxray is ready to take you down.",
        :shieldCount => 1,
        :immunities => {
             :moves => [:FAKEOUT,:PRECIPICEBLADES,:EARTHQUAKE,:HIGHHORSEPOWER,:WILLOWISP,:SCALD,:SOAK,:CURSE,:TRICKORTREAT,:DISABLE,:LEECHSEED,:PYROKINESIS,:LAVAPLUME,:SACREDFIRE,:FLAMETHROWER,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :LUXRAY,
            :level => 100,
            :item => :ELECTRICGEM,
            :moves => [:WICKEDBLOW,:JUSTICEBLADE,:FLAREBLITZ,:FISHIOUSREND],
            :ability => :INTREPIDSWORD,
            :nature => :JOLLY,
            :iv => 31,
            :happiness => 255,
            :shiny => true,
            :ev => [252, 252, 252, 252, 252, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Saber: FOR JUSTICE!",
                :formchange => 1,
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :LUXRITE,
                :bgmChange => "Battle - Warden15",
                :abilitychange => :TERAVOLT,
            },
        }
    },
    :IRONHELL => {
        :name => "Zacian",
        :entryText => "Zacian is ready to take you down.",
        :shieldCount => 1,
        :immunities => {
             :moves => [:FAKEOUT,:WILLOWISP,:SCALD,:PYROKINESIS,:LAVAPLUME,:SACREDFIRE,:FLAMETHROWER,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :ZACIAN,
            :level => 75,
            :item => :GROUNDGEM,
            :moves => [:BEHEMOTHBLADE,:DOUBLESLAP,:HEADLONGRUSH,:CLOSECOMBAT],
            :ability => :INTREPIDSWORD,
            :nature => :JOLLY,
            :iv => 31,
            :happiness => 255,
            :shiny => true,
            :ev => [100, 252, 100, 252, 100, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "V: Let's ramp this up!",
                :formchange => 1,
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :RUSTEDSWORD,
            },
        }
    },
    :IRONHELL2 => {
        :name => "Zamazenta",
        :entryText => "Zamazenta is ready to take you down.",
        :shieldCount => 1,
        :immunities => {
             :moves => [:FAKEOUT,:WILLOWISP,:SCALD,:PYROKINESIS,:LAVAPLUME,:SACREDFIRE,:FLAMETHROWER,:FIREBLAST,:INFERNO],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :ZAMAZENTA,
            :level => 75,
            :item => :FIGHTINGGEM,
            :moves => [:WARCRY,:BURSTRUSH,:FISSURE,:STEELBEAM],
            :ability => :DAUNTLESSSHIELD,
            :nature => :HASTY,
            :iv => 31,
            :happiness => 255,
            :shiny => true,
            :ev => [100, 252, 152, 252, 152, 252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "V: Come on!",
                :movesetUpdate => [:BEHEMOTHBASH,:HIGHHORSEPOWER,:HEADLONGRUSH,:CLOSECOMBAT],
                :formchange => 1,
                :statDropCure => true,
                :statusCure => true,
                :itemchange => :RUSTEDSHIELD,
            },
        }
    },
    :DOXIE => {
        :name => "Doxie",
        :entryText => "Doxie is hungry.",
        :shieldCount => 7,
        :immunities => {},
        :moninfo => {
            :species => :MARSHADOW,
            :level => 100,
            :moves => [:SPECTRALTHIEF,:DRAINPUNCH,:SHADOWSNEAK,:SHADOWBALL],
            :ability => :TECHNICIAN,
            :item => :LEPPABERRY,
            :gender => "M",
            :nature => :JOLLY,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
        :onBreakEffects => {
            6 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :fieldChange => :HAUNTED, # field changes
                :itemchange => :LEPPABERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 2,
                    PBStats::SPATK => 2,
                }
            },
            5 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :fieldChange => :HAUNTED, # field changes
                :itemchange => :LEPPABERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 2,
                    PBStats::SPATK => 2,
                }
            },
            4 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :fieldChange => :HAUNTED, # field changes
                :effectClear => true,
                :itemchange => :LEPPABERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 3,
                    PBStats::SPATK => 3,
                }
            },
            3 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :fieldChange => :HAUNTED, # field changes
                :abilitychange => :MOLDBREAKER,
                :itemchange => :LEPPABERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 4,
                    PBStats::SPATK => 4,
                }
            },
            2 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :fieldChange => :HAUNTED, # field changes
                :effectClear => true,
                :itemchange => :LEPPABERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 5,
                    PBStats::SPATK => 5,
                }
            },
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :fieldChange => :HAUNTED, # field changes
                :abilitychange => :MOLDBREAKER,
                :itemchange => :LEPPABERRY,
                :effectClear => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 6,
                    PBStats::DEFENSE => 2,
                    PBStats::SPATK => 6,
                    PBStats::SPDEF => 2,
                    PBStats::SPEED => 6,
                }
            },
        },
    },
##############################
# Easy Bosses
##############################
    :BOSSGARBODOR_EASY => {
        :name => "Garbage Menace",
        :entryText => "The Garbage Crew approached!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GARBODOR,
            :level => 10,
            :moves => [:POUND,:ACIDSPRAY,:DOUBLESLAP,:ATTRACT],
            :ability => :STENCH,
            :gender => "M",
            :shiny => true,
            :nature => :NAUGHTY,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 1",
            :totalMonCount => 2,
            :moninfos => {
                1 => {
                    :species => :TRUBBISH,
                    :level => 9,
                    :moves => [:POUND,:POISONGAS,:THIEF,nil],
                    :ability => :STENCH,
                    :iv => 10,
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Garbodor's typing changed!",
                :animation => :NASTYPLOT,
                :typeChange => [:POISON,:DARK],
            },
        }
    },

    :RIFTGYARADOS1_EASY => {
        :name => "Rift Gyarados",
        :entryText => "Rift Gyarados attacked in a rage!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :GYARADOS,
            :level => 18,
            :form => 4,
            :moves => [:SHADOWSNEAK,:BITE,:WATERGUN,:LEER],
            :ability => :INTIMIDATE,
            :gender => "M",
            :nature => :NAUGHTY,
            :iv => 10,
            :happiness => 255,
            :ev => [0,0,0,0,0,0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Rift Gyarados started acting defensive!",
                :animation => :WITHDRAW,
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => 1
                }
            }
        }
    },
    :BOSSPYROAR_EASY => {
        :name => "Pride King",
        :entryText => "The freshly evolved Pyroar attacked!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :PYROAR,
            :level => 15,
            :moves => [:TAKEDOWN,:NOBLEROAR,:FIREFANG,:ROAR],
            :ability => :UNNERVE,
            :gender => "M",
            :nature => :NAUGHTY,
            :iv => 10,
            :happiness => 255,
            :ev => [0,0,0,0,0,0],
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 1",
            :continuous => true,
            :moninfos => {
                1 => {
                    :species => :LITLEO,
                    :level => 12,
                    :moves => [:EMBER,:HEADBUTT,:LEER,:WORKUP],
                    :ability => :UNNERVE,
                    :iv => 10,
                },
            },
        },
        :onBreakEffects => {
        },
    },
    :RIFTCHANDELURE_EASY => {
        :name => "Rift Chandelure",
        :entryText => "Otherworldly wind chimes echo through the air...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :CHANDELURE,
            :level => 55,
            :form => 2,
            :moves => [:SHADOWBALL,:HEX,:FIREBLAST,:WILLOWISP],
            :gender => "M",
            :nature => :TIMID,
            :happiness => 255,
        },
        :onEntryEffects => {
            :message => "A feeling of warmth emanates from Rift Chandelure...",
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :animation => :OMINOUSWIND,
                :message => "The air feels cold and moist...",
                :statDropRefresh => true,
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                },
                :typeChange => [:GHOST,:WATER],
                :movesetUpdate => [:SHADOWBALL,:HEX,:SURF,:WHIRLPOOL],
                :abilitychange => :TRACE
            },
            1 => {
                :threshold => 0,
                :animation => :OMINOUSWIND,
                :message => "A sickly sweet scent attacks your nose...",
                :statDropRefresh => true,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                },
                :typeChange => [:GHOST,:GRASS],
                :movesetUpdate => [:SHADOWBALL,:HEX,:ENERGYBALL,:LEECHSEED],
                :abilitychange => :TRACE
            },
        }
    },
    :SHADOWMEWTWO_EASY => {
        :name => "Shadow Mewtwo",
        :entryText => "Mewtwo's power is building up!",
        :shieldCount => 1,
        :immunities => {},
        :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
            :message => "KETA: We have to defeat it quickly or else...",
        },
        :chargeAttack => {
            :turns => 10,
            :chargingMessage => "Mewtwo is charging its attack...",
            :continueCharging => true,
            :canAttack => false,
            :intermediateattack => {
                :move => :SHADOWBEAM,
                :type => :SHADOW,
                :basedamage => 20,
                :name => "Shadow Beam",
                :category => 0,
                :target => :AllOpposing,
            }
        },
        :moninfo => {
            :species => :MEWTWO,
            :level => 27,
            :moves => [:SHADOWSNEAK],
            :ability => :PRESSURE,
            :nature => :HARDY,
            :iv => 20,
            :happiness => 0,
            :form => 3,
            :shadow => true,
            :ev => [20,20,20,20,20,20]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Shadow Mewtwo's power grows!",
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => -2,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => -2
                }
            }
        }
    },
    :RIFTGYARADOS2_EASY => {
        :name => "Rift Gyarados",
        :entryText => "Rift Gyarados is intent on revenge!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GYARADOS,
            :level => 31,
            :form => 4,
            :moves => [:PHANTOMFORCE,:WATERFALL,:BITE,:SCREECH],
            :ability => :INTIMIDATE,
            :gender => "M",
            :nature => :NAUGHTY,
            :iv => 20,
            :happiness => 255,
            :ev => [20,20,20,20,20,20],
            :BaseStats => [95,145,89,120,110,81]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Rift Gyarados's type changed!",
                :typeChange => [:WATER,:DRAGON],
                :movesetUpdate => [:DRAGONBREATH,:WATERFALL,:THUNDERFANG,:SCREECH],
                :fieldChange => :WATERSURFACE,
                :fieldChangeMessage => "Rift Gyarados dragged the battle to the lake!"
            },
            1 => {
                :threshold => 0,
                :message => "Rift Gyarados's type changed!",
                :typeChange => [:FIRE,:DRAGON],
                :movesetUpdate => [:DRAGONBREATH,:LAVAPLUME,:BITE,:SCREECH],
                :statDropCure => true,
                :fieldChange => :INFERNAL,
                :fieldChangeMessage => "Rift Gyarados conflagarated the arena!"
            }
        }
    },
    :PULSEMUSHARNA_EASY => {
        :name => "Pulse+ Musharna",
        :entryText => "The dangerous(?) Musharna attacked(?)!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :MUSHARNA,
            :level => 18,
            :form => 2,
            :moves => [:PSYBEAM,:DISARMINGVOICE,:CHARGEBEAM,:SWEETSCENT],
            :gender => "F",
            :nature => :DOCILE,
            :ability => :PASTELVEIL,
            :iv => 0,
            :happiness => 255,
            :ev => [0,0,0,0,0,0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :fieldChange => :MISTY,
                :fieldChangeMessage => "Pulse Musharna spread mist everywhere."
            }
        }
    },
    :PULSEMUSHARNA2_EASY => {
        :name => "Pulse+ Musharna",
        :entryText => "The dangerous(?) Musharna attacked(?) again!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :MUSHARNA,
            :level => 86,
            :form => 2,
            :item => :SITRUSBERRY,
            :moves => [:MISTBALL,:DAZZLINGGLEAM,:AURASPHERE,:SWEETSCENT],
            :gender => "F",
            :nature => :MODEST,
            :ability => :PASTELVEIL,
            :happiness => 255,
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :bosssideChanges => :Mist,
                :bosssideChangeAnimation => :MIST,
                :bosssideChangeCount => 3,
                :movesetUpdate => [:MISTBALL,:STRANGESTEAM,:MAGICALLEAF,:STUNSPORE],
                :message => "Pulse Musharna is laying lazily in the flowers...",
           },
            1 => {
                :threshold => 0,
                :bosssideChanges => :Safeguard,
                :bosssideChangeAnimation => :SAFEGUARD,
                :bosssideChangeCount => 3,
                :message => "Pulse Musharna became one with the bugs...",
                :typeChange => [:BUG,:FAIRY],
                :movesetUpdate => [:BUGBUZZ,:STRANGESTEAM,:MISTBALL,:MYSTICALFIRE],
                :delayedaction => {
                    :delay => 4,
                    :message => "Pulse Musharna let out a defend order!",
                    :animation => :DEFENDORDER,
                    :bossStatChanges => {
                        PBStats::DEFENSE => 1,
                        PBStats::SPDEF => 1,                  
                    },
                    :delayedaction => {
                        :delay => 4,
                        :message => "Pulse Musharna let out an attack order!",
                        :animation => :ATTACKORDER,
                        :bossStatChanges => {
                            PBStats::SPATK => 1,                
                        },
                        :delayedaction => {
                            :delay => 4,
                            :message => "Pulse Musharna let out a heal order!",
                            :animation => :HEALORDER,
                            :statusCure => true,
                            :statDropCure => true,
                            :effectClear => true,
                        }
                    }
                }
            },
        }
    },
    :BOSSGOTHITELLE_SHERIDAN_EASY => {
        :name => "Gothitelle",
        :entryText => "The mischievous Gothitelle laughs at you!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :GOTHITELLE,
            :level => 32,
            :form => 1,
            :moves => [:FAKETEARS,:PSYCHIC,:FLATTER,:DARKPULSE],
            :gender => "F",
            :nature => :MODEST,
            :ability => :SHADOWTAG,
            :happiness => 255,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                }
            }
        }
    },
    :CRESCGOTHITELLE_EASY => {
        :name => "Gothitelle",
        :entryText => "The mischievous Gothitelle laughs at you!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :GOTHITELLE,
            :level => 45,
            :form => 1,
            :moves => [:PLAYNICE,:PSYSHOCK,:FOCUSBLAST,:DARKPULSE],
            :gender => "F",
            :nature => :MODEST,
            :ability => :COMPETITIVE,
            :iv => 20,
            :happiness => 255,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :fieldChange => :PSYTERRAIN,
                :fieldChangeMessage => "Gothitelle laughs at how dumb your face looks. So mean!"
            }
        }
    },
    :KIERANXURK_1_EASY => {
        :name => "Xurkitree",
        :entryText => "Static electricity crackles in the air...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :XURKITREE,
            :level => 65,
            :form => 1,
            :moves => [:THUNDER,:ENERGYBALL,:DAZZLINGGLEAM,:TAILGLOW],
            :nature => :MODEST,
            :ability => :BEASTBOOST,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,0,252,0,252]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :fieldChange => :ELECTERRAIN,
                :fieldChangeMessage => "Xurkitree repositions itself."
            }
        }
    },
    :SEAPRINCE_EASY => {
        :name => "Manaphy", # nickname
        :entryText => "ODESSA: Witness the might of the seas!",
        :shieldCount => 3, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :MANAPHY,
            :level => 53,
            :item => :LEFTOVERS,
            :moves => [:SCALD,:SHADOWBALL,:RAINDANCE,:TAKEHEART],
            :ability => :HYDRATION,
            :nature => :MODEST,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 3,
        :moninfos => {
            1 => {
                :species => :PHIONE,
                :level => 45,
                :moves => [:SURF,:ENERGYBALL,:HELPINGHAND,:DAZZLINGGLEAM],
                :ability => :HYDRATION,
                :gender => "F",
                :nature => :MODEST,
                :happiness => 255,
            },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "ODESSA: The Prince of the Sea's tail shines bright. Be blinded by its glow!", # message that plays when shield is broken
                :animation => :TAILGLOW,
                :weatherChange => :RAINDANCE, # weather to apply
                :weatherCount => 5, # weather turncount
                :weatherChangeMessage => "The Rain pours down!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPATK => 1,
                },
                :delayedaction => {
                    :delay => 2,
                    :message => "The Prince's glowing tail starts to dim...",
                    :bossStatChanges => { 
                        PBStats::SPATK => -1,
                    },
                }
            },
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "ODESSA: The Prince can command the sea themselves. As such as a Prince should! Be purged by the sacred waters of Kristiline! ", # message that plays when shield is broken
                :abilitychange => :PRESSURE,
                :fieldChange => :WATERSURFACE, # field changes
                :fieldChangeMessage => "The battlefield was plunged underwater!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
            },
        }
    },  
    :RIFTGALVANTULA_EASY => {
        :name => "Rift Galvantula",
        :entryText => "Joltik swarm the egg...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GALVANTULA,
            :level => 22,
            :form => 2,
            :moves => [:ELECTROWEB,:BUGBITE,:CROSSPOISON,:TOXICTHREAD],
            :gender => "F",
            :nature => :HASTY,
            :ability => :PARENTALBOND,
            :iv => 20,
            :happiness => 255,
            :ev => [0,0,0,0,0,0]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 2",
            :continuous => true,
            :moninfos => {
                1 => {
                    :species => :JOLTIK,
                    :level => 17,
                    :moves => [:ELECTROWEB,:STRINGSHOT,:STRUGGLEBUG,nil],
                    :ability => :COMPOUNDEYES,
                    :form => 1,
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :formchange => 1,
                :message => "Rift Galvantula hatched out of the egg!",
                :movesetUpdate => [:ELECTROWEB,:BUGBITE,:CROSSPOISON,:SLUDGE],
                :statDropCure => true,
                :playersideChanges => :ToxicSpikes,
                :playersideChangeAnimation => :TOXICPSIKES,
                :playersideChangeMessage => "Broken eggshell was strewn everywhere!",
            },
        }
    },
    :RIFTVOLCANION_EASY => {
        :name => "Rift Volcanion",
        :entryText => "Rift Volcanion let out a languid grumble...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :VOLCANION,
            :level => 24,
            :form => 1,
            :moves => [:STEAMERUPTION,:FLAMETHROWER,:SCORCHINGSANDS,:ROCKSLIDE],
            :gender => "F",
            :nature => :LONELY,
            :iv => 0,
            :happiness => 255,
            :ev => [0,0,0,0,0,0]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Volcanion is losing motivation…",
                :movesetUpdate => [:SCALD,:INCINERATE,:MUDSHOT,:ROCKTOMB],
                :bossStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1                    
                }
            },
            1 => {
                :threshold => 0,
                :message => "Volcanion is losing motivation…",
                :movesetUpdate => [:WATERGUN,:EMBER,:MUDSLAP,:ROCKTHROW],
                :bossStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1                    
                }
            },
        }
    },
    :BOSSDUSKNOIR_EASY => {
        :name => "Dusknoir",
        :entryText => "The Dusknoir is threatening you.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :DUSKNOIR,
            :level => 28,
            :moves => [:SHADOWPUNCH,:WILLOWISP,:INFESTATION,:PAYBACK],
            :gender => "M",
            :nature => :ADAMANT,
            :iv => 20,
            :form => 1,
            :ev => [32,32,32,32,32,32]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Dusknoir is about to throw hands!",
                :movesetUpdate => [:SHADOWPUNCH,:WILLOWISP,:ICYWIND,:THUNDERPUNCH],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,                
                }
            },
        }
    },
    :WISPYGIRATINA_EASY => {
        :name => "Renegade Giratina",
        :entryText => "GEARA: Destroy them, Giratina! Show them the might of a Legendary Pokémon!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GIRATINA,
            :level => 33,
            :moves => [:SHADOWCLAW,:DRAGONBREATH,:SLASH,:SCARYFACE],
            :nature => :HARDY,
            :iv => 20,
			:form => 1,
            :ev => [32,32,32,32,32,32]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Giratina's ghastly aura lowered offenses!",
                :statDropCure => true,
                :playerSideStatChanges => {
                    PBStats::ATTACK => -1,               
                }
            },
            1 => {
                :threshold => 0,
                :message => "Giratina's aura enveloped the battlefield!",
                :bossStatChanges => {
                    PBStats::DEFENSE => -2,
                    PBStats::SPDEF => -2,                 
                },
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,                 
                }
            }
        }
    },
    :BOSSCROBAT_EASY => {
        :name => "Furious Bat",
        :entryText => "The Crobat attacked with furor!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :CROBAT,
            :level => 32,
            :moves => [:CROSSPOISON,:BITE,:WINGATTACK,:PROTECT],
            :ability => :INFILTRATOR,
            :gender => "F",
            :nature => :NAUGHTY,
            :item => :FLYINGGEM,
            :happiness => 255,
            :ev => [0,0,0,0,0,0],
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 10",
            :continuous => true,
            :moninfos => {
                1 => {
                    :species => :ZUBAT,
                    :level => 27,
                    :moves => [:CONFUSERAY,:POISONFANG,:THIEF,],
                    :ability => :INNERFOCUS,
                    :iv => 31,
                },
                2 => {
                    :species => :WOOBAT,
                    :level => 27,
                    :moves => [:CONFUSION,:CHARM,:AIRSLASH,],
                    :ability => :UNAWARE,
                    :iv => 31,
                },
                3 => {
                    :species => :NOIBAT,
                    :level => 27,
                    :moves => [:SUPERFANG,:WHIRLWIND,:AIRSLASH,],
                    :ability => :INFILTRATOR,
                    :iv => 31,
                },
            },
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :bosssideChanges => :Tailwind,
                :bosssideChangeAnimation => :TAILWIND,
                :bosssideChangeCount => 3,
                :movesetUpdate => [:ACROBATICS,:CROSSPOISON,:PROTECT,:UTURN],
                :statDropCure => true,
                :itemchange => :SITRUSBERRY,
            },
        },
    },
    :MADAMEXYVELTAL_EASY => {
        :name => "Yveltal",
        :entryText => "Yveltal looms above.",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :YVELTAL,
            :level => 75,
            :moves => [:DECIMATION,:HURRICANE,:FOCUSBLAST,nil],
            :nature => :MODEST,
            :ev => [0,0,0,0,0,0]
        },
    },
    :MYNORIKOKO => {
        :name => "Thunder Warrior",
        :shieldCount => 0,
        :immunities => { # any immunities to things 
             :moves => [:FAKEOUT,:SUCKERPUNCH,:MACHPUNCH,:ANCIENTPOWER,:LEAFSTORM,:LEECHSEED,:TOXIC,:THUNDERWAVE,:SOLARBEAM,:CURSE,:THUNDER,:FIRESPIN,:THUNDERBOLT,:EARTHQUAKE,:SCALD],
            :fieldEffectDamage => []
        },
        :moninfo => {
            :species => :TAPUKOKO,
            :level => 62,
            :shiny => true,
            :moves => [:THUNDERPULSE,:MAGMADRIFT,:MAGNETBOMB,:TAKEDOWN],
            :nature => :RASH,
            :item => :ELECTRIUMZ,
            :ability => :FLASHOFLIGHT,
            :iv => 31,
            :happiness => 255,
            :ev => [252,252,252,252,252,252]
        },
    },
    :BOSSCONKELDURR_EASY => {
        :name => "Strained Worker",
        :entryText => "Conkeldurr is agitated!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :CONKELDURR,
            :level => 45,
            :moves => [:CHIPAWAY,:ICEPUNCH,:FIREPUNCH,:THUNDERPUNCH],
            :ability => :IRONFIST,
            :gender => "M",
            :nature => :ADAMANT,
            :iv => 0,
            :happiness => 0,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 1",
            :continuous => true,
            :moninfos => {
                1 => {
                    :species => :TIMBURR,
                    :level => 30,
                    :moves => [:COACHING,:HELPINGHAND,:ROCKTHROW,:HAMMERARM],
                    :ability => :IRONFIST,
                    :nature => :ADAMANT
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Conkeldurr built a miniature city in anger!",
                :fieldChange => :CITY,
            },
            1 => {
                :threshold => 0,
                :message => "The miniature city was destroyed...",
                :fieldChange => :FOREST,
                :bossStatChanges => {
                    PBStats::ATTACK => -1,             
                },
            },
        },
    },
    :RIFTCARNIVINE_EASY => {
        :name => "Corrupted Carnivine",
        :entryText => "Carnivine is dancing the samba!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :CARNIVINE,
            :level => 40,
            :form => 1,
            :moves => [:DRAGONDANCE,:SEEDBOMB,:DRAGONPULSE,:FLAMEBURST],
            :ability => :OWNTEMPO,
            :gender => "M",
            :nature => :NAUGHTY,
            :happiness => 255,
            :ev => [0,0,0,0,0,0],
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 2",
            :continuous => true,
            :totalMonCount => 2,
            :moninfos => {
                1 => {
                    :species => :TANGELA,
                    :level => 35,
                    :form => 1,
                    :moves => [:FOLLOWME,:SWAGGER,:POLLENPUFF,:PETALDANCE],
                    :ability => :DANCER,
                    :gender => "F",
                    :nature => :MODEST,
                    :happiness => 255,
                },
                2 => {
                    :species => :TANGROWTH,
                    :level => 35,
                    :form => 1,
                    :moves => [:FOLLOWME,:QUASH,:POLLENPUFF,:ROCKTOMB],
                    :ability => :DANCER,
                    :gender => "M",
                    :nature => :MODEST,
                    :happiness => 255,
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :animation => :SHIFTGEAR,
                :message => "The rhythm of the music has changed!",
                :bossEffectMessage => "Carnivine did the robot and became Steel-type!",
                :typeChange => [:GRASS,:STEEL],
                :movesetUpdate => [:SHIFTGEAR,:SEEDBOMB,:IRONHEAD,:KNOCKOFF],
                :statDropRefresh => true,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1               
                },
                :playerSideStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,             
                }
            },
            1 => {
                :threshold => 0,
                :animation => :QUIVERDANCE,
                :message => "The rhythm of the music has changed!",
                :bossEffectMessage => "Carnivine did the jitterbug and became Bug-type!",
                :typeChange => [:GRASS,:BUG],
                :movesetUpdate => [:QUIVERDANCE,:SEEDBOMB,:POLLENPUFF,:KNOCKOFF],
                :statDropRefresh => true,
                :bossStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,           
                },
                :playerSideStatChanges => {
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1                
                }
            }
        }
    },
    :TAPUKOKOMAGRODAR_EASY => {
        :name => "Thunder Warrior",
        :entryText => "The Thunder Warrior is ready to rumble!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :TAPUKOKO,
            :level => 45,
            :shiny => true,
            :moves => [:LIGHTSCREEN,:NATURESMADNESS,:BRAVEBIRD,:REFLECT],
            :nature => :TIMID,
            :ability => :ELECTRICSURGE,
        },
        :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
            :weatherChange => nil,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount <= 1",
            :refreshingRequirement => [0],
            :entryMessage => ["Charizard charged into the fight!","The Thunder Warrior revitalized Charizard's energy!"],
            :totalMonCount => 2,
            :moninfos => {
                1 => {
                    :species => :CHARIZARD,
                    :level => 40,
                    :moves => [:INCINERATE,:AIRSLASH,:DRAGONBREATH,:ROOST],
                    :ability => :BLAZE,
                    :shiny => true,
                    :nature => :TIMID,
                },
                2 => {
                    :species => :CHARIZARD,
                    :level => 40,
                    :item => :CHARIZARDITEX,
                    :moves => [:BULLDOZE,:DRAGONBREATH,:INCINERATE,:AIRSLASH],
                    :ability => :BLAZE,
                    :shiny => true,
                    :nature => :BRAVE,
                },
            },
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :ability => :TELEPATHY,
                :itemchange => :ELEMENTALSEED,
                :message => "Tapu Koko is putting in its all!!",
                :movesetUpdate => [:SPARK,:HYPERVOICE,:ROOST,:DAZZLINGGLEAM],
            },
        }
    },
    :BOSS_CHAOTICFUSION_EASY => {
        :name => "Chaotic Fusion",
        :entryText => "The fused Pokémon suddenly attacked!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :SOLROCK,
            :level => 48,
            :moves => [:WILLOWISP,:ROCKTOMB,:SOLARFLARE,:MORNINGSUN],
            :nature => :QUIRKY,
            :form => 1,
            :ability => :SOLARIDOL,
            :item => :SITRUSBERRY,
        },
        :onEntryEffects => { # effects applied on entry, use same attributes/syntax as onbreakeffects
            :weatherChange => :SUNNYDAY,
            :weatherChangeAnimation => "Sunny",
            :weatherCount => 5,
        },
        :onBreakEffects => {
            3 => {
                :animation => :FLASH,
                :weatherChange => :HAIL,
                :weatherChangeAnimation => "Hail",
                :weatherCount => 5,
                :threshold => 0,
                :message => "Lunatone gained control!",
                :itemchange => :SITRUSBERRY,
                :speciesUpdate => :LUNATONE,
                :abilitychange => :LUNARIDOL,
                :form => 1,
                :movesetUpdate => [:COSMICPOWER,:ANCIENTPOWER,:HOARFROSTMOON,:MOONLIGHT],
            },
        }
    },
    :AMETHYSTREGIROCK_EASY => {
        :name => "Stone Guardian",
        :entryText => "The Guardian is watching your every move.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :REGIROCK,
            :level => 48,
            :moves => [:CURSE,:HAMMERARM,:ROCKSLIDE,:EARTHQUAKE],
            :nature => :IMPISH,
            :iv => 31,
            :shiny => true,
            :item => :SITRUSBERRY,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Regirock hardened up!",
                :statDropCure => true,
                :playersideChanges => :StealthRock,
                :playersideChangeCount => true,
                :playersideChangeAnimation => :STEALTHROCK,
                :playersideChangeMessage => "Floating rocks were deployed!",
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,                 
                },
            }
        }
    },
    :AMETHYSTREGISTEEL_EASY => {
        :name => "Iron Guardian",
        :entryText => "The Guardian is watching your every move.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :REGISTEEL,
            :level => 48,
            :moves => [:CURSE,:HAMMERARM,:IRONHEAD,:EARTHQUAKE],
            :nature => :IMPISH,
            :iv => 31,
            :shiny => true,
            :item => :SITRUSBERRY,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Registeel hardened up!",
                :statDropCure => true,
                :playersideChanges => :Spikes,
                :playersideChangeAnimation => :SPIKES,
                :playersideChangeCount => 1,
                :playersideChangeMessage => "Spikes were deployed!",
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,                 
                },
            }
        }
    },
    :BELIAL_EASY => {
        :name => "Belial", # nickname
        :entryText => "A feisty Volcarona appeared!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :VOLCARONA,
            :level => 40,
            :moves => [:MYSTICALFIRE,:BUGBUZZ,:GIGADRAIN,:SUNNYDAY],
            :ability => :FLAMEBODY,
            :nature => :MODEST,
            :gender => "M",
            :iv => 31,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :totalMonCount => 2,
        :continuous => true,
        :moninfos => {
            1 => {
                :species => :SHUCKLE,
                :level => 30,
                :moves => [:STEALTHROCK,:INFESTATION,:STICKYWEB,:HELPINGHAND],
                :ability => :STURDY,
                :nature => :BOLD,
                :iv => 31,
            },
            2 => {
                :species => :MOTHIM,
                :level => 30,
                :moves => [:STRUGGLEBUG,:POISONPOWDER,:PROTECT,:LUNGE],
                :ability => :TINTEDLENS,
                :iv => 31,
            },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Belial is in its last stand!", # message that plays when shield is broken                :weatherChange => :SUNNYDAY, # weather to applyes
                :abilitychange => :SWARM,
                :fieldChange => :FLOWERGARDEN1, # field changes
                :fieldChangeMessage => "The field is covered in flowers!", # message that plays when the field is changes
                :weatherCount => 5, # weather turncount
                :weatherChangeMessage => "The Sun is bright!", # weather message
                :weatherChangeAnimation => "Sunny", # string of "Rain", "Sunny","Hail","Sandstorm"
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :LEFTOVERS, # item that is given upon breaking shield
            },
        }
    },  
    :BOSSKYOGRE_EASY => {
        :name => "Leviathan Kyogre",
        :entryText => "Kyogre's power is overwhelming!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :KYOGRE,
            :level => 55,
            :moves => [:MUDDYWATER,:ICYWIND,:ANCIENTPOWER,:THUNDERWAVE],
            :nature => :MODEST,
            :item => :SITRUSBERRY,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Kyogre summoned a storm and flooded the arena!",
                :weatherChangeAnimation => "Rain",
                :fieldChange => :WATERSURFACE,
                :movesetUpdate => [:WHIRLPOOL,:SHOCKWAVE,:ANCIENTPOWER,:THUNDERWAVE],
                :statDropCure => true,
            }
        }
    },
    :BOSSGROUDON_EASY => {
        :name => "Behemoth Groudon",
        :entryText => "Groudon attacked under command!",
        :shieldCount => 1,
        :immunities => {
            :fieldEffectDamage => [:VOLCANIC]
        },
        :moninfo => {
            :species => :GROUDON,
            :level => 55,
            :moves => [:BULLDOZE,:ROCKSLIDE,:TOXIC,:HEATCRASH],
            :nature => :ADAMANT,
            :item => :SITRUSBERRY,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Groudon summoned fierce eruptions!",
                :weatherChange => :SUNNYDAY,
                :weatherChangeAnimation => "Sunny",
                :fieldChange => :VOLCANIC,
                :movesetUpdate => [:BULLDOZE,:ROCKSLIDE,:SWORDSDANCE,:HEATWAVE],
                :statDropCure => true,
            }
        }
    },
    :VALORGIRATINA_EASY => {
        :name => "Renegade Giratina",
        :entryText => "Giratina is blocking the way forward!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :GIRATINA,
            :level => 50,
            :moves => [:SHADOWFORCE,:AURASPHERE,:EARTHPOWER,:DRAGONCLAW],
            :nature => :NAUGHTY,
            :iv => 31,
			:form => 1,
            :ev => [0,0,0,0,0,0]
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Giratina drew power from the Distortion World!",
                :statDropCure => true,
                :itemchange => :GRISEOUSORB,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,               
                },
            }
        }
    },
    :DARCHGIRATINA_EASY => {
        :name => "Clown Caricature",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :GIRATINA,
            :level => 62,
            :moves => [:SLUDGEWAVE,:DRAGONPULSE,:NASTYPLOT,:FIREBLAST],
            :nature => :NAUGHTY,
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :speciesUpdate => :PORYGONZ,
                :message => "a Vir us in  d e  ed ",
                :statDropCure => true,
                :abilitychange => :WONDERGUARD,
                :itemchange => :TOXICORB,
            },
            2 => {
                :threshold => 0,
                :speciesUpdate => :BLACEPHALON,
                :movesetUpdate => [:MINDBLOWN,:SHADOWBALL,:NASTYPLOT,:PRESENT],
                :message => "F u n t i m e s w i t h e v e r y o n e ' s b a d e n d i n g",
                :statDropCure => true,
            },
            1 => {
                :threshold => 0,
                :speciesUpdate => :PIDGEY,
                :message => "Can you even beat a Pidgey? Likely not.",
                :statDropCure => true,
            }
        }
    },
    :LAVALAKAZAM_EASY => {
        :name => "Alakazam",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :ALAKAZAM,
            :level => 62,
            :gender => "M",
            :moves => [:CALMMIND,:REFLECT,:LIGHTSCREEN,:NIGHTSHADE],
            :nature => :TIMID,
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :formchange => 1,
                :message => "Alakazam is pulling all of its psychic energy to its core!",
                :statDropCure => true,
                :movesetUpdate => [:PSYCHIC,:SHADOWBALL,:FOCUSBLAST,:COUNTER],
                :itemchange => :TWISTEDSPOON,
                :bossStatChanges => {
                    PBStats::SPDEF => 2,
                    PBStats::SPEED => 2                 
                },
            },
            1 => {
                :threshold => 0,
                :bosssideChanges => :Reflect, # effect that applies on the boss when breaking shield
                :bosssideChangeCount => 5, # duration of the effect(some effects are booleans, double check)
                :statDropCure => true,
            },
        }
    },
    :DARKGARDEVOIR_EASY => {
        :name => "Dark Gardevoir",
        :entryText => "Gardevoir is staring you down.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :GARDEVOIR,
            :level => 60,
            :moves => [:DARKPULSE,:DAZZLINGGLEAM,:CALMMIND,:PSYCHIC],
            :nature => :TIMID,
            :form => 2,
            :iv => 31,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :bosssideChanges => [:Reflect,:Safeguard],
                :bosssideChangeCount => [3,3],
                :bosssideChangeAnimation => [:REFLECT,:SAFEGUARD],
                :message => "Gardevoir quickly set up protection!",
                :statDropCure => true,
            }
        }
    },
    :RIFTGARBODOR_EASY => {
        :name => "Rift Garbodor",
        :entryText => "The rampaging Rift Garbodor attacked!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :GARBODOR,
            :level => 57,
            :item => :BLACKSLUDGE,
            :moves => [:DRAINPUNCH,:BULLETSEED,:BRUTALSWING,:SLUDGEWAVE],
            :nature => :SASSY,
            :shiny => true,
            :form => 2,
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "Garbodor gorged itself on rotten berries!",
                :typeChange => [:POISON,:GRASS],
                :movesetUpdate => [:DRAINPUNCH,:GIGADRAIN,:BRUTALSWING,:BELCH],
                :itemchange => :SITRUSBERRY,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,              
                },
                :statDropCure => true,
            },
            2 => {
                :threshold => 0,
                :message => "Garbodor gorged itself on scrap metal!",
                :typeChange => [:POISON,:STEEL],
                :movesetUpdate => [:DRAINPUNCH,:GIGADRAIN,:MAGNETBOMB,:BELCH],
                :itemchange => :METALCOAT,
                :bossStatChanges => {
                    PBStats::SPDEF => 1,                
                },
                :statDropCure => true,
            },
            1 => {
                :threshold => 0,
                :message => "Garbodor desperately gorged itself on nearby rocks!",
                :typeChange => [:POISON,:ROCK],
                :movesetUpdate => [:ROCKBLAST,:GIGADRAIN,:MAGNETBOMB,:BELCH],
                :itemchange => :ROCKYHELMET,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => -2,
                    PBStats::SPATK => 1,   
                    PBStats::SPDEF => -2,                
                },
                :statDropCure => true,
            },
        }
    },
    :RIFTAELITA_EASY => {
        :name => "Rift Aelita",
        :entryText => "Rift Aelita is taking aim...",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :REGIROCK,
            :level => 70,
            :item => :LIFEORB,
            :moves => [:ROCKBLAST,:ARMTHRUST,:BULLETSEED,:BARRAGE],
            :nature => :NAUGHTY,
            :form => 2,
            :iv => 31,
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "Rift Aelita is cocking her gun...",
                :animation => :LASERFOCUS,
                :bossEffect => :LaserFocus,
                :bossEffectduration => 1,
                :fieldChange => :ROCKY,
                :fieldChangeMessage => "The field became littered with rocks!",
                :movesetUpdate => [:ROCKBLAST,:BULLDOZE,:POLLENPUFF,:SHADOWBALL],
                :bossStatChanges => {
                    PBStats::ACCURACY => 1,              
                },
                :delayedaction => {
                    :delay => 5,
                    :message => "Rift Aelita is cocking her gun...",
                    :animation => :LASERFOCUS,
                    :bossEffect => :LaserFocus,
                    :bossEffectduration => 1,
                    :repeat => true,
                }
            },
            2 => {
                :threshold => 0,
                :message => "Aelita let out a piercing screech!",
                :movesetUpdate => [:ROCKWRECKER,:AURASPHERE,:ACIDSPRAY,:ENERGYBALL],
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => 1,   
                    PBStats::SPDEF => -1,               
                },
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
            },
        }
    },
    :VIVIANREGIROCK_EASY => {
        :name => "Stone Guardian",
        :entryText => "The Stone Guardian attacked!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :REGIROCK,
            :level => 68,
            :shiny => true,
            :moves => [:DRAINPUNCH,:SUPERPOWER,:ROCKSLIDE,:EARTHQUAKE],
            :nature => :IMPISH,
            :iv => 31,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :effect => nil,
                :bossEffectduration => nil,
                :message => "Regirock drew power from the earth...",
                :itemchange => :ROCKIUMZ,
                :sideChanges => :StealthRock,
                :sideChangeAnimation => :STEALTHROCK,
                :sideChangesSide => 0,
                :sideChangeMessage => "Floating rocks were deployed!",
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,  
                    PBStats::SPDEF => 1,                
                },
            }
        }
    },
    :RIFTFERROTHORN_EASY => {
        :name => "Rift Ferrothorn",
        :entryText => "Rift Ferrothorn is readying to attack!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :FERROTHORN,
            :level => 70,
            :moves => [:SEEDBOMB,:LEECHSEED,:GYROBALL,:FIRELASH],
            :nature => :BRAVE,
            :form => 1,
            :iv => 31,
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :bosssideChanges => [:Reflect,:LightScreen],
                :bosssideChangeCount => [3,3],
                :message => "Rift Ferrothorn put up defenses!",
            },
            2 => {
                :threshold => 0,
                :effect => nil,
                :bossEffectduration => nil,
                :message => "Rift Ferrothorn became unrestrained!",
                :bgmChange => "Battle - Pseudo Contribution",
                :movesetUpdate => [:FLAREBLITZ,:ENERGYBALL,:IRONHEAD,:SHIFTGEAR],
                :formchange => 2,
                :statDropCure => true,
            },
            1 => {
                :threshold => 0,
                :effect => nil,
                :bossEffectduration => nil,
                :message => "Rift Ferrothorn is out of control!",
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => -2,
                    PBStats::SPATK => 1,   
                    PBStats::SPDEF => -2, 
                    PBStats::SPEED => 1,                
                },
            }
        }
    },
    :RIFTHIPPOWDON_EASY => {
        :name => "Rift Hippowdon",
        :entryText => "Rift Hippowdon is filling the arena with sand!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :HIPPOWDON,
            :level => 80,
            :form => 1,
            :moves => [:SPITUP,:HEATWAVE,:EARTHPOWER,:SLUDGEBOMB],
            :gender => "F",
            :nature => :RELAXED,
            :item => :BLACKSLUDGE,
            :iv => 31,
            :happiness => 0,
        },
        :onEntryEffects => {
            :animation => :HEATWAVE,
            :message => "The whirling sands are scorching!",
            :delayedaction => {
                :delay => 4,
                :message => "The searing sands inflicted burns!",
                :playerSideStatusChanges => [:BURN,"Burn"],
                :repeat => true,
            }
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "Rift Hippowdon shot sand everywhere!",
                :movesetUpdate => [:SPITUP,:EARTHQUAKE,:GUNKSHOT,:FLAMETHROWER],
                :weatherChange => :SANDSTORM,
                :weatherChangeAnimation => "Sandstorm",
                :weatherChangeMessage => "Sandstorms keep brewing...",
                :playersideChanges => :StealthRock,
                :playersideChangeAnimation => :STEALTHROCK,
            },
            1 => {
                :threshold => 0,
                :statDropCure => true,
                :statusCure => true,
                :message => "The arena is heating up more!",
                :animation => :INFERNO,
                :movesetUpdate => [:SPITUP,:EARTHPOWER,:DRAGONPULSE,:HEATWAVE],
                :weatherChange => :SANDSTORM,
                :weatherChangeAnimation => "Sandstorm",
                :weatherChangeMessage => "Sandstorms keep brewing...",
                :typeChange => [:GROUND,:FIRE],
                :itemchange => :SITRUSBERRY,
                :playersideChanges => :Spikes,
                :playersideChangeAnimation => :SPIKES,
                :playersideChangeCount => 1,
                :delayedaction => {
                    :delay => 5,
                    :message => "Rift Hippowdon is burning up!",
                    :bossStatChanges => {
                        PBStats::ATTACK => 1,
                        PBStats::SPATK => 1,
                    }
                }
            },
        }
    },
    :ANGELOFDEATH_EASY => {
        :name => "Angel of Death",
        :entryText => "The Angel of Death appears with bloodlust...",
        :shieldCount => 4,
        :immunities => {},
        :moninfo => {
            :species => :GARDEVOIR,
            :level => 70,
            :form => 3,
            :moves => [:DARKPULSE,:SWEETKISS,:DAZZLINGGLEAM,:MYSTICALFIRE],
            :gender => "F",
            :nature => :SERIOUS,
            :item => :LUMBERRY,
            :iv => 10,
            :happiness => 255,
            :ev => [35,35,35,35,35,35]
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 3",
            :continuous => true,
            :totalMonCount => 4,
            :moninfos => {
                1 => {
                    :species => :RALTS,
                    :level => 70,
                    :form => 1,
                    :moves => [:TORMENT,:HELPINGHAND,:POISONGAS,:NIGHTSHADE],
                    :gender => "F",
                    :iv => 10,
                },
                2 => {
                    :species => :KIRLIA,
                    :level => 70,
                    :form => 1,
                    :moves => [:QUASH,:HELPINGHAND,:WILLOWISP,:SNARL],
                    :gender => "F",
                    :iv => 10,
                },
            },
        },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :animation => :SECRETSWORD,
                :message => "The Angel of Death drew its scythe.",
                :movesetUpdate => [:NIGHTSLASH,:SWEETKISS,:SPIRITBREAK,:PSYCHOCUT],
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -1,
                }
            },
            3 => {
                :threshold => 0,
                :animation => :DAZZLINGGLEAM,
                :message => "The Angel of Death summoned minions.",
                :movesetUpdate => [:NIGHTSLASH,:PROTECT,:LAVAPLUME,:SACREDSWORD],
                :playerSideStatChanges => {
                    PBStats::SPATK => -1,
                }
            },
            2 => {
                :threshold => 0,
                :animation => :CHARGE,
                :message => "The Angel of Death is summoning power.",
                :movesetUpdate => [:DARKPULSE,:PSYCHOCUT,:BULLDOZE,:AURASPHERE],
            },
            1 => {
                :threshold => 0,
                :animation => :DARKPULSE,
                :message => "The Angel of Death has fury.",
                :movesetUpdate => [:HYPERSPACEFURY,:DAZZLINGGLEAM,:TAUNT,:HYPERVOICE],
            },
        }
    },
    :FALLENANGEL_EASY => {
        :name => "Fallen Angel",
        :entryText => "The Angel is on its last legs...",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :GARDEVOIR,
            :level => 70,
            :form => 4,
            :moves => [:LASHOUT,:BURNINGJEALOUSY,:HYPERSPACEHOLE,:THRASH],
            :gender => "F",
            :nature => :LONELY,
            :iv => 31,
            :happiness => 255,
            :ev => [0,0,0,0,0,0]
        },
        :onBreakEffects => {
        }
    },
    :BOSSARCEUS_CASINO_EASY => {
        :name => "Casino Bouncer",
        :entryText => "STOP! You've violated the law! Pay the court a fine or serve your sentence. Your stolen goods are now forfeit.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :ARCEUS,
            :level => 70,
            :moves => [:JUDGMENT,:PUNISHMENT,:EXTREMESPEED,:LIQUIDATION],
            :gender => "F",
            :nature => :LONELY,
            :ability => :MULTITYPE,
            :item => :FISTPLATE,
            :happiness => 255,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "STOP! You've violated the law! Pay the court a fine or serve your sentence. Your stolen goods are now forfeit.",
                :animation => :COSMICPOWER,
            }
        }
    },
    :NIGHTMAREREMIX_EASY => {
        :name => "Nightmare Remix",
        :entryText => "The... Puppet Master? Attacks?",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :DARKRAI,
            :level => 70,
            :form => 7,
            :moves => [:SPIRITBREAK,:PSYCHIC,:AURORAVEIL,:THROATCHOP],
            :gender => "M",
            :nature => :BRAVE,
            :happiness => 0,
        },
        :onEntryEffects => {
            :fieldChange => :STARLIGHT,
            :message => "Twinkle twinkle little star...",
            :delayedaction => {
                :delay => 5,
                :fieldChange => :NEWWORLD,
                :playerSideStatusChanges => [:SLEEP,"Sleep"],
                :message => "All fall to the Puppet Master's sway...",
                :playerEffects => :Nightmare,
                :playerEffectsAnimation => :NIGHTMARE,
                :playerEffectsduration => true,
                :playerEffectsMessage => "Now, sleep with this trauma that will leave you sleepless!",
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1,
                }
            }
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "Grow weary...",
                :movesetUpdate => [:MOONBLAST,:ICEBEAM,:EARTHQUAKE,:PROTECT],
                :itemchange => :LEFTOVERS,
                :animation => :HYPNOSIS,
                :playerSideStatChanges => {
                    PBStats::ATTACK => -3,
                    PBStats::SPATK=> -3
                }
            },
            2 => {
                :threshold => 0,
                :message => "Don't sleep... Don't wake up...",
                :movesetUpdate => [:DOOMDESIRE,:VACUUMWAVE,:DARKPULSE,:ANCIENTPOWER],
                :statDropCure => true,
                :statusCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,
                }
            },
            1 => {
                :threshold => 0,
                :message => "Welcome the end...",
                :movesetUpdate => [:METEORMASH,:COMETPUNCH,:THROATCHOP,:PSYSTRIKE],
                :statDropCure => true,
            },
        }
    },
    :BIGBETTY_EASY => {
        :name => "Big Betty",
        :entryText => "Big Betty stands her ground!",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :EMBOAR,
            :level => 76,
            :moves => [:EARTHQUAKE,:HEADSMASH,:FLAREBLITZ,:WILLOWISP],
            :ability => :BLAZE,
            :gender => "F",
            :form => 1,
            :nature => :ADAMANT,
            :iv => 31,
        },
        :onBreakEffects => {
        }
    },
    :BIGBETTYTWO_EASY => {
        :name => "Big Betty",
        :entryText => "Big Betty stands her ground... again!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :EMBOAR,
            :level => 78,
            :moves => [:EARTHQUAKE,:HEADSMASH,:FLAREBLITZ,:WILLOWISP],
            :ability => :BLAZE,
            :gender => "F",
            :form => 1,
            :nature => :ADAMANT,
            :iv => 31,
        },
        :onEntryEffects => {
            :fieldChange => :FAIRYTALE,
            :fieldChangeMessage => "Goomink's resolve manifested!"
        },
        :onBreakEffects => {
        }
    },
    :BOSSZEKROM_EASY => {
        :name => "Fanciful Ideals",
        :entryText => "Zekrom is crackling with electricity!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :ZEKROM,
            :level => 85,
            :moves => [:FOCUSBLAST,:REFLECT,:BOLTSTRIKE,:OUTRAGE],
            :ability => :TERAVOLT,
            :gender => "M",
            :nature => :NAIVE,
            :iv => 31,
        },
        :onBreakEffects => {
        }
    },
    :BOSSRESHIRAM_EASY => {
        :name => "Imaginary Truths",
        :entryText => "Reshiram is blazing with fire!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :RESHIRAM,
            :level => 85,
            :moves => [:DRAGONCLAW,:FUSIONFLARE,:LIGHTSCREEN,:CRUNCH],
            :ability => :TURBOBLAZE,
            :gender => "M",
            :nature => :TIMID,
            :iv => 31,
        },
        :onBreakEffects => {
        }
    },
    :BOSSNAGANADEL_EASY => {
        :name => "Naganadel",
        :entryText => "Naganadel is ready to kill!",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :NAGANADEL,
            :level => 87,
            :item => :LIFEORB,
            :moves => [:SLUDGEWAVE,:DRAGONPULSE,:TOXIC,:NASTYPLOT],
            :ability => :BEASTBOOST,
            :gender => "M",
            :nature => :TIMID,
            :iv => 31,
            :happiness => 0,
        },
        :onBreakEffects => {
        }
    },
    :BOSSGOTHITELLE_EASY => {
        :name => "Gothitelle",
        :entryText => "Gothitelle is looking serious!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :GOTHITELLE,
            :level => 86,
            :item => :GOTHCREST,
            :moves => [:GRAVITY,:THUNDERBOLT,:PSYCHIC,:DARKPULSE],
            :ability => :SHADOWTAG,
            :gender => "F",
            :nature => :MODEST,
            :form => 1,
        },
        :onBreakEffects => {
        }
    },
    :STORMNINE_EASY => {
        :name => "STORM | Wind",
        :entryText => "Erratic weather begets a disaster...",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :XERNEAS,
            :level => 80,
            :item => :LIFEORB,
            :moves => [:WEATHERBALL,:HURRICANE,:THUNDERBOLT,:PSYSHOCK],
            :ability => :TEMPEST,
            :nature => :MODEST,
            :form => 1,
            :iv => 31,
        },
        :onBreakEffects => {
        }
    },
    :BOSSCOFAGRIGUS_EASY => {
        :name => "Totem Cofagrigus",
        :entryText => "The menacing Cofagrigus attacked!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :COFAGRIGUS,
            :level => 80,
            :moves => [:SHADOWBALL,:NASTYPLOT,:WILLOWISP,:ENERGYBALL],
            :ability => :MUMMY,
            :gender => "M",
            :nature => :MODEST,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount < 2",
            :totalMonCount => 4,
            :moninfos => {
                1 => {
                    :species => :STANTLER,
                    :level => 75,
                    :item => :STANTCREST,
                    :moves => [:HYPNOSIS,:MEGAHORN,:JUMPKICK,:ZENHEADBUTT],
                    :ability => :INTIMIDATE,
                    :gender => "F",
                    :nature => :JOLLY,
                    :happiness => 255,
                },
                2 => {
                    :species => :MAGCARGO,
                    :level => 75,
                    :item => :MAGCREST,
                    :moves => [:FLAMEBURST,:YAWN,:EARTHPOWER,:WILLOWISP],
                    :ability => :FLAMEBODY,
                    :gender => "M",
                    :nature => :BOLD,
                    :happiness => 255,
                },
                3 => {
                    :species => :LEAFEON,
                    :level => 75,
                    :item => :LEAFCREST,
                    :moves => [:SWORDSDANCE,:NATUREPOWER,:LEAFBLADE,:XSCISSOR],
                    :ability => :LEAFGUARD,
                    :gender => "F",
                    :nature => :ADAMANT,
                    :happiness => 255,
                },
            },
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :bosssideChanges => :AreniteWall,
                :bosssideChangeAnimation => :ARENITEWALL,
                :bosssideChangeCount => 5,
                :message => "Sand swarms all around!",
                :movesetUpdate => [:SHADOWBALL,:BODYPRESS,:CALMMIND,:PSYCHIC],
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,           
                },
            },
            1 => {
                :threshold => 0,
                :movesetUpdate => [:SHADOWBALL,:PROTECT,:ENERGYBALL,:HIDDENPOWERFIG],
                :statDropCure => true,
                :itemchange => :LEFTOVERS,
                :delayedaction => {
                    :delay => 5,
                    :message => "Beware the Pharaoh's curse!",
                    :playerEffects => :Curse,
                    :playerEffectsAnimation => :CURSE,
                    :playerEffectsduration => true,
                    :repeat => true,            
                }
            }
        }
    },
    :COFFEEGREGUS_EASY => {
        :name => "COFFEE GREGUS",
        :entryText => "COFFEE GREGUS!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :COFAGRIGUS,
            :level => 80,
            :moves => [:SHADOWPUNCH,:COMETPUNCH,:BULLETPUNCH,:HOWL],
            :gender => "M",
            :nature => :MODEST,
            :form => 1,
            :happiness => 255,
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :movesetUpdate => [:SHADOWPUNCH,:SCORCHINGSANDS,:AURASPHERE,:HOWL],
                :message => "COFFEE GREGUS!",
                :animation => :BULKUP,
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,             
                },
                :fieldChange => :BIGTOP,
                :fieldChangeMessage => "CLOWN FIESTA!"
            },
            2 => {
                :threshold => 0,
                :movesetUpdate => [:SHADOWPUNCH,:DYNAMICPUNCH,:BODYPRESS,:HOWL],
                :message => "COFFEE GREGUS!",
                :animation => :BULKUP,
                :statDropCure => true,
                :effectClear => true,
                :delayedaction => {
                    :delay => 2,
                    :repeat => true,
                    :playerEffects => :Foresight,
                    :playerEffectsAnimation => :FORESIGHT,
                    :message => "THERE IS NO ESCAPE FROM COFFEE GREGUS!",
                    :playerSideStatChanges => {
                        PBStats::EVASION => -1
                    }
                }
            },
        }
    },
    :KAWOPUDUNGA_EASY => {
        :name => "Kawopudunga",
        :entryText => "Kawopudunga is ready to feast!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :WAILORD,
            :level => 70,
            :form => 1,
            :moves => [:DIVE,:DARKESTLARIAT,:AQUARING,:FRUSTRATION],
            :gender => "F",
            :nature => :HARDY,
            :item => :SITRUSBERRY,
            :iv => 31,
            :happiness => 0,
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :itemchange => :SITRUSBERRY,
                :message => "Kawopudunga changed its type!",
                :movesetUpdate => [:DIVE,:OUTRAGE,:DRAGONDANCE,:HEAVYSLAM],
                :typeChange => [:WATER,:DRAGON],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 2,
                }
            },
            1 => {
                :threshold => 0,
                :itemchange => :SITRUSBERRY,
                :message => "Kawopudunga changed its type!",
                :movesetUpdate => [:DIVE,:DARKPULSE,:RECOVER,:TOXIC],
                :typeChange => [:WATER,:DARK],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::SPATK => 2,
                }
            },
        }
    },
    :BOSSGOURGEIST_EASY => {
        :name => "Jack-o'-lantern",
        :entryText => "A large pumpkin suddenly attacked!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :GOURGEIST,
            :level => 75,
            :form => 1,
            :moves => [:WILLOWISP,:SEEDBOMB,:LEECHSEED,:CURSE],
            :gender => "F",
            :ability => :INSOMNIA,
            :nature => :BRAVE,
            :item => :SITRUSBERRY,
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "The Jack-o'-lantern was lit up!",
                :movesetUpdate => [:FLAMETHROWER,:ENERGYBALL,:DISABLE,:ROCKSLIDE],
                :typeChange => [:GRASS,:FIRE],
                :abilitychange => :FLASHFIRE,
                :itemchange => :ELEMENTALSEED,
                :fieldChange => :GRASSY,
                :statDropCure => true,
                :statusCure => true,
                :effectClear => true,
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                }
            },
            2 => {
                :threshold => 0,
                :movesetUpdate => [:GIGADRAIN,:LEECHSEED,:MYSTICALFIRE,:PHANTOMFORCE],
                :bossStatChanges => {
                    PBStats::SPDEF => 1,
                }
            },
            1 => {
                :threshold => 0,
                :movesetUpdate => [:GRASSYGLIDE,:ROCKSLIDE,:SYNTHESIS,:SHADOWSNEAK],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                }
            },
        }
    },
    :BOSSKECLEON => {
        :name => "Wacky Lizard",
        :entryText => "Wacky Lizard's staring into space.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :KECLEON,
            :level => 80,
            :form => 0,
            :moves => [:PLAYROUGH,:THUNDERPUNCH,:BOUNCE,:EARTHQUAKE],
            :gender => "F",
            :ability => :SHEERFORCE,
            :nature => :BRAVE,
            :item => :SITRUSBERRY,
            :iv => 31,
            :happiness => 0,
        },
        :onEntryEffects => {
            :delayedaction => {
                :delay => 1,
                :repeat => true,
                :loopingsetchanges => true,
                :itemchange => :LIFEORB,
                :setwinvariable => true,
                :message => "Wacky Lizard's type shifted!",
                :typeSequence => {
                    1 => {
                            :typeChange => [:FLYING,:FLYING],
                         },
                    2 => {
                            :typeChange => [:ELECTRIC,:FLYING],
                         },
                    3 => {
                            :typeChange => [:GROUND,:FLYING],
                         },
                    4 => {
                            :typeChange => [:FAIRY,:FLYING],
                         },
                },
            },
        },
        :onBreakEffects => {
            1 => {
            :threshold => 0,
            :statDropCure => true,
            :bossStatChanges => {
                }
            },
        },
    },
    :DUFAUX_EASY => {
        :name => "Dufaux",
        :entryText => "The Clefairy doll attacked!",
        :shieldCount => 2,
        :immunities => {
             :moves => [:RISINGVOLTAGE,:THUNDER,:ROCKSLIDE,:STONEEDGE,:WILLOWISP,:SCALD,:TOXIC,:BLIZZARD,:GILDEDARROW,:GILDEDHELIX,:ICYWIND,:DIAMONDSTORM,:EXTREMESPEED,:FLAMETHROWER,:FIREBLAST,:ZAPCANNON,:ACCELEROCK],
        },
        :moninfo => {
            :species => :FROSLASS,
            :level => 98,
            :form => 2,
            :moves => [:HEX,:IRRITATION,:COLDTRUTH,:RISINGVOLTAGE],
            :gender => "F",
            :nature => :MODEST,
            :iv => 31,
            :happiness => 0,
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :bosssideChanges => :Safeguard,
                :bosssideChangeCount => 5,
                :bosssideChangeAnimation => :SAFEGUARD,
                :itemchange => :MAGICALSEED,
                :message => "Dufaux attempted to repair itself…",
                :statDropCure => true,
                :statusCure => true,
                :bossStatChanges => {
                    PBStats::SPATK => -1
                }
            },
            1 => {
                :threshold => 0,
                :itemchange => :MAGNET,
                :message => "Dufaux broke out of its shell!",
                :movesetUpdate => [:SLUDGEBOMB,:DISCHARGE,:BLIZZARD,:WILLOWISP],
                :statDropCure => true,
                :formchange => 3,
                :weatherChange => :HAIL,
                :weatherChangeMessage => "Hail started to fall!",
                :weatherChangeAnimation => "Hail",
                :playerSideStatChanges => {
                    PBStats::ATTACK => -1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPATK => -1,
                    PBStats::SPDEF => -1,
                    PBStats::SPEED => -1
                }
            },
        }
    },
    :MECHAGYARADOS_EASY => {
        :name => "GYARA-01",
        :entryText => "WARNING! WARNING! WARNING!",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :GYARADOS,
            :level => 86,
            :form => 3,
            :moves => [:THUNDERBOLT,:HYPERBEAM,:FLAMETHROWER,:SCALD],
            :gender => "F",
            :nature => :HARDY,
            :iv => 31,
            :happiness => 0,
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => "DESTRUCTION MODE ENGAGED!",
                :movesetUpdate => [:STEELBEAM,:MINDBLOWN,nil,nil],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                }
            },
            2 => {
                :threshold => 0,
                :message => "COOLING DOWN...",
                :movesetUpdate => [:HYPERVOICE,:ICEBEAM,:IRONHEAD,:DOUBLEEDGE],
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPEED => -1,
                }
            },
            1 => {
                :threshold => 0,
                :message => "SELF-DESTRUCT SEQUENCE ACTIVATED!",
                :movesetUpdate => [:EXPLOSION,nil,nil,nil],
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 6,
                }
            }
        }
    },
    :MASTEROFNIGHTMARES_EASY => {
        :name => "Master of Nightmares",
        :entryText => "The battle against nightmares has begun.",
        :shieldCount => 4,
        :immunities => {},
        :moninfo => {
            :species => :DARKRAI,
            :level => 85,
            :form => 2,
            :moves => [:THUNDERBOLT,:LOWKICK,:BUNRAKUBEATDOWN,:NIGHTMARE],
            :gender => "M",
            :nature => :BRAVE,
            :happiness => 0,
        },
        :onEntryEffects => {
            :animation => :IONDELUGE,
            :fieldChange => :ELECTERRAIN,
            :fieldChangeMessage => "Aelita's nightmares manifest into reality...",
            :delayedaction => {
                :delay => 1,
                :playerSideStatusChanges => [:PARALYSIS,"Paralysis"],
            }
        },
        :onBreakEffects => {
            4 => {
                :threshold => 0,
                :message => "Memories of being burned alive pass by...",
                :movesetUpdate => [:LAVAPLUME,:BULLDOZE,:BUNRAKUBEATDOWN,:NIGHTMARE],
                :formchange => 3,
                :animation => :ERUPTION,
                :playerSideStatusChanges => [:BURN,"Burn"],
                :playerEffects => :TarShot,
                :playerEffectsAnimation => :TARSHOT,
                :playerEffectsMessage => "You feel highly flammable...",
                :fieldChange => :VOLCANICTOP,
            },
            3 => {
                :threshold => 0,
                :message => "The feeling of an explosion creeps up your spine...",
                :movesetUpdate => [:DAZZLINGGLEAM,:SACREDSWORD,:BUNRAKUBEATDOWN,:NIGHTMARE],
                :formchange => 4,
                :animation => :EXPLOSION,
                :fieldChange => :DIMENSIONAL,
                :bossStatChanges => {
                    PBStats::SPDEF => 1,
                },
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1
                }
            },
            2 => {
                :threshold => 0,
                :message => "You feel death incarnate staring you down...",
                :movesetUpdate => [:AIRSLASH,:DARKPULSE,:BUNRAKUBEATDOWN,:NIGHTMARE],
                :formchange => 5,
                :fieldChange => :CHESS,
                :animation => :DECIMATION,
                :playerEffects => :PerishSong,
                :playerEffectsduration => 3,
                :playerEffectsAnimation => :PERISHSONG,
                :playerEffectsMessage => "Death is imminent...",
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                }
            },
            1 => {
                :threshold => 0,
                :message => "The true nightmare begins.",
                :movesetUpdate => [:BUNRAKUBEATDOWN,:DARKPULSE,:SHADOWBALL,:THUNDERCAGE],
                :formchange => 1,
                :statDropCure => true,
                :fieldChange => :NEWWORLD,
                :animation => :NIGHTDAZE,
                :delayedaction => {
                    :delay => 1,
                    :playerEffects => :Yawn,
                    :playerEffectsAnimation => :YAWN,
                    :playerEffectsduration => 1,
                    :playerEffectsMessage => "A strong feeling of drowsiness...",
                },
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                    PBStats::SPDEF => 1,
                    PBStats::SPEED => 1,
                },
                :itemchange => :GHOSTIUMZ
            },
        }
    },
    :MASTEROFNIGHTMARES2_EASY => {
        :name => "Master of Nightmares",
        :entryText => "The nightmare will end soon.",
        :shieldCount => 0,
        :immunities => {},
        :moninfo => {
            :species => :DARKRAI,
            :level => 80,
            :moves => [:BUNRAKUBEATDOWN,:NIGHTMARE,:TAUNT,:SHADOWCLAW],
            :gender => "F",
            :nature => :MODEST,
            :form => 6,
            :iv => 31,
        },
        :onBreakEffects => {
        }
    },
    :BOSSKLINKLANG_EASY => {
        :name => "Klinklang Queen",
        :entryText => "KLINKLANG: Ohohoho!",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :KLINKLANG,
            :level => 82,
            :form => 1,
            :moves => [:SHIFTGEAR,:GEARGRIND,:FACADE,:WILDCHARGE],
            :nature => :ADAMANT,
            :ability => :CLEARBODY,
            :item => :LEFTOVERS,
            :iv => 31,
            :happiness => 0,
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "The Klinklang Queen revs up!",
                :statusCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPEED => 1
                }
            },
            1 => {
                :threshold => 0,
                :message => "Gears appear all around!",
                :movesetUpdate => [:SUBSTITUTE,:GEARGRIND,:FACADE,:WILDCHARGE],
                :fieldChange => :FACTORY,
                :bossStatChanges => {
                    PBStats::SPEED => 1
                }
            },
        }
    },
    :GERBIL1_EASY => {
        :name => "Entei", # nickname
        :entryText => "Entei appeared before you!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :capturable => true, # can you catch this boss after shields are removed?
        :moninfo => { # pokemon details
            :species => :ENTEI,
            :level => 80,
            :form => 0,
            :moves => [:SACREDFIRE,:DIG,:EXTREMESPEED,:WILLOWISP],
            :ability => :PRESSURE,
            :nature => :ADAMANT,
            :iv => 31,
            :happiness => 255,
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :bgmChange => "Battle - Final Endeavor",
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :weatherChange => :SUNNYDAY, # weather to apply
                :fieldChange => :VOLCANICTOP, # field changes
                :fieldChangeMessage => "Entei changed reality around it!", # message that plays when the field is changes
                :weatherCount => 5, # weather turncount
                :weatherChangeMessage => "The Sun is bright!", # weather message
                :weatherChangeAnimation => "Sunny", # string of "Rain", "Sunny","Hail","Sandstorm"
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :movesetUpdate => [:LAVAPLUME,:EXTRASENSORY,:EARTHQUAKE,:CALMMIND],
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPATK => 1,
                },
            },
        }
    },  
    :GERBIL2_EASY => {
        :name => "Suicune", # nickname
        :entryText => "Suicune appeared before you!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :capturable => true, # can you catch this boss after shields are removed?
        :moninfo => { # pokemon details
            :species => :SUICUNE,
            :level => 80,
            :form => 0,
            :moves => [:AQUARING,:EXTRASENSORY,:SCALD,:CALMMIND],
            :ability => :PRESSURE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :bgmChange => "Battle - Final Endeavor",
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "", # message that plays when shield is broken
                :abilitychange => :PRESSURE,
                :fieldChange => :UNDERWATER, # field changes
                :fieldChangeMessage => "Suicune changed reality around it!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken shield
                :movesetUpdate => [:SURF,:ICEBEAM,:EXTRASENSORY,:CALMMIND],
                :bossStatChanges => { # any statboosts that are given
                    PBStats::DEFENSE => 1,
                },
            },
        }
    },  
    :GERBIL3_EASY => {
        :name => "Raikou", # nickname
        :entryText => "Raikou appeared before you!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :capturable => true, # can you catch this boss after shields are removed?
        :moninfo => { # pokemon details
            :species => :RAIKOU,
            :level => 80,
            :form => 0,
            :moves => [:THUNDERBOLT,:AURASPHERE,:SCALD,:CALMMIND],
            :ability => :PRESSURE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :bgmChange => "Battle - Final Endeavor",
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "", # message that plays when shield is broken
                :weatherChange => :RAINDANCE, # weather to apply
                :fieldChange => :ELECTERRAIN, # field changes
                :fieldChangeMessage => "Raikou changed reality around it!", # message that plays when the field is changes
                :weatherChangeMessage => "The Rain pours down!", # weather message
                :weatherChangeAnimation => "Rain", # string of "Rain", "Sunny","Hail","Sandstorm"
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :movesetUpdate => [:THUNDERBOLT,:WEATHERBALL,:AURASPHERE,:EXTREMESPEED],
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPATK => 1,
                },
            },
        }
    },
    :TIEMPAGOOD_EASY => {
        :name => "Tiempa", # nickname
        :entryText => "Tiempa is looking ready to attack!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :DIALGA,
            :level => 85,
            :form => 0,
            :item => :ADAMANTORB,
            :moves => [:EARTHPOWER,:FLASHCANNON,:POWERGEM,:DRAGONPULSE],
            :ability => :PRESSURE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Tiempa twisted time around the field!", # message that plays when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :ADAMANTORB, # item that is given upon breaking shield
                :movesetUpdate => [:EARTHPOWER,:FLASHCANNON,:AURASPHERE,:ROAROFTIME],
                :playerSideStatChanges => {
                    PBStats::SPEED => -1,
                },
                :delayedaction => {
                    :delay => 2,
                    :message => "Tiempa slows down movement!",
                    :animation => :FAIRYLOCK,
                    :playerSideStatChanges => {
                        PBStats::SPEED => -1,
                    },
                    :repeat => true,
                }
            },
        }
    }, 
    :SPACEAGOOD_EASY => {
        :name => "Spacea", # nickname
        :entryText => "Spacea is finishing what Tiempa started!",
        :shieldCount => 2, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :PALKIA,
            :level => 85,
            :form => 0,
            :item => :LUSTROUSORB,
            :moves => [:SURF,:THUNDERBOLT,:DRAGONPULSE,:FLAMETHROWER],
            :ability => :PRESSURE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 2",
            :totalMonCount => 1,
            :playerMons => true,
            :moninfos => {
                1 => {
                    :species => :MINIOR,
                    :level => 90,
                    :form => 0,
                    :moves => [:ROCKSLIDE,:CONFUSERAY,:ACROBATICS,:LIGHTSCREEN],
                    :ability => :SHIELDSDOWN,
                },
            },
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :statDropCure => true, # if statdrops are negated when shield is broken
                :movesetUpdate => [:THUNDER,:FIREBLAST,:SPACIALREND,:HYDROPUMP],
                :itemchange => :LUSTROUSORB, # item that is given upon breaking shield
                :statchanges => :Gravity,
                :stateChangeAnimation => :GRAVITY,
                :stateChangeCount => 99,
                :stateChangeMessage => "The space around was contorted!",
                :bossStatChanges => {
                }
            },
            1 => {
                :message => "SPACEA: No more... NO... MORE!!!!!!!", # message that plays when shield is broken
                :animation => :FLASH, # effect animation
                :bgmChange => "Battle - End of Night",
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :formchange => 1, # formchanges
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :LUSTROUSORB, # item that is given upon breaking shield
                :bossStatChanges => { # any statboosts that are given
                    PBStats::DEFENSE => 1,
                    PBStats::SPATK => 1,
                },
            },
        }
    },
    :SPACEABAD_EASY => {
        :name => "Spacea", # nickname
        :entryText => "Spacea is looking ready to attack!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :PALKIA,
            :level => 90,
            :form => 0,
            :item => :LUSTROUSORB,
            :moves => [:SURF,:DRAGONPULSE,:FLAMETHROWER,:THUNDERBOLT],
            :ability => :PRESSURE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
            :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 1",
            :continuous => true,
            :totalMonCount => 2,
            :moninfos => {
                1 => {
                    :species => :MINIOR,
                    :level => 85,
                    :item => :FLYINGGEM,
                    :moves => [:ROCKSLIDE,:CONFUSERAY,:ACROBATICS,:LIGHTSCREEN],
                    :ability => :SHIELDSDOWN,
                },
                2 => {
                    :species => :CLEFAIRY,
                    :level => 85,
                    :item => :EVIOLITE,
                    :moves => [:FOLLOWME,:HELPINGHAND,:MOONBLAST,:REFLECT],
                    :ability => :FRIENDGUARD,
                },
            },
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Spacea twisted the space around the field!", # message that plays when shield is broken
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :LUSTROUSORB, # item that is given upon breaking shield
                :movesetUpdate => [:HYDROPUMP,:SPACIALREND,:FIREBLAST,:THUNDER],
                :bossStatChanges => { # any statboosts that are given
                    PBStats::SPATK => 1,
                    PBStats::SPEED => 1,
                },
                :playerSideStatChanges => {
                    PBStats::SPEED => -1,
                }
            },
        }
    }, 
    :TIEMPABAD_EASY => {
        :name => "Tiempa", # nickname
        :entryText => "Tiempa is finishing what Spacea started!",
        :shieldCount => 3, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :DIALGA,
            :level => 90,
            :form => 0,
            :item => :ADAMANTORB,
            :moves => [:POWERGEM,:ROAROFTIME,:FLASHCANNON,:EARTHPOWER],
            :ability => :PRESSURE,
            :nature => :MODEST,
            :happiness => 255,
        },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            2 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :ADAMANTORB, # item that is given upon breaking shield
            },
            1 => {
                :CustomMethod => "battlesnapshot(battler,1,1)",
            },
            0 => {
                :CustomMethod => "timewarp(battler,1)",
                :movesetUpdate => [:FLAMETHROWER,:ROAROFTIME,:FLASHCANNON,:ICEBEAM],
                :delayedaction => {
                    :delay => 1,
                    :CustomMethod => "battlesnapshot(battler,2,-1)",
                    :message => "Tiempa is focusing on the kill!",
                    :bossStatChanges => { # any statboosts that are given
                        PBStats::DEFENSE => -1,
                        PBStats::SPDEF => -1,
                    },
                    :delayedaction => {
                        :delay => 8,
                        :message => "TIEMPA: You are wasting your time, Interceptor...",
                        :CustomMethod => "timewarp(battler,2)",
                    },
                },
                :message => "TIEMPA: No more... NO... MORE!!!!!!!", # message that plays when shield is broken
                :animation => :FLASH, # effect animation
                :bgmChange => "Battle - End of Night",
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :formchange => 1, # formchanges
                :statusCure => true, # if status is cured when shield is broken
                :statDropCure => true, # if statdrops are negated when shield is broken
                :itemchange => :ADAMANTORB, # item that is given upon breaking shield
            },
        }
    },
    :BOSSRATICATE_EASY => {
        :name => "Monstrosity",
        :entryText => "The grotesque rodent attacked!",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :RATICATE,
            :level => 16,
            :form => 2,
            :moves => [:POISONFANG,:BITE,:TAILWHIP,:SECRETPOWER],
            :ability => :NOGUARD,
            :nature => :NAUGHTY,
            :iv => 10,
            :happiness => 255,
            :ev => [0,0,0,0,0,0]
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "The Monstrosity started acting desperate!",
                :statDropCure => true,
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1,
                }
            }
        }
    },  
    :STARMIEGOD_EASY => {
        :name => "Shooting Star",
        :entryText => "You can't look away from the Star...",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :STARMIE,
            :level => 88,
            :moves => [:SURF,:THUNDERBOLT,:RECOVER,:PSYCHIC],
            :ability => :NATURALCURE,
            :nature => :MODEST,
            :item => :PETAYABERRY,
            :iv => 31,
            :happiness => 255,
            :shiny => true,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "The Shooting Star is sparkling!",
                :statDropCure => true,
                :fieldChange => :RAINBOW,
                :fieldChangeMessage => "A prismatic luminance buries the surroundings!",
                :movesetUpdate => [:TRIATTACK,:DAZZLINGGLEAM,:RAPIDSPIN,:PSYSHOCK],
                :abilitychange => :PRISMARMOR,
            }
        }
    }, 
    :UXIEBAD_EASY => {
        :name => "Uxie", # nickname
        :entryText => "Uxie is defending itself!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :UXIE,
            :level => 85,
            :form => 0,
            :moves => [:PSYCHUP,:PSYCHIC,:DRAININGKISS,:YAWN],
            :ability => :LEVITATE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :MESPRIT,
                :level => 80,
                :moves => [:CHARM,:PSYSHOCK,:SHADOWBALL,:CONFUSERAY],
                :ability => :LEVITATE,
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
            },
            2 => {
                :species => :AZELF,
                :level => 80,
                :moves => [:THUNDERWAVE,:ZENHEADBUTT,:PLAYROUGH,:KNOCKOFF],
                :ability => :LEVITATE,
                :nature => :ADAMANT,
                :iv => 31,
                :happiness => 255,
                },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Uxie drew power from the Starlight!", # message that plays when shield is broken
                :abilitychange => :VICTORYSTAR,
                :typeChange => [:PSYCHIC,:FAIRY],
                :fieldChange => :STARLIGHT,
                :movesetUpdate => [:PSYCHIC,:DRAININGKISS,:YAWN,:SIGNALBEAM],
                :fieldChangeMessage => "The field shines bright!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :MAGICALSEED, # item that is given upon breaking shield
                :statBoosts => { # any statboosts that are given
                    PBStats::DEFENSE => 1,
                },
            },
        }
    },
    :MESPRITBAD_EASY => {
        :name => "Mesprit", # nickname
        :entryText => "Mesprit is defending itself!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :MESPRIT,
            :level => 85,
            :form => 0,
            :moves => [:FLATTER,:CHARGEBEAM,:DRAININGKISS,:PSYCHIC],
            :ability => :LEVITATE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :UXIE,
                :level => 80,
                :moves => [:YAWN,:PSYCHIC,:THUNDERBOLT,:HELPINGHAND],
                :ability => :LEVITATE,
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
            },
            2 => {
                :species => :AZELF,
                :level => 80,
                :moves => [:THUNDERWAVE,:ZENHEADBUTT,:PLAYROUGH,:KNOCKOFF],
                :ability => :LEVITATE,
                :nature => :ADAMANT,
                :iv => 31,
                :happiness => 255,
                },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Mesprit submerged itself in water!", # message that plays when shield is broken
                :abilitychange => :TECHNICIAN,
                :typeChange => [:PSYCHIC,:WATER],
                :fieldChange => :WATERSURFACE,
                :movesetUpdate => [:PSYCHIC,:DRAININGKISS,:CHARGEBEAM,:WATERPULSE],
                :fieldChangeMessage => "The field was flash flooded!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :ELEMENTALSEED, # item that is given upon breaking shield
                :statBoosts => { # any statboosts that are given
                    PBStats::SPEED => 1,
                },
            },
        }
    },
    :AZELFBAD_EASY => {
        :name => "Azelf", # nickname
        :entryText => "Azelf is defending itself!",
        :shieldCount => 1, # number of shields
        :barGraphic => "",
        :immunities => { # any immunities to things 
            :moves => [],
            :fieldEffectDamage => []
        },
        :moninfo => { # pokemon details
            :species => :AZELF,
            :level => 85,
            :form => 0,
            :moves => [:TAUNT,:FLAMETHROWER,:KNOCKOFF,:PSYCHIC],
            :ability => :LEVITATE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :sosDetails =>  { # pokemon details
        :activationRequirement => "@battle.battlers[battlerIndex].shieldCount == 0",
        :continuous => true,
        :totalMonCount => 2,
        :moninfos => {
            1 => {
                :species => :UXIE,
                :level => 80,
                :moves => [:YAWN,:PSYCHIC,:THUNDERBOLT,:HELPINGHAND],
                :ability => :LEVITATE,
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
            },
            2 => {
                :species => :MESPRIT,
                :level => 80,
                :moves => [:CHARM,:PSYSHOCK,:SHADOWBALL,:CONFUSERAY],
                :ability => :LEVITATE,
                :nature => :MODEST,
                :iv => 31,
                :happiness => 255,
            },
        },
    },
        :onBreakEffects => { # in order of shield count, with the highest value being the first shield broken and the lowest the last
            1 => {
                :threshold => 0, # if desired, shield can be broken at higher hp% than 0
                :message => "Azelf conflagrated in hellfire!", # message that plays when shield is broken
                :abilitychange => :MAGMAARMOR,
                :typeChange => [:PSYCHIC,:DARK],
                :fieldChange => :INFERNAL,
                :movesetUpdate => [:TORMENT,:FLAMETHROWER,:KNOCKOFF,:PSYCHIC],
                :fieldChangeMessage => "The field is burning with anguish!", # message that plays when the field is changes
                :statusCure => true, # if status is cured when shield is broken
                :itemchange => :ELEMENTALSEED, # item that is given upon breaking shield
                :statBoosts => { # any statboosts that are given
                    PBStats::ATTACK => 1,
                },
            },
        }
    },
    :RIFTTALON_EASY => {
        :name => "Karma Beast Talon",
        :entryText => "Talon fumbles toward you...",
        :shieldCount => 3,
        :immunities => {},
        :moninfo => {
            :species => :BRAVIARY,
            :level => 85,
            :form => 2,
            :moves => [:SLUDGEWAVE,:STEELWING,:ESPERWING,:VENOSHOCK],
            :gender => "M",
            :nature => :BRAVE,
            :item => :TELLURICSEED,
            :iv => 31,
            :happiness => 0,
        },
        :onBreakEffects => {
            3 => {
                :threshold => 0,
                :message => ".... stOooP.....",
                :movesetUpdate => [:ACIDARMOR,:BARBBARRAGE,:AIRSLASH,:BODYPRESS],
                :playersideChanges => :ToxicSpikes, # handles side changes found in the Battle_Side class(in Battle_ActiveSide file) 
                :playersideChangeAnimation => :TOXICSPIKES, # side change animation
                :playersideChangeCount => 1, # side change turncount
                :playersideChangeMessage => "Toxic Spikes was set up!",
            },
            2 => {
                :threshold => 0,
                :message => "oUu.... dOn'T.....",
                :formchange => 3,
                :typeChange => [:POISON,:DRAGON],
                :movesetUpdate => [:HEXINGSLASH,:DRAGONCLAW,:DRACOMETEOR,:ACIDSPRAY],
                :statDropCure => true,
                :statusCure => true,
                :formchange => 3,
                :fieldChange => :CORROSIVEMIST,
                :playerSideStatChanges => {
                    PBStats::DEFENSE => -1,
                    PBStats::SPDEF => -1
                }
            },
            1 => {
                :threshold => 0,
                :message => ".... pLEase.... enD IT....",
                :movesetUpdate => [:VILEASSAULT,:DRAGONRUSH,:SHADOWCLAW,:DRAGONDANCE],
                :itemchange => :POISONIUMZ,
                :bossStatChanges => {
                    PBStats::DEFENSE => -2,
                    PBStats::SPDEF => -2,
                    PBStats::SPEED => 1,
                }
            },
        }
    },
    :NANODRIVE_EASY => {
        :name => "NANO DRIVE",
        :entryText => "The NANO DRIVE is analyzing...",
        :shieldCount => 2,
        :immunities => {},
        :moninfo => {
            :species => :MAGNEZONE,
            :level => 90,
            :form => 1,
            :moves => [:DOUBLEIRONBASH,:BRICKBREAK,:IRONDEFENSE,:SUCKERPUNCH],
            :gender => "F",
            :nature => :IMPISH,
            :happiness => 0,
        },
        :onBreakEffects => {
            2 => {
                :threshold => 0,
                :message => "The NANO DRIVE is planning...",
                :movesetUpdate => [:DOUBLEIRONBASH,:BRUTALSWING,:SCREECH,:ELECTROWEB],
                :playersideChanges => :Spikes, # handles side changes found in the Battle_Side class(in Battle_ActiveSide file) 
                :playersideChangeAnimation => :SPIKES, # side change animation
                :playersideChangeCount => 1, # side change turncount
                :playersideChangeMessage => "A layer of Spikes was set up!",
                :bossStatChanges => {
                    PBStats::SPATK => 1,
                }
            },
            1 => {
                :threshold => 0,
                :message => "The NANO DRIVE is closing out the battle...",
                :movesetUpdate => [:METEORMASH,:ELECTROWEB,:KINGSSHIELD,:CLOSECOMBAT],
                :bossStatChanges => {
                    PBStats::DEFENSE => 1,
                }
            },
        }
    },
    :NANODRIVE_1_EASY => {
        :name => "NANO DRIVE",
        :entryText => "The NANO DRIVE is analyzing...",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :MAGNEZONE,
            :level => 90,
            :moves => [:HAMMERARM,:WOODHAMMER,:ICEHAMMER,:DRAGONHAMMER],
            :nature => :NAUGHTY,
            :form => 2,
            :happiness => 0,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "Will you... Remember all of this too? ",
                :movesetUpdate => [:BLIZZARD,:THUNDER,:FIREBLAST,:HYPERBEAM],
                :bossStatChanges => {
                    PBStats::ATTACK => 1,
                    PBStats::SPATK => 1,                  
                },
                :statDropCure => true,
            },
        }
    },
    :IRONHELL_EASY => {
        :name => "Iron Moth",
        :entryText => "The Iron Moth is ready to take you down.",
        :shieldCount => 1,
        :immunities => {},
        :moninfo => {
            :species => :IRONMOTH,
            :level => 90,
            :moves => [:MORNINGSUN,:FIERYDANCE,:STRUGGLEBUG,:SOLARBEAM],
            :ability => :QUARKDRIVE,
            :nature => :MODEST,
            :iv => 31,
            :happiness => 255,
        },
        :onBreakEffects => {
            1 => {
                :threshold => 0,
                :message => "V: You... Grandma was right about you. This ends now.",
                :bossStatChanges => {
                    PBStats::SPEED => 1,
                }
            },
        }
    },

##############################
# Shadow Den Template
##############################

    :SHADOWDEN => {
        :name => "",
        :shieldCount => 1,
        :immunities => {},
        :capturable => true, # can you catch this boss after shields are removed?
        :moninfo => {},
        :onBreakEffects => {}
    },
}