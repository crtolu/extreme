TTYPEHASH = {
:CHILDOFLIGHT => {
	:ID => 0,
	:title => "Child of Light",
	:skill => 0,
},

:TRAINER_AEVIS => {
	:ID => 1,
	:title => "Pokémon Trainer",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AEVIA => {
	:ID => 2,
	:title => "Pokémon Trainer",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_ARIA => {
	:ID => 3,
	:title => "Pokémon Trainer",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AXEL => {
	:ID => 4,
	:title => "Pokémon Trainer",
	:skill => 110,
	:moneymult => 14,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_ALAIN => {
	:ID => 5,
	:title => "Pokémon Trainer",
	:skill => 110,
	:moneymult => 14,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_AERO => {
	:ID => 6,
	:title => "Pokémon Trainer",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_ANA => {
	:ID => 7,
	:title => "Pokémon Trainer",
	:skill => 110,
	:battleBGM => "Battle - Rival.mp3",
	:player => true
},

:TRAINER_REN => {
	:ID => 8,
	:title => "Pokémon Trainer",
	:trainerID => 27412,
	:skill => 110,
	:moneymult => 7,
	:battleBGM => "Battle- Quake.mp3",
},

:TRAINER_MELIA1 => {
	:ID => 9,
	:title => "Pre-Leader",
	:trainerID => 27973,
	:skill => 110,
	:moneymult => 7,
	:battleBGM => "Battle- Chosen.mp3",
},

:TRAINER_AMANDA => {
	:ID => 10,
	:title => "League Scout",
	:skill => 110,
	:moneymult => 7,
	:battleBGM => "Battle- Chosen.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:OPT => {
	:ID => 11,
	:title => "Optimist",
	:skill => 110,
	:moneymult => 6,
},

:AROMALADY => {
	:ID => 12,
	:title => "Fragrant Lady",
	:skill => 90,
	:moneymult => 11,
},

:BEAUTY => {
	:ID => 13,
	:title => "Prima Donna",
	:skill => 90,
	:moneymult => 8,
},

:COOLGUY => {
	:ID => 14,
	:title => "Cool Guy",
	:skill => 90,
	:moneymult => 9,
	:battleBGM => "Battle - Rival.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:CHANELLER => {
	:ID => 15,
	:title => "Old Lady",
	:skill => 90,
	:moneymult => 13,
},

:CUEBALL => {
	:ID => 16,
	:title => "Gang Member",
	:skill => 90,
	:moneymult => 5,
},

:TECH => {
	:ID => 17,
	:title => "Technician",
	:skill => 90,
	:moneymult => 10,
},

:BUGCATCHER => {
	:ID => 18,
	:title => "Bug Catcher",
	:skill => 90,
	:moneymult => 2,
},

:FISHERMAN => {
	:ID => 19,
	:title => "Fisherman",
	:skill => 90,
	:moneymult => 6,
},

:CHARMER => {
	:ID => 20,
	:title => "Charmer",
	:skill => 90,
	:moneymult => 9,
},

:HIKER => {
	:ID => 21,
	:title => "Hiker",
	:skill => 90,
	:moneymult => 9,
},

:LADY => {
	:ID => 22,
	:title => "Mistress",
	:skill => 90,
	:moneymult => 16,
},

:ROCKER => {
	:ID => 23,
	:title => "Punk",
	:skill => 90,
	:moneymult => 6,
},

:YOUNGSTER => {
	:ID => 24,
	:title => "Youngster",
	:skill => 90,
	:moneymult => 6,
},

:POKEBREEDER_F => {
	:ID => 25,
	:title => "Pokémon Caretaker",
	:skill => 90,
},

:POKEBREEDER_M => {
	:ID => 26,
	:title => "Pokémon Caretaker",
	:skill => 90,
},

:BLACKBELT => {
	:ID => 27,
	:title => "Battle Boy",
	:skill => 90,
	:moneymult => 7,
},

:COOLTRAINER_M => {
	:ID => 28,
	:title => "Hardcore Trainer",
	:skill => 90,
	:moneymult => 10,
},

:COOLTRAINER_F => {
	:ID => 29,
	:title => "Hardcore Trainer",
	:skill => 90,
	:moneymult => 10,
},

:KIMONOGIRL => {
	:ID => 30,
	:title => "Yukata Girl",
	:skill => 110,
	:moneymult => 12,
	:battleBGM => "Battle - Warden11.mp3",
    :winBGM => "Victory - Warden.mp3",
},

:KIMONOGIRL2 => {
	:ID => 31,
	:title => "Kimono Girl",
	:skill => 110,
	:moneymult => 14,
	:battleBGM => "Battle - Warden11.mp3",
    :winBGM => "Victory - Warden.mp3",
},

:GUITARIST => {
	:ID => 32,
	:title => "Guitarist",
	:skill => 90,
	:moneymult => 4,
},

:WORKERF => {
	:ID => 33,
	:title => "Clerk",
	:skill => 90,
	:moneymult => 15,
},

:WORKERM => {
	:ID => 34,
	:title => "Clerk",
	:skill => 90,
	:moneymult => 15,
},

:OFFICER => {
	:ID => 35,
	:title => "Police Officer",
	:skill => 90,
	:moneymult => 15,
},

:SCIENTIST => {
	:ID => 36,
	:title => "Scientist",
	:skill => 90,
	:moneymult => 16,
},

:LASS => {
	:ID => 37,
	:title => "Enthusiast",
	:skill => 90,
	:moneymult => 9,
},

:POKEMONRANGER_M => {
	:ID => 38,
	:title => "Pokémon Ranger",
	:skill => 90,
	:moneymult => 11,
},

:POKEMONRANGER_F => {
	:ID => 39,
	:title => "Pokémon Ranger",
	:skill => 90,
	:moneymult => 11,
},

:CRUSHGIRL => {
	:ID => 40,
	:title => "Battle Girl",
	:skill => 90,
	:moneymult => 14,
},

:CAMPER => {
	:ID => 41,
	:title => "Schoolboy",
	:skill => 90,
	:moneymult => 5,
},

:PICNICKER => {
	:ID => 42,
	:title => "Schoolgirl",
	:skill => 90,
	:moneymult => 5,
},

:FAIRYGIRL => {
	:ID => 43,
	:title => "Fairy Girl",
	:skill => 90,
	:moneymult => 6,
},

:TOURIST => {
	:ID => 44,
	:title => "Tourist",
	:skill => 90,
	:moneymult => 21,
},

:XENANALYST_M => {
	:ID => 45,
	:title => "Xen Analyst",
	:skill => 112,
	:moneymult => 4,
	:battleBGM => "Battle - Team Xen_1.mp3",
},

:COOLCOUPLE1 => {
	:ID => 46,
	:title => "Cool Couple",
	:skill => 90,
	:moneymult => 16,
},

:DESERTDWELLER_MW => {
	:ID => 47,
	:title => "Desert Dweller",
	:skill => 90,
	:moneymult => 1,
},

:DESERTDWELLER_MB => {
	:ID => 48,
	:title => "Desert Dweller",
	:skill => 90,
	:moneymult => 1,
},

:DESERTDWELLER_FW => {
	:ID => 49,
	:title => "Desert Dweller",
	:skill => 90,
	:moneymult => 1,
},

:DESERTDWELLER_FB => {
	:ID => 50,
	:title => "Desert Dweller",
	:skill => 90,
	:moneymult => 1,
},

:NEWREP => {
	:ID => 60,
	:title => "News Crew",
	:skill => 90,
	:moneymult => 4,
},

:POKEGANG2 => {
	:ID => 61,
	:title => "Poke Gang",
	:skill => 90,
},

:MERCH => {
	:ID => 62,
	:title => "Merchant",
	:skill => 90,
	:battleBGM => "Stop!Thief!",
},

:BEAST => {
	:ID => 63,
	:title => "Ancient Leviathan",
	:skill => 90,
	:battleBGM => "Battle - Legendary.mp3",
},

:LUNA => {
	:ID => 64,
	:title => "Chaotic Fusion",
	:skill => 90,
	:battleBGM => "Battle - Legendary.mp3",
},

:POKEGANG => {
	:ID => 65,
	:title => "PokeGang",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Challenger.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:RENEGADE => {
	:ID => 66,
	:title => "Renegade",
	:skill => 90,
	:battleBGM => "Battle- Distortion.mp3",
},

:CHALLENGER => {
	:ID => 67,
	:title => "Challenger",
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle- Challenger.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:GHOSTGIRL => {
	:ID => 68,
	:title => "Ghost Girl",
	:skill => 100,
	:moneymult => 4,
},

:GHOSTGUY => {
	:ID => 69,
	:title => "Ghost Guy",
	:skill => 100,
	:moneymult => 4,
},

:GANGLEADER => {
	:ID => 70,
	:title => "Gang Leader",
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle - Warden13.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:POKEGANG_1 => {
	:ID => 71,
	:title => "PokeGang",
	:skill => 90,
},

:BUGCATCH => {
	:ID => 72,
	:title => "Bug Catcher",
	:skill => 90,
	:moneymult => 10,
	:battleBGM => "RSE - Battle.mp3",
},

:WITCH => {
	:ID => 73,
	:title => "Spellcaster",
	:skill => 90,
	:moneymult => 10,
	:battleBGM => "RSE - Battle.mp3",
},

:YOUNGMONEY => {
	:ID => 74,
	:title => "YOUNGSTER",
	:skill => 90,
	:moneymult => 10,
	:battleBGM => "RSE - Battle.mp3",
},

:LADYGIRL => {
	:ID => 75,
	:title => "Lady",
	:skill => 90,
	:moneymult => 13,
	:battleBGM => "RSE - Battle.mp3",
},

:SUPERSTAR => {
	:ID => 76,
	:title => "Lingering Regret",
	:skill => 90,
	:battleBGM => "Battle- Mother.mp3",
},

:SECURITYBOT => {
	:ID => 77,
	:title => "Security Bot",
	:skill => 110,
	:battleBGM => "Battle- Pretentious.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:GARBODOR => {
	:ID => 78,
	:title => "Garbodor",
	:skill => 90,
	:battleBGM => "Battle - Mini Boss.mp3",
},

:DISCOTEEN => {
	:ID => 79,
	:title => "Dance Prodigy",
	:skill => 110,
	:moneymult => 18,
	:battleBGM => "Battle - Rorrim B..mp3",
	:winBGM => "Victory - Warden.mp3",
},

:ANCIENT => {
	:ID => 80,
	:title => "Ancient Guard",
	:skill => 110,
	:battleBGM => "Battle- Pretentious.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:WANDERER => {
	:ID => 81,
	:title => "Wanderer",
	:skill => 110,
	:moneymult => 18,
	:battleBGM => "Battle - Rival",
},

:SENSEI_1 => {
	:ID => 82,
	:title => "Sensei",
	:skill => 110,
	:battleBGM => "Battle- Arrogance.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:POKEGANG3 => {
	:ID => 83,
	:title => "PokeGang",
	:skill => 100,
	:battleBGM => "Battle - Mini Boss.mp3",
},

:POKEGANG4 => {
	:ID => 84,
	:title => "PokeGang",
	:skill => 100,
	:battleBGM => "Battle - Mini Boss.mp3",
},

:POKEGANG5 => {
	:ID => 85,
	:title => "Island Deity",
	:skill => 100,
	:battleBGM => "Battle - Mini Boss.mp3",
},

:POKEMONRANGER_M1 => {
	:ID => 86,
	:title => "Pokemon Ranger",
	:skill => 110,
	:moneymult => 10,
	:battleBGM => "Battle- Pretentious.mp3",
    :winBGM => "Victory - Warden.mp3",
},

:POKEMONRANGER_F1 => {
	:ID => 87,
	:title => "Pokémon Ranger",
	:skill => 110,
	:moneymult => 10,
	:battleBGM => "Battle- Pretentious.mp3",
    :winBGM => "Victory - Warden.mp3",
},

:MADSCIENTIST => {
	:ID => 88,
	:title => "Mad Scientist",
	:skill => 110,
	:battleBGM => "Battle- Pretentious.mp3",
    :winBGM => "Victory - Warden.mp3",
},

:STUDENT => {
	:ID => 90,
	:title => "Student",
	:trainerID => 45886,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Challenger.mp3",
},

:STUDENT_2 => {
	:ID => 91,
	:title => "Student",
	:trainerID => 45886,
	:skill => 110,
	:battleBGM => "Battle- Challenger.mp3",
},

:ENIGMA => {
	:ID => 92,
	:title => "Pokemon Trainer",
	:trainerID => 27973,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Chosen.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:APPRENTICE => {
	:ID => 93,
	:title => "Apprentice",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Apprentice.mp3",
},

:ROGUEAPP => {
	:ID => 94,
	:title => "Rogue Apprentice",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Apprentice.mp3",
},

:CANDIDGIRL => {
	:ID => 95,
	:title => "Candid Girl",
	:trainerID => 63932,
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Chosen.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:OUTCAST => {
	:ID => 96,
	:title => "Outcast",
	:trainerID => 27412,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Quake.mp3",
},

:RUNAWAYGIRL => {
	:ID => 97,
	:title => "Runaway",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:XENDEATHWING_M => {
	:ID => 98,
	:title => "Deathwing",
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle - Team Xen_1.mp3",
},

:XENDEATHWING_F => {
	:ID => 99,
	:title => "Deathwing",
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle - Team Xen_1.mp3",
},

:XENGRUNT_M => {
	:ID => 100,
	:title => "Team Xen",
	:skill => 90,
	:moneymult => 4,
	:battleBGM => "Battle - Team Xen.mp3",
},

:XENGRUNT_F => {
	:ID => 101,
	:title => "Team Xen",
	:skill => 90,
	:moneymult => 4,
	:battleBGM => "Battle - Team Xen.mp3",
},

:XENEXECUTIVE_1 => {
	:ID => 102,
	:title => "Xen Executive",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Xen ExecutivesZ.mp3",
	:winBGM => "Victory - Xen.mp3",
},

:XENEXECUTIVE_2 => {
	:ID => 103,
	:title => "Xen Executive",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Xen Executives.mp3",
},

:XENEXECUTIVE_3 => {
	:ID => 104,
	:title => "Xen Executive",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Xen ExecutivesG.mp3",
},

:XENEXECUTIVE_4 => {
	:ID => 105,
	:title => "Xen Executive",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Xen ExecutivesN.mp3",
	:winBGM => "Victory - Xen.mp3",
},

:MISFORTUNATEDUO => {
	:ID => 106,
	:title => "Misfortunate Duo",
	:skill => 110,
	:moneymult => 13,
	:battleBGM => "Battle - Team Xen.mp3",
},

:DNACLONE => {
	:ID => 107,
	:title => "DNA Clone",
	:skill => 100,
	:battleBGM => "Battle - Mini Boss.mp3",
},

:SERVANT => {
	:ID => 108,
	:title => "Servant",
	:skill => 110,
	:moneymult => 1,
	:battleBGM => "Battle - Intense.mp3",
},

:SECURITYSYSTEM => {
	:ID => 109,
	:title => "Security Component",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Sec.mp3",
	:winBGM => "Victory - Xen.mp3",
},

:DOCTOR => {
	:ID => 110,
	:title => "Doctor",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Remedy.mp3",
},

:HOOD => {
	:ID => 111,
	:title => "Mystery Girl",
	:trainerID => 27973,
	:skill => 110,
	:battleBGM => "Battle - Lonely Moon.ogg",
	:winBGM => "Victory - Warden.mp3",

},

:XENDICTATOR => {
	:ID => 112,
	:title => "Xen Dictator",
	:skill => 110,
	:moneymult => 30,
	:battleBGM => "Battle - MX",
},

:TEAMAA_F => {
	:ID => 113,
	:title => "Team Anti-Assist",
	:skill => 110,
	:moneymult => 6,
	:battleBGM => "Battle- Pretentious.mp3",
},

:TEAMAA_M => {
	:ID => 114,
	:title => "Team Anti-Assist",
	:skill => 110,
	:moneymult => 6,
	:battleBGM => "Battle- Pretentious.mp3",
},

:BLADESTAR_F => {
	:ID => 115,
	:title => "Bladestar",
	:skill => 110,
	:moneymult => 6,
	:battleBGM => "Battle - Machine.mp3",
},

:BLADESTAR_M => {
	:ID => 116,
	:title => "Bladestar",
	:skill => 110,
	:moneymult => 6,
	:battleBGM => "Battle - Machine.mp3",
},

:CAPTAIN => {
	:ID => 117,
	:title => "Captain",
	:skill => 110,
	:moneymult => 22,
	:battleBGM => "Battle- Apprehensive.mp3",
},

:SURVIVOR => {
	:ID => 118,
	:title => "Survivor",
	:skill => 110,
	:battleBGM => "Battle- Sensei.mp3",
},

:SPELUNKER_BLADEM => {
	:ID => 119,
	:title => "Spelunker Grunt",
	:skill => 110,
	:moneymult => 22,
	:battleBGM => "Battle - Intense.mp3",
},

:PRISONGUARD => {
	:ID => 120,
	:title => "Prison Guard",
	:skill => 90,
	:moneymult => 12,
	:battleBGM => "Battle - Team Xen.mp3",
},

:XENANALYST_F => {
	:ID => 121,
	:title => "Xen Analyst",
	:skill => 100,
	:moneymult => 12,
	:battleBGM => "Battle - Team Xen_1.mp3",
},

:DIMENSIONALRIFT => {
	:ID => 122,
	:title => "Dimensional Rift",
	:skill => 110,
	:battleBGM => "Battle - Dimensional Rift.mp3",
},

:RENEGADEM => {
	:ID => 124,
	:title => "Pyriah",
	:skill => 100,
	:moneymult => 1,
	:battleBGM => "Battle - Team Xen.mp3",
},

:RENEGADEF => {
	:ID => 125,
	:title => "Pyriah",
	:skill => 100,
	:moneymult => 1,
	:battleBGM => "Battle - Team Xen.mp3",
},

:FAITHFUL => {
	:ID => 126,
	:title => "Angie's Right Hand",
	:skill => 110,
	:moneymult => 22,
	:battleBGM => "Battle - Legendary.mp3",
},

:HOOD1 => {
	:ID => 127,
	:title => "Hooded Boy",
	:skill => 100,
	:moneymult => 22,
	:battleBGM => "Battle - Xen Executives.mp3",
},

:BLADESTAR_F1 => {
	:ID => 128,
	:title => "Bladestar Admin",
	:skill => 110,
	:moneymult => 16,
	:battleBGM => "Battle - Machine.mp3",
},

:BLADESTAR_M1 => {
	:ID => 129,
	:title => "Bladestar Admin",
	:skill => 110,
	:moneymult => 17,
	:battleBGM => "Battle - Machine.mp3",
},

:LEADER_VENAM => {
	:ID => 130,
	:title => "Punk Girl",
	:skill => 110,
	:moneymult => 19,
	:battleBGM => "Battle- Bigshot.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_VENAM2 => {
	:ID => 131,
	:title => "Punk Girl",
	:skill => 110,
	:moneymult => 24,
	:battleBGM => "Battle- Punk.mp3",
},

:LEADER_KETA => {
	:ID => 132,
	:title => "Sensei",
	:skill => 110,
	:moneymult => 22,
	:battleBGM => "Battle- Sensei.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_KETA2 => {
	:ID => 133,
	:title => "Sensei",
	:skill => 110,
	:battleBGM => "Battle- SpiritKeta.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:LEADER_MARIANETTE => {
	:ID => 134,
	:title => "Child of Light",
	:skill => 110,
	:moneymult => 8,
	:battleBGM => "Battle- Diviner.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_NARCISSA => {
	:ID => 135,
	:title => "Actress",
	:skill => 110,
	:moneymult => 23,
	:battleBGM => "Battle- Thespian.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_VALARIE => {
	:ID => 136,
	:title => "Water Show Performer",
	:skill => 110,
	:moneymult => 22,
	:battleBGM => "Battle- Aquatic.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_CRAWLI => {
	:ID => 137,
	:title => "Head Ranger",
	:skill => 110,
	:moneymult => 28,
	:battleBGM => "Battle- Assiduous.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_CRAWLI2 => {
	:ID => 138,
	:title => "International Police",
	:skill => 110,
	:moneymult => 30,
	:battleBGM => "Battle- Assiduous.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_ANGIE => {
	:ID => 139,
	:title => "Faithful Servant",
	:skill => 110,
	:moneymult => 12,
	:battleBGM => "Battle - Angie.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_TEXEN => {
	:ID => 140,
	:title => "Pseudo Sensei",
	:skill => 110,
	:moneymult => 6,
	:battleBGM => "Battle -Texen.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:LEADER_AMBER => {
	:ID => 141,
	:title => "Music Enthusiast",
	:trainerID => 57893,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Temper.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_ERICK => {
	:ID => 142,
	:title => "Electrical Engineer",
	:skill => 110,
	:moneymult => 22,
	:battleBGM => "Battle- Cyberpunk.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_FLORA => {
	:ID => 143,
	:title => "Botanist",
	:skill => 110,
	:moneymult => 16,
	:battleBGM => "Battle- Blossom.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_FLORIN => {
	:ID => 144,
	:title => "Botanist",
	:skill => 110,
	:moneymult => 16,
	:battleBGM => "Battle- Sprout.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_PUPPET1 => {
	:ID => 145,
	:title => "Puppet Master",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Strings.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_PUPPET2 => {
	:ID => 146,
	:title => "Puppet Master",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Strings.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_SOUTA => {
	:ID => 147,
	:title => "Spiritual Healer",
	:skill => 110,
	:moneymult => 10,
	:battleBGM => "Battle- Windborne.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_SPECTOR => {
	:ID => 148,
	:title => "Ghost Kid",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Shadow.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_SAKI => {
	:ID => 149,
	:title => "Ultimate Engineer",
	:skill => 110,
	:moneymult => 30,
	:battleBGM => "Battle- Eccentric.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_SAKI2 => {
	:ID => 150,
	:title => "Ultimate Engineer",
	:skill => 110,
	:moneymult => 98,
	:battleBGM => "Battle- Eccentric.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_RYLAND => {
	:ID => 151,
	:title => "Forgotten Prince",
	:skill => 110,
	:moneymult => 10,
	:battleBGM => "Battle - Flora.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_LAVENDER => {
	:ID => 152,
	:title => "Psychologist",
	:trainerID => 19303,
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Metaphysical.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:UNKNOWN_1 => {
	:ID => 153,
	:title => "???",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Kieran.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:UNKNOWN_2 => {
	:ID => 154,
	:title => "???",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Clear.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:RECO_F => {
	:ID => 155,
	:title => "Rejuv Co. Employee",
	:skill => 90,
	:moneymult => 10,
	:battleBGM => "RSE - Enemy Battle.mp3",
},

:RECO_M => {
	:ID => 156,
	:title => "Rejuv Co. Employee",
	:skill => 90,
	:moneymult => 10,
	:battleBGM => "RSE - Enemy Battle.mp3",
},

:OPTKID => {
	:ID => 157,
	:title => "Optimistic Guy",
	:trainerID => 34605,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
},

:OPTKID_1 => {
	:ID => 158,
	:title => "Optimistic Guy",
	:trainerID => 34605,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
},

:TRENDYGIRL => {
	:ID => 159,
	:title => "Trendy Girl",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival 2.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:TRENDYGIRL_1 => {
	:ID => 160,
	:title => "Trendy Girl",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival 2.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_ADAM => {
	:ID => 161,
	:title => "Aevium Sensation",
	:trainerID => 56474,
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Wasteland.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_ADAM1 => {
	:ID => 162,
	:title => "Ruin Maniac",
	:trainerID => 56474,
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Wasteland.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:ANGELOFDEATH => {
	:ID => 163,
	:title => "Angel of Death",
	:skill => 110,
	:battleBGM => "Battle - Dimensional Rift.mp3",
},

:OPTKID_2 => {
	:ID => 164,
	:title => "Servant",
	:trainerID => 34605,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
},

:ENIGMA_2 => {
	:ID => 165,
	:title => "Pokemon Trainer",
	:trainerID => 27973,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Chosen.mp3",
},

:WPUNK => {
	:ID => 166,
	:title => "Wasteland Punk",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Cyanide.mp3",
},

:POKEGANG6 => {
	:ID => 168,
	:title => "PokeGang",
	:skill => 100,
	:battleBGM => "Battle - Mini Boss.mp3",
},

:POPSTAR => {
	:ID => 169,
	:title => "Popstar",
	:skill => 110,
	:battleBGM => "Battle- Hypothesis.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:ROGPSYCHIC => {
	:ID => 170,
	:title => "Rogue Psychic",
	:skill => 100,
},

:STUDENT_3 => {
	:ID => 171,
	:title => "Leader",
	:trainerID => 45886,
	:skill => 110,
	:battleBGM => "Battle- Reflection.mp3",
},

:HERO => {
	:ID => 172,
	:title => "Eventual Hero",
	:skill => 110,
	:battleBGM => "Battle - Rival.mp3",
},

:POKEGANG7 => {
	:ID => 173,
	:title => "Tormented Leviathan",
	:skill => 110,
	:battleBGM => "Battle - Legendary.mp3",
},

:HERO1 => {
	:ID => 174,
	:title => "Hero of Goomidra",
	:skill => 110,
	:battleBGM => "Battle - Rival.mp3",
},

:GAUNTLET => {
	:ID => 175,
	:title => "Guardian Spectre",
	:skill => 110,
	:battleBGM => "Battle - Mini Boss.mp3",
},

:DEFENSEMECH => {
	:ID => 176,
	:title => "Defense",
	:skill => 100,
	:battleBGM => "Battle - Paradox",
},

:NANO => {
	:ID => 177,
	:title => "Android Girl",
	:trainerID => 1001,
	:skill => 110,
	:battleBGM => "Battle- Soaring.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:POKEGANG8 => {
	:ID => 178,
	:title => "Temple",
	:skill => 100,
	:battleBGM => "Battle - Legendary.mp3",
},

:LEADER_VENAM3 => {
	:ID => 179,
	:title => "Punk Girl",
	:skill => 110,
	:moneymult => 24,
	:battleBGM => "Battle- Punk.mp3",
},

:ENIGMA_1 => {
	:ID => 180,
	:title => "Pokemon Trainer",
	:trainerID => 27973,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Chosen.mp3",
},

:LEADER_ANGIE2 => {
	:ID => 181,
	:title => "Faithful Servant",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Angie.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:AXISSTUDENT_MW => {
	:ID => 182,
	:title => "Axis High Student",
	:skill => 90,
	:moneymult => 1,
},

:AXISSTUDENT_MB => {
	:ID => 183,
	:title => "Axis High Student",
	:skill => 90,
	:moneymult => 1,
},

:AXISSTUDENT_FW => {
	:ID => 184,
	:title => "Axis High Student",
	:skill => 90,
	:moneymult => 1,
},

:AXISSTUDENT_FB => {
	:ID => 185,
	:title => "Axis High Student",
	:skill => 90,
	:moneymult => 1,
},

:LEADER_AMBER2 => {
	:ID => 186,
	:title => "Music Enthusiast",
	:trainerID => 57893,
	:skill => 110,
	:moneymult => 68,
	:battleBGM => "Battle- Temper.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:MASKEDMAN => {
	:ID => 187,
	:title => "Masked Individual",
	:skill => 110,
	:battleBGM => "Battle- Purgatory.mp3",
    :winBGM => "Victory - Warden.mp3",
},

:MYSTSTUDENT => {
	:ID => 188,
	:title => "Mysterious Student",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Apprentice.mp3",
    :winBGM => "Victory - Warden.mp3",
},

:XENADMIN_1 => {
	:ID => 189,
	:title => "Xen Admin",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Xen Executives.mp3",
},

:ELITE_KAREN => {
	:ID => 190,
	:title => "Elite Eight",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Mentalist.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:ROGUEHERO => {
	:ID => 191,
	:title => "Rogue Hero",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Protector of Aevium.mp3",
},

:LITTLEDEMON => {
	:ID => 192,
	:title => "Little Demon",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Tyrant.mp3",
},

:LEADER_DAMIEN => {
	:ID => 193,
	:title => "Ruin Maniac",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Foremost.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:CANDIDGIRL2 => {
	:ID => 194,
	:title => "Strategist",
	:trainerID => 639,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle -Erin.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:ICESOLDIERS => {
	:ID => 195,
	:title => "Ice Soldiers",
	:skill => 110,
	:battleBGM => "Battle- Snowmen.mp3",
},

:MYSTMAGE => {
	:ID => 196,
	:title => "Arrogant Scholar",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle - Rival.mp3",
},

:XENEXECUTIVE_5 => {
	:ID => 197,
	:title => "Xen Executive",
	:skill => 110,
	:moneymult => 22,
	:battleBGM => "Battle - Xen ExecutivesG.mp3",
	:winBGM => "Victory - Xen.mp3",
},

:ELITE_ALEXANDRA => {
	:ID => 198,
	:title => "Elite Eight",
	:trainerID => 2,
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Scion.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},
:PRINCESS_ODESSA => {
	:ID => 199,
	:title => "Kristilian Princess",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Gyms.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:LEADER_TALON => {
	:ID => 200,
	:title => "Cartographer",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Soaring.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},
:MASKEDDUO => {
	:ID => 201,
	:title => "Mystery Duo",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle - Lonely Moon.oog",
	:winBGM => "Gym Battle Victory.mp3",
},
:INTERCEPTOR => {
	:ID => 202,
	:title => "Interceptor",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Windborne.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},
:TREAT_01 => {
	:ID => 203,
	:title => "Inevitable Grief",
	:skill => 110,
	:battleBGM => "Griefgaunt.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},
:TREAT_02 => {
	:ID => 204,
	:title => "Inevitable Grief",
	:skill => 110,
	:battleBGM => "Griefgaunt.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},
:TREAT_03 => {
	:ID => 205,
	:title => "Inevitable Grief",
	:skill => 110,
	:battleBGM => "Battle - Lonely Moon.oog",
	:winBGM => "Gym Battle Victory.mp3",
},

:XENMAGE_M => {
	:ID => 206,
	:title => "Xen Mage",
	:skill => 112,
	:moneymult => 4,
	:battleBGM => "Battle - Team Xen_1.mp3",
},

:XENMAGE_F => {
	:ID => 207,
	:title => "Xen Mage",
	:skill => 112,
	:moneymult => 4,
	:battleBGM => "Battle - Team Xen_1.mp3",
},

:XG_SABER => {
	:ID => 208,
	:title => "Trainer",
	:trainerID => 13164,
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle - XG Rival.mp3",
},

:XG_WYNN => {
	:ID => 209,
	:title => "Neighbor",
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle - XG Rival.mp3",
},

:XG_ENYA => {
	:ID => 210,
	:title => "Firebrand",
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle - XG Rival.mp3",
},

:XG_ADELINDE => {
	:ID => 211,
	:title => "Serenity",
	:skill => 100,
	:moneymult => 4,
	:battleBGM => "Battle - XG Rival.mp3",
},

:XG_LUCILE => {
	:ID => 212,
	:title => "Mayor",
	:skill => 100,
	:moneymult => 4,
	:battleBGM => "Battle - Lucile.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:XG_GRUNTM => {
	:ID => 213,
	:title => "Splicer Grunt",
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle - Machine.mp3",
},

:XG_GRUNTF => {
	:ID => 214,
	:title => "Splicer Grunt",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Machine.mp3",
},

:XG_SIERRA => {
	:ID => 215,
	:title => "Splicer Admin",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Flora.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:POKEGANG9 => {
	:ID => 216,
	:title => "Garbage Gang",
	:skill => 100,
	:moneymult => 1,
	:battleBGM => "Battle - Boss.mp3",
},

:STEELRESERVE => {
	:ID => 217,
	:title => "Steel Reserve",
	:skill => 112,
	:moneymult => 4,
	:battleBGM => "Battle - Warden15.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:ICEHEIRESS => {
	:ID => 218,
	:title => "Ice Heiress",
	:skill => 110,
	:moneymult => 23,
},

:LEADER_RYLAND1 => {
	:ID => 219,
	:title => "Forgotten Prince",
	:skill => 110,
	:moneymult => 4,
	:battleBGM => "Battle- Arenaceous.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:TRAINER_M2 => {
	:ID => 220,
	:title => "Fallen Goddess",
	:trainerID => 27973,
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Griefgaunt.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:GIRLSCOUTS => {
	:ID => 221,
	:title => "Girl Scouts",
	:skill => 100,
	:moneymult => 4,
},

:DON => {
	:ID => 222,
	:title => "Don",
	:skill => 100,
	:moneymult => 23,
},

:LEADER_TALON_1 => {
	:ID => 223,
	:title => "Cartographer",
	:skill => 110,
	:moneymult => 20,
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_ALICE => {
	:ID => 224,
	:title => "Gym Leader",
	:skill => 110,
	:moneymult => 20,
	:winBGM => "Battle- Queen.mp3",
},

:SASHILAWARRIORM_1 => {
	:ID => 225,
	:title => "Sashilan Warrior",
	:skill => 100,
	:moneymult => 4,
},

:SASHILAWARRIORM_2 => {
	:ID => 226,
	:title => "Sashilan Warrior",
	:skill => 100,
	:moneymult => 4,
},

:SASHILAWARRIORF_1 => {
	:ID => 227,
	:title => "Sashilan Warrior",
	:skill => 100,
	:moneymult => 4,
},

:SASHILAWARRIORF_2 => {
	:ID => 228,
	:title => "Sashilan Warrior",
	:skill => 110,
	:moneymult => 4,
},
:DIABOLICALGENIUS => {
	:ID => 229,
	:title => "Diabolical Evil Genius",
	:skill => 110,
	:moneymult => 15,
	:battleBGM => "Battle- Dissociation.mp3",
},
:INTERCEPTORV => {
	:ID => 230,
	:title => "Interceptor",
	:skill => 110,
	:moneymult => 15,
},

:MELIA_AWAKEN => {
	:ID => 231,
	:title => "Awakened Goddess",
	:trainerID => 27973,
	:skill => 110,
	:moneymult => 20,
	:winBGM => "Gym Battle Victory.mp3",
},

:PROFJENNER => {
	:ID => 232,
	:title => "Professor",
	:skill => 110,
	:moneymult => 18,
	:battleBGM => "Battle- Hypothesis.mp3",
},

:COMMANDER => {
	:ID => 233,
	:title => "Commander",
	:skill => 110,
	:moneymult => 18,
	:battleBGM => "Battle - Mini Boss.mp3",
},

:SPIRITJENNER => {
	:ID => 234,
	:title => "Spirit",
	:skill => 110,
	:moneymult => 18,
	:battleBGM => "Battle-Spiritjenner.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:LEADER_SPECTOR2 => {
	:ID => 235,
	:title => "Ghost Kid",
	:skill => 110,
	:moneymult => 20,
	:battleBGM => "Battle- Purgatory.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:SPIRITXARA => {
	:ID => 236,
	:title => "Spirit",
	:skill => 110,
	:moneymult => 18,
	:battleBGM => "Battle-XJ.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:SPIRITJEAN => {
	:ID => 237,
	:title => "Spirit",
	:skill => 110,
	:moneymult => 18,
	:battleBGM => "Battle-XJ.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},

:JOHTO_1 => {
	:ID => 300,
	:title => "Gym Leader",
	:skill => 7,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_2 => {
	:ID => 301,
	:title => "Gym Leader",
	:skill => 14,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_3 => {
	:ID => 302,
	:title => "Gym Leader",
	:skill => 21,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_4 => {
	:ID => 303,
	:title => "Gym Leader",
	:skill => 28,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_5 => {
	:ID => 304,
	:title => "Gym Leader",
	:skill => 35,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_6 => {
	:ID => 305,
	:title => "Gym Leader",
	:skill => 42,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_7 => {
	:ID => 306,
	:title => "Gym Leader",
	:skill => 49,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_8 => {
	:ID => 307,
	:title => "Gym Leader",
	:skill => 56,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_9 => {
	:ID => 308,
	:title => "Elite Four",
	:skill => 90,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_10 => {
	:ID => 309,
	:title => "Elite Four",
	:skill => 90,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_11 => {
	:ID => 310,
	:title => "Elite Four",
	:skill => 90,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_12 => {
	:ID => 311,
	:title => "Elite Four",
	:skill => 90,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},

:JOHTO_13 => {
	:ID => 312,
	:title => "Champion",
	:skill => 100,
	:battleBGM => "GSC - Gym Leader.mp3",
	:winBGM => "Gym Battle Victory GS.mp3",
},
:DAYDREAMER_MERRY => {
	:ID => 922,
	:title => "Dreamer",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Dreamer.mp3",
	:winBGM => "Gym Battle Victory.mp3",
},
:WARDEN_SAMSON => {
	:ID => 923,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_TAKA => {
	:ID => 924,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden2.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_ROSETTA => {
	:ID => 925,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden6.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_SHIV => {
	:ID => 926,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden4.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_AURORA => {
	:ID => 927,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden5.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_VICTORIA => {
	:ID => 928,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden3.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_LILITH => {
	:ID => 929,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden7.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_LAURA => {
	:ID => 930,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden8.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_HARDY => {
	:ID => 931,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden9.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_BLAKE => {
	:ID => 932,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden10.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_CHARLOTTE => {
	:ID => 933,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden11.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_CIEL => {
	:ID => 934,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden12.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_LUNA => {
	:ID => 935,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden13.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_EMILY => {
	:ID => 936,
	:title => "Warden",
	:skill => 100,
	:moneymult => 32,
	:battleBGM => "Battle- Pretentious.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:WARDEN_FERN => {
	:ID => 937,
	:title => "Warden",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden15.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:MASTEROFNIGHTMARE => {
	:ID => 938,
	:title => "Master",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Master of Nightmares.mp3",
	:winBGM => "Victory Nightmare.mp3",
},
:CHIEF_TOLU => {
	:ID => 939,
	:title => "Leader",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Tolu.mp3",
	:winBGM => "Victory Tolu.mp3",
},
:CHIEF_TOLU2 => {
	:ID => 968,
	:title => "Leader",
	:skill => 110,
	:moneymult => 32,
},
:CHIEF_TOLU3 => {
	:ID => 981,
	:title => "Leader",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden15.mp3",
	:winBGM => "Victory Tolu.mp3",
},
:EVILGIRL_MELANIE => {
	:ID => 940,
	:title => "Evil Girl",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Thug.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSKYOGRE => {
	:ID => 942,
	:title => "Ocean Titan",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Kyogre.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSGROUDON => {
	:ID => 943,
	:title => "Earth Titan",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Kyogre.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSGARDE => {
	:ID => 944,
	:title => "Fallen",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Devil.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSCONK => {
	:ID => 945,
	:title => "Ferocious Fist",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- AA.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSFUSION => {
	:ID => 947,
	:title => "Disaster Duo",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Apprehensive.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSUXIE => {
	:ID => 948,
	:title => "Guardian",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Devil.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSAZELF => {
	:ID => 949,
	:title => "Guardian",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Devil.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSMESPRIT => {
	:ID => 950,
	:title => "Guardian",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Devil.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSSTARMIE => {
	:ID => 951,
	:title => "Spinning Menace",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Apprehensive.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSENTEI => {
	:ID => 952,
	:title => "Flame Devil",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Entei.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSSUICUNE => {
	:ID => 953,
	:title => "Wind Demon",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Suicune.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSRAIKOU => {
	:ID => 954,
	:title => "Thunder Lord",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- doggo.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSSPACEA => {
	:ID => 955,
	:title => "Ruthless",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- timehoe.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSTIEMPA => {
	:ID => 956,
	:title => "Ruthless",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- spacehoe.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSGARB=> {
	:ID => 957,
	:title => "Garbage Gang",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Thug.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSWAILORD=> {
	:ID => 958,
	:title => "Sea Titan",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Thug.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSHIPO => {
	:ID => 959,
	:title => "Earth Devil",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Apprehensive.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSFERO => {
	:ID => 960,
	:title => "Firespike",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Apprehensive.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:REBORN_SIRIUS => {
	:ID => 961,
	:title => "Reborn",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Clear.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:DREAMER_BARON => {
	:ID => 962,
	:title => "Dreamer",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Final Duel.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:REBORN_SHADE => {
	:ID => 963,
	:title => "Reborn",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Evil.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:REBORN_EL => {
	:ID => 964,
	:title => "Reborn",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Warden15.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:REBORN_SOLARIS => {
	:ID => 965,
	:title => "Reborn",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Xen ExecutivesG.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:DREAMER_WALDENHALL => {
	:ID => 966,
	:title => "Dreamer",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Diviner.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSKOKO=> {
	:ID => 970,
	:title => "Thunder Lord",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Tapukoko.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:YOSHI=> {
	:ID => 974,
	:title => "Yoshi",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- BIGBOI.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:DUFAUX=> {
	:ID => 975,
	:title => "Forgotten Phantom",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Thug.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:RIFTAELITA=> {
	:ID => 976,
	:title => "Dissonance",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Thug.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSCHANDE=> {
	:ID => 977,
	:title => "Flame Demon",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Thug.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:TRAVELER_APRIL => {
	:ID => 946,
	:title => "Traveler",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Mini Boss.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:THUG_ANDIL => {
	:ID => 941,
	:title => "Thug",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Thug.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:MIGHTY_BEAR=> {
	:ID => 978,
	:title => "Bear",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Bear.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:MOONPAWS=> {
	:ID => 979,
	:title => "Moonpaw's",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Bear.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:SPIRITSOUTA=> {
	:ID => 980,
	:title => "Spirit",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Windborne.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:GLITCHLEAGUE=> {
	:ID => 982,
	:title => "Glitch League",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Aquatic.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:GLITCHLEAGUE1=> {
	:ID => 983,
	:title => "Glitch League",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Koga.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:GLITCHLEAGUE2=> {
	:ID => 984,
	:title => "Glitch League",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Bear.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:GLITCHLEAGUE3=> {
	:ID => 985,
	:title => "Glitch League",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- Windborne.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:GLITCHLEAGUE4=> {
	:ID => 986,
	:title => "Glitch Villain",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle- GlitchF.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:ICESOLDIER => {
	:ID => 987,
	:title => "Ice Soldier",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Conclusive_1.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:BOSSCARN => {
	:ID => 988,
	:title => "Demonic",
	:skill => 110,
	:moneymult => 32,
	:battleBGM => "Battle - Trainers3.ogg",
	:winBGM => "Victory - Warden.mp3",
},

:SPIRITKETA => {
	:ID => 133,
	:title => "Spirit",
	:skill => 110,
	:battleBGM => "Battle- SpiritKeta.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:ESCAV => {
	:ID => 989,
	:title => "Metereologist",
	:skill => 110,
	:battleBGM => "Battle - Rival 2.mp3",
	:winBGM => "Victory - Warden.mp3",
},

:GAUNTLETBOT => {
	:ID => 990,
	:title => "Security",
	:skill => 110,
	:battleBGM => "Battle- Pretentious.mp3",
	:winBGM => "Victory - Warden.mp3",
},
:JOHTO_0F => {
	:ID => 314,
	:title => "Trainer",
	:trainerID => 1010,
	:skill => 100,
},

:RUINMANIAC => {
	:ID => 900,
	:title => "Ruin Maniac",
	:skill => 48,
	:moneymult => 48,
},

:POKEMANIAC => {
	:ID => 901,
	:title => "Poké Maniac",
	:skill => 64,
	:moneymult => 64,
},

:POKEMONBREEDER => {
	:ID => 902,
	:title => "Pokémon Breeder",
	:skill => 48,
	:moneymult => 48,
},

:JUGGLER => {
	:ID => 903,
	:title => "Juggler",
	:skill => 32,
	:moneymult => 32,
},

:GAMBLER => {
	:ID => 904,
	:title => "Gambler",
	:skill => 32,
	:moneymult => 72,
},

:SUPERNERD => {
	:ID => 905,
	:title => "Super Nerd",
	:skill => 48,
	:moneymult => 48,
},

:TAMER => {
	:ID => 906,
	:title => "Tamer",
	:skill => 40,
	:moneymult => 40,
},

:SWIMMER_M => {
	:ID => 907,
	:title => "Swimmer",
	:skill => 32,
	:moneymult => 16,
},

:SWIMMER_F => {
	:ID => 908,
	:title => "Swimmer",
	:skill => 32,
	:moneymult => 16,
},

:TUBER_M => {
	:ID => 909,
	:title => "Tuber",
	:skill => 16,
	:moneymult => 4,
},

:TUBER_F => {
	:ID => 910,
	:title => "Tuber",
	:skill => 16,
	:moneymult => 4,
},

:TEAMROCKET_M => {
	:ID => 911,
	:title => "Team Rocket",
	:skill => 32,
	:moneymult => 32,
},

:TEAMROCKET_F => {
	:ID => 912,
	:title => "Team Rocket",
	:skill => 32,
	:moneymult => 32,
},

:PSYCHIC_M => {
	:ID => 913,
	:title => "Psychic",
	:skill => 32,
	:moneymult => 32,
},

:PSYCHIC_F => {
	:ID => 914,
	:title => "Psychic",
	:skill => 32,
	:moneymult => 32,
},

:TWINS => {
	:ID => 915,
	:title => "Twins",
	:skill => 24,
	:moneymult => 24,
},

:COOLCOUPLE => {
	:ID => 916,
	:title => "Cool Couple",
	:skill => 48,
	:moneymult => 72,
},

:CRUSHKIN => {
	:ID => 917,
	:title => "Crush Kin",
	:skill => 48,
	:moneymult => 48,
},

:SISANDBRO => {
	:ID => 918,
	:title => "Sis and Bro",
	:skill => 48,
	:moneymult => 16,
},

:BIKER => {
	:ID => 919,
	:title => "Biker",
	:skill => 32,
	:moneymult => 32,
},

:SAILOR => {
	:ID => 920,
	:title => "Sailor",
	:skill => 32,
	:moneymult => 32,
},

:GENTLEMAN => {
	:ID => 921,
	:title => "Sailor",
	:skill => 32,
	:moneymult => 32,
},
:JOHTO_0M => {
	:ID => 313,
	:title => "Trainer",
	:trainerID => 1010,
	:skill => 100,
},

}