FIELDEFFECTS = {
:INDOOR => {
	:name => "",
	:fieldMessage => [
		""
	],
	:graphic => ["Indoor","IndoorA","IndoorB","IndoorC","IndoorD","IndoorE","IndoorVenam","AxisHigh","NightmareSchool"],
	:secretPower => "TRIATTACK",
	:naturePower => :TRIATTACK,
	:mimicry => :NORMAL,	
	:damageMods => { #damage modifiers for specific moves, written as multipliers (e.g. 1.5 => [:TACKLE])
	},				# a damage mod of 0 denotes the move failing on this field
	:accuracyMods => { #accuracy chance for specific moves, written as percent chance to hit (e.g. 80 => [:TOXIC])
	},				# a accuracy mod of 0 denotes the move always hitting on this field
	:moveMessages => {	# the field message displayed when using a move (written as "message" => [move1,move2....] )
	},
	:typeMods => {	# secondary types applied to moves (written as "type" => [move1,move2,....])
	},
	:typeAddOns => { # secondary types applied to entire types (written as SecondaryTypeSymbol => [typesymbol1,typesymbol2,...])
	},
	:moveEffects => { # arbitrary commands that are evaled after a move executes but before fieldchanges are checked
	},	#evaled in "fieldEffectAfterMove" method in the battle class
	:typeBoosts => { # damage multipliers applied to all moves of a specific type (e.g. 1.3 => [:FIRE,:WATER])
	},
	:typeMessages => {	# field message shown when using a move of the denoted type ("message" => [type1,type2,....])
	},
	:typeCondition => {	# conditions for the type boost written as a string of conditions that are evaled later
	},	#evaled as a function on the move class
	:typeEffects => { # arbitrary commands attached to all moves of a type that are evaled after a move executes but before fieldchanges are checked
	},	#evaled in "fieldEffectAfterMove" method in the battle class
	:changeCondition => { # conditions for a field change written as a string of conditions that are evaled later
	},	#evaled as a function on the move class
	:fieldChange => {  # moves that change this field to a different field (Fieldsymbol => [move1,move2,....])
	},
	:dontChangeBackup => [],	#list of moves which store the current field as backup when changing the field
	:changeMessage => {	# message displayed when changing a field to a different one ("message" => [move1,move2,....])
	},
	:statusMods => [],	#list of non-damaging moves boosted by the field in different ways, for field highlighting
	:changeEffects => {#additional effects that happen when specific moves change a field (such as corrisive mist explosion)
	},	#evaled in "fieldEffectAfterMove" method in the battle class
	:seed => {		# the seed effects on this field
		:seedtype => nil,	# which seed is activated
		:effect => nil,		# which battler effect is being changed if any
		:duration => nil,	# duration of the extra effect
		:message => nil,	# message shown with the seeds boost
		:animation => nil,	# animation associated with the effect
		:stats => {			# statchanges caused by the seed
		},
	},
	:overlay => {		# effects of this field as an overlay instead of a full field #Rejuv
		:damageMods => { #damage modifiers for specific moves, written as multipliers (e.g. 1.5 => [:TACKLE])
		},				# a damage mod of 0 denotes the move failing on this field
		:typeMods => {	# secondary types applied to moves (written as "type" => [move1,move2,....])
		},
		:moveMessages => {	# the field message displayed when using a move (written as "message" => [move1,move2....] )
		},
		:typeBoosts => { # damage multipliers applied to all moves of a specific type (e.g. 1.3 => [:FIRE,:WATER])
		},
		:typeMessages => {	# field message shown when using a move of the denoted type ("message" => [type1,type2,....])
		},
		:typeCondition => {	# conditions for the type boost written as a string of conditions that are evaled later
		},	#evaled as a function on the move class
		:statusMods => [],	#list of non-damaging moves boosted by the field in different ways, for field highlighting
	},
},
:ELECTERRAIN => {
	:name => "Electric Terrain",
	:fieldMessage => [
		"The field is hyper-charged!"
	],
	:graphic => ["Electric"],
	:secretPower => "SHOCKWAVE",
	:naturePower => :THUNDERBOLT,
	:mimicry => :ELECTRIC,
	:damageMods => {
		1.2 =>  [:RAZORWIND],
		1.5 => [:EXPLOSION, :SELFDESTRUCT, :HURRICANE, :SURF, :MAGMADRIFT, :SMACKDOWN, :MUDDYWATER, :THOUSANDARROWS, :WILDBOLTSTORM,:ROLLOUT,:RUSHHOUR,:FLAMEWHEEL,:JUMPKICK],
		2.0 => [:TAKEDOWN], #Extreme Ace move
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The explosion became hyper-charged!" => [:EXPLOSION, :SELFDESTRUCT],
		"The attack became hyper-charged!" => [:HURRICANE, :SURF, :SMACKDOWN, :MAGMADRIFT, :MUDDYWATER, :THOUSANDARROWS,:RAZORWIND, :WILDBOLTSTORM],
		"The attack becomes faster and faster!" => [:TAKEDOWN,:ROLLOUT,:RUSHHOUR,:FLAMEWHEEL,:JUMPKICK],
	},
	:typeMods => {
		:ELECTRIC => [:EXPLOSION, :SURF, :MUDDYWATER,:MAGMADRIFT, :HURRICANE],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ELECTRIC],
	},
	:typeMessages => {
		"The Electric Terrain strengthened the attack!" => [:ELECTRIC],
	},
	:typeCondition => {
		:ELECTRIC => "!attacker.isAirborne?",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:changeMessage => {
	},
	:statusMods => [:CHARGE, :EERIEIMPULSE, :MAGNETRISE, :SPIKES, :ELECTRIFY],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :Charge,
		:duration => 2,
		:message => "{1} began charging power!",
		:animation => :CHARGE,
		:stats => {
			PBStats::SPEED => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.2 => [:RAZORWIND,:ROLLOUT,:RUSHHOUR,:FLAMEWHEEL,:JUMPKICK],
			1.4 => [:EXPLOSION, :SELFDESTRUCT, :HURRICANE, :SURF, :SMACKDOWN, :MUDDYWATER,:MAGMADRIFT,:MAGNETBOMB,:THOUSANDARROWS],
		},
		:typeMods => {
			:ELECTRIC => [:EXPLOSION, :SELFDESTRUCT, :SMACKDOWN, :SURF, :MUDDYWATER, :HURRICANE,:MAGMADRIFT, :THOUSANDARROWS],
		},
		:moveMessages => {
			"The explosion became hyper-charged!" => [:EXPLOSION, :SELFDESTRUCT],
			"The attack became hyper-charged!" => [:HURRICANE, :SURF, :SMACKDOWN, :MUDDYWATER, :THOUSANDARROWS,:MAGMADRIFT],
			"The attack became charged!" => [:RAZORWIND,:ROLLOUT,:RUSHHOUR,:FLAMEWHEEL,:JUMPKICK],
			"The magnet energy got electrocuted!" => [:MAGNETBOMB],
		},
		:typeBoosts => {
			1.5 => [:ELECTRIC],
		},
		:typeMessages => {
			"The Electric Terrain strengthened the attack!" => [:ELECTRIC],
		},
		:typeCondition => {
			:ELECTRIC => "!attacker.isAirborne?",
		},
		:statusMods => [:MAGNETRISE],
	},
},
:GRASSY => {
	:name => "Grassy Terrain",
	:fieldMessage => [
		"The field is in full bloom."
	],
	:graphic => ["Grassy"],
	:secretPower => "SEEDBOMB",
	:naturePower => :GRASSYGLIDE,
	:mimicry => :GRASS,
	:damageMods => {
		1.4 => [:ENERGYBALL, :SEEDFLARE, :UPROOT, :GRASSYGLIDE, :POWERWHIP, :LEAFBLADE],
		2.0 => [:NATURALGIFT,:INCINERATE],#Extreme Ace move and Celebi sig
		1.3 => [:FAIRYWIND, :SILVERWIND, :OMINOUSWIND,:LEAFTORNADO, :ICYWIND, :RAZORWIND,:PIXIESTORM, :GUST, :TWISTER, :GRASSKNOT,:FEVERPITCH],
		0.5 => [:MUDDYWATER, :SURF, :EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
	},
	:accuracyMods => {
		80 => [:GRASSWHISTLE],
	},
	:moveMessages => {
		"The wind picked up strength from the field!" => [:FAIRYWIND, :SILVERWIND,:LEAFTORNADO, :OMINOUSWIND, :ICYWIND, :RAZORWIND,:PIXIESTORM, :GUST, :TWISTER],
		"The meadow strengthened the attack!" => [:GRASSKNOT, :ENERGYBALL, :SEEDFLARE, :UPROOT, :GRASSYGLIDE, :POWERWHIP, :LEAFBLADE],
		"The grass softened the attack..." => [:MUDDYWATER, :SURF, :EARTHQUAKE, :MAGNITUDE, :BULLDOZE],
		"The green got plunged into a sea of flames!" => [:INCINERATE,:FEVERPITCH],
		"The nature is at its peak!" => [:NATURALGIFT],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
	},
	:typeBoosts => {
		1.5 => [:GRASS, :FIRE,:BUG],
	},
	:typeMessages => {
		"The Grassy Terrain strengthened the attack!" => [:GRASS],
		"The grass caught fire!" => [:FIRE],
		"The grass got infested by bugs!" => [:BUG],
	},
	:typeCondition => {
		:GRASS => "!attacker.isAirborne?",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:GROWTH, :FLORALHEALING, :SYNTHESIS, :WORRYSEED, :INGRAIN, :GRASSWHISTLE, :LEECHSEED, :COTTONSPORE],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :Growth,
		:message => "{1} is growing!",
		:animation => :GROWTH,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.25 => [:ENERGYBALL, :HORNLEECH, :GIGADRAIN, :SEEDBOMB, :LEAFBLADE,:GRASSYGLIDE,:FAIRYWIND, :SILVERWIND, :OMINOUSWIND, :ICYWIND, :RAZORWIND, :GUST, :TWISTER,:PIXIESTORM],
			2.0 => [:NATURALGIFT],
		},
		:typeMods => {
		},
		:moveMessages => {
			"The green meadow amplified the attack!" => [:ENERGYBALL, :HORNLEECH, :GIGADRAIN, :SEEDBOMB, :LEAFBLADE,:GRASSYGLIDE],
			"The green meadow became one with nature!" => [:NATURALGIFT],
			"The winds energy powered up the attack!" => [:FAIRYWIND, :SILVERWIND, :OMINOUSWIND, :ICYWIND, :RAZORWIND,:PIXIESTORM, :GUST, :TWISTER],
		},
		:typeBoosts => {
			1.4 => [:GRASS],
			1.2 => [:FIRE,:BUG],
		},
		:typeMessages => {
			"The Grassy Terrain strengthened the attack!" => [:GRASS],
			"The grass below caught flame!" => [:FIRE],
			"The grass got infested by bugs!" => [:BUG],
		},
		:typeCondition => {
		},
		:statusMods => [],
	},
},
:MISTY => {
	:name => "Misty Terrain",
	:fieldMessage => [
		"Mist settles on the field."
	],
	:graphic => ["Misty"],
	:secretPower => "MISTBALL",
	:naturePower => :MISTBALL,
	:mimicry => :FAIRY,
	:damageMods => {
		1.5 => [:MYSTICALFIRE,:STARBURST, :MAGICALLEAF, :DOOMDUMMY, :ICYWIND, :MISTBALL, :AURASPHERE, :STEAMERUPTION, :SILVERWIND, :MOONGEISTBEAM,:STRANGESTEAM, :SPRINGTIDESTORM,:FAIRYWIND,:PLAYROUGH],
		0.5 => [:DARKPULSE, :SHADOWBALL, :NIGHTDAZE],
		0 => [:SELFDESTRUCT, :EXPLOSION, :MINDBLOWN, :STEELBEAM],
		2.0 => [:SHOCKWAVE],
	},
	:accuracyMods => {
		100 => [:SWEETKISS],
	},
	:moveMessages => {
		"The mist's energy strengthened the attack!" => [:MYSTICALFIRE,:STARBURST, :MAGICALLEAF, :DOOMDUMMY, :ICYWIND, :MISTBALL, :AURASPHERE, :STEAMERUPTION, :SILVERWIND, :MOONGEISTBEAM, :SMOG, :CLEARSMOG, :STRANGESTEAM, :SPRINGTIDESTORM,:FAIRYWIND,:PLAYROUGH],
		"The mist softened the attack..." => [:DARKPULSE, :SHADOWBALL, :NIGHTDAZE],
		"The damp mist prevented the explosion..." => [:SELFDESTRUCT, :EXPLOSION, :MINDBLOWN],
		"The mist vaporized the beam..." => [:STEELBEAM],
		"Bright light and tension charges the mist!" => [:SHOCKWAVE],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
	},
	:typeBoosts => {
		1.5 => [:FAIRY],
		0.5 => [:DRAGON,:STEEL],
	},
	:typeMessages => {
		"The Misty Terrain strengthened the attack!" => [:FAIRY],
		"The Misty Terrain weakened the attack!" => [:DRAGON],
		"The mist corroded the steel!" => [:STEEL],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:changeMessage => {
	},
	:statusMods => [:COSMICPOWER, :AROMATICMIST, :SWEETSCENT, :WISH, :AQUARING],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :Wish,
		:duration => 2,
		:message => "A wish was made for {1}!",
		:animation => :WISH,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.5 => [:MYSTICALFIRE, :MAGICALLEAF, :DOOMDUMMY, :ICYWIND, :MISTBALL, :AURASPHERE, :SILVERWIND, :OMINOUSWIND, :SCALD,:LIQUIDATION, :THUNDERBOLT, :FAIRYWIND,:PLAYROUGH,:BOLTARROWS],
		},
		:typeMods => {
		},
		:moveMessages => {
			"The wind picked up energy!" => [:MYSTICALFIRE, :MAGICALLEAF, :DOOMDUMMY, :ICYWIND, :MISTBALL, :AURASPHERE, :SILVERWIND, :OMINOUSWIND, :FAIRYWIND,:PLAYROUGH],
			"The fog charged the attack!" => [:THUNDERBOLT,:BOLTARROWS],
			"The water infused with the Mist!" => [:SCALD,:LIQUIDATION],
		},
		:typeBoosts => {
			1.5 => [:FAIRY],
			1.2 => [:ELECTRIC,:WATER],
		},
		:typeMessages => {
			"The Misty Terrain strengthened the attack!" => [:FAIRY],
			"The Mist sparks a jolt on top!" => [:ELECTRIC],
			"The mist's Fog infused the water!" => [:WATER],
		},
		:typeCondition => {
		},
		:statusMods => [],
	},
},
:DARKCRYSTALCAVERN => {
	:name => "Dark Crystal Cavern",
	:fieldMessage => [
		"Darkness is gathering..."
	],
	:graphic => ["DarkCrystalCavern"],
	:secretPower => "DARKPULSE",
	:naturePower => :SPECTRALSCREAM,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:DARKPULSE, :NIGHTDAZE,:OBLITERATION, :BIND, :GILDEDHELIX, :NIGHTSLASH, :SHADOWBALL,:HEXINGSLASH, :SHADOWPUNCH, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWFORCE, :SHADOWBONE, :AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :DOOMDUMMY, :POWERGEM, :MOONGEISTBEAM, :PHOTONGEYSER, :DIAMONDSTORM, :MENACINGMOONRAZEMAELSTROM, :BLACKHOLEECLIPSE],
		2.0 => [:PRISMATICLASER,:FREEZINGGLARE,:VOIDREAPER],
		1.3 => [:CHAOSDRAFT,:DAZZLINGGLEAM],
		0.5 => [:LIGHTTHATBURNSTHESKY],
	},
	:accuracyMods => {
		100 => [:DARKVOID],
		0 => [:DOOMSDAY]
	},
	:moveMessages => {
		"The darkness began to gather...!" => [:DARKPULSE, :NIGHTDAZE, :NIGHTSLASH],
		"The darkness strengthened the attack!" => [:SHADOWBALL, :SHADOWPUNCH,  :BIND, :GILDEDHELIX, :SHADOWCLAW,:HEXINGSLASH, :SHADOWSNEAK, :SHADOWFORCE, :SHADOWBONE, :MENACINGMOONRAZEMAELSTROM],
		"The crystals' light strengthened the attack!" => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :DOOMDUMMY, :POWERGEM, :MOONGEISTBEAM, :PHOTONGEYSER, :DIAMONDSTORM],
		"The crystal split the attack!" => [:PRISMATICLASER],
		"The consuming darkness fed the attack!" => [:BLACKHOLEECLIPSE],
		"{1} couldn't consume much light..." => [:LIGHTTHATBURNSTHESKY],
		"The glaring attack powered up in the darkness!" => [:FREEZINGGLARE],
		"Endless fear!" => [:VOIDREAPER],
		"The darkness infused the attack!" => [:CHAOSDRAFT],
	},
	:typeMods => {
		:DARK => [:STRENGTH, :ANCIENTPOWER],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK], 
	},
	:typeMessages => {
     "The darkness strengthened the attack!" => [:DARK],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:FLASH, :DARKVOID, :MOONLIGHT, :AURORAVEIL,:ARENITEWALL],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPDEF => 1,
		},
		},
	:overlay => {
		:damageMods => {
			1.2 => [:SNARL,:POWERGEM,:DARKPULSE,:HEX,:CHAOSDRAFT,:SLUDGEBOMB,:SHADOWPUNCH],
			1.3 => [:THUNDERPUNCH,:ICEPUNCH,:FIREPUNCH,:KARATECHOP,:TOXICARROWS],
			2.0 => [:VOIDREAPER],
		},
	:accuracyMods => {
		0 => [:DOOMSDAY]
	},
		:typeMods => {
		},
		:moveMessages => {
			"The void's energy strengthened the attack!" => [:SNARL,:POWERGEM,:DARKPULSE,:HEX,:CHAOSDRAFT,:SLUDGEBOMB,:SHADOWPUNCH,:TOXICARROWS],
			"The punch comes out of nowhere!" => [:THUNDERPUNCH,:ICEPUNCH,:FIREPUNCH,:KARATECHOP],
			"Endless fear!" => [:VOIDREAPER],
		},
		:typeBoosts => {
			1.3 => [:DARK],
			1.2 => [:GHOST],
		},
		:typeMessages => {
			"The darkness strengthened the attack!" => [:DARK],
			"The shadows strengthened the attack!" => [:GHOST],
		},
		:typeCondition => {
		},
		:statusMods => [:AURORAVEIL,:ARENITEWALL],
	},
},
:CHESS => {
	:name => "Chess Board",
	:fieldMessage => [
		"Opening variation set."
	],
	:graphic => ["Chess","Chess1"],
	:secretPower => "FEINT",
	:naturePower => :ANCIENTPOWER,
	:mimicry => :PSYCHIC,
	:damageMods => {
		1.5 => [:FEINT, :FEINTATTACK,  :SUCKERPUNCH, :FIRSTIMPRESSION, :DISCHARGE, :SHADOWSNEAK, :SMARTSTRIKE, :STRENGTH, :ANCIENTPOWER, :PSYCHIC, :STOMPINGTANTRUM,:BODYPRESS,:DUALWINGBEAT,:AQUAJET, :CONTINENTALCRUSH, :SECRETPOWER, :SHATTEREDPSYCHE],
		2.0 => [:PAYBACK,:FAKEOUT],
	},
	:accuracyMods => {},
	:moveMessages => {
		"En passant!" => [:FEINT, :FEINTATTACK, :FAKEOUT, :SUCKERPUNCH, :FIRSTIMPRESSION, :SHADOWSNEAK, :SMARTSTRIKE],
		"The Immortal Game!" => [:PAYBACK],
		"The Italian Game!" => [:STOMPINGTANTRUM],
		"The French Defense!" => [:BODYPRESS],
		"An unstoppable Wing Gambit!" => [:DUALWINGBEAT],
		"A fast King's Gambit!" => [:AQUAJET],
		"Overloaded!" => [:DISCHARGE],
	},
	:typeMods => {
		:ROCK => [:STRENGTH, :ANCIENTPOWER, :PSYCHIC, :BARRAGE, :SECRETPOWER, :SHATTEREDPSYCHE],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:CALMMIND, :NASTYPLOT, :TRICKROOM, :NORETREAT, :KINGSSHIELD, :OBSTRUCT],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPATK => 1,
			PBStats::ACCURACY => 1,
		},
	},
},
:BIGTOP => {
	:name => "Big Top Arena",
	:fieldMessage => [
		"Now presenting...!"
	],
	:graphic => ["BigTop"],
	:secretPower => "DYNAMICPUNCH",
	:naturePower => :ACROBATICS,
	:mimicry => :FIGHTING,
	:damageMods => {
		1.5 => [:VINEWHIP, :POWERWHIP, :FIRELASH, :FIERYDANCE, :PETALDANCE, :REVELATIONDANCE, :FLY, :ACROBATICS, :FIRSTIMPRESSION, :DRUMBEATING,:VILEASSAULT],
		2.0 => [:RAPIDSPIN],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Back, foul beast!" => [:VINEWHIP, :POWERWHIP, :FIRELASH],
		"What grace!" => [:FIERYDANCE, :PETALDANCE, :REVELATIONDANCE],
		"An extravagant aerial finish!" => [:FLY, :ACROBATICS],
		"And what an entrance it is!" => [:FIRSTIMPRESSION],
		"Loud and clear!" => [:DRUMBEATING],
		"An extravagant assault!" => [:VILEASSAULT],
		"Amazing turn of events!" => [:RAPIDSPIN],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:ENCORE, :DRAGONDANCE, :QUIVERDANCE, :SWORDSDANCE, :FEATHERDANCE, :SING, :RAINDANCE, :BELLYDRUM, :SPOTLIGHT, :AQUABATICS, :CLANGOROUSSOUL,:FICKLEBEAM],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::ATTACK => 1,
		},
	},
},
:VOLCANIC => {
	:name => "Volcanic Field",
	:fieldMessage => [
		"The field is molten!"
	],
	:graphic => ["Volcano"],
	:secretPower => "LAVAPLUME",
	:naturePower => :LAVAPLUME,
	:mimicry => :FIRE,
	:damageMods => {
		2.0 => [:FORCEPALM],
		1.5 => [:SMACKDOWN,:SMOG, :THOUSANDARROWS, :ROCKSLIDE, :INFERNALPARADE,:ERUPTION,:SCALD,:PYROKINESIS,:STEAMERUPTION,:BRANDISHBUSTER],
		0 => [:HAIL,:RAINDANCE,:SANDSTORM,:DEWDASH],
	},
	:accuracyMods => {
		100 => [:WILLOWISP],
	},
	:moveMessages => {
		"The flames spread from the attack!" => [:SMOG, :INFERNALPARADE,:BRANDISHBUSTER],
		"A flaming palm of justice!" => [:FORCEPALM],
		"Overwhelmed and knocked into the flames!" => [:SMACKDOWN, :THOUSANDARROWS, :ROCKSLIDE, :ERUPTION,:PYROKINESIS, :SCALD, :STEAMERUPTION],
		"The hail melted away." => [:HAIL],
		"The rain evaporated!" => [:RAINDANCE,:DEWDASH],
		"The sand turned into hot dust!" => [:SANDSTORM],
	},
	:typeMods => {
		:FIRE => [:SMOG, :CLEARSMOG, :THOUSANDARROWS,:EARTHQUAKE],
	},
	:typeAddOns => {
			:FIRE => [:ROCK],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FIRE],
		0.5 => [:GRASS, :ICE, :WATER],
	},
	:typeMessages => {
		"The blaze amplified the attack!" => [:FIRE],
		"The blaze softened the attack..." => [:GRASS, :ICE, :WATER],
	},
	:typeCondition => {
		:FIRE => "!attacker.isAirborne?",
		:GRASS => "!opponent.isAirborne?",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:WILLOWISP, :SMOKESCREEN],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :MultiTurnAttack,
		:duration => :FIRESPIN,
		:message => "{1} was trapped by Fire Spin!",
		:animation => :FIRESPIN,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
			PBStats::SPEED => 1,
		},
	},
		:overlay => {
		:damageMods => {
			1.2 => [:FLAMETHROWER,:ROCKSLIDE,:SCORCHINGSANDS,:MAGMADRIFT,:SCALD,:BRANDISHBUSTER,:PYROKINESIS,:RAGINGFLAMES,:SOLARBEAM],
		},
		:typeMods => {
		},
		:moveMessages => {
		"The flames spread from the attack!" => [:FLAMETHROWER,:SOLARBEAM,:PYROKINESIS,:SCORCHINGSANDS,:SCALD,:MAGMADRIFT,:BRANDISHBUSTER],
		"Smacked into the flames!" => [:ROCKSLIDE],
		"The flames got infused!" => [:RAGINGFLAMES],
		},
		:typeBoosts => {
			1.3 => [:FIRE],
		},
		:typeMessages => {
		"The blaze amplified the attack!" => [:FIRE],
		},
		:typeCondition => {
		},
		:statusMods => [],
	},
},
:SWAMP => {
	:name => "Swamp Field",
	:fieldMessage => [
		"The field is swamped."
	],
	:graphic => ["Swamp"],
	:secretPower => "MUDDYWATER",
	:naturePower => :MUDDYWATER,
	:mimicry => :WATER,
	:damageMods => {
		1.5 => [:IRRITATION, :MUDDYWATER, :SLUDGEWAVE, :GUNKSHOT, :BRINE, :SMACKDOWN, :HYDROVORTEX, :SAVAGESPINOUT,:VENAMSKISS],
		1.3 => [:MUDBOMB,:THOUSANDARROWS,:MUDBARRAGE],
		0.25 => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE,:FISSURE,:GIGAQUAKE,:TECTONICRAGE],
		0 => [:SELFDESTRUCT, :EXPLOSION, :MINDBLOWN],
		2.0 => [:ECHOEDVOICE],
	},
	:accuracyMods => {
		100 => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER],
	},
	:moveMessages => {
		"The murk strengthened the attack!" => [:MUDBOMB, :MUDBARRAGE, :MUDDYWATER, :SLUDGEWAVE, :GUNKSHOT, :BRINE, :SMACKDOWN, :THOUSANDARROWS, :HYDROVORTEX,:VENAMSKISS],
		"The attack dissipated in the soggy ground..." => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE,:FISSURE,:GIGAQUAKE,:TECTONICRAGE],
		"The dampness prevents the explosion!" => [:SELFDESTRUCT, :EXPLOSION, :MINDBLOWN],
		"There are bugs EVERYWHERE!" => [:SAVAGESPINOUT,:IRRITATION],
		"WHAT ARE YA DOING IN MA SWAMP??!" => [:ECHOEDVOICE],
	},
	:typeMods => {
		:WATER => [:SMACKDOWN, :THOUSANDARROWS],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:BUG,:GRASS],
		1.3 => [:WATER],
		0.5 => [:FIRE,:GROUND],
	},
	:typeMessages => {
		"Bugs are swarming everywhere!" => [:BUG],
		"The dampness strengthened the attack!" => [:WATER],
		"Thick mangroves line the area!" => [:GRASS],
		"The dampness weakened the flame..." => [:FIRE],
		"The marshy ground weakened the attack..." => [:GROUND],
	},
	:typeCondition => {
		:GROUND => "self.move!=:MUDBARRAGE && self.move!=:THOUSANDARROWS && self.move!=:MUDBOMB",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER, :AQUARING, :STRENGTHSAP, :LEECHSEED, :STRINGSHOT, :SPIDERWEB],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => nil,
		:duration => nil,
		:message => "{1}'s body became clear!",
		:animation => :ROCKPOLISH,
		:stats => {
			PBStats::DEFENSE => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.2 => [:MUDDYWATER,:SURF,:SLUDGEWAVE],
			1.3 => [:MUDBOMB,:GRASSYGLIDE,:NEEDLEARM,:MAGICALLEAF],
		},
		:typeMods => {
		},
		:moveMessages => {
		"The dampness boosted the ride!" => [:MUDDYWATER,:SURF,:SLUDGEWAVE],
		"The rich soil strengthened the attack!" => [:MUDBOMB,:GRASSYGLIDE,:NEEDLEARM,:MAGICALLEAF],
		},
		:typeBoosts => {
			1.2 => [:BUG,:WATER,:GRASS],
		},
		:typeMessages => {
		"The dampness strengthened the attack!" => [:WATER],
		"Thick mangroves line the area!" => [:GRASS],
		"Bugs are swarming everywhere!" => [:BUG],
		},
		:typeCondition => {
		},
		:statusMods => [],
	},
},
:RAINBOW => {
	:name => "Rainbow Field",
	:fieldMessage => [
		"What does it mean?"
	],
	:graphic => ["Rainbow"],
	:secretPower => "AURORABEAM",
	:naturePower => :AURORABEAM,
	:mimicry => :DRAGON,
	:damageMods => {
		1.5 => [:SILVERWIND, :MYSTICALFIRE, :DRAGONPULSE, :TRIATTACK, :SACREDFIRE, :FIREPLEDGE, :WATERPLEDGE, :GRASSPLEDGE, :AURORABEAM, :MIRRORBEAM, :JUDGMENT, :PYROKINESIS, :HIDDENPOWER, :SECRETPOWER, :WEATHERBALL, :MISTBALL, :MAGICALLEAF, :MOONBLAST, :ZENHEADBUTT, :SPARKLINGARIA, :FLEURCANNON, :PRISMATICLASER, :TWINKLETACKLE, :OCEANICOPERETTA, :SOLARBEAM, :SOLARBLADE, :DAZZLINGGLEAM],
		0.5 => [:DARKPULSE, :SHADOWBALL, :NIGHTDAZE, :NEVERENDINGNIGHTMARE],
		1.3 => [:HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		0 => [:NIGHTMARE,:CLEARSMOG],
		2.0 => [:MULTIPULSE],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The attack was rainbow-charged!" => [:SILVERWIND, :MYSTICALFIRE, :DRAGONPULSE, :TRIATTACK, :SACREDFIRE, :FIREPLEDGE, :WATERPLEDGE, :GRASSPLEDGE, :AURORABEAM, :MIRRORBEAM, :JUDGMENT, :PYROKINESIS, :HIDDENPOWER, :SECRETPOWER, :WEATHERBALL, :MISTBALL, :MAGICALLEAF, :MOONBLAST, :ZENHEADBUTT, :SPARKLINGARIA, :FLEURCANNON, :PRISMATICLASER, :TWINKLETACKLE, :OCEANICOPERETTA, :SOLARBEAM, :SOLARBLADE, :DAZZLINGGLEAM, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		"The rainbow softened the attack..." => [:DARKPULSE, :SHADOWBALL, :NIGHTDAZE, :NEVERENDINGNIGHTMARE],
		"The rainbow ensures good dreams." => [:NIGHTMARE],
		"The rainbow purified the smog into sparkling dust!" => [:CLEARSMOG],
		"The rainbow energized the pulse!" => [:MULTIPULSE],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:NORMAL],
	},
	:typeMessages => {
		"The rainbow energized the attack!" => [:NORMAL],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:COSMICPOWER, :MEDITATE, :WISH, :LIFEDEW, :AURORAVEIL],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :Wish,
		:duration => 2,
		:message => "A wish was made for {1}!",
		:animation => :WISH,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.3 => [:SILVERWIND, :MYSTICALFIRE, :DRAGONPULSE,:FLAMEWHEEL, :TRIATTACK,:CHARGEDWHIP, :FIREPLEDGE, :WATERPLEDGE, :GRASSPLEDGE, :AURORABEAM, :MIRRORBEAM, :MAGICALLEAF, :HIDDENPOWER, :SECRETPOWER, :WEATHERBALL, :MISTBALL,:HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		},
		:typeMods => {
		},
		:moveMessages => {
			"The attack was rainbow-charged!" => [:SILVERWIND, :MYSTICALFIRE, :DRAGONPULSE,:FLAMEWHEEL,:CHARGEDWHIP, :TRIATTACK, :FIREPLEDGE, :WATERPLEDGE, :GRASSPLEDGE, :AURORABEAM, :MIRRORBEAM, :MAGICALLEAF, :HIDDENPOWER, :SECRETPOWER, :WEATHERBALL, :MISTBALL,:HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		},
		:typeBoosts => {
			1.25 => [:NORMAL],
		},
		:typeMessages => {
			"The rainbow energized the attack!" => [:NORMAL],
		},
		:typeCondition => {
		},
		:statusMods => [:LIFEDEW, :AURORAVEIL],
	},
},
:CORROSIVE => {
	:name => "Corrosive Field",
	:fieldMessage => [
		"The field is corrupted!"
	],
	:graphic => ["Poison"],
	:secretPower => "ACID",
	:naturePower => :TOXICSPIKES,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:SMACKDOWN, :MUDDYWATER, :WHIRLPOOL, :APPLEACID, :FLAMEWHEEL, :DARKPULSE, :TOXICRAMPAGE,:TOXICGLARE],
		1.3 => [:FREEZEDRY, :UPROOT, :POWERGEM, :FLASHCANNON],
		2.0 => [:ROCKSLIDE],
	},
	:accuracyMods => {
	},
	:moveMessages => {
	"The corrosion mutated the attack!" => [:FLAMEWHEEL, :DARKPULSE],
	"The corrosion infused the attack!" => [:FREEZEDRY, :UPROOT, :POWERGEM, :FLASHCANNON],
	"An avalanche of rocks!" => [:ROCKSLIDE],
	"The corrosion strengthened the attack!" => [:SMACKDOWN, :MUDDYWATER, :WHIRLPOOL, :APPLEACID,:TOXICRAMPAGE,:TOXICGLARE],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:ACIDARMOR, :POISONPOWDER, :SLEEPPOWDER, :STUNSPORE, :TOXIC, :VENOMDRENCH],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => :Protect,
		:duration => :BanefulBunker,
		:message => "The Telluric Seed shielded {1} against damage!",
		:animation => :BANEFULBUNKER,
		:stats => {
		},	
	},
		:overlay => {
		:damageMods => {
			1.2 => [:SLUDGEWAVE,:SLUDGEBOMB,:POISONJAB,:POISONTAIL],
			1.3 => [:SMACKDOWN,:APPLEACID,:CHARGEBEAM,:VENOSHOCK,:TOXICRAMPAGE,:TOXICGLARE],
		},
		:typeMods => {},
		:moveMessages => {
			"The corrosion strengthened the attack!" => [:SMACKDOWN, :SLUDGEWAVE,:POISONJAB,:APPLEACID,:CHARGEBEAM,:SLUDGEBOMB,:VENOSHOCK,:TOXICRAMPAGE,:TOXICGLARE],
		},
		:typeBoosts => {
			1.3 => [:POISON],
		},
		:typeMessages => {
			"The toxic wasted over the attack!" => [:POISON],
		},
		:typeCondition => {
		},
	},
},
:CORROSIVEMIST => {
	:name => "Corrosive Mist Field",
	:fieldMessage => [
		"Corrosive mist settles on the field!"
	],
	:graphic => ["CorrosiveMist"],
	:secretPower => "ACIDSPRAY",
	:naturePower => :VENOSHOCK,
	:mimicry => :POISON,
	:damageMods => {
	2.0 => [:SNARL,:TOXICRAMPAGE,:TOXICGLARE],	
	1.5 => [:SCALD, :HEATWAVE, :GUNKSHOT, :BELCH, :TOXICARROWS, :SPARKLINGARIA, :HYPERVOICE, :SLUDGEWAVE,:VENAMSKISS],
	},
	:accuracyMods => {
		100 => [:TOXIC],
	},
	:moveMessages => {
		"The poison strengthened the attack!" => [:SCALD, :HEATWAVE, :GUNKSHOT, :BELCH, :TOXICARROWS, :SPARKLINGARIA, :HYPERVOICE, :SLUDGEWAVE,:VENAMSKISS,:TOXICRAMPAGE,:TOXICGLARE],
		"The snarl got infused with the mist!" => [:SNARL],
	},
	:typeMods => {
		:POISON => [:SCALD, :ENERGYBALL, :SPARKLINGARIA, :HYPERVOICE],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FIRE,:POISON],
	},
	:typeMessages => {
		"The toxic mist caught flame!" => [:FIRE],
		"The toxic mist infused the poison further!" => [:POISON],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [:GRAVITY],
	:changeMessage => {
	},
	:statusMods => [:ACIDARMOR, :SMOKESCREEN, :VENOMDRENCH, :TOXIC],
	:changeEffects => {
	},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} was badly poisoned!",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
		},
	},
},
:DESERT => {
	:name => "Desert Field",
	:fieldMessage => [
		"The field is rife with sand."
	],
	:graphic => ["Desert","Desert2","Desert3","DesertNight","DesertEve"],
	:secretPower => "SANDTOMB",
	:naturePower => :SANDTOMB,
	:mimicry => :GROUND,
	:damageMods => {
		1.5 => [:NEEDLEARM, :PINMISSILE, :DIG, :SANDTOMB, :HEATWAVE, :THOUSANDWAVES, :BURNUP, :SEARINGSUNRAZESMASH, :SOLARBLADE, :SOLARBEAM, :SCALD, :STEAMERUPTION, :SANDSEARSTORM,:BONECLUB, :BONERUSH, :BONEMERANG, :SHADOWBONE,:SCORCHINGSANDS,:PYROKINESIS],
		0 => [:SOAK, :AQUARING, :LIFEDEW,:RAINDANCE,:HAIL,:DEWDASH],
		2.0 => [:FIREARROWS],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The desert strengthened the attack!" => [:NEEDLEARM, :PINMISSILE, :DIG, :SANDTOMB, :HEATWAVE, :THOUSANDWAVES, :BURNUP, :SEARINGSUNRAZESMASH, :SOLARBLADE, :SOLARBEAM, :SCALD, :STEAMERUPTION, :SANDSEARSTORM, :SCORCHINGSANDS,:PYROKINESIS],
		"The lifeless desert strengthened the attack!" => [:BONECLUB, :BONERUSH, :BONEMERANG, :SHADOWBONE],
		"The desert is too dry..." => [:SOAK, :AQUARING, :LIFEDEW],
		"The burning arrows infused with hot air!" => [:FIREARROWS],
		"The rain evaporated!" => [:RAINDANCE,:DEWDASH],
		"The hail cant pierce the desert!" => [:HAIL],

	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.3 => [:GROUND],
		0.5 => [:WATER, :ELECTRIC, :ICE],
	},
	:typeMessages => {
		"The desert softened the attack..." => [:WATER, :ELECTRIC, :ICE],
		"The dry ground boosted the attack!" => [:GROUND],
	},
	:typeCondition => {
		:WATER => "!attacker.isAirborne? && self.move!=:SCALD && self.move!=:STEAMERUPTION",
		:ELECTRIC => "!opponent.isAirborne?",
	  	:ICE => "attacker.ability!=:ICEBENDER",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:SANDSTORM, :SUNNYDAY, :SANDATTACK, :SHOREUP, :ARENITEWALL],
	:changeEffects => {},
	:seed => {	
		:seedtype => :TELLURICSEED,
		:effect => :MultiTurnAttack,
		:duration => :SANDTOMB,
		:message => "{1} was trapped by Sand Tomb!",
		:animation => :SANDTOMB,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
			PBStats::SPEED => 1,
		},	
	},
		:overlay => {
		:damageMods => {
			1.2 => [:SCORCHINGSANDS,:EARTHPOWER,:ACCELEROCK,:NEEDLEARM,:BUBBLEBOIL],
			1.3 => [:SCALD,:HEATWAVE,:PYROKINESIS,:STOMPINGTANTRUM,:FIREARROWS],
		},
		:typeMods => {
		},
		:moveMessages => {
			"The sand strengthened the attack!" => [:SCORCHINGSANDS,:EARTHPOWER,:ACCELEROCK,:STOMPINGTANTRUM],
			"The desert strengthened the attack!" => [:SCALD,:HEATWAVE,:PYROKINESIS,:NEEDLEARM,:BUBBLEBOIL,:FIREARROWS],
		},
		:typeBoosts => {
			1.3 => [:GROUND],
		},
		:typeMessages => {
			"The dry land powered up the attack!" => [:GROUND],
		},
		:typeCondition => {
		},
		:statusMods => [:SANDSTORM,:ARENITEWALL],
	},
},
:ICY => {
	:name => "Icy Field",
	:fieldMessage => [
		"The field is covered in ice."
	],
	:graphic => ["Icy"],
	:secretPower => "ICYWIND",
	:naturePower => :GLACIATE,
	:mimicry => :ICE,
	:damageMods => {
		2.0 => [:AQUAJET],
		1.5 => [:BITTERMALICE,:COLDTRUTH,:FREEZEDRY,:ICESHARD,:SHEERCOLD,:FROSTBREATH,:FREEZINGGLARE,:ICICLESPEAR],
		1.3 => [:SAVAGESPINOUT,:FATALITY,:TAKEDOWN,:VOIDREAPER],
		0.5 => [:SCALD, :STEAMERUPTION],
		0  => [:RAINDANCE, :SANDSTORM,:SUNNYDAY,:DEWDASH],

	},
	:accuracyMods => {},
	:moveMessages => {
		"The attack merged with the frost!" => [:FROSTBREATH,:FREEZINGGLARE,:ICICLESPEAR,:AQUAJET],
		"Frostbites enhanced the attack!" => [:BITTERMALICE,:COLDTRUTH,:FREEZEDRY,:ICESHARD],
		"The cold softened the attack..." => [:SCALD, :STEAMERUPTION],
		"The attack picked up speed!" => [:SAVAGESPINOUT, :FATALITY,:TAKEDOWN],
		"A Never ending cold death!" => [:SHEERCOLD,:VOIDREAPER],
		"The rain evaporated!" => [:RAINDANCE,:DEWDASH],
		"The sun cant pierce the cold!" => [:SUNNYDAY],
		"The sand turned into cold dust!" => [:SANDSTORM],
	},
	:typeMods => {
		:ICE => [:GRASSYGLIDE, :BULLETPUNCH, :STRENGTH],
	},
	:typeAddOns => {
		:ICE => [:ROCK],
	},
	:moveEffects => {
		"@battle.iceSpikes" => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE,:GIGAQUAKE],
		
	},
	:typeBoosts => {
		1.5 => [:ICE],
		0.5 => [:FIRE,:FIGHTING],
	},
	:typeMessages => {
		"The cold strengthened the attack!" => [:ICE],
		"The cold softened the attack..." => [:FIRE],
		"The cold environment makes it hard to move swiftly..." => [:FIGHTING],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:HAIL, :AURORAVEIL],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} was hurt by icy Spikes!",
		:animation => nil,
		:stats => {
			PBStats::SPEED => 2,
		},
	},
	:overlay => {
		:damageMods => {
			1.1 => [:BLIZZARD,:ICEBEAM,:COLDTRUTH],
			1.2 => [:FREEZEDRY,:FROSTBREATH,:FREEZINGGLARE,:ICEFANG,:ICEPUNCH],
		},
		:typeMods => {
		},
		:moveMessages => {
		"The cold powered up the attack!" => [:FREEZEDRY,:FROSTBREATH,:FREEZINGGLARE,:ICEFANG,:ICEPUNCH,:BLIZZARD,:ICEBEAM,:COLDTRUTH],
		},
		:typeBoosts => {
			1.3 => [:ICE],
		},
		:typeMessages => {
		"The frost strengthened the attack!" => [:ICE],
		},
		:typeCondition => {
		},
		:statusMods => [:HAIL,:AURORAVEIL],
	},
},
:ROCKY => {
	:name => "Rocky Field",
	:fieldMessage => [
		"The field is littered with rocks."
	],
	:graphic => ["Rocky"],
	:secretPower => "ROCKTHROW",
	:naturePower => :ANCIENTFANGS,
	:mimicry => :ROCK,
	:damageMods => {
		1.5 => [:ROCKCLIMB, :STRENGTH,:BULLDOZE, :ACCELEROCK,:IRONFANGS,:AVALANCHE,:OVERHEAT,:ROCKTOMB,:GALESTRIKE],
		2.0 => [:ROCKSMASH],
		0 => [:RAINDANCE,:HAIL,:DEWDASH,:SUNNYDAY],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The rocks strengthened the attack!" => [:ROCKCLIMB, :STRENGTH, :BULLDOZE, :ACCELEROCK,:IRONFANGS,:AVALANCHE],
		"SMASH'D!" => [:ROCKSMASH,:ROCKTOMB],
		"Smashing hands!" => [:GALESTRIKE],
		"The rocks begin to heat up!" => [:OVERHEAT],
		"The rain does not affect the dry rocks!" => [:RAINDANCE,:DEWDASH],
		"The hail crushed into dust!" => [:HAIL],
		"The rocks block the sunlight!" => [:SUNNYDAY],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ROCK],
	},
	:typeMessages => {
		"The field strengthened the attack!" => [:ROCK],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:ROCKPOLISH, :SANDSTORM, :ARENITEWALL, :STEALTHROCK],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} was hurt by Stealth Rocks!",
		:animation => nil,
		:stats => {
			PBStats::DEFENSE => 1,
			PBStats::SPDEF => 1,
		},
	},
},
:FOREST => {
	:name => "Forest Field",
	:fieldMessage => [
		"The field is abound with trees."
	],
	:graphic => ["Forest","GoldForest","ForestCave"],
	:secretPower => "WOODHAMMER",
	:naturePower => :WOODHAMMER,
	:mimicry => :BUG,
	:damageMods => {
		0.5 => [:SURF, :MUDDYWATER],
		1.3 => [:SEEDBOMB, :WOODHAMMER],
		1.5 => [:GRAVAPPLE,:ATTACKORDER,:APPLEACID,:HORNLEECH, :ELECTROWEB, :GALESTRIKE,:SHADOWCLAW,:CRUSHCLAW, :BREAKINGSWIPE,:GRASSYGLIDE,:SLASH,:XSCISSOR,:SILVERWIND,:FURYCUTTER,:NIGHTSLASH,:SACREDSWORD,:SECREDSWORD,:AIRSLASH,:AERIALACE,:AIRCUTTER,:LEAFBLADE,:MAGICALLEAF,:RAZORWIND,:CUT,:CROSSPOISON,:PSYCHOCUT,:LEAFAGE,:RAZORSHELL,:FAIRYWIND,:SMARTSTRIKE,:SOLARBLADE,:BEHEMOTHBLADE,:CAESELESSEDGE,:STONEAXE,:AQUACUTTER,:GILDEDARROW,:GILDEDHELIX,:SLASHANDBURN,:HEXINGSLASH,:SPLITSECONDSLASH,:ROYALBLADE,:DRAGONCLAW],
		2.0 => [:OVERDRIVE,:NATURALGIFT],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The forest softened the attack..." => [:SURF, :MUDDYWATER],
		"Nature is in perfect sync!" => [:NATURALGIFT],
		"They're coming out of the woodwork!" => [:ATTACKORDER],
		"Gossamer and arbor strengthened the attack!" => [:ELECTROWEB],
		"The apple did not fall far from the tree" => [:GRAVAPPLE,:APPLEACID],
		"The nature powered up the attack!" => [:GRASSYGLIDE],
		"The forest powered up the attack!" => [:WOODHAMMER,:SEEDBOMB,:HORNLEECH],
		"The sound of bugs join in on the attack!" => [:OVERDRIVE],
		"The Forest got cut down!" => [:SLASH,:XSCISSOR,:SILVERWIND,:FURYCUTTER,:CRUSHCLAW,:NIGHTSLASH,:SACREDSWORD,:SHADOWCLAW,:SECREDSWORD,:AIRSLASH,:AERIALACE,:AIRCUTTER,:LEAFBLADE,:MAGICALLEAF,:RAZORWIND,:CUT,:CROSSPOISON,:PSYCHOCUT,:LEAFAGE,:RAZORSHELL,:FAIRYWIND,:SMARTSTRIKE,:SOLARBLADE,:BEHEMOTHBLADE,:CAESELESSEDGE,:STONEAXE,:AQUACUTTER,:GILDEDARROW,:GILDEDHELIX,:SLASHANDBURN,:HEXINGSLASH,:SPLITSECONDSLASH,:ROYALBLADE,:DRAGONCLAW],
	},
	:typeMods => {
		:GRASS => [:CUT, :SLASH, :AIRSLASH, :GALESTRIKE, :FURYCUTTER, :AIRCUTTER, :PSYCHOCUT,:SECRETPOWER, :BREAKINGSWIPE],
		:GROUND	=> [:GRASSYGLIDE],
	},
	:typeAddOns => {
		:GRASS => [:FLYING],
	},
	:moveEffects => {
		"@battle.treeChecker" => [:SLASH,:XSCISSOR,:SILVERWIND,:FURYCUTTER,:NIGHTSLASH,:SHADOWCLAW,:CRUSHCLAW,:SACREDSWORD,:SECREDSWORD,:AIRSLASH,:AERIALACE,:AIRCUTTER,:LEAFBLADE,:MAGICALLEAF,:RAZORWIND,:CUT,:CROSSPOISON,:PSYCHOCUT,:LEAFAGE,:RAZORSHELL,:FAIRYWIND,:SMARTSTRIKE,:SOLARBLADE,:BEHEMOTHBLADE,:CAESELESSEDGE,:STONEAXE,:AQUACUTTER,:GILDEDARROW,:GILDEDHELIX,:SLASHANDBURN,:HEXINGSLASH,:SPLITSECONDSLASH,:ROYALBLADE,:DRAGONCLAW],
	},
	:typeBoosts => {
		1.5 => [:BUG, :GRASS],
	},
	:typeMessages => {
		"The attack spread throughout the forest!" => [:BUG],
		"The forestry strengthened the attack!" => [:GRASS],
	},
	:typeCondition => {
		:BUG => "self.pbIsSpecial?(type)",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:STICKYWEB, :DEFENDORDER, :GROWTH, :STRENGTHSAP, :HEALORDER, :NATURESMADNESS, :FORESTSCURSE],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => :Protect,
		:duration => :SpikyShield,
		:message => "The Telluric Seed shielded {1} against damage!",
		:animation => :SPIKYSHIELD,
		:stats => {
		},
	},
},
:VOLCANICTOP => {
	:name => "Volcanic Top",
	:fieldMessage => [
		"The mountain top is super-heated!"
	],
	:graphic => ["Voltop"],
	:secretPower => "FLAMEBURST",
	:naturePower => :ERUPTION,
	:mimicry => :FIRE,
	:damageMods => {
		1.5 => [:OMINOUSWIND, :SILVERWIND, :RAZORWIND, :ICYWIND, :GUST, :TWISTER, :GALESTRIKE,:BUBBLEBOIL, :CLEARSMOG, :PRECIPICEBLADES, :THUNDER, :SCALD, :STEAMERUPTION, :INFERNALPARADE],
		1.3 => [:ERUPTION, :HEATWAVE, :MAGMASTORM, :LAVAPLUME, :MAGMADRIFT],
		0.5 => [:SURF, :MUDDYWATER, :WATERPLEDGE, :WATERSPOUT, :HYDROPUMP, :SPARKLINGARIA, :HYDROVORTEX, :OCEANICOPERETTA],
		2.0 => [:ZAPCANNON],
		0 => [:HAIL,:RAINDANCE,:SANDSTORM,:DEWDASH],
	},
	:accuracyMods => {
		100 => [:THUNDER]
	},
	:moveMessages => {
		"The field super-heated the attack!" => [:SCALD, :STEAMERUPTION,:BUBBLEBOIL,:OMINOUSWIND, :SILVERWIND, :RAZORWIND, :ICYWIND, :GUST, :TWISTER, :CLEARSMOG, :PRECIPICEBLADES],
		"The field powers up the flaming attacks!" => [:ERUPTION, :HEATWAVE, :MAGMASTORM, :LAVAPLUME, :MAGMADRIFT, :INFERNALPARADE],
		"The open air powered up the attack!" => [:THUNDER,:GALESTRIKE],
		"The hail melted away." => [:HAIL],
		"The rain melted away." => [:RAINDANCE,:DEWDASH],
		"The sand turned into hot dust." => [:SANDSTORM],
		"The volcanic heat combusted the attack!" => [:ZAPCANNON],
	},
	:typeMods => {
		:FIRE => [:OMINOUSWIND, :SILVERWIND, :RAZORWIND, :ICYWIND, :GUST, :TWISTER, :PRECIPICEBLADES, :EXPLOSION, :SELFDESTRUCT],
	},
	:typeAddOns => {
			:FIRE => [:ROCK],
	},
	:moveEffects => {
		"@battle.eruptionChecker" => [:BULLDOZE, :EARTHQUAKE, :MAGNITUDE, :ERUPTION, :PRECIPICEBLADES,:HEATWAVE, :LAVAPLUME, :MAGMADRIFT, :EARTHPOWER, :FEVERPITCH],
	},
	:typeBoosts => {
		0.5 => [:ICE,:WATER],
		1.5 => [:FIRE,:FLYING],
	},
	:typeMessages => {
		"The extreme heat softened the attack..." => [:ICE, :WATER],
		"The attack was super-heated!" => [:FIRE],
		"The mountain strengthened the attack!!" => [:FLYING],
	},
	:typeCondition => {
		:WATER => "self.move!=:SCALD && self.move!=:STEAMERUPTION",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:TAILWIND, :STEALTROCK, :SMOKESCREEN, :POISONGAS],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => :ShellTrap,
		:duration => true,
		:message => "{1} primed a trap!",
		:animation => :SHELLTRAP,
		:stats => {
			PBStats::DEFENSE => 1,
		},
	},
},
:FACTORY => {
	:name => "Factory Field",
	:fieldMessage => [
		"Machines whir in the background."
	],
	:graphic => ["Factory"],
	:secretPower => "MAGNETBOMB",
	:naturePower => :GEARGRIND,
	:mimicry => :STEEL,
	:damageMods => {
		1.5 => [:STEAMROLLER, :TECHNOBLAST, :ULTRAMEGADEATH,:FLASHCANNON, :GYROBALL, :MAGNETBOMB, :GEARGRIND],
		2.0 => [:BRICKBREAK],
	},
	:accuracyMods => {},
	:moveMessages => {
		"ATTACK SEQUENCE UPDATE." => [:STEAMROLLER, :TECHNOBLAST, :ULTRAMEGADEATH],
		"ATTACK SEQUENCE INITIATE." => [:FLASHCANNON, :GYROBALL, :MAGNETBOMB, :GEARGRIND],
		"Working over time like a machine!" => [:BRICKBREAK],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.2 => [:ELECTRIC],
		1.5 => [:STEEL],
	},
	:typeMessages => {
		"The attack took energy from the field!" => [:ELECTRIC],
		"The attack took energy from the field!" => [:STEEL],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:AUTOTOMIZE, :IRONDEFENSE, :METALSOUND, :SHIFTGEAR, :MAGNETRISE, :GEARUP, :MAGNETRISE],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :LaserFocus,
		:duration => 1,
		:message => "{1} is focused!",
		:animation => :LASERFOCUS,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:SHORTCIRCUIT => {
	:name => "Short-Circuit Field",
	:fieldMessage => [
		"Bzzt!"
	],
	:graphic => ["ShortCircuit"],
	:secretPower => "ELECTROBALL",
	:naturePower => :OVERDRIVE,
	:mimicry => :ELECTRIC,
	:damageMods => {
		1.667 => [:STEELBEAM],
		1.5 => [:DAZZLINGGLEAM, :SURF, :MUDDYWATER, :MAGNETBOMB,:MAGMADRIFT, :GYROBALL, :FLASHCANNON, :GEARGRIND, :HYDROVORTEX, :ULTRAMEGADEATH],
		1.3 => [:DARKPULSE, :NIGHTDAZE, :NIGHTSLASH, :SHADOWBALL, :SHADOWPUNCH, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWFORCE, :SHADOWBONE, :PHANTOMFORCE,:FLASH],
		2.0 => [:FLAREBLITZ],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The attack caught tension and ignited!" => [:FLAREBLITZ],
		"CHARGING UP!" => [:ULTRAMEGADEATH],
		"Blinding!" => [:DAZZLINGGLEAM, :FLASHCANNON,:FLASH],
		"The attack picked up electricity!" => [:SURF, :MUDDYWATER, :MAGNETBOMB, :GYROBALL,:MAGMADRIFT, :GEARGRIND, :HYDROVORTEX],
		"The darkness strengthened the attack!" => [:DARKPULSE, :NIGHTDAZE, :NIGHTSLASH, :SHADOWBALL, :SHADOWPUNCH, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWFORCE, :SHADOWBONE, :PHANTOMFORCE],
	},
	:typeMods => {
		:ELECTRIC => [:SURF, :MUDDYWATER, :MAGMADRIFT, :GYROBALL, :FLASHCANNON, :GEARGRIND, :STEELBEAM],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		2.0 => [:ELECTRIC],
	},
	:typeMessages => {
		"The attack short-circuited with recoil!" => [:ELECTRIC],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:FLASH, :METALSOUND, :MAGNETRISE],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Charge,
		:duration => 2,
		:message => "{1} began charging power!",
		:animation => :CHARGE,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:WASTELAND => {
	:name => "Wasteland",
	:fieldMessage => [
		"The waste is watching..."
	],
	:graphic => ["Wasteland"],
	:secretPower => "GUNKSHOT",
	:naturePower => :GUNKSHOT,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:VINEWHIP, :POWERWHIP, :FLASHCANNON, :MUDBOMB, :LEECHLIFE,:VENAMSKISS,:TOXICRAMPAGE,:TOXICGLARE],
		0.25 => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE,:FISSURE,:GIGAQUAKE,:TECTONICRAGE],
		2.0 => [:FIREPUNCH,:SWALLOW],
		1.2 => [:OCTAZOOKA, :SLUDGE, :GUNKSHOT, :SLUDGEWAVE, :SLUDGEBOMB],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The waste did it for the vine!" => [:VINEWHIP, :POWERWHIP],
		"The waste was added to the attack!" => [:LEECHLIFE, :MUDBOMB, :FLASHCANNON],
		"Wibble-wibble wobble-wobb..." => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE,:FISSURE,:GIGAQUAKE,:TECTONICRAGE],
		"BLEAAARGGGGH!" => [:SWALLOW],
		"The Wasteland caught fire!" => [:FIREPUNCH],
		"The waste joined the attack!" => [:OCTAZOOKA, :SLUDGE, :GUNKSHOT, :SLUDGEWAVE, :SLUDGEBOMB, :ACIDDOWNPOUR,:VENAMSKISS,:TOXICRAMPAGE,:TOXICGLARE],
	},
	:typeMods => {
		:POISON => [:MUDBOMB,:HEADLONGRUSH],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:POISON],
	},
	:typeMessages => {
		"Wasted!" => [:POISON],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:SWALLOW, :STEALTHROCK, :SPIKES, :TOXICSPIKES, :STICKYWEB],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
		},
	},
},
:ASHENBEACH => {
	:name => "Beach",
	:fieldMessage => [
		"Focus and relax to the sound of crashing waves..."
	],
	:graphic => ["AshenBeach","Beach","BeachEve","BeachNight"],
	:secretPower => "MUDSHOT",
	:naturePower => :MEDITATE,
	:mimicry => :GROUND,
	:damageMods => {
		1.5 => [:HIDDENPOWER, :BRINE, :SMELLINGSALTS,:GALESTRIKE,:SUBMISSION, :CRABHAMMER, :RAZORSHELL,:CRAMODIVE,:CRAMOCHARGE, :SHELLSIDEARM, :SHELLTRAP, :SCORCHINGSANDS, :SANDSEARSTORM, :STRENGTH, :LANDSWRATH, :THOUSANDWAVES, :SURF, :MUDDYWATER, :WAVECRASH, :CLANGOROUSSOULBLAZE, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI,:ACCELEROCK, :VACUUMWAVE, :EARTHPOWER, :POWERGEM],
		2.0 => [:ICYWIND],
		1.3 => [:PYROKINESIS, :ZENHEADBUTT, :FOCUSBLAST, :AURASPHERE, :FOCUSPUNCH,:PSYCHIC,:RAZORWIND],
	},
	:accuracyMods => {
		90 => [:FOCUSBLAST],
	},
	:moveMessages => {
		"...And with pure focus!" => [:HIDDENPOWER, :STRENGTH,:SUBMISSION, :CLANGOROUSSOULBLAZE, :HIDDENPOWERNOR,:GALESTRIKE, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		"The sand strengthened the atttack!" => [:LANDSWRATH, :THOUSANDWAVES, :SANDTOMB, :SCORCHINGSANDS, :SANDSEARSTORM],
		"Surf's up!" => [:SURF, :MUDDYWATER, :WAVECRASH],
		"A shining shell on the beach!" => [:RAZORSHELL, :SHELLSIDEARM, :SHELLTRAP],
		"The salty sea strengthened the attack!" => [:BRINE, :SMELLINGSALTS],
		"Time for crab!" => [:CRABHAMMER],
		"MINE MINE MINE!" => [:CRAMODIVE,:CRAMOCHARGE],
		"Sand mixed into the attack!" => [:ACCELEROCK, :VACUUMWAVE, :EARTHPOWER, :POWERGEM],
		"...And with full focus...!" => [:PYROKINESIS, :ZENHEADBUTT, :FOCUSBLAST, :FOCUSPUNCH, :AURASPHERE],
		"...And with focus...!" => [:PSYCHIC],
		"...A cool summer breeze!" => [:ICYWIND],
	},
	:typeMods => {
		:PSYCHIC => [:STRENGTH],
		:GROUND => [:RAZORWIND],
	},
	:typeAddOns => {},
	:moveEffects => {
	},
	:typeBoosts => {
		1.3 => [:WATER,:GROUND],
	},
	:typeMessages => {
		"The high tide boosted the attack!" => [:WATER],
		"The sandy ground strengthened the attack!" => [:GROUND],
	},
	:typeCondition => {
	},
	:typeEffects => {
	},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:KINESIS, :MEDITATE, :SANDSTORM, :PSYCHUP, :FOCUSENERGY, :SHOREUP, :ARENITEWALL],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => :FocusEnergy,
		:duration => 3,
		:message => "{1}'s Telluric Seed is getting it pumped!",
		:animation => :FOCUSENERGY,
		:stats => {
		},
	},
},
:WATERSURFACE => {
	:name => "Water Surface",
	:fieldMessage => [
		"The water's surface is calm."
	],
	:graphic => ["Water"],
	:secretPower => "AQUAJET",
	:naturePower => :FLIPTURN,
	:mimicry => :WATER,
	:damageMods => {
		1.2 => [:WHIRLPOOL, :SURF, :MUDDYWATER, :WHIRLPOOL, :DIVE, :SLUDGEWAVE, :OCTAZOOKA, :ORIGINPULSE, :HYDROVORTEX,:CRAMODIVE,:CRAMOCHARGE],
		0 => [:SPIKES, :TOXICSPIKES,:GRASSYGLIDE],
		2.0 => [:ICEPUNCH],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The attack rode the current!" => [:WHIRLPOOL, :SURF, :MUDDYWATER, :WHIRLPOOL, :DIVE, :ORIGINPULSE, :HYDROVORTEX],
		"Poison spread through the water!" => [:SLUDGEWAVE],
		"The punch got infused with water to power up!" => [:ICEPUNCH],
		"Mine mine mine!" => [:CRAMODIVE,:CRAMOCHARGE],
		"...The spikes sank into the water and vanished!" => [:SPIKES, :TOXICSPIKES],
		"...But there was no solid ground to attack from!" => [:GRASSYGLIDE],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
	},
	:typeBoosts => {
		1.5 => [:WATER],
		1.2 => [:ELECTRIC],
		0.5 => [:FIRE],
		0 => [:GROUND],
	},
	:typeMessages => {
		"The water conducted the attack!" => [:ELECTRIC],
		"The water strengthened the attack!" => [:WATER],
		"The water deluged the attack..." => [:FIRE],
		"...But there was no solid ground to attack from!" => [:GROUND],
	},
	:typeCondition => {
		:FIRE => "!opponent.isAirborne?",
		:ELECTRIC => "!opponent.isAirborne?",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:changeMessage => {
	},
	:statusMods => [:SPLASH, :AQUARING, :LIFEDEW, :TAKEHEART],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :AquaRing,
		:duration => true,
		:message => "{1} surrounded itself with a veil of water!",
		:animation => :AQUARING,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:UNDERWATER => {
	:name => "Underwater",
	:fieldMessage => [
		"Blub blub..."
	],
	:graphic => ["Underwater"],
	:secretPower => "AQUATAIL",
	:naturePower => :AQUABATICS,
	:mimicry => :WATER,
	:damageMods => {
		1.5 => [:ANCHORSHOT, :WATERPULSE, :AQUAJET,:STEELWING,:BUBBLEBOIL,:POWERGEM,:DRILLPECK,:AIRSLASH,:PSYBEAM,:DAZZLINGGLEAM,:DRAGONPULSE],
		0.5 => [:ACROBATICS,:QUICKATTACK,:EXTREMESPEED,:BULLETPUNCH,:VACUUMWAVE,:SUCKERPUNCH,:ACCELEROCK,:MACHPUNCH,:FEINT],
		2.0 => [:AURASPHERE],
		0 => [:SUNNYDAY, :HAIL, :SANDSTORM, :RAINDANCE, :SHADOWSKY, :TARSHOT,:DEWDASH],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The water breaks the speed!" => [:ACROBATICS,:QUICKATTACK,:EXTREMESPEED,:BULLETPUNCH,:VACUUMWAVE,:SUCKERPUNCH,:ACCELEROCK,:MACHPUNCH,:FEINT],
		"Dazzled!" => [:DAZZLINGGLEAM,:PSYBEAM],
		"The attacked got cloaked in a glowing light!" => [:POWERGEM,:STEELWING],
		"The pulse spread!" => [:DRAGONPULSE],
		"A Typhon formed!" => [:DRILLPECK,:AIRSLASH],
		"Jet-streamed!" => [:WATERPULSE,:AQUAJET],
		"The sphere blocked the vision!" => [:AURASPHERE],
		"From the depths!" => [:ANCHORSHOT],
		"You're too deep to notice the weather!" => [:SUNNYDAY, :HAIL, :SANDSTORM, :RAINDANCE, :SHADOWSKY,:DEWDASH],
		"The tar washed of instantly!" => [:TARSHOT],
		"The boiling bubbles start to forment!" => [:BUBBLEBOIL],
	},
	:typeMods => {
		:WATER => [:GRAVAPPLE,:GRASSYGLIDE],
	},
	:typeAddOns => {
		:WATER => [:GROUND],
	},
	:moveEffects => {
	},
	:typeBoosts => {
		1.5 => [:WATER],
		1.3 => [:ELECTRIC],
		0 => [:FIRE],
	},
	:typeMessages => {
		"The water strengthened the attack!" => [:WATER],
		"The water super-conducted the attack!" => [:ELECTRIC],
		"...But the attack was doused instantly!" => [:FIRE],
	},
	:typeCondition => {
		:FIRE => "self.move!=:BUBBLEBOIL",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:AQUARING, :TAKEHEART],
	:changeEffects => {
	},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} transformed into the Water type!",
		:animation => :SOAK,
		:stats => {
			PBStats::SPEED => 1,
		},
	},
},
:CAVE => {
	:name => "Cave",
	:fieldMessage => [
		"The cave echoes dully..."
	],
	:graphic => ["Cave"],
	:secretPower => "ROCKWRECKER",
	:naturePower => :ROCKTOMB,
	:mimicry => :ROCK,
	:damageMods => {
		1.5 => [:ROCKTOMB,:ROCKSLIDE,:AVALANCHE,:STRENGTH,:MAGNETBOMB,:FORCEPALM,:SHOCKWAVE],
		2.0 => [:DRAGONPULSE],
		1.2 => [:STONEEDGE,:ELECTROBALL,:GYROBALL,:ANCIENTPOWER,:MOUNTAINGALE],
		0 => [:SKYDROP],
	},
	:accuracyMods => {},
	:moveMessages => {
		"...Piled on!" => [:ROCKTOMB,:ROCKSLIDE,:STONEEDGE,:ANCIENTPOWER,:AVALANCHE,:MOUNTAINGALE],
		"Bits of rocks joined the attack!" => [:FORCEPALM],
		"The attack bounced off the walls!" => [:DRAGONPULSE,:ELECTROBALL,:GYROBALL,:MAGNETBOMB,:SHOCKWAVE],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {
	},
	:typeBoosts => {
		1.5 => [:ROCK],
		1.2 => [:WATER,:GRASS],
		0.5 => [:FLYING],
	},
	:typeMessages => {
		"The cave choked out the air!" => [:FLYING],
		"The cavern strengthened the attack!" => [:ROCK],
		"The cave got flooded with water!" => [:WATER],
		"Moss is spreading through the cave!" => [:GRASS],
	},
	:typeCondition => {
		:FLYING => "!self.contactMove?",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:STEALTHROCK],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} was hurt by Stealth Rocks!",
		:animation => nil,
		:stats => {
			PBStats::DEFENSE => 2,
		},
	},
},
:GLITCH => {
	:name => "Glitch Field",
	:fieldMessage => [
		"1n!taliz3 .b//////attl3"
	],
	:graphic => ["Glitch","99"],
	:secretPower => "TECHNOBLAST",
	:naturePower => :PYROKINESIS,
	:mimicry => :QMARKS,
	:damageMods => {
		0 => [:ROAR, :WHIRLWIND],
		2.0 => [:WRAP],
	},
	:accuracyMods => {
		90 => [:BLIZZARD],
	},
	:moveMessages => {
		"ERROR! MOVE NOT FOUND!" => [:ROAR, :WHIRLWIND],
		"A $g4me de_c1d1n&g m0ve3!" => [:WRAP],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.2 => [:PSYCHIC],
	},
	:typeMessages => {
		".0P pl$ nerf!-//" => [:PSYCHIC],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:METRONOME],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1}.TYPE = (:QMARKS)",
		:animation => :AMNESIA,
		:stats => {
			PBStats::DEFENSE => 1,
		},
	},
},
:CRYSTALCAVERN => {
	:name => "Crystal Cavern",
	:fieldMessage => [
		"The cave is littered with crystals."
	],
	:graphic => ["CrystalCavern","AmethystCave","CaveAqua"],
	:secretPower => "POWERGEM",
	:naturePower => :DIAMONDSTORM,
	:mimicry => :DRAGON,
	:damageMods => {
		1.3 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :DAZZLINGGLEAM,:ASTRALSURGE, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :DOOMDUMMY, :MOONGEISTBEAM, :PHOTONGEYSER,:DIAMONDCLAW,:ROCKCLIMB],
		1.5 => [:POWERGEM,:WONDERTRAP, :DIAMONDSTORM, :ANCIENTPOWER, :JUDGMENT, :ROCKSMASH,:MULTIPULSE, :ROCKTOMB, :STRENGTH, :MULTIATTACK, :PRISMATICLASER, :LUSTERPURGE,:GEMBURST,:MAJESTICSHINE],
		2.0 => [:SEEDBOMB],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The crystals' light strengthened the attack!" => [:AURORABEAM,:MULTIPULSE,:DIAMONDCLAW,:ASTRALSURGE, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :DOOMDUMMY,:GEMBURST,:MAJESTICSHINE,:MOONGEISTBEAM, :PHOTONGEYSER, :PRISMATICLASER],
		"The power of Gems strengthened the attack!" => [:POWERGEM,:WONDERTRAP, :DIAMONDSTORM, :ANCIENTPOWER, :JUDGMENT, :ROCKSMASH, :ROCKTOMB, :STRENGTH, :ROCKCLIMB, :MULTIATTACK],
		"The seeds got charged by crystals!" => [:SEEDBOMB],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ROCK, :DRAGON],
	},
	:typeMessages => {
		"Crystals charged the attack!" => [:ROCK],
		"The crystal energy strengthened the attack!" => [:DRAGON],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:CAVE => "@battle.field.counter > 1",
	},
	:fieldChange => {
	},
	:dontChangeBackup => [:EARTHQUAKE, :BULLDOZE, :MAGNITUDE, :FISSURE, :TECTONICRAGE, :DARKPULSE, :DARKVOID, :NIGHTDAZE],
	:changeMessage => {
		 "The crystals were broken up!" => [:SCRATCH],
		 "The crystals' light was consumed!" => [:TACKLE],
	},
	:statusMods => [:ROCKPOLISH, :STEALTHROCK, :AURORAVEIL],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:MURKWATERSURFACE => {
	:name => "Murkwater Surface",
	:fieldMessage => [
		"The water is tainted..."
	],
	:graphic => ["MurkwaterSurface"],
	:secretPower => "SLUDGEBOMB",
	:naturePower => :SLUDGEWAVE,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:MUDBOMB, :ENERGYBALL, :SEEDBOMB, :MUDBARRAGE, :AURASPHERE, :ELECTROBALL, :DARKPULSE, :BRINE, :THOUSANDWAVES, :APPLEACID,:PLASMAVOLT],
		0 => [:SPIKES, :TOXICSPIKES],
		2.0 => [:MAGMADRIFT],
	},
	:accuracyMods => {},
	:moveMessages => {		
		"The toxic water strengthened the attack!" => [:MUDBOMB, :SEEDBOMB, :DARKPULSE, :THOUSANDWAVES,:PLASMAVOLT, :APPLEACID],
		"Stinging!" => [:BRINE],
		"The sphere drifts along the water!" => [:AURASPHERE,:ELECTROBALL,:ENERGYBALL],
		"The magma absorbed the pollution!" => [:MAGMADRIFT],
		"...The spikes sank into the water and vanished!" => [:SPIKES, :TOXICSPIKES],
	},
	:typeMods => {
		:POISON => [:MUDBOMB, :MUDBARRAGE, :THOUSANDWAVES, :APPLEACID],
		:WATER => [:SLUDGEWAVE],
	},
	:typeAddOns => {
		:POISON => [:WATER],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:WATER, :POISON],
		1.3 => [:ELECTRIC],
		0 => [:GROUND],
	},
	:typeMessages => {
		"The toxic water strengthened the attack!" => [:WATER, :POISON],
		"The toxic water conducted the attack!" => [:ELECTRIC],
		"...But there was no solid ground to attack from!" => [:GROUND],
	},
	:typeCondition => {
		:ELECTRIC => "!opponent.isAirborne?",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => {},
	:changeMessage => {
	},
	:statusMods => [:ACIDARMOR, :TARSHOT, :VENOMDRENCH],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :AquaRing,
		:duration => true,
		:message => "{1} surrounded itself with a veil of water!",
		:animation => :AQUARING,
		:stats => {
			PBStats::SPEED => 1,
		},
	},
},
:MOUNTAIN => {
	:name => "Mountain",
	:fieldMessage => [
		"High up!",
	],
	:graphic => ["Mountain"],
	:secretPower => "ROCKBLAST",
	:naturePower => :ROCKSLIDE,
	:mimicry => :ROCK,
	:damageMods => {
	2.0 => [:AIRCUTTER],	
	0  => [:RAINDANCE, :SANDSTORM,:SUNNYDAY,:HAIL,:DEWDASH],
	1.5 => [:VITALTHROW,:POWERDIVE, :CIRCLETHROW, :STORMTHROW, :OMINOUSWIND, :ICYWIND, :SILVERWIND, :TWISTER, :RAZORWIND,:SKYUPPERCUT, :FAIRYWIND, :THUNDER, :ERUPTION, :AVALANCHE, :HYPERVOICE, :MOUNTAINGALE,:ROCKTHROW,:GALESTRIKE,:LEAFTORNADO,:HEATWAVE, :GUST,:TEMPESTWEAVE,:OBLIVIONWING,:PIXIESTORM,:AIRSLASH,:SANDSEARSTORM,:WILDBOLTSTORM],
	},
	:accuracyMods => {
		0 => [:THUNDER]
	},
	:moveMessages => {
		"Enjoy the trip!" => [:VITALTHROW, :CIRCLETHROW, :STORMTHROW,:ROCKTHROW,:POWERDIVE],
		"The wind strengthened the attack!" => [:OMINOUSWIND, :ICYWIND, :SILVERWIND, :TWISTER, :RAZORWIND, :FAIRYWIND,:SKYUPPERCUT, :MOUNTAINGALE,:MACHPUNCH,:LEAFTORNADO,:AERIALACE,:HEATWAVE, :GUST,:TEMPESTWEAVE,:OBLIVIONWING,:AIRSLASH,:SANDSEARSTORM,:WILDBOLTSTORM,:PIXIESTORM],
		"The mountain strengthened the attack!" => [:THUNDER, :ERUPTION, :AVALANCHE,:GALESTRIKE],
		"Yodelayheehoo~" => [:HYPERVOICE],
		"The attack sharpened up!" => [:AIRCUTTER],
		"The wind blew away the sand." => [:SANDSTORM],
		"The wind consumed the rain." => [:RAINDANCE,:DEWDASH],
		"The wind consumed the hail." => [:HAIL],
		"The wind consumed the sunlight." => [:SUNNYDAY],
	},
	:typeMods => {
		:ROCK => [:RAZORWIND],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ROCK, :FLYING],
	},
	:typeMessages => {
		"The mountain strengthened the attack!" => [:ROCK],
		"The open air strengthened the attack!" => [:FLYING],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:TAILWIND,:WINDFALL],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::SPDEF => 1,
			PBStats::ATTACK => 1,
		},
	},
},
:SNOWYMOUNTAIN => {
	:name => "Snowy Mountain",
	:fieldMessage => [
		"The snow glows white on the mountain..."
	],
	:graphic => ["SnowyMountain"],
	:secretPower => "ICYWIND",
	:naturePower => :AVALANCHE,
	:mimicry => :ICE,
	:damageMods => {
		1.5 => [:VITALTHROW, :CIRCLETHROW, :STORMTHROW, :OMINOUSWIND,:BRAVEBIRD, :SILVERWIND, :TWISTER, :RAZORWIND, :FAIRYWIND, :GALESTRIKE, :AVALANCHE, :POWDERSNOW, :HYPERVOICE, :GLACIATE, :MOUNTAINGALE, :BITTERMALICE],
		0.5 => [:SCALD, :STEAMERUPTION],
		2.0 => [:ICYWIND,:AIRSLASH],
		0  => [:RAINDANCE, :SANDSTORM,:SUNNYDAY,:DEWDASH],
	},
	:accuracyMods => {
		0 => [:THUNDER]
	},
	:moveMessages => {
		"{1} was thrown partway down the mountain!" => [:VITALTHROW, :CIRCLETHROW, :STORMTHROW],
		"The wind strengthened the attack!" => [:OMINOUSWIND, :SILVERWIND, :TWISTER, :RAZORWIND, :FAIRYWIND, :GALESTRIKE, :MOUNTAINGALE],
		"The snow strengthened the attack!" => [:AVALANCHE, :POWDERSNOW, :BITTERMALICE],
		"The cold softened the attack..." => [:SCALD, :STEAMERUPTION],
		"The frigid wind strengthened the attack!" => [:ICYWIND],
		"Yodelayheehoo~" => [:HYPERVOICE],
		"The air infused with the environment!" => [:AIRSLASH],
		"The frigid wind blew away the sand." => [:SANDSTORM],
		"The frigid wind consumed the rain." => [:RAINDANCE,:DEWDASH],
		"The frigid wind overpowers the sunlight." => [:SUNNYDAY],
	},
	:typeMods => {
		:ICE => [:RAZORWIND],
	},
	:typeAddOns => {
		:ICE => [:ROCK],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ROCK, :ICE, :FLYING],
		0.5 => [:FIRE],
	},
	:typeMessages => {
		"The snowy mountain strengthened the attack!" => [:ROCK, :ICE],
		"The open air strengthened the attack!" => [:FLYING],
		"The cold softened the attack!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:TAILWIND,:HAIL],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:HOLY => {
	:name => "Blessed Field",
	:fieldMessage => [
		"The field is blessed!"
	],
	:graphic => ["Ruin","Ruin2","Ruin3"],
	:secretPower => "DAZZLINGGLEAM",
	:naturePower => :JUDGMENT,
	:mimicry => :NORMAL,
	:damageMods => {
		1.3 => [:PSYSTRIKE, :AEROBLAST, :ORIGINPULSE, :DOOMDUMMY, :MISTBALL, :CRUSHGRIP, :LUSTERPURGE, :SECRETSWORD, :PSYCHOBOOST, :RELICSONG, :SPACIALREND, :HYPERSPACEHOLE, :ROAROFTIME, :LANDSWRATH, :PRECIPICEBLADES, :DRAGONASCENT, :MOONGEISTBEAM, :SUNSTEELSTRIKE, :PRISMATICLASER, :FLEURCANNON, :DIAMONDSTORM, :GENESISSUPERNOVA, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM, :BEHEMOTHBLADE, :BEHEMOTHBASH, :ETERNABEAM, :DYNAMAXCANNON, :MULTIPULSE],
		1.5 => [:MYSTICALFIRE, :MAGICALLEAF, :ANCIENTPOWER, :JUDGMENT, :SACREDFIRE, :EXTREMESPEED, :SACREDSWORD,:LIQUIDATION, :RETURN],
		2.0 => [:VACUUMWAVE],
	},
	:accuracyMods => {},
	:moveMessages => {
		"Legendary power accelerated the attack!" => [:PSYSTRIKE, :AEROBLAST, :SACREDFIRE, :ORIGINPULSE, :DOOMDUMMY, :JUDGMENT, :MISTBALL, :CRUSHGRIP, :LUSTERPURGE, :SECRETSWORD, :PSYCHOBOOST, :RELICSONG, :SPACIALREND, :HYPERSPACEHOLE, :ROAROFTIME, :LANDSWRATH, :PRECIPICEBLADES, :DRAGONASCENT, :MOONGEISTBEAM, :SUNSTEELSTRIKE, :PRISMATICLASER, :FLEURCANNON, :DIAMONDSTORM, :GENESISSUPERNOVA, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM, :BEHEMOTHBLADE, :BEHEMOTHBASH, :ETERNABEAM, :DYNAMAXCANNON, :MULTIPULSE],
		"The holy energy resonated with the attack!" => [:MYSTICALFIRE, :MAGICALLEAF, :ANCIENTPOWER, :SACREDSWORD, :RETURN],
		"Godspeed!" => [:EXTREMESPEED],
		"Your sins shall be washed away!" => [:LIQUIDATION],
		"Perish you fool!" => [:VACUUMWAVE],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FAIRY, :NORMAL],
		1.2 => [:PSYCHIC, :DRAGON],
		0.5 => [:GHOST, :DARK],
	},
	:typeMessages => {
		"The holy energy resonated with the attack!" => [:FAIRY, :NORMAL],
		"The legendary energy resonated with the attack!" => [:PSYCHIC, :DRAGON],
		"The attack was cleansed..." => [:GHOST, :DARK],
	},
	:typeCondition => {
		:FAIRY => "self.pbIsSpecial?(type)",
		:NORMAL => "self.pbIsSpecial?(type)",
		:DARK => "self.pbIsSpecial?(type)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:LIFEDEW, :WISH, :MIRACLEEYE, :COSMICPOWER, :NATURESMADNESS],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:MIRROR => {
	:name => "Mirror Arena",
	:fieldMessage => [
		"Mirror, mirror, on the field,",
		"Who shall this fractured power wield?",
	],
	:graphic => ["Mirror"],
	:secretPower => "MIRRORSHOT",
	:naturePower => :MIRRORBEAM,
	:mimicry => :STEEL,
	:damageMods => {
		1.5 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE,:DIAMONDCLAW, :DAZZLINGGLEAM, :TECHNOBLAST, :DOOMDUMMY,:SOLARBEAM,:ICEBEAM, :PRISMATICLASER, :PHOTONGEYSER, :LIGHTTHATBURNSTHESKY,:DIAMONDSTORM,:PSYBEAM,:STEELBEAM],
		2.0 => [:MIRRORSHOT,:MIRRORBEAM],
	},
	:accuracyMods => {
		0 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :TECHNOBLAST, :DOOMDUMMY, :PRISMATICLASER, :PHOTONGEYSER, :LIGHTTHATBURNSTHESKY, :MIRRORSHOT],
	},
	:moveMessages => {
		"The reflected light was blinding!" => [:AURORABEAM, :SIGNALBEAM,:DIAMONDSTORM,:DIAMONDCLAW, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :TECHNOBLAST, :DOOMDUMMY, :PRISMATICLASER, :PHOTONGEYSER,:SOLARBEAM,:ICEBEAM, :LIGHTTHATBURNSTHESKY,:PSYBEAM,:STEELBEAM],
		"The mirrors strengthened the attack!" => [:MIRRORSHOT,:PSYBEAM,:MIRRORBEAM],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:LIGHTSCREEN, :AURORAVEIL, :REFLECT, :MIRRORMOVE, :MIRRORCOAT, :DOUBLETEAM, :FLASH],
	:changeEffects => {
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :MagicCoat,
		:duration => true,
		:message => "{1} shrouded itself with Magic Coat!",
		:animation => :MAGICCOAT,
		:stats => {
			PBStats::SPEED => 1,
			PBStats::SPATK => 1,
		},
	},
},
:FAIRYTALE => {
	:name => "Fairy Tale Field",
	:fieldMessage => [
		"Once upon a time..."
	],
	:graphic => ["FairyTale"],
	:secretPower => "SLASH",
	:naturePower => :SECRETSWORD,
	:mimicry => :FAIRY,
	:damageMods => {
		1.5 => [:NIGHTSLASH,:MEADOWDRIVE, :LEAFBLADE, :PSYCHOCUT, :SMARTSTRIKE, :AIRSLASH, :SOLARBLADE,:GIGADRAIN, :MAGICALLEAF, :MYSTICALFIRE, :ANCIENTPOWER, :RELICSONG, :SPARKLINGARIA, :MOONGEISTBEAM, :FLEURCANNON, :RAZORSHELL, :BEHEMOTHBASH,:CEASELESSEDGE,:STONEAXE,:AQUACUTTER,:KINETICSLICER,:FRAGARACH],
		1.6 => [:DRAININGKISS, :MISTBALL,:ROYALBLADE,:HORNATTACK,:HORNDRILL],
		2.0 => [:BURSTRUSH],
	},
	:accuracyMods => {},
	:moveMessages => {
		"The blade cuts true!" => [:NIGHTSLASH, :LEAFBLADE, :PSYCHOCUT, :SMARTSTRIKE, :AIRSLASH, :SOLARBLADE, :RAZORSHELL,:ROYALBLADE,:KINETICSLICER,:FRAGARACH],
		"The magical energy strengthened the attack!" => [:MAGICALLEAF,:GIGADRAIN, :MYSTICALFIRE, :ANCIENTPOWER, :RELICSONG, :SPARKLINGARIA, :MOONGEISTBEAM, :FLEURCANNON, :BEHEMOTHBASH, :MISTBALL],
		"True love never hurt so badly!" => [:DRAININGKISS],
		"Pegasus takes charge!" => [:BURSTRUSH],
		"Pixies powered up the glide!" => [:MEADOWDRIVE],
		"The horn cuts true!" => [:HORNATTACK,:HORNDRILL],
	},
	:typeMods => {},
	:typeAddOns => {
		:DRAGON => [:FIRE],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:STEEL, :FAIRY],
		2.0 => [:DRAGON],
		0.5 => [:POISON],
	},
	:typeMessages => {
		"For ever after!" => [:FAIRY],
		"For justice!" => [:STEEL],
		"The foul beast's attack gained strength!" => [:DRAGON],
		"The pixies purified the pollusion!" => [:POISON],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:KINGSSHIELD, :CRAFTYSHIELD, :FLOWERSHIELD, :ACIDARMOR, :NOBLEROAR, :SWORDSDANCE, :WISH, :HEALINGWISH, :MIRACLEEYE, :FORESTSCURSE, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :Protect,
		:duration => :KingsShield,
		:message => "The Magical Seed shielded {1} against damage!",
		:animation => :KINGSSHIELD,
		:stats => {
		},
	},
},
:DRAGONSDEN => {
	:name => "Dragon's Den",
	:fieldMessage => [
		"If you wish to slay a dragon..."
	],
	:graphic => ["DragonsDen"],
	:secretPower => "DRAGONPULSE",
	:naturePower => :TITANFANGS,
	:mimicry => :DRAGON,
	:damageMods => {
		1.5 => [:MEGAKICK, :MAGMASTORM, :LAVAPLUME, :STOMPINGTANTRUM, :EARTHPOWER, :DIAMONDSTORM, :MATRIXSHOT, :SHELLTRAP, :POWERGEM, :MAGMADRIFT, :ROCKCLIMB, :STRENGTH,:TITANFANGS,:ANCIENTFANGS],             
		1.7 => [:DRAGONASCENT, :MISTBALL, :LUSTERPURGE,:THUNDERRAID],
		0 => [:GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN, :ELECTRICTERRAIN, :MIST, :HAIL,:RAINDANCE,:DEWDASH],
	},
	:accuracyMods => {
		100 => [:DRAGONRUSH],
	},
	:moveMessages => {
		"Trial of the Dragon!!!" => [:MEGAKICK,:TITANFANGS],
		"Wrath of the Dragon!!!" => [:STOMPINGTANTRUM],
		"Unrivaled Power!" => [:STRENGTH, :ROCKCLIMB,:ANCIENTFANGS],
		"The lava strengthened the attack!" => [:MAGMASTORM, :LAVAPLUME, :EARTHPOWER, :SHELLTRAP, :MAGMADRIFT],
		"The draconic energy boosted the attack!" => [:DRAGONASCENT, :MISTBALL, :LUSTERPURGE],
		"Sparkling treasure!" => [:PAYDAY, :POWERGEM, :DIAMONDSTORM, :MATRIXSHOT],
		"The draconic power blocked the terrain..." => [:GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN, :ELECTRICTERRAIN, :MIST],
		"The hail is melting in the heat..." => [:HAIL],
		"The rain evaporated..." => [:RAINDANCE,:DEWDASH],
		"The dragonic energy pitches up the tension!" => [:THUNDERRAID],
	},
	:typeMods => {
		:FIRE => [:SMACKDOWN, :THOUSANDARROWS, :STRENGTH, :ROCKCLIMB, :EARTHQUAKE,:GIGAQUAKE,:FISSURE],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DRAGON, :FIRE],
		1.3 => [:ROCK],
		0.5 => [:ICE, :WATER],
	},
	:typeMessages => {
		"The lava's heat boosted the flame!" => [:FIRE],
		"The draconic energy boosted the attack!" => [:DRAGON],
		"The lava's heat softened the attack..." => [:ICE, :WATER],
	},
	:typeCondition => {
      :WATER => "self.move!=:SCALD && self.move!=:WAVECRASH",
	  :ICE => "attacker.ability!=:ICEBENDER",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:DRAGONDANCE, :NOBLEROAR, :COIL, :STEALTHROCK,:FICKLEBEAM],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :FlashFire,
		:duration => true,
		:message => "{1} raised its Fire power!",
		:animation => nil,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:FLOWERGARDEN1 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden0"],
	:secretPower => "SWEETSCENT",
	:naturePower => :GROWTH,
	:mimicry => :GRASS,
	:damageMods => {
	},
	:accuracyMods => {},
	:moveMessages => {
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:FLOWERGARDEN2 => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
	},
	:dontChangeBackup => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY, :ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
	:changeMessage => {
		"The garden grew a little!" => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY, :ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:FLOWERGARDEN2 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden1"],
	:secretPower => "PETALBLIZZARD",
	:naturePower => :GROWTH,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:CUT],
	},
	:accuracyMods => {},
	:moveMessages => {
		"{1} was cut down to size!" => [:CUT],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.1 => [:GRASS],
	},
	:typeMessages => {
		"The garden's power boosted the attack!" => [:GRASS],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:FLOWERGARDEN3 => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		:FLOWERGARDEN1 => [:CUT,:XSCISSOR,:ACIDDOWNPOUR],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The garden was cut down a bit!" => [:CUT,:XSCISSOR],
		"The garden grew a little!" => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		"The acid melted the bloom!" => [:ACIDDOWNPOUR],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:FLOWERGARDEN3 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden2"],
	:secretPower => "PETALBLIZZARD",
	:naturePower => :GROWTH,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:CUT],
		1.2 => [:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON],
	},
	:accuracyMods => {
		85 => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER],
	},
	:moveMessages => {
		"{1} was cut down to size!" => [:CUT],
		"The fresh scent of flowers boosted the attack!" => [:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FIRE,:BUG],
		1.3 => [:GRASS],
	},
	:typeMessages => {
		"The budding flowers boosted the attack!" => [:GRASS],
		"The attack infested the garden!" => [:BUG],
		"The nearby flowers caught flame!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:BURNING => "state.effects[:WaterSport] <= 0 && pbWeather != :RAINDANCE",
	},
	:fieldChange => {
		:FLOWERGARDEN4 => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		:FLOWERGARDEN2 => [:CUT,:XSCISSOR],
		:FLOWERGARDEN1 => [:ACIDDOWNPOUR,:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The garden caught fire!" => [:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
		"The garden was cut down a bit!" => [:CUT,:XSCISSOR],
		"The garden grew a little!" => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		"The acid melted the bloom!" => [:ACIDDOWNPOUR],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:FLOWERGARDEN4 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden3"],
	:secretPower => "PETALBLIZZARD",
	:naturePower => :GROWTH,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:CUT,:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON],
	},
	:accuracyMods => {
		85 => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER],
	},
	:moveMessages => {
		"{1} was cut down to size!" => [:CUT],
		"The vibrant aroma scent of flowers boosted the attack!" => [:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		2.0 => [:BUG],
		1.5 => [:FIRE,:GRASS],
	},
	:typeMessages => {
		"The blooming flowers boosted the attack!" => [:GRASS],
		"The attack infested the flowers!" => [:BUG],
		"The nearby flowers caught flame!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
		:BURNING => "state.effects[:WaterSport] <= 0 && pbWeather != :RAINDANCE",
	},
	:fieldChange => {
		:FLOWERGARDEN5 => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		:FLOWERGARDEN3 => [:CUT,:XSCISSOR],
		:FLOWERGARDEN1 => [:ACIDDOWNPOUR],
		:FLOWERGARDEN2 => [:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The garden caught fire!" => [:HEATWAVE,:ERUPTION,:SEARINGSHOT,:FLAMEBURST,:LAVAPLUME,:FIREPLEDGE,:MINDBLOWN,:INFERNOOVERDRIVE],
		"The garden was cut down a bit!" => [:CUT,:XSCISSOR],
		"The garden grew a little!" => [:GROWTH,:FLOWERSHIELD,:RAINDANCE,:SUNNYDAY,:ROTOTILLER,:INGRAIN,:GRASSYTERRAIN,:WATERSPORT,:BLOOMDOOM],
		"The acid melted the bloom!" => [:ACIDDOWNPOUR],
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:FLOWERGARDEN5 => {
	:name => "Flower Garden",
	:fieldMessage => [
		"Seeds line the field."
	],
	:graphic => ["FlowerGarden4"],
	:secretPower => "PETALDANCE",
	:naturePower => :PETALBLIZZARD,
	:mimicry => :GRASS,
	:damageMods => {
		1.5 => [:CUT,:PETALBLIZZARD,:PETALDANCE,:FLEURCANNON,:NIMBLESTRIKE,:LEAFTORNADO,:HYPERVOICE,:BODYSLAM,:REVELATIONDANCE,:LAVAPLUME],
		2.0 => [:FLOWERFEVER,:SWARMDANCE,:HORRIDPOLLEN,:RAMPANTVINE,:DAZZLINGGLEAM],
	},
	:accuracyMods => {
		85 => [:SLEEPPOWDER, :STUNSPORE, :POISONPOWDER],
	},
	:moveMessages => {
		"{1} was cut down to size!" => [:CUT],
		"The Sound travels through the garden!" => [:HYPERVOICE],
		"Tucked into the ground!" => [:BODYSLAM],
		"The colorful flowers reflected the light!" => [:DAZZLINGGLEAM],
		"A sea of flames cloaks the garden!" => [:LAVAPLUME],
		"The blooming flowers powered up the dance!" => [:REVELATIONDANCE],
		"The sweet scent of the flowers made the attack unstoppable!" => [:FLOWERFEVER],
		"The vibrant aroma made the bugs join the melody!" => [:SWARMDANCE],
		"The vibrant aroma scent of flowers boosted the attack!" => [:PETALBLIZZARD,:PETALDANCE,:LEAFTORNADO,:FLEURCANNON,:HORRIDPOLLEN,:RAMPANTVINE],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		2.0 => [:GRASS,:BUG],
		1.5 => [:FIRE],
	},
	:typeMessages => {
		"The thriving flowers boosted the attack!" => [:GRASS],
		"The attack infested the flowers!" => [:BUG],
		"The garden caught fire!" => [:FIRE],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:GROWTH, :ROTOTILLER, :RAINDANCE, :WATERSPORT, :SUNNYDAY, :FLOWERSHIELD, :SWEETSCENT, :INGRAIN, :FLORALHEALING],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:STARLIGHT => {
	:name => "Starlight Arena",
	:fieldMessage => [
		"Starlight fills the battlefield."
	],
	:graphic => ["Starlight","Starlight1"],
	:secretPower => "SWIFT",
	:naturePower => :MOONBLAST,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:AURORABEAM, :SIGNALBEAM,:MOONLIGHTBLADE,:HORNATTACK, :FLASHCANNON, :LUSTERPURGE, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :SOLARBEAM, :SOLARBLADE, :PHOTONGEYSER, :PRISMATICLASER, :NIGHTDAZE,:MISTBALL,:GALAXYBLADE,:OMINOUSWIND,:AURASPHERE,:BUBBLEBEAM,:MYSTICALFIRE,:SPIRITSHACKLE],
		2.0 => [:SWIFT],
		4.0 => [:DOOMDUMMY],
	},
	:accuracyMods => {},
	:moveMessages => {
		"Starlight surged through the attack!" => [:AURORABEAM,:MOONLIGHTBLADE,:HORNATTACK,  :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :MIRRORSHOT, :MIRRORBEAM, :TECHNOBLAST, :SOLARBEAM, :PHOTONGEYSER, :PRISMATICLASER,:MISTBALL,:GALAXYBLADE,:OMINOUSWIND,:AURASPHERE,:BUBBLEBEAM,:MYSTICALFIRE,:SPIRITSHACKLE],
		"Lunar energy surged through the attack!" => [:NIGHTSLASH, :NIGHTDAZE],
		"The astral energy boosted the attack!" => [:SWIFT],
		"A star came crashing down!" => [:DOOMDUMMY],
	},
	:typeMods => {
		:FIRE => [:DOOMDUMMY],
		:FAIRY => [:SOLARBEAM, :SOLARBLADE],
	},
	:typeAddOns => {
		:FAIRY => [:DARK],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK,:PSYCHIC,:FAIRY],
	},
	:typeMessages => {
		"Starlight supercharged the attack!" => [:FAIRY],
		"The night sky boosted the attack!" => [:DARK],
		"The astral energy boosted the attack!" => [:PSYCHIC],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:INDOOR => [:LIGHTTHATBURNSTHESKY],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The cosmic light was consumed!" => [:LIGHTTHATBURNSTHESKY],
	},
	:statusMods => [:AURORAVEIL, :COSMICPOWER, :FLASH, :WISH, :HEALINGWISH, :LUNARDANCE, :MOONLIGHT, :TRICKROOM, :MAGICROOM, :WONDERROOM, :LUNARBLESSING],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :Wish,
		:duration => 2,
		:message => "A wish was made for {1}!",
		:animation => :WISH,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
		:overlay => {
		:damageMods => {
			1.3 => [:AURORABEAM, :SIGNALBEAM, :LUSTERPURGE, :DAZZLINGGLEAM, :CHAOSDRAFT, :ICEBEAM, :MULTIPULSE, :SOLARBEAM, :SOLARBLADE, :FLASHCANNON, :PRISMATICLASER, :NIGHTSLASH,:MIRRORBEAM,:MISTBALL,:GALAXYBLADE,:OMINOUSWIND,:AURASPHERE,:BUBBLEBEAM,:MYSTICALFIRE,:SPIRITSHACKLE],
		},
		:typeMods => {
		},
		:moveMessages => {
		"Starlight surged through the attack!" => [:AURORABEAM, :SIGNALBEAM, :LUSTERPURGE, :CHAOSDRAFT, :ICEBEAM, :MULTIPULSE, :SOLARBEAM,:SOLARBLADE,:FLASHCANNON, :PRISMATICLASER,:MIRRORBEAM,:MISTBALL,:GALAXYBLADE,:OMINOUSWIND,:AURASPHERE,:BUBBLEBEAM,:MYSTICALFIRE,:SPIRITSHACKLE],
		"Lunar energy surged through the attack!" => [:NIGHTSLASH],
		},
		:typeBoosts => {
		1.2 => [:DARK, :PSYCHIC,:FAIRY],
		},
		:typeMessages => {
		"Starlight supercharged the attack!" => [:FAIRY],
		"The night sky boosted the attack!" => [:DARK],
		"The astral energy boosted the attack!" => [:PSYCHIC],
		},
		:typeCondition => {
		},
		:statusMods => [:AURORAVEIL],
	},
},
:NEWWORLD => {
	:name => "New World",
	:fieldMessage => [
		"From darkness, from stardust,",
		"From memories of eons past and visions yet to come...",
	],
	:graphic => ["NewWorld"],
	:secretPower => "ROAROFTIME",
	:naturePower => :SPACIALREND,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:AURORABEAM, :SIGNALBEAM,:GALAXYBLADE, :FLASHCANNON,:METEORMASH,:COMETPUNCH, :DAZZLINGGLEAM,:DOOMSDAY, :MIRRORSHOT, :MIRRORBEAM, :PHOTONGEYSER, :PSYSTRIKE, :AEROBLAST, :SACREDFIRE, :MISTBALL, :LUSTERPURGE, :ORIGINPULSE, :PRECIPICEBLADES, :DRAGONASCENT, :PSYCHOBOOST, :ROAROFTIME, :MAGMASTORM, :CRUSHGRIP, :JUDGMENT, :SEEDFLARE, :SHADOWFORCE, :SEARINGSHOT, :VCREATE, :SECRETSWORD, :SACREDSWORD, :RELICSONG, :FUSIONBOLT, :FUSIONFLARE, :ICEBURN, :FREEZESHOCK, :BOLTSTRIKE, :BLUEFLARE, :TECHNOBLAST, :OBLIVIONWING, :LANDSWRATH, :THOUSANDARROWS, :THOUSANDWAVES, :DIAMONDSTORM, :STEAMERUPTION, :COREENFORCER, :FLEURCANNON, :PRISMATICLASER, :SUNSTEELSTRIKE, :SPECTRALTHIEF, :MOONGEISTBEAM, :MULTIATTACK, :MINDBLOWN, :PLASMAFISTS, :EARTHPOWER, :POWERGEM, :ERUPTION, :CONTINENTALCRUSH, :GENESISSUPERNOVA, :SOULSTEALING7STARSTRIKE, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM],
		4.0 => [:DOOMDUMMY,:BLACKHOLEECLIPSE],
		2.0 => [:FRIENDBEAM,:RETURN,:SWIFT,:ANCIENTPOWER],
		0.25 => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE,:GIGAQUAKE],
		0 => [:HAIL, :SUNNYDAY, :SANDSTORM, :RAINDANCE, :DEWDASH, :SHADOWSKY, :GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN, :ELECTRICTERRAIN, :MIST, :FISSURE],
	},
	:accuracyMods => {
		100 => [:DARKVOID],
		0 => [:DOOMSDAY],
	},
	:moveMessages => {
		"The light shone through the infinite darkness!" => [:AURORABEAM,:GALAXYBLADE, :SIGNALBEAM, :FLASHCANNON, :DAZZLINGGLEAM, :MIRRORSHOT, :MIRRORBEAM, :PHOTONGEYSER, :LIGHTTHATBURNSTHESKY],
		"The ethereal energy strengthened the attack!" => [:PSYSTRIKE, :AEROBLAST, :SACREDFIRE,:COMETPUNCH, :MISTBALL,:SWIFT,:ANCIENTPOWER, :LUSTERPURGE, :ORIGINPULSE, :PRECIPICEBLADES, :DRAGONASCENT, :PSYCHOBOOST, :ROAROFTIME, :MAGMASTORM, :CRUSHGRIP, :JUDGMENT, :SEEDFLARE, :SHADOWFORCE, :SEARINGSHOT, :VCREATE, :SECRETSWORD, :SACREDSWORD, :RELICSONG, :FUSIONBOLT, :FUSIONFLARE, :GLACIATE, :ICEBURN, :FREEZESHOCK, :BOLTSTRIKE, :BLUEFLARE, :TECHNOBLAST, :OBLIVIONWING, :LANDSWRATH, :THOUSANDARROWS, :THOUSANDWAVES, :DIAMONDSTORM, :STEAMERUPTION, :COREENFORCER, :FLEURCANNON, :PRISMATICLASER, :SUNSTEELSTRIKE, :SPECTRALTHIEF, :MOONGEISTBEAM, :MULTIATTACK, :MINDBLOWN, :PLASMAFISTS, :GENESISSUPERNOVA, :SOULSTEALING7STARSTRIKE, :SEARINGSUNRAZESMASH, :MENACINGMOONRAZEMAELSTROM],
		"The germinal matter amassed in the attack!" => [:EARTHPOWER, :POWERGEM, :ERUPTION, :CONTINENTALCRUSH],
		"A star came crashing down on {1}!" => [:DOOMDUMMY],
		"The power of friendship reaches through the galaxy!" => [:FRIENDBEAM,:RETURN],
		"The void consumes thy!" => [:BLACKHOLEECLIPSE],
		"The world is doomed!" => [:DOOMSDAY],
		"The cosmos boosted the attack!" => [:METEORMASH],
		"The unformed land diffused the attack..." => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE, :FISSURE,:GIGAQUAKE],
		"The terrain had no solid ground to attach..." => [:GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN, :ELECTRICTERRAIN, :MIST],
		"The weather drifted off into space..." => [:HAIL, :SUNNYDAY, :SANDSTORM, :RAINDANCE, :DEWDASH, :SHADOWSKY]
	},
	:typeMods => {
		:FIRE => [:DOOMDUMMY],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK],
	},
	:typeMessages => {
		"Infinity boosted the attack!" => [:DARK],
	},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:changeMessage => {
	},
	:statusMods => [:DARKVOID, :HEARTSWAP, :TRICKROOM, :MAGICROOM, :WONDERROOM, :COSMICPOWER, :FLASH, :MOONLIGHT, :NATURESMADNESS, :LUNARBLESSING],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :HyperBeam,
		:duration => 1,
		:message => "{1} must recharge!",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::DEFENSE => 1,
			PBStats::SPEED => 1,
			PBStats::SPATK => 1,
			PBStats::SPDEF => 1,
		},
	},
},
:INVERSE => {
	:name => "Inverse Field",
	:fieldMessage => [
		"!trats elttaB"
	],
	:graphic => ["Inverse"],
	:secretPower => "CONFUSION",
	:naturePower => :MULTIATTACK,
	:mimicry => :NORMAL,
	:damageMods => {
		2.0 => [:REVERSAL],
	},
	:accuracyMods => {},
	:moveMessages => {
		"?ereh did I tahw ees uoy oD"=> [:REVERSAL],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :HyperBeam,
		:duration => 1,
		:message => "{1} received Contrary!",
		:animation => :CONVERSION,
		:stats => {},
	},
},
:PSYTERRAIN => {
	:name => "Psychic Terrain",
	:fieldMessage => [
		"The field became mysterious!"
	],
	:graphic => ["Psychic","Psychic_2"],
	:secretPower => "PSYCHIC",
	:naturePower => :BUNRAKUBEATDOWN,
	:mimicry => :PSYCHIC,
	:damageMods => {
		1.5 => [:SECRETPOWER, :HIDDENPOWER, :HEX, :MAGICALLEAF, :MYSTICALFIRE, :MOONBLAST, :AURASPHERE, :FOCUSBLAST, :MINDBLOWN, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		2.0 => [:IRRITATION],
	},
	:accuracyMods => {
		90 => [:HYPNOSIS],
	},
	:moveMessages => {
		"The psychic energy strengthened the attack!" => [:SECRETPOWER, :HIDDENPOWER, :HEX, :MAGICALLEAF, :MYSTICALFIRE, :MOONBLAST, :AURASPHERE, :FOCUSBLAST, :MINDBLOWN, :HIDDENPOWERNOR, :HIDDENPOWERFIR, :HIDDENPOWERFIG, :HIDDENPOWERWAT, :HIDDENPOWERFLY, :HIDDENPOWERGRA, :HIDDENPOWERPOI, :HIDDENPOWERELE, :HIDDENPOWERGRO, :HIDDENPOWERPSY, :HIDDENPOWERROC, :HIDDENPOWERICE, :HIDDENPOWERBUG, :HIDDENPOWERDRA, :HIDDENPOWERGHO, :HIDDENPOWERDAR, :HIDDENPOWERSTE, :HIDDENPOWERFAI],
		"The attack became even MORE weird!" => [:IRRITATION],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:PSYCHIC],
	},
	:typeMessages => {
		"The Psychic Terrain strengthened the attack!" => [:PSYCHIC],
	},
	:typeCondition => {
		:PSYCHIC => "!attacker.isAirborne?",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:CALMMIND, :COSMICPOWER, :KINESIS, :MEDITATE, :NASTYPLOT, :HYPNOSIS, :PSYCHUP, :MINDREADER, :MIRACLEEYE, :TELEKINESIS, :GRAVITY, :MAGICROOM, :TRICKROOM, :WONDERROOM],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::SPATK => 1,
			PBStats::ATTACK => 1,
		},
	},
	:overlay => {
		:damageMods => {
			1.5 => [:SECRETPOWER, :HIDDENPOWER, :MYSTICALFIRE,:MAGICALLEAF,:AURASPHERE,:HEX,:MOONBLAST,:MINDBLOWN],
		},
		:typeMods => {
		},
		:moveMessages => {
			"The psychic energy strengthened the attack!" => [:SECRETPOWER, :HIDDENPOWER, :MYSTICALFIRE,:MAGICALLEAF,:AURASPHERE,:HEX,:MOONBLAST,:MINDBLOWN],
		},
		:typeBoosts => {
			1.5 => [:PSYCHIC],
		},
		:typeMessages => {
			"The Psychic Terrain strengthened the attack!" => [:PSYCHIC],
		},
		:typeCondition => {	
			:PSYCHIC => "!attacker.isAirborne?",
		},
		:statusMods => [],
	},
},
:DIMENSIONAL => {
	:name => "Dimensional Field",
	:fieldMessage => [
		"Darkness Radiates."
	],
	:graphic => ["Dimensional","Dimensional1","AelitaRift","DimensionalGard"],
	:secretPower => "DARKPULSE",
	:naturePower => :NIGHTDAZE,
	:mimicry => :DARK,
	:damageMods => {
		1.5 => [:HYPERSPACEFURY, :HYPERSPACEHOLE, :SPACIALREND,:ABSOLUTEZERO, :ROAROFTIME, :ETERNABEAM, :DYNAMAXCANNON, :SHADOWFORCE, :OUTRAGE, :THRASH, :STOMPINGTANTRUM, :LASHOUT, :FREEZINGGLARE, :FIREYWRATH, :RAGINGFURY],
		1.2 => [:DARKPULSE, :NIGHTDAZE,:DOOMSDAY],
		2.0 => [:HEX],
		0 => [:HAIL, :SUNNYDAY, :SANDSTORM, :RAINDANCE, :TEATIME, :LUCKYCHANT],
	},
	:accuracyMods => {
		0 => [:DARKVOID, :DARKPULSE, :NIGHTDAZE],
	},
	:moveMessages => {
		"The attack has been corrupted." => [:HYPERSPACEFURY, :HYPERSPACEHOLE,:ABSOLUTEZERO, :SPACIALREND, :ROAROFTIME, :ETERNABEAM, :DYNAMAXCANNON, :SHADOWFORCE, :DARKPULSE, :NIGHTDAZE],
		"The rage continues." => [:OUTRAGE, :THRASH, :STOMPINGTANTRUM, :LASHOUT, :FREEZINGGLARE, :FIREYWRATH, :RAGINGFURY],
		"But it failed." => [:TEATIME, :LUCKYCHANT],
		"The darkest day. ." => [:DOOMSDAY],
		"The darkness infuses to combine a hexing maelstrom!" => [:HEX],
		"The dark dimension swallowed the sand." => [:SANDSTORM],
		"The dark dimension swallowed the rain." => [:RAINDANCE],
		"The dark dimension swallowed the hail." => [:HAIL],
		"The sunlight cannot pierce the darkness." => [:SUNNYDAY],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {
	},
	:typeBoosts => {
		1.5 => [:DARK, :GHOST],
		1.2 => [:SHADOW],
		0.5 => [:FAIRY],
	},
	:typeMessages => {
		"The darkness is here..." => [:DARK],
		"The shadow is strengthened..." => [:SHADOW],
		"The evil aura powered up the attack..." => [:GHOST],
		"The evil aura depleted the attack!" => [:FAIRY],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:OBSTRUCT, :QUASH, :EMBARGO, :HEALBLOCK, :DARKVOID],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => nil,
		:duration => nil,
		:message => "{1} gained armor!",
		:animation => :GRAVITY,
		:stats => {
			PBStats::DEFENSE => 1,
			PBStats::SPDEF => 1,
		},
	},
},
:FROZENDIMENSION => {
	:name => "Frozen Dimensional Field",
	:fieldMessage => [
		"Hate and anger radiates."
	],
	:graphic => ["Angie"],
	:secretPower => "ICYWIND",
	:naturePower => :GLACIATE,
	:mimicry => :ICE,
	:damageMods => {
		2.0 => [:ANCIENTFANGS],
		1.5 => [:RAGINGFURY,:THRASH,:OUTRAGE,:STOMPINGTANTRUM,:RAGE,:LASHOUT,:FREEZINGGLARE,:FIERYWRATH,:ROAROFTIME],
		1.2 => [:SURF, :MUDDYWATER, :WATERPULSE, :HYDROPUMP, :NIGHTSLASH, :DARKPULSE, :HYPERSPACEFURY, :HYPERSPACEHOLE],
		0 => [:MAGICROOM, :WONDERROOM, :TRICKROOM, :GRAVITY, :COURTCHANGE, :TEATIME, :ELECTRICTERRAIN, :GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN,:RAINDANCE, :SANDSTORM,:SUNNYDAY,:DEWDASH],

	},
	:accuracyMods => {
		100 => [:DARKVOID],
	},
	:moveMessages => {
		"The rage continues." => [:RAGINGFURY,:THRASH,:OUTRAGE,:STOMPINGTANTRUM,:RAGE,:LASHOUT,:FREEZINGGLARE,:FIERYWRATH,:ROAROFTIME],
		"The ice warped the attack." => [:SURF, :MUDDYWATER, :WATERPULSE, :HYDROPUMP, :NIGHTSLASH, :DARKPULSE, :HYPERSPACEFURY, :HYPERSPACEHOLE],
		"The frozen dimension remains unchanged." => [:MAGICROOM, :WONDERROOM, :TRICKROOM, :GRAVITY, :COURTCHANGE, :ELECTRICTERRAIN, :GRASSYTERRAIN, :PSYCHICTERRAIN, :MISTYTERRAIN],
		"But it failed." => [:TEATIME],
		"Devastating fangs!" => [:ANCIENTFANGS],
		"The rain evaporated!" => [:RAINDANCE,:DEWDASH],
		"The sun cant pierce the cold!" => [:SUNNYDAY],
		"The sand turned into cold dust!" => [:SANDSTORM],
	},
	:typeMods => {
		:ICE => [:SURF, :MUDDYWATER, :WATERPULSE, :HYDROPUMP, :NIGHTSLASH, :DARKPULSE],
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ICE,:DARK],
		0.5 => [:FIRE,:STEEL],
	},
	:typeMessages => {
		"The darkness is here..." => [:DARK],
		"The dimension mutated the ice!" => [:ICE],
		"The cold evaporates the attack..." => [:FIRE],
		"The metal caught corrosions..." => [:STEEL],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:PARTINGSHOT, :AURORAVEIL, :DARKVOID],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => :Torment,
		:duration => true,
		:message => "{1} is subjected to torment!",
		:animation => :TORMENT,
		:stats => {
			PBStats::SPEED => 2,
		},
	},
},
:HAUNTED => {
	:name => "Haunted Field",
	:fieldMessage => [
		"The field is haunted!"
	],
	:graphic => ["Haunted","Haunted2","Haunted3"],
	:secretPower => "SHADOWCLAW",
	:naturePower => :POLTERGEIST,
	:mimicry => :GHOST,
	:damageMods => {
		1.5 => [:SLASHANDBURN, :FREEZINGGLARE, :FLAMECHARGE, :FIRESPIN, :BONECLUB, :BONERUSH, :BONEMERANG,:MYSTICALFIRE,:MAGICALLEAF],
		1.2 => [:SHADOWBONE,:DARKPULSE,:DAZZLINGGLEAM,:AURORABEAM,:ICYWIND,:PYROGLARE],
		2.0 => [:FLASH],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"Will-o'-wisps joined the attack!" => [:SLASHANDBURN, :MAGICALLEAF, :FLAMECHARGE, :FIRESPIN],
		"Spooky scary skeletons!" => [:BONECLUB, :BONERUSH, :BONEMERANG, :SHADOWBONE],	
		"The spirits combust the attack!" => [:PYROGLARE],
		"Boo!" => [:ASTONISH,:FREEZINGGLARE,:PYROGLARE],
		"FLASHBANG!" => [:FLASH,:DAZZLINGGLEAM],
		"The spooky energy powered up the attack!" => [:DARKPULSE,:MYSTICALFIRE],
		"A cold chill powered up the attack!" => [:ICYWIND,:AURORABEAM],
	},
	:typeMods => {
		:GHOST => [:SLASHANDBURN, :MAGICALLEAF, :FIRESPIN],
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:GHOST],
	},
	:typeMessages => {
		"The evil aura powered up the attack!" => [:GHOST],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:HOLY => [:LIGHTTHATBURNSTHESKY],
		:INDOOR => [:LIGHTTHATBURNSTHESKY],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The evil spirits have been exorcised!" => [:LIGHTTHATBURNSTHESKY],
		 "The evil spirits have been forced back!" => [:LIGHTTHATBURNSTHESKY],
	},
	:statusMods => [:NIGHTMARE, :SPITE, :CURSE, :DESTINYBOND, :MEANLOOK, :SCARYFACE, :MAGICPOWDER, :HYPNOSIS, :WILLOWISP],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :nil,
		:duration => nil,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::SPDEF => 1,
			PBStats::DEFENSE => 1,
		},
	},
},
:CORRUPTED => {
	:name => "Corrupted Cave",
	:fieldMessage => [
		"Corruption seeps from every crevice!"
	],
	:graphic => ["Corrupted"],
	:secretPower => "POISONJAB",
	:naturePower => :TOXICSTORM,
	:mimicry => :POISON,
	:damageMods => {
		1.5 => [:SEEDFLARE, :APPLEACID,:UPROOT,:GIGADRAIN,:MAGMADRIFT,:SCORCHINGSANDS],
		2.0 => [:THUNDERPUNCH],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The move absorbed the corruption!" => [:APPLEACID,:UPROOT,:SEEDFLARE,:GIGADRAIN,:MAGMADRIFT,:SCORCHINGSANDS],
		"The electricity infused with the filfth!" => [:THUNDERPUNCH],
	},
	:typeMods => {
		:POISON => [:ROCKSLIDE, :SMACKDOWN, :STONEEDGE, :ROCKTOMB, :DIAMONDSTORM],
		:ROCK => [:SLUDGEWAVE, :APPLEACID,:SEEDFLARE],
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:POISON],
		1.2 => [:ROCK, :GRASS],
		0.5 => [:FAIRY, :FLYING],
	},
	:typeMessages => {
		"The chemicals strengthened the attack." => [:POISON],
		"The corruption morphed the attack!" => [:ROCK, :GRASS],
		"The corruption weakened the attack." => [:FAIRY],
		"The cave choked out the air!" => [:FLYING],
	},
	:typeCondition => {
		:FLYING => "!self.contactMove?",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:WILLOWISP],
	:changeEffects => {
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => nil,
		:duration => nil,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::DEFENSE => 2,
		},
	},
},
:BEWITCHED => {
	:name => "Bewitched Woods",
	:fieldMessage => [
		"Everlasting glow and glamour!"
	],
	:graphic => ["Darchlight"],
	:secretPower => "NEEDLEARM",
	:naturePower => :DAZZLINGGLEAM,
	:mimicry => :FAIRY,
	:damageMods => {
		1.5 => [:HEX, :MYSTICALFIRE, :SPIRITBREAK,:DAZZLINGGLEAM,:SEEDBOMB],
		2.0 => [:PYROPETALS],
		1.4 => [:ICEBEAM, :HYPERBEAM, :SIGNALBEAM, :AURORABEAM, :CHARGEBEAM, :PSYBEAM, :FLASHCANNON, :MIRRORBEAM, :MAGICALLEAF, :BUBBLEBEAM],
		1.2 => [:DARKPULSE, :NIGHTDAZE, :MOONBLAST],
	},
	:accuracyMods => {
		85 => [:SLEEPPOWDER, :POISONPOWDER, :STUNSPORE, :GRASSWHISTLE],
		0 => [:DOOMSDAY]
	},
	:moveMessages => {
		"Magic aura amplified the attack!" => [:HEX, :MYSTICALFIRE, :SPIRITBREAK,:DAZZLINGGLEAM, :ICEBEAM, :HYPERBEAM, :SIGNALBEAM, :AURORABEAM, :CHARGEBEAM, :PSYBEAM, :FLASHCANNON, :MIRRORBEAM, :MAGICALLEAF, :BUBBLEBEAM],
		"The forest is cursed with nightfall!" => [:DARKPULSE, :NIGHTDAZE, :MOONBLAST],
		"The seeds got cursed and befallen!" => [:SEEDBOMB],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FAIRY, :GRASS],
		1.3 => [:DARK],
	},
	:typeMessages => {
		"The fairy aura amplified the attack's power!" => [:FAIRY],
		"Flourish!" => [:GRASS],
		"The dark aura amplified the attack's power!" => [:DARK],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:STRENGTHSAP, :FORESTSCURSE, :MAGICPOWDER, :MOONLIGHT, :SLEEPPOWDER, :POISONPOWDER, :STUNSPORE, :GRASSWHISTLE],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots.",
		:animation => :INGRAIN,
		:stats => {
			PBStats::SPDEF => 1,
		},
	},
},
:SKY => {
	:name => "Sky Field",
	:fieldMessage => [
		"The sky is filled with clouds. "
	],
	:graphic => ["GoldenArena"],
	:secretPower => "WINGATTACK",
	:naturePower => :TAILWIND,
	:mimicry => :FLYING,
	:damageMods => {
		2.0 => [:FLAMEWHEEL],
		1.5 => [:LUSTERPURGE,:THUNDERPULSE],
		1.3 => [:ICYWIND, :SILVERWIND, :OMINOUSWIND,:GUST, :TWISTER, :FAIRYWIND,:HEATWAVE, :AEROBLAST, :FLYINGPRESS, :SKYUPPERCUT, :THUNDERBOLT,:LEAFTORNADO, :STEELWING, :DRAGONDARTS, :GRAVAPPLE, :DRAGONASCENT, :RAZORWIND, :DIVE, :ESPERWING],
		1.2 => [:SPRINGTIDESTORM, :SANDSEARSTORM,:CLOUDBURST,:BLEAKWINDSTORM],
		0 => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE, :DIG, :ROTOTILLER, :SPIKES, :TOXICSPIKES, :STICKYWEB]
	},
	:accuracyMods => {
		0 => [:THUNDER, :HURRICANE]
	},
	:moveMessages => {
		"The open skies strengthened the attack!" => [:ICYWIND,:HEATWAVE, :GUST, :SILVERWIND, :OMINOUSWIND, :FAIRYWIND, :AEROBLAST,:LEAFTORNADO, :FLYINGPRESS, :SKYUPPERCUT, :THUNDERBOLT, :STEELWING, :DRAGONDARTS, :GRAVAPPLE, :DRAGONASCENT, :TWISTER, :RAZORWIND, :DIVE, :ESPERWING, :SPRINGTIDESTORM, :SANDSEARSTORM, :BLEAKWINDSTORM],
		"But there is no solid ground!" => [:EARTHQUAKE, :MAGNITUDE, :BULLDOZE, :DIG, :ROTOTILLER, :SPIKES, :TOXICSPIKES, :STICKYWEB],
		"The bright light sky strengthened the attack!" => [:LUSTERPURGE,:THUNDERPULSE],
		"The open air strengthened the attack!" => [:CLOUDBURST],
		"The flames formed the silhouette of a phoenix!" => [:FLAMEWHEEL],
	},
	:typeMods => {
		:FLYING => [:DIVE, :TWISTER],
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FLYING],
		1.1 => [:FIRE,:ELECTRIC],
	},
	:typeMessages => {
		"The attack glides along the sky!" => [:FLYING],
		"The close distance to the sun powered up the attack!" => [:FIRE],
		"Clouds amplified the attack!" => [:ELECTRIC],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:MIRRORMOVE, :TAILWIND, :SUNNYDAY, :HAIL, :SANDSTORM, :RAINDANCE],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::DEFENSE => 1,
			PBStats::SPDEF => 1,
		},
	},
},
:COLOSSEUM => {
	:name => "Colosseum",
	:fieldMessage => [
		"All eyes are on the combatants!"
	],
	:graphic => ["Colosseum"],
	:secretPower => "POWERUPPUNCH",
	:naturePower => :STEAMROLLER,
	:mimicry => :STEEL,
	:damageMods => {
		2.0 => [:BEATUP, :FELLSTINGER, :PAYDAY, :REVERSAL, :PURSUIT],
		1.5 => [:SACREDSWORD, :SECRETSWORD, :SUBMISSION, :METEORASSAULT, :SMARTSTRIKE, :SMACKDOWN, :BRUTALSWING, :ELECTROWEB, :VINEWHIP, :PSYCHOCUT, :NIGHTSLASH, :BONEMERANG, :FIRSTIMPRESSION, :BONERUSH, :BONECLUB, :LEAFBLADE, :PAYBACK, :PUNISHMENT, :METEORMASH, :BULLETPUNCH, :CLANGINGSCALES, :STEAMROLLER],
		1.2 => [:STORMTHROW, :WOODHAMMER, :DRAGONHAMMER, :POWERWHIP, :SPIRITSHACKLE,:THUNDERRAID, :DRILLRUN, :DRILLPECK, :ICEHAMMER, :ICICLESPEAR, :ANCHORSHOT, :CRABHAMMER, :SHADOWBONE, :FIRELASH, :SUCKERPUNCH, :THROATCHOP],
		0 => [:BATONPASS, :ENCORE, :WHIRLWIND],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The fighters rallied together!" => [:BEATUP],
		"The coup de grâce!" => [:FELLSTINGER],
		"The audience hurled coins down!" => [:PAYDAY],
		"There is no escape!" => [:PURSUIT],
		"For Honor!" => [:REVERSAL, :SACREDSWORD, :SECRETSWORD, :SUBMISSION, :METEORASSAULT, :SMARTSTRIKE, :SMACKDOWN, :BRUTALSWING, :STORMTHROW],
		"For Glory!" => [:ELECTROWEB, :VINEWHIP, :PSYCHOCUT, :NIGHTSLASH,:THUNDERRAID, :BONEMERANG, :FIRSTIMPRESSION, :BONERUSH, :BONECLUB, :LEAFBLADE, :PAYBACK, :PUNISHMENT, :METEORMASH, :BULLETPUNCH, :CLANGINGSCALES, :STEAMROLLER, :WOODHAMMER, :DRAGONHAMMER, :POWERWHIP, :SPIRITSHACKLE, :DRILLRUN, :DRILLPECK, :ICEHAMMER, :ICICLESPEAR, :ANCHORSHOT, :CRABHAMMER, :SHADOWBONE, :FIRELASH, :SUCKERPUNCH, :THROATCHOP],
		"There can be no retreat!" => [:BATONPASS],
		"{1} stands their ground in the arena!!" => [:WHIRLWIND],
		"The audience demands fighting not repetition!" => [:ENCORE],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:SWORDSDANCE, :KINGSSHIELD, :HOWL, :NORETREAT, :ROAR, :SWAGGER, :FLATTER],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :Taunt,
		:duration => 4,
		:message => "{1} feels taunted!",
		:animation => :TAUNT,
		:stats => {
			PBStats::ATTACK => 2,
		},
	},
},
:INFERNAL => {
	:name => "Infernal Field",
	:fieldMessage => [
		"The souls of the damned burn on."
	],
	:graphic => ["Infernal"],
	:secretPower => "INFERNO",
	:naturePower => :DOOMSDAY,
	:mimicry => :FIRE,
	:damageMods => {
		2.0 => [:PUNISHMENT, :SMOG, :DREAMEATER],
		1.5 => [:BLASTBURN, :EARTPOWER,:HELLFIRESTORM, :VILEASSAULT, :PRECIPICEBLADES, :INFERNO, :RAGINGFURY, :INFERNALPARADE,:SPECTRALSCREAM,:THUNDERPULSE,:SHADOWFIRE,:SHADOWCHILL,:SHADOWBOLT,:FIRSTIMPRESSION],
		0  => [:RAINDANCE, :HAIL,:SANDSTORM,:DEWDASH],
	},
	:accuracyMods => {
		0 => [:WILLOWISP, :DARKVOID, :INFERNO],
	},
	:moveMessages => {
		"Hellish Suffering!" => [:PUNISHMENT, :SMOG,:SPECTRALSCREAM,:HELLFIRESTORM],
		"The never ending nightmare amplifies the attack!" => [:SHADOWFIRE,:SHADOWCHILL,:SHADOWBOLT],
		"Dream a dream so big it becomes. . ." => [:DREAMEATER],
		"Fever rush!" => [:FIRSTIMPRESSION],
		"Infernal flames strengthened the attack" => [:BLASTBURN, :EARTPOWER, :VILEASSAULT, :PRECIPICEBLADES, :INFERNO, :RAGINGFURY, :INFERNALPARADE,:THUNDERPULSE],
		"The hail melted away." => [:HAIL],
		"The rain evaporated." => [:RAINDANCE,:DEWDASH],
		"The sand turned into hot dust." => [:SANDSTORM],
	},
	:typeMods => {
		:DARK => [:SPIRITBREAK, :AURASPHERE, :FRUSTRATION],
	},
	:typeAddOns => {
		:FIRE => [:GROUND, :STEEL, :ROCK],
	},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:FIRE, :DARK, :SHADOW],
		0.5 => [:FAIRY, :WATER],
	},
	:typeMessages => {
		"The infernal flames strengthened the attack!" => [:FIRE, :DARK],
		"The hellfire burnt out the attack!" => [:FAIRY, :WATER],
	},
	:typeCondition => {
		:FAIRY => "@move != :SPIRITBREAK",
		:WATER => "self.move!=:SCALD && self.move!=:STEAMERUPTION",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:WILLOWISP, :DARKVOID, :TORMENT, :NIGHTMARE, :STEALTHROCK],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => nil,
		:duration => nil,
		:message => "{1} can't escape now!",
		:animation => :MEANLOOK,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
		},
	},
},
:CONCERT1 => {
	:name => "Concert Venue",
	:fieldMessage => [
		"Let's get HYPED!"
	],
	:graphic => ["Concert1"],
	:secretPower => "BOOMBURST",
	:naturePower => :BOOMBURST,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACID,:ACIDSPRAY,:DRUMBEATING,:FAKEOUT,:ROLLOUT,:FIRSTIMPRESSION,:DRAGONTAIL,:CIRCLETHROW,:RAGE,:THRASH,:FRUSTRATION,:OUTRAGE,:STOMPINGTANTRUM],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Face melting!" => [:ACID,:ACIDSPRAY,:APPLEACID],
		"Rock and roll!" => [:ROLLOUT],
		"An amazing drumsolo!" => [:DRUMBEATING],
		"What an opening act!" => [:FIRSTIMPRESSION,:FAKEOUT],
		"MOSHPIT!!!" => [:DRAGONTAIL,:CIRCLETHROW],
		"The outraged audience is rioting!" => [:RAGE,:THRASH,:FRUSTRATION,:OUTRAGE,:STOMPINGTANTRUM],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
	},
	:typeMessages => {
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:CONCERT2 => [:WORKUP,:ROLLOUT,:FIRSTIMPRESSION,:DRUMBEATING,:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE,:SWAGGER,:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM],
		:CONCERT3 => [:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME],
		:CONCERT4 => [:SELFDESTRUCT,:EXPLOSION],
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:ACIDARMOR,:WORKUP,:HOWL,:PARTINGSHOT,:METALSOUND,:SCREECH,:GROWL,:CLANGOROUSSOUL,:SING,:ROAR,:ENCORE],
	:changeEffects => {
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:CONCERT2 => {
	:name => "Concert Venue",
	:fieldMessage => [
		"Let's get HYPED!"
	],
	:graphic => ["Concert2"],
	:secretPower => "BOOMBURST",
	:naturePower => :BOOMBURST,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACID,:ACIDSPRAY,:DRUMBEATING,:FAKEOUT,:ROLLOUT,:FIRSTIMPRESSION,:DRAGONTAIL,:CIRCLETHROW,:RAGE,:THRASH,:FRUSTRATION,:OUTRAGE,:STOMPINGTANTRUM],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Face melting!" => [:ACID,:ACIDSPRAY,:APPLEACID],
		"Rock and roll!" => [:ROLLOUT],
		"An amazing drumsolo!" => [:DRUMBEATING],
		"What an opening act!" => [:FIRSTIMPRESSION,:FAKEOUT],
		"MOSHPIT!!!" => [:DRAGONTAIL,:CIRCLETHROW],
		"The outraged Audience is rioting!" => [:RAGE,:THRASH,:FRUSTRATION,:OUTRAGE,:STOMPINGTANTRUM],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
	},
	:typeMessages => {
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:ACIDARMOR,:WORKUP,:HOWL,:PARTINGSHOT,:METALSOUND,:SCREECH,:GROWL,:CLANGOROUSSOUL,:SING,:ROAR,:ENCORE],
	:changeEffects => {
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:CONCERT3 => {
	:name => "Concert Venue",
	:fieldMessage => [
		"Let's get HYPED!"
	],
	:graphic => ["Concert3"],
	:secretPower => "BOOMBURST",
	:naturePower => :BOOMBURST,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACID,:ACIDSPRAY,:DRUMBEATING,:FAKEOUT,:ROLLOUT,:FIRSTIMPRESSION,:DRAGONTAIL,:CIRCLETHROW],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Face melting!" => [:ACID,:ACIDSPRAY,:APPLEACID],
		"Rock and roll!" => [:ROLLOUT],
		"An amazing drumsolo!" => [:DRUMBEATING],
		"What an opening act!" => [:FIRSTIMPRESSION,:FAKEOUT],
		"MOSHPIT!!!" => [:DRAGONTAIL,:CIRCLETHROW],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
	},
	:typeMessages => {
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
		:CONCERT1 => [:SHEERCOLD,:COLDTRUTH],
		:CONCERT2 => [:THROATCHOP,:EMBARGO,:QUASH,:SLACKOFF,:YAWN,:PLAYNICE,:BABYDOLLEYES,:TICKLE],
		:CONCERT4 => [:WORKUP,:ROLLOUT,:FIRSTIMPRESSION,:DRUMBEATING,:REVELATIONDANCE,:FIERYDANCE,:PETALDANCE,:DRAGONDANCE,:QUIVERDANCE,:AQUABATICS,:SWORDSDANCE,:FEATHERDANCE,:SWAGGER,:LASERFOCUS,:LUCKYCHANT,:FOCUSENERGY,:SPOTLIGHT,:FOLLOWME,:BOOMBURST,:BUGBUZZ,:CHATTER,:CLANGINGSCALES,:CLANGOROUSSOUL,:CLANGOROUSSOULBLAZE,:DISARMINGVOICE,:ECHOEDVOICE,:GROWL,:HOWL,:HYPERVOICE,:METALSOUND,:NOBLEROAR,:OVERDRIVE,:PARTINGSHOT,:RELICSONG,:ROAR,:ROUND,:SCREECH,:SHADOWPANIC,:SING,:SNARL,:SPARKLINGARIA,:SUPERSONIC,:UPROAR,:FEVERPITCH,:SPECTRALSCREAM,:SELFDESTRUCT,:EXPLOSION],
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:ACIDARMOR,:WORKUP,:HOWL,:PARTINGSHOT,:METALSOUND,:SCREECH,:GROWL,:CLANGOROUSSOUL,:SING,:ROAR,:ENCORE],
	:changeEffects => {
	},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:CONCERT4 => {
	:name => "Concert Venue",
	:fieldMessage => [
		"Let's get HYPED!"
	],
	:graphic => ["Concert4"],
	:secretPower => "BOOMBURST",
	:naturePower => :BOOMBURST,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACID,:ACIDSPRAY,:DRUMBEATING,:FAKEOUT,:ROLLOUT,:FIRSTIMPRESSION,:DRAGONTAIL,:CIRCLETHROW],
		2.0 => [:ACROBATICS],
	},
	:accuracyMods => {
		100 => [:SING],
	},
	:moveMessages => {
		"Face melting!" => [:ACID,:ACIDSPRAY,:APPLEACID],
		"Rock and roll!" => [:ROLLOUT],
		"Elegance and grace!" => [:ACROBATICS],
		"An amazing drumsolo!" => [:DRUMBEATING],
		"What an opening act!" => [:FIRSTIMPRESSION,:FAKEOUT],
		"MOSHPIT!!!" => [:DRAGONTAIL,:CIRCLETHROW],
	},
	:typeMods => {
	},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
	},
	:typeMessages => {
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:ACIDARMOR,:WORKUP,:HOWL,:PARTINGSHOT,:METALSOUND,:SCREECH,:GROWL,:CLANGOROUSSOUL,:SING,:ROAR,:ENCORE,:FICKLEBEAM],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => :HelpingHand,
		:duration => true,
		:message => "{1} accepts the crowd's help!",
		:animation => :HELPINGHAND,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:DEEPEARTH => {
	:name => "Deep Earth",
	:fieldMessage => [
		"The core is pulling you in...",
	],
	:graphic => ["DeepEarth","Zeight","Zeight2","Zeight3","Zeight4"],
	:secretPower => "HEAVYSLAM",
	:naturePower => :GRAVITY,
	:mimicry => :GROUND,
	:damageMods => {
		1.3 => [:LANDSWRATH, :PRECIPICEBLADES, :MAGNETBOMB, :TECTONICRAGE, :CRUSHGRIP, :SMACKDOWN, :COREENFORCER],
		2.0 => [:GYROBALL],
		1.5 => [:HEAVYSLAM,	:HEATCRASH, :BODYSLAM, :STOMP, :DRAGONRUSH, :STEAMROLLER, :GRAVAPPLE, :ANCIENTPOWER, :FLING, :GRASSKNOT, :LOWKICK, :SPACIALREND, :STORMTHROW, :CIRCLETHROW, :VITALTHROW, :BODYPRESS, :SUBMISSION, :ICEHAMMER, :HAMMERARM, :CRABHAMMER, :ICICLECRASH, :THOUSANDARROWS, :THOUSANDWAVES],
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"The attack came crashing down!" => [:HEAVYSLAM, :HEATCRASH, :BODYSLAM, :STOMP, :DRAGONRUSH, :STEAMROLLER, :GRAVAPPLE, :BODYPRESS, :ICICLECRASH, :FLING],
		"Enjoy the trip!" => [:GRASSKNOT, :LOWKICK,:GYROBALL],
		"{1} threw their whole weight into it!" => [:ICEHAMMER, :HAMMERARM, :CRABHAMMER],
		"Slammed into the ground!" => [:STORMTHROW, :CIRCLETHROW, :VITALTHROW, :SUBMISSION, :SMACKDOWN],
		"CRUSHED!" => [:CRUSHGRIP],
		"The magnetic field is strengthened!" => [:MAGNETBOMB],
		"The power of the earth is utterly overwhelming!"  => [:THOUSANDARROWS, :THOUSANDWAVES, :LANDSWRATH, :PRECIPICEBLADES, :TECTONICRAGE],
		"The power of ages gone by..." => [:ANCIENTPOWER],
		"The power of the core obliterates all!" => [:COREENFORCER],
		"The intense gravity is ruptured!" => [:SPACIALREND],
	},
	:typeMods => {},
	:typeAddOns => {
	},
	:moveEffects => {},
	:typeBoosts => {
		1.3 => [:ROCK, :PSYCHIC],
		1.5 => [:GROUND],
	},
	:typeMessages => {
		"The core's magical forces are immense!" => [:PSYCHIC],
		"The earth empowered the attack!" => [:ROCK, :GROUND],
	},
	:typeCondition => {
		:GROUND => "!opponent.hasType?(:GROUND)",
	},
	:typeEffects => {},
	:changeCondition => {
	},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:AUTOTOMIZE, :GEOMANCY, :ROTOTILLER, :MAGNETFLUX, :EERIEIMPULSE, :MAGNETRISE, :GRAVITY, :TOPSYTURVY, :SEISMICTOSS, :PSYWAVE],
	:changeEffects => {},
	:seed => {
		:seedtype => :TELLURICSEED,
		:effect => nil,
		:duration => nil,
		:message => "{1}'s weight increased!",
		:animation => :QUASH,
		:stats => {
			PBStats::DEFENSE => 1,
		}
	},
},
:BACKALLEY => {
	:name => "Backalley",
	:fieldMessage => [
		"Shifty eyes are all around..."
	],
	:graphic => ["Under"],
	:secretPower => "SMOG",
	:naturePower => :CEASELESSEDGE,
	:mimicry => :STEEL,
	:damageMods => {
			1.5 => [:STEAMROLLER,:DUSTJAVELIN, :SMOG, :BEATUP, :PAYDAY, :INFESTATION, :SPECTRALTHIEF, :FIRSTIMPRESSION, :TECHNOBLAST, :SHADOWSNEAK,
				:XSCISSOR, :FURYCUTTER, :NIGHTSLASH,:DRAGONCLAW, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :LEAFBLADE, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :SOLARBLADE, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :SLASHANDBURN, :HEXINGSLASH,
				:HORNATTACK, :FURYATTACK, :POISONSTING, :TWINEEDLE, :PINMISSILE, :PECK, :DRILLPECK, :MEGAHORN, :POISONJAB, :NEEDLEARM, :PLUCK, :DRILLRUN, :HORNLEECH, :FELLSTINGER, :SMARTSTRIKE, :BRANCHPOKE, :FALSESURRENDER, :GLACIALLANCE, :GILDEDARROW, :GILDEDHELIX,:SECRETSWORD,  :QUICKSILVERSPEAR],
				2.0 => [:PHANTOMFORCE],
	},
	:accuracyMods => {
		0 => [:SMOG, :POISONGAS],
	},
	:moveMessages => {
		"The power of science is amazing!" => [:TECHNOBLAST],
		"A crowd is gathering!" => [:BEATUP],
		"Darkness approaches!" => [:PHANTOMFORCE],
		"The city smog is suffocating!" => [:SMOG],
		"Careful on the street!" => [:STEAMROLLER],
		"Gotta make ends meet somehow..." => [:PAYDAY, :SPECTRALTHIEF, :SHADOWSNEAK],
		"A frightening first impression!" => [:FIRSTIMPRESSION],
		"A knife glints in the dark!" => [:XSCISSOR, :FURYCUTTER, :NIGHTSLASH, :SACREDSWORD, :AIRSLASH, :AERIALACE, :AIRCUTTER, :LEAFBLADE, :RAZORLEAF, :SLASH, :CUT, :CROSSPOISON, :PSYCHOCUT, :RAZORSHELL, :SOLARBLADE, :BEHEMOTHBLADE, :CEASELESSEDGE, :STONEAXE, :AQUACUTTER, :SLASHANDBURN, :HEXINGSLASH],
		"Better watch your back..." => [:HORNATTACK,:DRAGONCLAW,:DUSTJAVELIN, :FURYATTACK, :POISONSTING, :TWINEEDLE, :PINMISSILE, :PECK, :DRILLPECK, :MEGAHORN, :POISONJAB, :NEEDLEARM, :PLUCK, :DRILLRUN, :HORNLEECH, :FELLSTINGER, :SMARTSTRIKE, :BRANCHPOKE,:SECRETSWORD, :FALSESURRENDER, :GLACIALLANCE, :GILDEDARROW, :GILDEDHELIX, :QUICKSILVERSPEAR],
	},
	:typeMods => {
		:DARK => [:FIRSTIMPRESSION],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:DARK],
		1.3 => [:POISON, :BUG, :STEEL],
		0.5 => [:FAIRY],
	},
	:typeMessages => {
		"Street rules!" => [:DARK],
		"The right tool for the job!" => [:STEEL],
		"In the cracks and the walls!" => [:BUG],
		"All kinds of pollution strengthened the attack!" => [:POISON],
		"This is no place for fairytales..." => [:FAIRY],
	},
	:typeCondition => {
		:DARK => "self.pbIsPhysical?(@type)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:SMOKESCREEN, :NASTYPLOT, :PARTINGSHOT, :FAKETEARS, :POISONGAS, :SMOG, :TRICK, :SWITCHEROO, :CORROSIVEGAS, :SNATCH],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPEED => 1,
		},
	},
},
:CITY => {
	:name => "City",
	:fieldMessage => [
		"The streets are busy..."
	],
	:graphic => ["GDCCentralSquare","City","GearenNew","GDCDreamDistrict","GDCDistrictOfHope","GDCJudicialDistrict","GDCScholarDistrict"],
	:secretPower => "SMOG",
	:naturePower => :VENAMSKISS,
	:mimicry => :NORMAL,
	:damageMods => {
		1.5 => [:ACROBATICS, :HYPERVOICE, :BRICKBREAK, :DISCHARGE,:STOMPINGTANTRUM,:PSYSWITCH,:QUICKATTACK],
		1.2 => [:STEAMROLLER,:FIRSTIMPRESSION,:NATURESLANCE,:EXTREMESPEED],
		2.0 => [:AERIALACE],
	},
	:accuracyMods => {
		0 => [:SMOG, :POISONGAS],
	},
	:moveMessages => {
		"A crowd is gathering to listen in!" => [:HYPERVOICE],
		"High Voltage!" => [:DISCHARGE],
		"Street Magic!" => [:PSYSWITCH],
		"SWOOOSH!" => [:EXTREMESPEED,:QUICKATTACK],
		"For Green Peace!" => [:NATURESLANCE],
		"The streets got torn up!" => [:STOMPINGTANTRUM],
		"An extravagant street performance!" => [:ACROBATICS],
		"Careful on the street!" => [:STEAMROLLER],
		"Working 9 to 5 for this!" => [:BRICKBREAK],
		"An overwhelming first impression!" => [:FIRSTIMPRESSION],
		"Deepdive from a nearby skyscraper!" => [:AERIALACE],
	},
	:typeMods => {
		:NORMAL => [:FIRSTIMPRESSION],
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:NORMAL],
		1.3 => [:POISON, :BUG, :STEEL],
		0.5 => [:FAIRY],
	},
	:typeMessages => {
		"The HUSTLE and BUSTLE of the city!" => [:NORMAL],
		"The power of science is amazing!" => [:STEEL],
		"In the cracks and the walls!" => [:BUG],
		"All kinds of pollution strengthened the attack!" => [:POISON],
		"This is no place for fairytales..." => [:FAIRY],
	},
	:typeCondition => {
		:NORMAL => "self.pbIsPhysical?(@type)",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
	},
	:statusMods => [:SMOKESCREEN, :WORKUP, :AUTOTOMIZE, :SHIFTGEAR, :POISONGAS, :SMOG, :RECYCLE, :CORROSIVEGAS],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => 0,
		:duration => 0,
		:message => "",
		:animation => nil,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::ACCURACY => 1,
		},
	},
},
:STORMY => {
	:name => "Stormy",
	:fieldMessage => [
		"A raging storm brews up. . ."
	],
	:graphic => ["STORMY"],
	:secretPower => "LIQUIDATION",
	:naturePower => :WILDBOLTSTORM,
	:mimicry => :ELECTRIC,
	:damageMods => {
		1.5 => [:AIRSLASH,:HYDROVORTEX,:AIRCUTTER,:GUST,:TWISTER,:LIGHTOFRUIN],
		1.3 => [:RISINGVOLTAGE,:HURRICANE,:RAZORWIND],
		0 => [:ERUPTION,:LEAFSTORM,:SUNNYDAY,:HAIL,:SUNNYDAY,:SANDSTORM],
		2.0 => [:QUICKATTACK],
	},
	:accuracyMods => {},
	:moveMessages => {
		"A giant tornado formed!" => [:HURRICANE,:HYDROVORTEX,:AIRCUTTER,:AIRSLASH,:TWISTER,:RAZORWIND],
		"The gust turned into a Typhon!" => [:GUST],
		"The never ending storm powered up the attack!" => [:LIGHTOFRUIN],
		"Lightning fast!" => [:QUICKATTACK],
		"The voltage is rising to the maximum!" => [:RISINGVOLTAGE],
		"The attack lost its energy due to the raging storm!" => [:ERUPTION, :LEAFSTORM],
		"The sunlight got consumed by the storm!" => [:SUNNYDAY],
		"The hail got blown away." => [:HAIL],
		"The sand turned into cold dust!" => [:SANDSTORM],
	},
	:typeMods => {
		:ELECTRIC => [:SKYATTACK],
	},
	:typeAddOns => {

	},	
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:ELECTRIC, :WATER,:FLYING],
		0.5 => [:FIRE,:GRASS,:GROUND],
	},
	:typeMessages => {
		"The storm amplified the attack!" => [:ELECTRIC],
		"The attack rides the storm!" => [:WATER,:FLYING],
		"The storm weakened the power." => [:FIRE],
		"The storm damaged the flora." => [:GRASS],
		"The moist land weakened the attack." => [:GROUND],
	},
	:typeCondition => {
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [],
	:changeEffects => {},
	:seed => {
		:seedtype => :ELEMENTALSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} is absorbing tension!",
		:animation => :CHARGE,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::DEFENSE => 1,
		},
		},
		:overlay => {
		:damageMods => {
			1.3 => [:AIRSLASH,:AQUACUTTER,:AIRCUTTER,:GUST],
			1.1 => [:RISINGVOLTAGE,:HURRICANE,:RAGINGTHUNDER],
		},
		:typeMods => {
		},
		:moveMessages => {
			 "The attack rides the storm!" => [:HURRICANE,:AIRCUTTER,:GUST,:AIRSLASH,:AQUACUTTER],
			 "The voltage is rising to the maximum!" => [:RISINGVOLTAGE],
			 "The attack got super charged!" => [:RAGINGTHUNDER],
		},
		:typeBoosts => {
			1.3 => [:ELECTRIC,:WATER,:FLYING],
		},
		:typeMessages => {
		"The storm amplified the attack!" => [:ELECTRIC],
		"The attack fused with the storm!" => [:WATER,:FLYING],
		},
		:typeCondition => {	
		},
		:statusMods => [],
	},
},
:BOG => {
	:name => "Battlefield of Gods",
	:fieldMessage => [
		"Sacred energies converge. . ."
	],
	:graphic => ["BOG"],
	:secretPower => "MULTIPULSE",
	:naturePower => :MULTIPULSE,
	:mimicry => :DRAGON,
	:damageMods => {
		2.0 => [:DOUBLEKICK],
		1.5 => [:GALESTRIKE,:MYSTICALFIRE,:DRAGONPULSE,:MULTIPULSE,:HEAVENLYWING,:HIDDENPOWER],
		1.2 => [:ANCIENTPOWER,:EXTREMESPEED,:RAZORWIND, :EARTHPOWER, :HEATWAVE, :STRENGTH, :ROCKCLIMB, :ROCKSLIDE, :LIQUIDATION, :SCALD, :BRAVEBIRD, :DRAGONBREATH, :CLOSECOMBAT,:SACREDFIRE,:HIGHHORSEPOWER],
		0 => [:STEELBEAM, :FLASHCANNON],
	},
	:accuracyMods => {},
	:moveMessages => {
		"Sacred energy amplifies the attack!" => [:GALESTRIKE,:MYSTICALFIRE,:DRAGONPULSE,:MULTIPULSE,:HEAVENLYWING,:HIDDENPOWER],
		"Divine Godspeed!" => [:EXTREMESPEED],
		"What a crazy leg day!" => [:DOUBLEKICK],
		"A gods blessing ignites the attack!" => [:ANCIENTPOWER,:RAZORWIND, :EARTHPOWER, :HEATWAVE, :STRENGTH, :ROCKCLIMB, :ROCKSLIDE, :LIQUIDATION, :SCALD, :BRAVEBIRD, :DRAGONBREATH, :CLOSECOMBAT,:SACREDFIRE,:HIGHHORSEPOWER],
		"The gods denied technology this advanced!" => [:STEELBEAM, :FLASHCANNON],
	},
	:typeMods => {
		:FLYING => [:RAZORWIND]
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.3 => [:FIRE, :FLYING, :WATER],
		1.1 => [:GROUND, :DRAGON],
		0.3 => [:STEEL],
	},
	:typeMessages => {
		"Divine energy surrounds the attack!" => [:FIRE, :FLYING,:WATER],
		"Divine energy cloaks the attack!" => [:GROUND,:DRAGON],
		"Technology is not ready yet.." => [:STEEL],
	},
	:typeCondition => {
		:STEEL => "!attacker.isAirborne?",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {},
	:dontChangeBackup => [],
	:changeMessage => {},
	:statusMods => [:ARENITEWALL],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :Protect,
		:duration => :KingsShield,
		:message => "The Magical Seed shielded {1} against damage!",
		:animation => :KINGSSHIELD,
		:stats => {
		},
	},
},
:SUPERHEATED => {
    :name => "Super-Heated Field",
    :fieldMessage => [
      "The field is super-heated!"
    ],
    :graphic => ["Superheated"],
    :secretPower => :FLAMEBURST,
    :naturePower => :HEATWAVE,
    :mimicry => :FIRE,
    :damageMods => {
      0.5 => [:SURF, :MUDDYWATER, :WATERPLEDGE, :WATERSPOUT, :SPARKLINGARIA, :HYDROVORTEX, :OCEANICOPERETTA],
      1.5 => [:SCALD, :STEAMERUPTION,:PYROKINESIS,:FLAMETHROWER,:MAGMADRIFT,:IGNISCRUSHER,:WILDCHARGE],
	  2.0 => [:ASSURANCE],
	  0 => [:HAIL,:RAINDANCE,:SANDSTORM,:DEWDASH],
    },
    :accuracyMods => {},
    :moveMessages => {
      "The field super-heated the attack!" => [:SCALD, :STEAMERUPTION,:PYROKINESIS,:FLAMETHROWER,:MAGMADRIFT,:IGNISCRUSHER],
	   "A burning fatal strike!" => [:ASSURANCE,:WILDCHARGE],
	   "The hail melted away." => [:HAIL],
		"The rain melted away." => [:RAINDANCE],
		"The sand turned into hot dust." => [:SANDSTORM],
    },
    :typeMods => {},
    :typeAddOns => {},
    :moveEffects => {
    },
    :typeBoosts => {
      0.5 => [:ICE,:WATER],
      1.5 => [:FIRE],
    },
    :typeMessages => {
      "The extreme heat softened the attack..." => [:ICE, :WATER],
      "The attack was super-heated!" => [:FIRE],
    },
    :typeCondition => {
      :WATER => "self.move!=:SCALD && self.move!=:STEAMERUPTION",
    },
    :typeEffects => {},
    :changeCondition => {
    },
    :fieldChange => {
    },
    :changeMessage => {
    },
    :statusMods => [],
    :changeEffects => {},
    :seed => {
      :seedtype => :TELLURICSEED,
		:effect => :ShellTrap,
		:duration => true,
		:message => "{1} primed a trap!",
		:animation => :SHELLTRAP,
		:stats => {
			PBStats::DEFENSE => 1,
		},
    },
  },
:DARKNESS1 => {
	:name => "Darkness Field",
	:fieldMessage => [
		"A shroud of darkness, however slight, gently envelops the field..."
	],
	:graphic => ["Darkness1"],
	:secretPower => "CRUNCH",
	:naturePower => :DARKPULSE,
	:mimicry => :DARK,
	:damageMods => {
		1.1 => [:DARKPULSE, :NIGHTDAZE,:NIGHTSLASH, :FALSESURRENDER, :SHADOWBALL, :SHADOWBONE, 
		:SHADOWBONE, :SHADOWCLAW, :SHADOWFORCE, :SHADOWSNEAK, :SHADOWPUNCH, :PHANTOMFORCE, 
		:SPIRITSHACKLE, :OMINOUSWIND, :SUCKERPUNCH, :THROATCHOP, :BLACKHOLEECLIPSE, :NEVERENDINGNIGHTMARE, :MOONGEISTBEAM, :ASTRALBARRAGE,
		:SPECTRALTHIEF, :SOULSTEALING7STARSTRIKE],
		0.9 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, 
		:DOOMDUMMY, :POWERGEM, :TECHNOBLAST, :PHOTONGEYSER, :STRANGESTEAM]
	},
	:accuracyMods => {},
	:moveMessages => {
		"The scattered shadows amassed around the attack!"=>[:DARKPULSE, :NIGHTDAZE,:NIGHTSLASH, :FALSESURRENDER, :SHADOWBALL, :SHADOWBONE, 
		:SHADOWBONE, :SHADODWCLAW, :SHADOWFORCE, :SHADOWSNEAK, :SHADOWPUNCH, :PHANTOMFORCE, 
		:SPIRITSHACKLE, :OMINOUSWIND, :SUCKERPUNCH, :THROATCHOP, :BLACKHOLEECLIPSE, :NEVERENDINGNIGHTMARE, :MOONGEISTBEAM, :ASTRALBARRAGE,
		:SPECTRALTHIEF, :SOULSTEALING7STARSTRIKE],
		"A glimmer of light infiltrates the dark..."=> [:MORNINGSUN, :SYNTHESIS, :AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, 
		:DOOMDUMMY, :POWERGEM, :TECHNOBLAST, :PHOTONGEYSER, :STRANGESTEAM],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:DARKNESS2 => [:DARKPULSE, :NIGHTDAZE, :MOONGEISTBEAM,:OMINOUSWIND,:ASTRALBARRAGE],
		:DARKNESS3 => [:DARKVOID]
	},
	:dontChangeBackup => [],
	:changeMessage => {
		 "The shadows grow..." => [:DARKPULSE, :NIGHTDAZE, :MOONGEISTBEAM,:OMINOUSWIND,:ASTRALBARRAGE],
		 "Straight to the abyss!" => [:DARKVOID]
	},
	:statusMods => [:FLASH,:DARKVOID, :MOONLIGHT, :SYNTHESIS, :MORNINGSUN],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => "setField(:DARKNESS2)",
		:duration => nil,
		:message => "The shadows grow...",
		:animation => :DARKVOID,
		:stats => {},
	},
},
:DARKNESS2 => {
	:name => "Darkness Field",
	:fieldMessage => [
		"The thick fog of darkness feels constricting..."
	],
	:graphic => ["Darkness2"],
	:secretPower => "CRUNCH",
	:naturePower => :DARKPULSE,
	:mimicry => :DARK,
	:damageMods => {
		1.3 => [:DARKPULSE, :NIGHTDAZE,:NIGHTSLASH, :FALSESURRENDER, :SHADOWBALL, :SHADOWBONE, 
		:SHADOWBONE, :SHADOWCLAW, :SHADOWFORCE, :SHADOWSNEAK, :SHADOWPUNCH, :PHANTOMFORCE, 
		:SPIRITSHACKLE, :OMINOUSWIND, :SUCKERPUNCH, :THROATCHOP, :BLACKHOLEECLIPSE, :NEVERENDINGNIGHTMARE, :MOONGEISTBEAM, :ASTRALBARRAGE,
		:SPECTRALTHIEF, :SOULSTEALING7STARSTRIKE],
		0.5 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, 
		:DOOMDUMMY, :POWERGEM, :TECHNOBLAST, :PHOTONGEYSER, :STRANGESTEAM],
		0 => [:SOLARBEAM, :SOLARBLADE],
	},
	:accuracyMods => {
		70 => [:DARKVOID] 
	},
	:moveMessages => {
		"The shadows joined in on the attack!"=>[:DARKPULSE, :NIGHTDAZE,:NIGHTSLASH, :FALSESURRENDER, :SHADOWBALL, :SHADOWBONE, 
		:SHADOWBONE, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWPUNCH, 
		:SPIRITSHACKLE, :OMINOUSWIND, :SUCKERPUNCH, :THROATCHOP, :BLACKHOLEECLIPSE, :NEVERENDINGNIGHTMARE, :MOONGEISTBEAM, :ASTRALBARRAGE,
		:SPECTRALTHIEF, :SOULSTEALING7STARSTRIKE],
		"Some dim light breaks through..."=> [:MORNINGSUN, :SYNTHESIS, :AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, 
		:DOOMDUMMY, :POWERGEM, :TECHNOBLAST, :PHOTONGEYSER, :STRANGESTEAM],
		"The darkness accelerated the attack!"=>[:SHADOWFORCE, :PHANTOMFORCE],
		"But there isn't enough light to attack!"=>[:SOLARBEAM, :SOLARBLADE],
	},
	:typeMods => {},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {},
	:typeMessages => {},
	:typeCondition => {},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
		:DARKNESS3 => [:DARKPULSE, :NIGHTDAZE, :MOONGEISTBEAM,:OMINOUSWIND,:ASTRALBARRAGE,:DARKVOID],
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The darkness is obliterated by the light!" =>[:LIGHTTHATBURNSTHESKY],
		"The shadows retreat!" => [:WISH, :SUNNYDAY, :LUSTERPURGE, :FLASH, :FLASHCANNON, :DAZZLINGGLEAM, :LIGHTOFRUIN,:PHOTONGEYSER],
		"The shadows grow!" => [:DARKPULSE, :NIGHTDAZE, :MOONGEISTBEAM,:OMINOUSWIND,:ASTRALBARRAGE],
	},
	:statusMods => [:DARKVOID, :MOONLIGHT, :SYNTHESIS, :MORNINGSUN],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => "setField(:DARKNESS3)",
		:duration => nil,
		:message => "The shadows engulf the surroundings!",
		:animation => :DARKVOID,
		:stats => {},
	},
},
:DARKNESS3 => {
	:name => "Darkness Field",
	:fieldMessage => [
		"In an endless sea of darkness, any glimmer of hope fades away..."
	],
	:graphic => ["Darkness3"],
	:secretPower => "CRUNCH",
	:naturePower => :DARKPULSE,
	:mimicry => :DARK,
	:damageMods => {
		2.0 => [:POISONJAB],
		1.5 => [:DARKPULSE, :NIGHTDAZE,:NIGHTSLASH, :FALSESURRENDER, :SHADOWBALL, :SHADOWBONE,
		:SHADOWBONE, :SHADOWCLAW, :SHADOWFORCE, :SHADOWSNEAK, :SHADOWPUNCH, :PHANTOMFORCE, 
		:SPIRITSHACKLE, :OMINOUSWIND, :SUCKERPUNCH, :THROATCHOP, :BLACKHOLEECLIPSE, :NEVERENDINGNIGHTMARE, :MOONGEISTBEAM, :ASTRALBARRAGE,
		:SPECTRALTHIEF, :SOULSTEALING7STARSTRIKE],
		1.2 => [:SPIRITBREAK],
		0.3 => [:AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, 
		:DOOMDUMMY, :POWERGEM, :TECHNOBLAST, :PHOTONGEYSER, :STRANGESTEAM],
		0 => [:SOLARBEAM, :SOLARBLADE],
	},
	:accuracyMods => {
		100 => [:DARKVOID] ,
	},
	:moveMessages => {
		"The void attacked!"=>[:DARKPULSE, :NIGHTDAZE,:NIGHTSLASH, :FALSESURRENDER, :SHADOWBALL, :SHADOWBONE, 
		:SHADOWBONE, :SHADOWCLAW, :SHADOWSNEAK, :SHADOWPUNCH, 
		:SPIRITSHACKLE, :OMINOUSWIND, :SUCKERPUNCH, :THROATCHOP, :BLACKHOLEECLIPSE, :NEVERENDINGNIGHTMARE, :MOONGEISTBEAM, :ASTRALBARRAGE,
		:SPECTRALTHIEF, :SOULSTEALING7STARSTRIKE],
		"A single ray of light makes its way..."=> [:MORNINGSUN, :SYNTHESIS, :AURORABEAM, :SIGNALBEAM, :FLASHCANNON, :LUSTERPURGE, :DAZZLINGGLEAM, :MIRRORSHOT, 
		:DOOMDUMMY, :POWERGEM, :TECHNOBLAST, :PHOTONGEYSER, :STRANGESTEAM],
		"The darkness accelerated the attack!"=>[:SHADOWFORCE, :PHANTOMFORCE,:SPIRITBREAK],
		"But there isn't enough light to attack!"=>[:SOLARBEAM, :SOLARBLADE],
		"A betrayal so toxic it hurts!"=>[:POISONJAB],
	},
	:typeMods => {

	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
	  0.5 => [:FAIRY],
      1.5 => [:DARK],
	},
	:typeMessages => {
	  "Pitch black!" => [:DARK],
      "Not enough light to shine through!" => [:FAIRY],
	},
	:typeCondition => {
		:FAIRY => "self.move!=:SPIRITBREAK",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {
		"The shadows grow!" => [:DARKPULSE, :NIGHTDAZE, :MOONGEISTBEAM,:OMINOUSWIND,:ASTRALBARRAGE],
	},
	:statusMods => [:AURORAVEIL, :MOONLIGHT, :SYNTHESIS, :MORNINGSUN],
	:changeEffects => {},
	:seed => {
		:seedtype => :MAGICALSEED,
		:effect => :LaserFocus,
		:duration => 1,
		:message => "{1} is focused!",
		:animation => :LASERFOCUS,
		:stats => {
			PBStats::SPATK => 1,
		},
	},
},
:DOJO => {
    :name => "Dojo",
    :fieldMessage => [
      "Up close and personal!"
    ],
    :graphic => ["dojo"],
    :secretPower => :BRICKBREAK,
    :naturePower => :CLOSECOMBAT,
    :mimicry => :FIGHTING,
    :damageMods => {
      0.5 => [:BRAVEBIRD, :SKYATTACK,:HURRICANE],
	  1.2 => [:WICKEDBLOW,:SURGINGSTRIKES,:COMETPUNCH,:TRIPLEAXEL,:KNOCKOFF,:MEGAPUNCH,:METEORMASH,:PLASMAFISTS,:FOCUSBLAST,:DOUBLEEDGE],
      1.5 => [:BRICKBREAK,:POWERUPPUNCH,:HEATPRESS,:ACROBATICS,:MACHPUNCH,:BULLETPUNCH,:ICEPUNCH,:FIREPUNCH,:THUNDERPUNCH,:SHADOWPUNCH,:THROATCHOP,:AURASPHERE,:ENERGYBALL,:GALESTRIKE,:HEAVYSLAM, :HEATCRASH,:CRUSHGRIP],
	  2.0 => [:PURSUIT],
    },
    :accuracyMods => {},
    :moveMessages => {
      "The roof is shut closed. ." => [:BRAVEBIRD, :SKYATTACK],
	  "Full-throttle!" => [:HEAVYSLAM, :HEATCRASH,:CRUSHGRIP,:HEATPRESS,:DOUBLEEDGE],
	  "There is no escape for you!" => [:PURSUIT],
	  "Swift movement!" => [:ACROBATICS],
	  "The indoor environment choked the tornado!" => [:HURRICANE],
	  "Devastating strike!" => [:WICKEDBLOW,:SURGINGSTRIKES,:COMETPUNCH,:KNOCKOFF,:MEGAPUNCH,:METEORMASH,:PLASMAFISTS,:GALESTRIKE],
      "The Ki is in perfect sync!" => [:BRICKBREAK,:MACHPUNCH,:BULLETPUNCH,:ICEPUNCH,:FIREPUNCH,:THUNDERPUNCH,:SHADOWPUNCH,:THROATCHOP],
	  "The Chakra is in perfect sync!" => [:POWERUPPUNCH,:TRIPLEAXEL,:FOCUSBLAST,:ENERGYBALL,:AURASPHERE],
    },
    :typeMods => {},
    :typeAddOns => {},
    :moveEffects => {

    },
    :typeBoosts => {	
      0.5 => [:FLYING],
      1.5 => [:FIGHTING],
    },
    :typeMessages => {
      "There is no room to fly!" => [:FLYING],
      "Channeling inner strength. ." => [:FIGHTING],
    },
    :typeCondition => {
		:FLYING => "self.move!=:ACROBATICS",
    },
    :typeEffects => {},
    :changeCondition => {
    },
    :fieldChange => {
    },
    :changeMessage => {
    },
    :statusMods => [:WORKUP],
    :changeEffects => {},
    :seed => {
      :seedtype => :SYNTHETICSEED,
		:effect => 0,
		:duration => 0,
		:message => "{1} is concentrating!",
		:animation => :FOCUSENERGY,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPEED => 1,
      },
    },
  },
:DANCEFLOOR => {
	:name => "Dance Floor Field",
	:fieldMessage => [
		"It's time to bust a move!"
	],
	:graphic => ["Nightclub"],
	:secretPower => "PSYCHIC",
	:naturePower => :REVELATIONDANCE,
	:mimicry => :PSYCHIC,
	:damageMods => {
		2.0 =>[:ACROBATICS],
		1.5 =>[:MYSTICALFIRE, :DAZZLINGGLEAM, :FLASHCANNON, :SIGNALBEAM, :AURASPHERE,:STRANGESTEAM, :BOOMBURST,:WARCRY, 
		:BUGBUZZ, :CHATTER, :CLANGINGSCALES, :DISARMINGVOICE, :ECHOEDVOICE, :EERIESPELL, :HYPERVOICE, 
		:OVERDRIVE, :UPROAR, :SNARL, :ROUND, :SPARKLINGARIA, :RELICSONG, :REVELATIONDANCE, :PETALDANCE,:FEVERPITCH, :FIERYDANCE,:HYDRODASH,:ELEGANTFLOW,:GRACEFULSTEP,:PRIMADONNA,:DIAMONDSTORM]
	},
	:accuracyMods => {
	},
	:moveMessages => {
		"What elegance!"=>[:REVELATIONDANCE, :PETALDANCE, :FIERYDANCE,:HYDRODASH,:ELEGANTFLOW,:FEVERPITCH,:GRACEFULSTEP,:PRIMADONNA,:DIAMONDSTORM],
		"Smoothe moves!"=>[:ACROBATICS],
		"In sync with the music!"=>[:MYSTICALFIRE, :DAZZLINGGLEAM, :FLASHCANNON, :SIGNALBEAM, :AURASPHERE,:STRANGESTEAM,:WARCRY, :BOOMBURST, :BUGBUZZ, :CHATTER, :CLANGINGSCALES, :DISARMINGVOICE, :ECHOEDVOICE, :EERIESPELL, :HYPERVOICE, 
		:OVERDRIVE, :UPROAR, :SNARL, :ROUND, :SPARKLINGARIA, :RELICSONG, :KINESIS],
	},
	:typeMods => {
	},
	:typeAddOns => {},
	:moveEffects => {},
	:typeBoosts => {
		1.5 => [:PSYCHIC],	
		0.5 => [:DARK],
	},
	:typeMessages => {
		"Drop the beat!" => [:PSYCHIC],
		"The reflective shining light weakens the attack!" => [:DARK],
	},
	:typeCondition => {
      :DARK => "self.move!=:SNARL",
	},
	:typeEffects => {},
	:changeCondition => {},
	:fieldChange => {
	},
	:dontChangeBackup => [],
	:changeMessage => {

	},
	:statusMods => [:KINESIS, :LIGHTSCREEN, :REFLECT, :SWORDSDANCE, :FEATHERDANCE, :LUNARDANCE, :QUIVERDANCE, :DRAGONDANCE, :TEETERDANCE],
	:changeEffects => {},
	:seed => {
		:seedtype => :SYNTHETICSEED,
		:effect => "battler.ability=(:DANCER)",
		:duration => nil,
		:message => "{1} started grooving on the dance floor!",
		:animation => nil,
		:stats => {
		},
	},
},
:SNOWYWOODS => {
    :name => "Snowy Woods",
    :fieldMessage => [
      "A chill runs between the trees!"
    ],
    :graphic => ["SnowyWoods","Evergreen"],
    :secretPower => :ICYWIND,
    :naturePower => :NORTHERNIMPACT,
    :mimicry => :ICE,
    :damageMods => {
	  1.5 => [:SEEDBOMB,:AURORABEAM,:DISARMINGVOICE,:AVALANCHE,:MAGICALLEAF,:WATERFALL,:WATERPULSE,:ABSOLUTEZERO,:FREEZINGGLARE],
	  0.5 => [:SCALD,:STEAMERUPTION],
	  1.2 => [:ICEHAMMER,:WOODHAMMER,:OMINOUSWIND],
	  2.0 => [:ICYWIND],
	  0  => [:RAINDANCE, :SANDSTORM,:SUNNYDAY,:DEWDASH],
    },
    :accuracyMods => {},
    :moveMessages => {
      "The chilly air cooled down the water.." => [:SCALD,:STEAMERUPTION],
	  "Snow from the trees enhanced the attack!" => [:AVALANCHE],
	  "The frigid chill strengthened the attack!" => [:SEEDBOMB,:ABSOLUTEZERO,:OMINOUSWIND,:FREEZINGGLARE],
	  "WHAMOO!" => [:ICEHAMMER,:WOODHAMMER],
	  "The frosty air strengthened the attack!" => [:AURORABEAM,:ICYWIND,:WATERFALL,:WATERPULSE],
	  "The leaves infused with frostbites!" => [:MAGICALLEAF],
	  "The frigid forest consumed the weather!" => [:RAINDANCE,:DEWDASH,:SUNNYDAY,:SANDSTORM],
    },
    :typeMods => {},
    :typeAddOns => {},
    :moveEffects => {

    },
    :typeBoosts => {	
      0.3 => [:FLYING,:FIRE],
      1.3 => [:GRASS,:ICE],
    },
    :typeMessages => {
      "The dense forest choked out the air!" => [:FLYING],
	  "The icy cold forest weakened the fire!" => [:FIRE],
      "The bittercold forest powered up the attack!" => [:ICE],
      "The frost sharpened up the leaves!" => [:GRASS],
    },
    :typeCondition => {
      :FIRE => "self.move!=:ICEBURN",
    },
    :typeEffects => {},
    :changeCondition => {
    },
    :fieldChange => {
    },
    :changeMessage => {
    },
    :statusMods => [:AURORAVEIL],
    :changeEffects => {},
    :seed => {
      :seedtype => :ELEMENTALSEED,
		:effect => :Ingrain,
		:duration => true,
		:message => "{1} planted its roots!",
		:animation => :INGRAIN,
		:stats => {
			PBStats::ATTACK => 1,
			PBStats::SPATK => 1,
			PBStats::SPEED => -2,
      },
    },
  },
}

