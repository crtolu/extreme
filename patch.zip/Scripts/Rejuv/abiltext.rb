ABILHASH = {
:STENCH => {
	:ID => 1,
	:name => "Stench",
	:desc => "The stench may cause the target to flinch."
},

:DRIZZLE => {
	:ID => 2,
	:name => "Drizzle",
	:desc => "The Pokémon makes it rain when it enters a battle."
},
:ICEBENDER => {
	:ID => 338,
	:name => "Ice Bender",
	:desc => "Boosts Atk and prevents burns.",
	:fullDesc => "Boosts the Attack stat on entry and prevents burn, keeps the power of Ice moves in Dragons Den and Desert field."
},
:SPEEDBOOST => {
	:ID => 3,
	:name => "Speed Boost",
	:desc => "Its Speed stat is gradually boosted."
},
:LOYALTY => {
	:ID => 3,
	:name => "Loyalty",
	:desc => "Return always deals 150 BP damage. Removes the negative side effects from high power moves. Grants immunity to Intimidate."
},
:SHARPSHOOTING => {
	:ID => 3,
	:name => "Sharp Shooter",
	:desc => "Damaging Physical & Special moves drop the respective defensive stats of targets. Only works with single hit moves that dont drop stats."
},
:FORCEFIELD => {
	:ID => 3,
	:name => "Force Field",
	:desc => "Creates a field that reduces incoming damage to the party by 35% and buffs damage dealt by the team by 30%."
},
:PSYSHIFT => {
	:ID => 3,
	:name => "Psy Shift",
	:desc => "Every move below 100 Base Power is boosted by 30%, Normal type moves becomes Psychic type."
},
:POWERSPIKE => {
	:ID => 3,
	:name => "Power Spike",
	:desc => "The damage of \"not very effective\" moves is doubled. Speed increases by one stage on entry."
},
:BRUTEFORCE => {
	:ID => 3,
	:name => "Brute Force",
	:desc => "yes you are fked."
},
:IRONHEART => {
	:ID => 3,
	:name => "Iron Heart",
	:desc => "Bypasses damage reducing screens on the enemy side. Breaks foes mold."
},
:LIGHTNINGSTRIKE => {
	:ID => 3,
	:name => "Thunder Strike",
	:desc => "Gains stab on Electric and Flying type moves. Reduces damage of super effective moves by 15%."
},
:POWERBREAK => {
	:ID => 3,
	:name => "Power Break",
	:desc => "Electric type moves can hit Ground types. User is immune to Intimidate."
},
:ROIDRAGE => {
	:ID => 3,
	:name => "Roid Rage",
	:desc => "The higher the users HP the more damage it deals up to twice as much. Knocking out enemies heals 12.5% health."
},
:MYSTICCLOAK => {
	:ID => 3,
	:name => "Mystic Cloak",
	:desc => "The duration of Light Screen and Reflect is 8 turns when casted."
},
:SUPREMEOVERLORD => {
	:ID => 335,
	:name => "S. Overlord",
	:fullName => "Supreme Overlord",
	:desc => "Gains power with every fainted ally.",
	:fullDesc => "Upon entering battle, its Attack and Sp. Atk stats are slightly boosted for each of the allies in its party that have already been defeated."
},
:BATTLEARMOR => {
	:ID => 4,
	:name => "Battle Armor",
	:desc => "The Pokémon is protected against critical hits."
},

:STURDY => {
	:ID => 5,
	:name => "Sturdy",
	:desc => "It cannot be knocked out with one hit."
},

:DAMP => {
	:ID => 6,
	:name => "Damp",
	:desc => "Prevents the use of self-destructing moves."
},

:LIMBER => {
	:ID => 7,
	:name => "Limber",
	:desc => "The Pokémon is protected from paralysis."
},

:SANDVEIL => {
	:ID => 8,
	:name => "Sand Veil",
	:desc => "Boosts the Pokémon's Defenses in a sandstorm or similar field."
},

:STATIC => {
	:ID => 9,
	:name => "Static",
	:desc => "Contact with the Pokémon may cause paralysis."
},

:VOLTABSORB => {
	:ID => 10,
	:name => "Volt Absorb",
	:desc => "Restores HP if hit by an Electric-type move."
},

:WATERABSORB => {
	:ID => 11,
	:name => "Water Absorb",
	:desc => "Restores HP if hit by a Water-type move."
},

:OBLIVIOUS => {
	:ID => 12,
	:name => "Oblivious",
	:desc => "Prevents it from becoming infatuated."
},

:CLOUDNINE => {
	:ID => 13,
	:name => "Cloud Nine",
	:desc => "Eliminates the effects of weather."
},

:COMPOUNDEYES => {
	:ID => 14,
	:name => "Compound Eyes",
	:desc => "The Pokémon's accuracy is boosted...",
	:fullDesc => "The Pokémon's accuracy is boosted by 30%."
},

:INSOMNIA => {
	:ID => 15,
	:name => "Insomnia",
	:desc => "Prevents the Pokémon from falling asleep."
},

:COLORCHANGE => {
	:ID => 16,
	:name => "Color Change",
	:desc => "Changes the Pokémon's type to the foe's move."
},

:IMMUNITY => {
	:ID => 17,
	:name => "Immunity",
	:desc => "Prevents the Pokémon from getting poisoned."
},

:FLASHFIRE => {
	:ID => 18,
	:name => "Flash Fire",
	:desc => "Powers up Fire-type moves if it's hit by one...",
	:fullDesc => "When hit by a Fire-type move, this Pokémon's attacking stats are boosted by 50% when using Fire-type moves."
},

:SHIELDDUST => {
	:ID => 19,
	:name => "Shield Dust",
	:desc => "Blocks the added effects of attacks taken."
},

:OWNTEMPO => {
	:ID => 20,
	:name => "Own Tempo",
	:desc => "Prevents the Pokémon from becoming confused."
},

:SUCTIONCUPS => {
	:ID => 21,
	:name => "Suction Cups",
	:desc => "Negates all moves that force switching out."
},

:INTIMIDATE => {
	:ID => 22,
	:name => "Intimidate",
	:desc => "Lowers the foe's Attack stat. Refuses to leave the field afterwards."
},

:SHADOWTAG => {
	:ID => 23,
	:name => "Shadow Tag",
	:desc => "Prevents the foe from escaping."
},

:ROUGHSKIN => {
	:ID => 24,
	:name => "Rough Skin",
	:desc => "Inflicts damage to the foe on contact."
},

:WONDERGUARD => {
	:ID => 25,
	:name => "Wonder Guard",
	:desc => "Only super-effective moves will hit."
},

:LEVITATE => {
	:ID => 26,
	:name => "Levitate",
	:desc => "Gives full immunity to all Ground-type moves."
},

:EFFECTSPORE => {
	:ID => 27,
	:name => "Effect Spore",
	:desc => "Contact may poison or cause paralysis or sleep."
},

:SYNCHRONIZE => {
	:ID => 28,
	:name => "Synchronize",
	:desc => "Passes a burn, poison, or paralysis to the foe."
},

:CLEARBODY => {
	:ID => 29,
	:name => "Clear Body",
	:desc => "Prevents other Pokémon from lowering its stats."
},

:NATURALCURE => {
	:ID => 30,
	:name => "Natural Cure",
	:desc => "All status problems heal when it switches out."
},

:LIGHTNINGROD => {
	:ID => 31,
	:name => "Lightningrod",
	:desc => "Draws in all Electric-type moves to raise Sp. Attack."
},

:SERENEGRACE => {
	:ID => 32,
	:name => "Serene Grace",
	:desc => "Boosts the likelihood of added effects appearing."
},

:SWIFTSWIM => {
	:ID => 33,
	:name => "Swift Swim",
	:desc => "Boosts the users speed by 1.5x during rain."
},

:CHLOROPHYLL => {
	:ID => 34,
	:name => "Chlorophyll",
	:desc => "Boosts the users speed by 1.5x during sun."
},

:ILLUMINATE => {
	:ID => 35,
	:name => "Illuminate",
	:desc => "Raises the likelihood of meeting wild Pokémon."
},

:TRACE => {
	:ID => 36,
	:name => "Trace",
	:desc => "The Pokémon copies a foe's Ability."
},

:HUGEPOWER => {
	:ID => 37,
	:name => "Huge Power",
	:desc => "Doubles the Pokémon's Attack stat."
},

:POISONPOINT => {
	:ID => 38,
	:name => "Poison Point",
	:desc => "Contact with the Pokémon may poison the attacker."
},

:INNERFOCUS => {
	:ID => 39,
	:name => "Inner Focus",
	:desc => "The Pokémon is protected from flinching."
},

:MAGMAARMOR => {
	:ID => 40,
	:name => "Magma Armor",
	:desc => "Prevents the Pokémon from becoming frozen."
},

:WATERVEIL => {
	:ID => 41,
	:name => "Water Veil",
	:desc => "Prevents the Pokémon from getting a burn."
},

:MAGNETPULL => {
	:ID => 42,
	:name => "Magnet Pull",
	:desc => "Prevents Steel-type Pokémon from escaping."
},

:SOUNDPROOF => {
	:ID => 43,
	:name => "Soundproof",
	:desc => "Gives full immunity to all sound-based moves."
},

:RAINDISH => {
	:ID => 44,
	:name => "Rain Dish",
	:desc => "The Pokémon gradually regains HP in rain."
},

:SANDSTREAM => {
	:ID => 45,
	:name => "Sand Stream",
	:desc => "The Pokémon summons a sandstorm in battle."
},

:PRESSURE => {
	:ID => 46,
	:name => "Pressure",
	:desc => "The Pokémon raises the foe's PP usage."
},

:THICKFAT => {
	:ID => 47,
	:name => "Thick Fat",
	:desc => "Ups resistance to Fire- and Ice-type moves...",
	:fullDesc => "Increases reistance to Fire- and Ice-type moves by 50%."
},

:EARLYBIRD => {
	:ID => 48,
	:name => "Early Bird",
	:desc => "The Pokémon awakens quickly from sleep."
},

:FLAMEBODY => {
	:ID => 49,
	:name => "Flame Body",
	:desc => "Contact with the Pokémon may burn the attacker."
},

:RUNAWAY => {
	:ID => 50,
	:name => "Run Away",
	:desc => "Enables a sure getaway from wild Pokémon."
},

:KEENEYE => {
	:ID => 51,
	:name => "Keen Eye",
	:desc => "Prevents other Pokémon from lowering accuracy."
},

:HYPERCUTTER => {
	:ID => 52,
	:name => "Hyper Cutter",
	:desc => "Prevents other Pokémon from lowering Attack stat."
},

:PICKUP => {
	:ID => 53,
	:name => "Pickup",
	:desc => "The Pokémon may pick up items."
},

:TRUANT => {
	:ID => 54,
	:name => "Truant",
	:desc => "Pokémon can't attack on consecutive turns."
},

:HUSTLE => {
	:ID => 55,
	:name => "Hustle",
	:desc => "Boosts the Attack stat, but lowers accuracy...",
	:fullDesc => "Boosts the Attack stat by 50%, but lowers accuracy by 20%."
},

:CUTECHARM => {
	:ID => 56,
	:name => "Cute Charm",
	:desc => "Contact with the Pokémon may cause infatuation."
},

:SUPREMEREIGN => {
	:ID => 56,
	:name => "Supreme Reign",
	:desc => "Blocks priority, disables redirection, boosts every outgoing damage by 20% and reduces incoming damage by 25%."
},

:MEGAMORPH => {
	:ID => 56,
	:name => "Megamorph",
	:desc => "Increases every contact moves damage, Meteor Assault has no downtime, additionally decreases incoming damage by 15%."
},

:ULTIMUSEXCLEUM => {
	:ID => 56,
	:name => "Ultimus Excleum",
	:desc => "Uses up every energy supplied by the body to deal more damage with every recoil and draining move."
},

:PLUS => {
	:ID => 57,
	:name => "Plus",
	:desc => "Ups Sp. Atk if another Pokémon has Plus or Minus...",
	:fullDesc => "Ups Sp. Attack if another Pokémon has Plus or Minus by 50%. Magnetic Flux raises Defense and Sp. Defense, Gear Up raises Attack and Sp. Attack."
},

:MINUS => {
	:ID => 58,
	:name => "Minus",
	:desc => "Ups Sp. Atk if another Pokémon has Plus or Minus...",
	:fullDesc => "Ups Sp. Attack if another Pokémon has Plus or Minus by 50%. Magnetic Flux raises Defense and Sp. Defense, Gear Up raises Attack and Sp. Attack."
},

:FORECAST => {
	:ID => 59,
	:name => "Forecast",
	:desc => "Castform transforms with the weather."
},

:STICKYHOLD => {
	:ID => 60,
	:name => "Sticky Hold",
	:desc => "Protects the Pokémon from item theft."
},

:SHEDSKIN => {
	:ID => 61,
	:name => "Shed Skin",
	:desc => "The Pokémon may heal its own status problems."
},

:GUTS => {
	:ID => 62,
	:name => "Guts",
	:desc => "Badly poisons the user on entry...",
	:fullDesc => "Badly poisons the user on entry and boosts the physical attack by 50% while being poisoned."
},

:MARVELSCALE => {
	:ID => 63,
	:name => "Marvel Scale",
	:desc => "Badly poisons the user on entry and raises Defense by 50% while being poisoned.",
},

:LIQUIDOOZE => {
	:ID => 64,
	:name => "Liquid Ooze",
	:desc => "Damages attackers using any draining move...",
	:fullDesc => "Damages attackers using any draining move by that amount instead of healing."
},

:OVERGROW => {
	:ID => 65,
	:name => "Overgrow",
	:desc => "Powers up Grass-type moves in a pinch...",
	:fullDesc => "Increases Attack/Special Attack by 50% when below 1/3 max HP when using Grass-type moves."
},

:BLAZE => {
	:ID => 66,
	:name => "Blaze",
	:desc => "Powers up Fire-type moves in a pinch...",
	:fullDesc => "Increases Attack/Special Attack by 50% when below 1/3 max HP when using Fire-type moves."
},

:TORRENT => {
	:ID => 67,
	:name => "Torrent",
	:desc => "Powers up Water-type moves in a pinch...",
	:fullDesc => "Increases Attack/Special Attack by 50% when below 1/3 max HP when using Water-type moves."
},

:SWARM => {
	:ID => 68,
	:name => "Swarm",
	:desc => "Powers up Bug-type moves in a pinch...",
	:fullDesc => "Increases Attack/Special Attack by 50% when below 1/3 max HP when using Bug-type moves."
},

:ROCKHEAD => {
	:ID => 69,
	:name => "Rock Head",
	:desc => "Protects the Pokémon from recoil damage."
},

:DROUGHT => {
	:ID => 70,
	:name => "Drought",
	:desc => "The Pokémon summons harsh sunlight in battle. Fire blast => 100% accuracy during sun."
},

:HELIOS => {
	:ID => 70,
	:name => "Helios",
	:desc => "The Pokémon summons harsh sunlight in battle. When hit by a Fire or Water type moves boosts Speed sharply."
},

:MASTERMIND => {
	:ID => 70,
	:name => "Master Mind",
	:desc => "On Psychic fields/overlay boosts speed by 20%. Additionally Psychic type moves used by itself and partners are boosted by 50%."
},

:ARENATRAP => {
	:ID => 71,
	:name => "Arena Trap",
	:desc => "Prevents the foe from fleeing."
},

:VITALSPIRIT => {
	:ID => 72,
	:name => "Vital Spirit",
	:desc => "Prevents the Pokémon from falling asleep."
},

:WHITESMOKE => {
	:ID => 73,
	:name => "White Smoke",
	:desc => "Prevents other Pokémon from lowering its stats."
},

:PUREPOWER => {
	:ID => 74,
	:name => "Pure Power",
	:desc => "Doubles the Pokémon's Attack stat."
},

:SHELLARMOR => {
	:ID => 75,
	:name => "Shell Armor",
	:desc => "The Pokémon is protected against critical hits."
},

:AIRLOCK => {
	:ID => 76,
	:name => "Air Lock",
	:desc => "Eliminates the effects of weather."
},

:TANGLEDFEET => {
	:ID => 77,
	:name => "Tangled Feet",
	:desc => "Raises evasion if the Pokémon is confused."
},

:MOTORDRIVE => {
	:ID => 78,
	:name => "Motor Drive",
	:desc => "Raises Speed if hit by an Electric-type move."
},

:RIVALRY => {
	:ID => 79,
	:name => "Rivalry",
	:desc => "Deals more damage to a foe of the same gender...",
	:fullDesc => "Deal 25% more damage to the same gender and deal 25% less damage to the opposite gender."
},

:STEADFAST => {
	:ID => 80,
	:name => "Steadfast",
	:desc => "Raises Speed each time the Pokémon flinches."
},

:SNOWCLOAK => {
	:ID => 81,
	:name => "Snow Cloak",
	:desc => "Raises defenses in a hailstorm or similar fields."
},

:GLUTTONY => {
	:ID => 82,
	:name => "Gluttony",
	:desc => "Encourages the early use of a held Berry."
},

:ANGERPOINT => {
	:ID => 83,
	:name => "Anger Point",
	:desc => "Maxes Attack after taking a critical hit."
},

:UNBURDEN => {
	:ID => 84,
	:name => "Unburden",
	:desc => "Doubles Speed if a held item is used."
},

:HEATPROOF => {
	:ID => 85,
	:name => "Heatproof",
	:desc => "Weakens the power of Fire-type moves...",
	:fullDesc => "Halves the damage done by Fire-type moves and Burn."
},

:SIMPLE => {
	:ID => 86,
	:name => "Simple",
	:desc => "The Pokémon is prone to wild stat changes."
},

:DRYSKIN => {
	:ID => 87,
	:name => "Dry Skin",
	:desc => "Reduces HP if it is hot. Water restores HP...",
	:fullDesc => "Fire-type moves deal 25% more damage. Water-type moves heal 1/4 max HP. Rain heals by 1/8 max HP. Sun damages for 1/8 max HP."
},

:DOWNLOAD => {
	:ID => 88,
	:name => "Download",
	:desc => "Adjusts power according to a foe's defenses...",
	:fullDesc => "Increase Attack or Special Attack by one stage based on the foe's lower defense stat."
},

:CHROMATIC => {
	:ID => 88,
	:name => "Chromatic",
	:desc => "Creates a layer of protection.",
	:fullDesc => ""
},

:IRONFIST => {
	:ID => 89,
	:name => "Iron Fist",
	:desc => "Boosts the power of punching moves...",
	:fullDesc => "Boosts the power of punching moves by 20%."
},

:POISONHEAL => {
	:ID => 90,
	:name => "Poison Heal",
	:desc => "On entry, badly poisons the user to generate consecutive healing."
},

:ADAPTABILITY => {
	:ID => 91,
	:name => "Adaptability",
	:desc => "Powers up moves of the same type...",
	:fullDesc => "Powers up STAB to an additional 100% rather than 50%."
},

:SKILLLINK => {
	:ID => 92,
	:name => "Skill Link",
	:desc => "Increases the frequency of multi-strike moves."
},

:HYDRATION => {
	:ID => 93,
	:name => "Hydration",
	:desc => "Heals status problems in the rain."
},

:SOLARPOWER => {
	:ID => 94,
	:name => "Solar Power",
	:desc => "Sunshine boosts Sp. Atk but HP decreases, boosts Attack when...",
	:fullDesc => "In sunshine, Special Attack is boosted by 50%, HP decreases by 1/8th per turn. Also raises Attack on Volcanic overlay."
},

:QUICKFEET => {
	:ID => 95,
	:name => "Quick Feet",
	:desc => "Badly poisons the user on entry to increase its speed by 50%.",
},

:NORMALIZE => {
	:ID => 96,
	:name => "Normalize",
	:desc => "All the user's moves become the Normal type and boosted by 20%."
},

:SNIPER => {
	:ID => 97,
	:name => "Sniper",
	:desc => "Powers up critical hits...",
	:fullDesc => "Powers up critical hits by 50%."
},

:CRUSADER => {
	:ID => 97,
	:name => "Crusader",
	:desc => "Boosts critical hit chance by 2 stages and powers up critical hits by 30%.",
},

:MAGICGUARD => {
	:ID => 98,
	:name => "Magic Guard",
	:desc => "The Pokémon only takes damage from attacks."
},

:NOGUARD => {
	:ID => 99,
	:name => "No Guard",
	:desc => "Ensures attacks by or against the user land."
},

:STALL => {
	:ID => 100,
	:name => "Stall",
	:desc => "The Pokémon moves after all other Pokémon do."
},

:TECHNICIAN => {
	:ID => 101,
	:name => "Technician",
	:desc => "Moves with 80 Base Power or less deal 50% more damage.",
},

:SUPERCHARGE => {
	:ID => 101,
	:name => "Super-Charge",
	:desc => "Moves with 100 Base Power or less deal 50% more damage.",
},

:LEAFGUARD => {
	:ID => 102,
	:name => "Leaf Guard",
	:desc => "Prevents status problems in sunny weather."
},

:KLUTZ => {
	:ID => 103,
	:name => "Klutz",
	:desc => "The Pokémon can't use any held items."
},

:MOLDBREAKER => {
	:ID => 104,
	:name => "Mold Breaker",
	:desc => "Moves can be used regardless of Abilities."
},

:SUPERLUCK => {
	:ID => 105,
	:name => "Super Luck",
	:desc => "Heightens the critical-hit ratios of moves...",
	:fullDesc => "Increases the critical-hit ratios of moves by 2 stages."
},

:ADRENALINE => {
	:ID => 105,
	:name => "Adrenaline",
	:desc => "Heightens the critical-hit ratios of moves...",
	:fullDesc => "Increases the critical-hit ratios of moves by 2 stages."
},

:FORTUNE => {
	:ID => 105,
	:name => "Fortune",
	:desc => "Heightens the critical-hit ratios of moves and...",
	:fullDesc => "Increases the critical-hit ratios of moves by 2 stages. Critical hits also deal 40% increased damage."
},

:AFTERMATH => {
	:ID => 106,
	:name => "Aftermath",
	:desc => "Damages the foe landing the finishing hit...",
	:fullDesc => "When reduced to 0 HP by a contact move, the attacker suffers 1/4th of its max HP. Damp prevents this effect."
},

:ANTICIPATION => {
	:ID => 107,
	:name => "Anticipation",
	:desc => "Senses a foe's dangerous moves."
},

:FOREWARN => {
	:ID => 108,
	:name => "Forewarn",
	:desc => "Determines what moves a foe has."
},

:UNAWARE => {
	:ID => 109,
	:name => "Unaware",
	:desc => "Ignores any stat changes in the Pokémon."
},

:TINTEDLENS => {
	:ID => 110,
	:name => "Tinted Lens",
	:desc => "Powers up \"not very effective\" moves...",
	:fullDesc => "The damage of \"not very effective\" moves is doubled."
},

:FILTER => {
	:ID => 111,
	:name => "Filter",
	:desc => "Reduces damage from supereffective attacks...",
	:fullDesc => "Reduces damage from supereffective attacks by 25%."
},

:SLOWSTART => {
	:ID => 112,
	:name => "Slow Start",
	:desc => "Temporarily halves Attack and Speed."
},

:SCRAPPY => {
	:ID => 113,
	:name => "Scrappy",
	:desc => "Enables moves to hit Ghost-type Pokémon."
},

:STORMDRAIN => {
	:ID => 114,
	:name => "Storm Drain",
	:desc => "Draws in Water-type moves to up Sp. Attack."
},

:ICEBODY => {
	:ID => 115,
	:name => "Ice Body",
	:desc => "The Pokémon gradually regains HP in hail."
},

:SOLIDROCK => {
	:ID => 116,
	:name => "Solid Rock",
	:desc => "Reduces damage from supereffective attacks...",
	:fullDesc => "Reduces damage from supereffective attacks by 25%."
},

:SNOWWARNING => {
	:ID => 117,
	:name => "Snow Warning",
	:desc => "5 turn hail that damages all none-Ice type Pokémon. Increases power of Ice type attacks by 50%, decreases power of Fire type moves by 30%."
},

:HONEYGATHER => {
	:ID => 118,
	:name => "Honey Gather",
	:desc => "The Pokémon may gather Honey from somewhere."
},

:FRISK => {
	:ID => 119,
	:name => "Frisk",
	:desc => "The Pokémon can check a foe's held item."
},

:RECKLESS => {
	:ID => 120,
	:name => "Reckless",
	:desc => "Powers up moves that have recoil damage...",
	:fullDesc => "Powers up moves that have recoil damage by 20%."
},

:MULTITYPE => {
	:ID => 121,
	:name => "Multitype",
	:desc => "Changes type to match the held Plate."
},

:FLOWERGIFT => {
	:ID => 122,
	:name => "Flower Gift",
	:desc => "Powers up party Pokémon when it is sunny...",
	:fullDesc => "Increases Attack and Special Defense by 50% for itself and ally Pokémon."
},
:BADDREAMS => {
	:ID => 123,
	:name => "Bad Dreams",
	:desc => "Reduces a sleeping foe's HP...",
	:fullDesc => "Reduces a sleeping foe's HP by 1/8th of its max HP."
},

:PICKPOCKET => {
	:ID => 124,
	:name => "Pickpocket",
	:desc => "Steals an item when hit by another Pokémon."
},

:SHEERFORCE => {
	:ID => 125,
	:name => "Sheer Force",
	:desc => "Removes added effects to increase move damage...",
	:fullDesc => "Removes added effects to increase move damage by 30%."
},

:CONTRARY => {
	:ID => 126,
	:name => "Contrary",
	:desc => "Makes stat changes have an opposite effect."
},

:UNNERVE => {
	:ID => 127,
	:name => "Unnerve",
	:desc => "Makes the foe unable to eat Berries."
},

:DEFIANT => {
	:ID => 128,
	:name => "Defiant",
	:desc => "When a stat is lowered its Attack increases."
},

:DEFEATIST => {
	:ID => 129,
	:name => "Defeatist",
	:desc => "Lowers stats when HP becomes half or less...",
	:fullDesc => "Halves attacking stats when HP becomes half or less."
},

:CURSEDBODY => {
	:ID => 130,
	:name => "Cursed Body",
	:desc => "May disable a move used on the Pokémon."
},

:HEALER => {
	:ID => 131,
	:name => "Healer",
	:desc => "May heal an ally's status conditions."
},

:FRIENDGUARD => {
	:ID => 132,
	:name => "Friend Guard",
	:desc => "Reduces damage done to allies...",
	:fullDesc => "Reduces damage done to allies by 20%, stacking multiplicatively."
},

:DIVINITY => {
	:ID => 132,
	:name => "Divinity",
	:desc => "Reduces party damage taken by 25%. Reduces field based taken damage to itself by 15%."
},

:CACTACEAE => {
	:ID => 132,
	:name => "Cactaceae",
	:desc => "Raises Special Attack by 1, deals 1/8th damage to attacker on contact, multi-hit moves hit 5 times."
},

:COLDQUEEN => {
	:ID => 132,
	:name => "Cold Queen",
	:desc => "Reduces damage done to itself and Ice type allies by 20%, this can stack multiplicatively.",
},

:OVERLOAD => {
	:ID => 132,
	:name => "Overload",
	:desc => "Reduces damage done to itself and Electric type allies by 20%, this can stack multiplicatively.",
},

:WEAKARMOR => {
	:ID => 133,
	:name => "Weak Armor",
	:desc => "Physical attacks lower Def. and sharply raise Spd."
},

:HEAVYMETAL => {
	:ID => 134,
	:name => "Heavy Metal",
	:desc => "Doubles the Pokémon's weight."
},

:LIGHTMETAL => {
	:ID => 135,
	:name => "Light Metal",
	:desc => "Halves the Pokémon's weight."
},

:MULTISCALE => {
	:ID => 136,
	:name => "Multiscale",
	:desc => "Halves damage when HP is full."
},

:TOXICBOOST => {
	:ID => 137,
	:name => "Toxic Boost",
	:desc => "Powers up physical attacks when poisoned...",
	:fullDesc => "Powers up physical attacks when poisoned by 50%."
},

:FLAREBOOST => {
	:ID => 138,
	:name => "Flare Boost",
	:desc => "Burns the user on entry...",
	:fullDesc => "Burns the user on entry and boosts the power of special attacks by 50% while the user is burned."
},

:HARVEST => {
	:ID => 139,
	:name => "Harvest",
	:desc => "May create another Berry after one is used."
},

:TELEPATHY => {
	:ID => 140,
	:name => "Telepathy",
	:desc => "Anticipates an ally's attack and dodges it."
},

:MOODY => {
	:ID => 141,
	:name => "Moody",
	:desc => "Raises one stat and lowers another."
},

:OVERCOAT => {
	:ID => 142,
	:name => "Overcoat",
	:desc => "Protects the Pokémon from damage from weather."
},

:POISONTOUCH => {
	:ID => 143,
	:name => "Poison Touch",
	:desc => "May poison targets upon contact."
},

:REGENERATOR => {
	:ID => 144,
	:name => "Regenerator",
	:desc => "Restores HP when withdrawn from battle...",
	:fullDesc => "Restores HP when withdrawn from battle by 33% max HP."
},

:BIGPECKS => {
	:ID => 145,
	:name => "Big Pecks",
	:desc => "Protects the Pokémon from Defense-lowering."
},

:SANDRUSH => {
	:ID => 146,
	:name => "Sand Rush",
	:desc => "Boosts the users speed by 1.5x during sandstorm."
},

:NEPHTIS => {
	:ID => 146,
	:name => "Nephtis",
	:desc => "Boosts the users speed and damage by 1.5x during sandstorm or dry fields/overlays such as desert/beach."
},

:AFFINITY => {
	:ID => 146,
	:name => "Affinity",
	:desc => "Boosts the users speed by 1.5x and damage by 1.3x during rain or on water based environments."
},

:WONDERSKIN => {
	:ID => 147,
	:name => "Wonder Skin",
	:desc => "Makes foes' status moves more likely to miss...",
	:fullDesc => "Makes foes' status 50% more likely to miss unless already below 50% accuracy."
},

:ANALYTIC => {
	:ID => 148,
	:name => "Analytic",
	:desc => "Boosts move power when the Pokémon moves last...",
	:fullDesc => "Boosts move power when the Pokémon moves last by 30%."
},

:ILLUSION => {
	:ID => 149,
	:name => "Illusion",
	:desc => "Comes out disguised as the Pokémon in back."
},

:IMPOSTER => {
	:ID => 150,
	:name => "Imposter",
	:desc => "Transforms itself into the foe it is facing."
},

:INFILTRATOR => {
	:ID => 151,
	:name => "Infiltrator",
	:desc => "Passes through the foe's barrier and strikes."
},

:MUMMY => {
	:ID => 152,
	:name => "Mummy",
	:desc => "Contact with this Pokémon spreads this Ability."
},

:MOXIE => {
	:ID => 153,
	:name => "Moxie",
	:desc => "Boosts Attack after knocking out any Pokémon."
},

:JUSTIFIED => {
	:ID => 154,
	:name => "Justified",
	:desc => "Raises Attack when hit by a Dark-type move."
},

:RATTLED => {
	:ID => 155,
	:name => "Rattled",
	:desc => "Some move types scare it and boost its Speed...",
	:fullDesc => "Bug-, Dark-, and Ghost-type moves that deal damage boost its Speed. Also activates against Intimidate."
},

:MAGICBOUNCE => {
	:ID => 156,
	:name => "Magic Bounce",
	:desc => "Reflects status-changing moves."
},

:SAPSIPPER => {
	:ID => 157,
	:name => "Sap Sipper",
	:desc => "Boosts Attack when hit by a Grass-type move."
},

:PRANKSTER => {
	:ID => 158,
	:name => "Prankster",
	:desc => "Gives priority to a status move."
},

:SANDFORCE => {
	:ID => 159,
	:name => "Sand Force",
	:desc => "Boosts damage in a sandstorm...",
	:fullDesc => "Boosts power by 40% in a sandstorm or desert like environment (+overlay), and takes no damage from sandstorm."
},

:IRONBARBS => {
	:ID => 160,
	:name => "Iron Barbs",
	:desc => "Inflicts damage to the Pokémon on contact...",
	:fullDesc => "Inflicts damage to the Pokémon on contact equal to 1/8th of its max HP."
},

:ZENMODE => {
	:ID => 161,
	:name => "Zen Mode",
	:desc => "Changes the Pokémon's shape when HP is halved."
},

:VICTORYSTAR => {
	:ID => 162,
	:name => "Victory Star",
	:desc => "Boosts the accuracy of its allies and itself...",
	:fullDesc => "Boosts the accuracy of its allies and itself by 10%. This ability may stack multiplicatively."
},

:TURBOBLAZE => {
	:ID => 163,
	:name => "Turboblaze",
	:desc => "Moves can be used regardless of Abilities."
},

:TERAVOLT => {
	:ID => 164,
	:name => "Teravolt",
	:desc => "Moves can be used regardless of Abilities."
},

:AERILATE => {
	:ID => 165,
	:name => "Aerilate",
	:desc => "Normal-type moves become Flying-type moves...",
	:fullDesc => "Normal-type moves become Flying-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},

:AROMAVEIL => {
	:ID => 166,
	:name => "Aroma Veil",
	:desc => "Protects allies from moves that effect their mind."
},

:AURABREAK => {
	:ID => 167,
	:name => "Aura Break",
	:desc => "The effects of Aura Abilities are reversed."
},

:BULLETPROOF => {
	:ID => 168,
	:name => "Bulletproof",
	:desc => "Protects the Pokémon from ball and bomb moves."
},

:CHEEKPOUCH => {
	:ID => 169,
	:name => "Cheek Pouch",
	:desc => "Restores HP when the Pokémon eats a Berry...",
	:fullDesc => "Restores 33% of the Pokémon's max HP when it eats a Berry."
},

:COMPETITIVE => {
	:ID => 170,
	:name => "Competitive",
	:desc => "Boosts the Sp. Atk stat when a stat is lowered."
},

:DARKAURA => {
	:ID => 171,
	:name => "Dark Aura",
	:desc => "Powers up each Pokémon's Dark-type moves...",
	:fullDesc => "Powers up each Pokémon's Dark-type moves by 33%."
},

:FAIRYAURA => {
	:ID => 172,
	:name => "Fairy Aura",
	:desc => "Powers up each Pokémon's Fairy-type moves...",
	:fullDesc => "Powers up each Pokémon's Fairy-type moves by 33%."
},

:FLOWERVEIL => {
	:ID => 173,
	:name => "Flower Veil",
	:desc => "Prevents lowering of ally Grass-type stats."
},

:FURCOAT => {
	:ID => 174,
	:name => "Fur Coat",
	:desc => "Halves damage from physical moves."
},

:GALEWINGS => {
	:ID => 175,
	:name => "Gale Wings",
	:desc => "Gives priority to Flying-type moves when HP is full."
},

:GOOEY => {
	:ID => 176,
	:name => "Gooey",
	:desc => "Contact lowers the foe's Speed stat. User cant switch out."
},

:GRASSPELT => {
	:ID => 177,
	:name => "Grass Pelt",
	:desc => "Boosts Defense when the terrain is grass."
},

:MAGICIAN => {
	:ID => 178,
	:name => "Magician",
	:desc => "The Pokémon steals the foe's held item on contact."
},

:MEGALAUNCHER => {
	:ID => 179,
	:name => "Mega Launcher",
	:desc => "Powers up aura and pulse moves...",
	:fullDesc => "Powers up aura and pulse moves by 50%. Heal Pulse heals by 75%."
},

:PARENTALBOND => {
	:ID => 180,
	:name => "Parental Bond",
	:desc => "Parent and child attack together...",
	:fullDesc => "Each attack deals an additional 25% damage and rolls effects separately, except for Secret Power."
},

:PIXILATE => {
	:ID => 181,
	:name => "Pixilate",
	:desc => "Normal-type moves become Fairy-type moves...",
	:fullDesc => "Normal-type moves become Fairy-type moves and deal 20% more damage. This overrides Ion Deluge."
},

:PROTEAN => {
	:ID => 182,
	:name => "Protean",
	:desc => "Changes the Pokémon's type to its move used."
},
:BRILLIANT => {
	:ID => 182,
	:name => "Brilliant",
	:desc => "Like a gem the Pokémon's type adjust to the move it uses."
},

:REFRIGERATE => {
	:ID => 183,
	:name => "Refrigerate",
	:desc => "Normal-type moves become Ice-type moves...",
	:fullDesc => "Normal-type moves become Ice-type moves and deal 20% more damage. This overrides Electrify and Ion Deluge."
},

:STANCECHANGE => {
	:ID => 184,
	:name => "Stance Change",
	:desc => "The Pokémon changes form depending on moves."

},

:TRIFORCE => {
	:ID => 184,
	:name => "Tri Force",
	:desc => "After attacking: two follow up attacks are launched matching the users secondary type and using the higher offensive stat."
},

:TOUGHASNAILS => {
	:ID => 184,
	:name => "Tough as Nails",
	:desc => "Maximizes the defense of its body to reduce the power of incoming Rock and Fighting type damage by 50%."
},

:MERCHANDISE => {
	:ID => 184,
	:name => "Merchandise",
	:desc => "Allows infinite use of Gems while it holds onto them. Razor Wind becomes Electric type and doesnt charge."
},

:DRYBLOW => {
	:ID => 184,
	:name => "Dry Blow",
	:desc => "Absorbs Water type damage and turns it into HP. Recoil damage is negated."
},

:HOTHEAD => {
	:ID => 184,
	:name => "Hot Head",
	:desc => "After attacking: launches another attack that will alternate between being grass or fire type per turn dealing 75BP damage."
},

:GRAVITATION => {
	:ID => 184,
	:name => "Gravitation",
	:desc => "Raises Special Attack on entry. Meteor Beam has no charge up. Normal type moves become Steel type."
},

:STRONGJAW => {
	:ID => 185,
	:name => "Strong Jaw",
	:desc => "The power of biting moves is increased...",
	:fullDesc => "The power of biting moves is increased by 50%."
},

:BERSERKJAW => {
	:ID => 185,
	:name => "Berserk Jaw",
	:desc => "The power of biting moves is greatly increased...",
	:fullDesc => "The power of biting moves is increased by 70%."
},

:SWEETVEIL => {
	:ID => 186,
	:name => "Sweet Veil",
	:desc => "Prevents ally Pokémon from falling asleep."
},

:SYMBIOSIS => {
	:ID => 187,
	:name => "Symbiosis",
	:desc => "The Pokémon can pass an item to an ally."
},

:TOUGHCLAWS => {
	:ID => 188,
	:name => "Tough Claws",
	:desc => "Powers up moves that make direct contact."
},

:PRIMORDIALSEA => {
	:ID => 189,
	:name => "Primordial Sea",
	:desc => "Summons heavy rain when on the field...",
	:fullDesc => "Summons heavy rain and nullifies any Fire-type attacks while on the field."
},

:DESOLATELAND => {
	:ID => 190,
	:name => "Desolate Land",
	:desc => "Summons extreme sunlight when on the field...",
	:fullDesc => "Summons extremely harsh sunlight and nullifies any Water-type attacks while on the field."
},

:DELTASTREAM => {
	:ID => 191,
	:name => "Delta Stream",
	:desc => "Summons strong winds when on the field...",
	:fullDesc => "Summons strong winds and removes Flying-type weaknesses while on the field."
},

:BATTERY => {
	:ID => 192,
	:name => "Battery",
	:desc => "Powers up ally Pokémon's special moves...",
	:fullDesc => "Increases the power of ally Pokémon's special moves by 30%."
},

:BEASTBOOST => {
	:ID => 193,
	:name => "Beast Boost",
	:desc => "Boosts highest stat after KO'ing a Pokémon."
},

:BERSERK => {
	:ID => 194,
	:name => "Berserk",
	:desc => "Boosts Sp. Atk when a hit drops HP below half."
},

:COMATOSE => {
	:ID => 195,
	:name => "Comatose",
	:desc => "It's always asleep, and attacks without waking up."
},

:CORROSION => {
	:ID => 196,
	:name => "Corrosion",
	:desc => "Can poison targets regardless of their type."
},

:DANCER => {
	:ID => 197,
	:name => "Dancer",
	:desc => "Dances with others, duplicating their moves."
},

:DAZZLING => {
	:ID => 198,
	:name => "Dazzling",
	:desc => "Surprises the opponent, preventing priority moves."
},

:ELECTRICSURGE => {
	:ID => 199,
	:name => "Electric Surge",
	:desc => "Electrifies the terrain on entry. (Lays over the field if a field is already present)."
},

:EMERGENCYEXIT => {
	:ID => 200,
	:name => "EmergencyExit",
	:desc => "It retreats when its HP becomes half or less."
},

:FLUFFY => {
	:ID => 201,
	:name => "Fluffy",
	:desc => "Weakens contact moves, but doubles Fire damage."
},

:FULLMETALBODY => {
	:ID => 202,
	:name => "Full Metal Body",
	:desc => "Prevents other Pokémon from lowering its stats."
},

:GALVANIZE => {
	:ID => 203,
	:name => "Galvanize",
	:desc => "Normal-type moves become Electric-type moves...",
	:fullDesc => "Normal-type moves become Electric-type moves and deal 20% more damage."
},

:GRASSYSURGE => {
	:ID => 204,
	:name => "Grassy Surge",
	:desc => "Makes the terrain grassy on entry. (Lays over the field if a field is already present)."
},

:CALLOFNATURE => {
	:ID => 204,
	:name => "Call of Nature",
	:desc => "Makes the terrain grassy on entry. Additionally summons heavy rain on entry."
},

:TEMPO => {
	:ID => 204,
	:name => "Tempo",
	:desc => "Boosts speed by 50% if any weather is present."
},

:TACTICIAN => {
	:ID => 390,
	:name => "Tactician",
	:desc => "Increases and decreases damage..",
	:fullDesc => "Hitting enemies debuffs them. Partner will deal 1.5x more damage, user will deal 30% more damage. Debuff changes when target changes."
},
:INNARDSOUT => {
	:ID => 205,
	:name => "Innards Out",
	:desc => "Damages the attacker the same amount when fainted."
},

:LIQUIDVOICE => {
	:ID => 206,
	:name => "Liquid Voice",
	:desc => "All sound-based moves become Water-type moves."
},

:LONGREACH => {
	:ID => 207,
	:name => "Long Reach",
	:desc => "This Pokémon's moves do not make contact."
},

:MERCILESS => {
	:ID => 208,
	:name => "Merciless",
	:desc => "Critically hits poisoned Pokémon without fail."
},

:MISTYSURGE => {
	:ID => 209,
	:name => "Misty Surge",
	:desc => "Makes the terrain misty on entry. (Lays over the field if a field is already present)."
},

:POWEROFALCHEMY => {
	:ID => 210,
	:name => "Alchemy",
	:desc => "The Pokémon copies the Ability of a defeated ally."
},

:PRISMARMOR => {
	:ID => 211,
	:name => "Prism Armor",
	:desc => "Reduces damage from supereffective attacks...",
	:fullDesc => "Reduces damage dealt by super effective moves by 25%. Cannot be ignored by moves or abilities."
},

:PSYCHICSURGE => {
	:ID => 212,
	:name => "Psychic Surge",
	:desc => "Summons a field with psychical powers on entry. (Lays over the field if a field is already present)."
},

:QUEENLYMAJESTY => {
	:ID => 213,
	:name => "Q. Majesty",
	:fullName => "Queenly Majesty",
	:desc => "Pressures the opponent, preventing priority moves."
},

:RECEIVER => {
	:ID => 214,
	:name => "Receiver",
	:desc => "The Pokémon receives the Ability of a defeated ally."
},

:SHADOWSHIELD => {
	:ID => 215,
	:name => "Shadow Shield",
	:desc => "Halves damage when HP is full...",
	:fullDesc => "Halves damage when HP is full. Cannot be ignored by moves or abilities."
},

:SLUSHRUSH => {
	:ID => 216,
	:name => "Slush Rush",
	:desc => "Boosts the users speed by 1.5x during hail."
},

:SOULHEART => {
	:ID => 217,
	:name => "Soul-heart",
	:desc => "Boosts its Sp. Atk every time a Pokémon faints."
},

:STAKEOUT => {
	:ID => 218,
	:name => "Stakeout",
	:desc => "Doubles damage to newly switched-in targets."
},

:STAMINA => {
	:ID => 219,
	:name => "Stamina",
	:desc => "Boosts the Defense stat when hit by an attack."
},

:STEELWORKER => {
	:ID => 220,
	:name => "Steelworker",
	:desc => "Powers up Steel-type moves...",
	:fullDesc => "Increases its respective stat by 50% when a Steel-type move is used."
},

:SURGESURFER => {
	:ID => 221,
	:name => "Surge Surfer",
	:desc => "Boosts the Speed stat on Electric Terrain and Water environments by 50%."
},
:POISONRUSH => {
	:ID => 221,
	:name => "Poison Rush",
	:desc => "Boosts the Speed stat on poison based environments by 50%, except Murkwater."
},
:SCENTEDGLIDE => {
	:ID => 221,
	:name => "Scented Glide",
	:desc => "Boosts the Speed stat on Starlight and Misty Terrain/Overlay by 50%."
},

:DARKGLIDE => {
	:ID => 221,
	:name => "Dark Glide",
	:desc => "Boosts the Speed stat on Darkness 3, Dark Crystal Cavern and New World Terrain/Overlay by 50%."
},

:VINEBURST => {
	:ID => 221,
	:name => "Vine Burst",
	:desc => "Every move additionally unleashes a vine that slashes the target for Grass Type-based damage."
},

:DARKSHELL => {
	:ID => 221,
	:name => "Dark Shell",
	:desc => "Moves that dont use offensive stats for damage calculation are boosted by 50%."
},

:ANHILATION => {
	:ID => 221,
	:name => "Anhilation",
	:desc => "Blocks critical hits and increases damage by 20% if the enemy is faster."
},

:INFERNALREIGN => {
	:ID => 221,
	:name => "Infernal Reign",
	:desc => "Every outgoing damage is boosted by 60% on Infernal and Dimensional Field. Increases both defenses by 20%."
},
#Extreme The seal that shut down Aevian Parasects prison has been removed.
:SOULHARVEST => {
	:ID => 221,
	:name => "Soul Harvest",
	:desc => "After successfully knocking out an enemy with a contact move, it will harvest the victims soul to transform into a more powerful form."
},
:WINDBENDER => {
	:ID => 221,
	:name => "Wind Bender",
	:desc => "Wind moves deal 20% less damage to this Pokémon, after knocking out an enemy with a contact move the user will mega evolve."
},
:PRECISION => {
	:ID => 221,
	:name => "Precision",
	:desc => "If the first move selected is a Bug type move, it will gain +1 increased priority, user cant switch out."
},
:REVENGESHOT => {
	:ID => 222,
	:name => "Revenge Shot",
	:desc => "The lower the users HP the more damage it deals up to twice as much."
},
:ROCKETLAUNCH => {
	:ID => 222,
	:name => "Rocket Launch",
	:desc => "Upon knocking out an opposing Pokémon the users speed increases by 2 stages."
},
:INSTINCT => {
	:ID => 222,
	:name => "Instinct",
	:desc => "When knocking out an opposing Pokémon with a contact move the user falls into rage."
},
:ETERNALFIRE => {
	:ID => 222,
	:name => "Eternal Fire",
	:desc => "The users Speed increases by 30% and Special Attack by 50% while sun is up, it will also take 1/4th HP damage every turn."
},
:HORIZON => {
	:ID => 222,
	:name => "Horizon",
	:desc => "Takes 30% less damage at full HP, Wind moves ignore enemy screens, fails if the screen is put up when this Pokémon is already on the field."
},
:TANGLINGHAIR => {
	:ID => 222,
	:name => "Tangling Hair",
	:desc => "Contact lowers the foe's Speed stat."
},

:TRIAGE => {
	:ID => 223,
	:name => "Triage",
	:desc => "Gives priority to a healing move."
},

:WATERBUBBLE => {
	:ID => 224,
	:name => "Water Bubble",
	:desc => "Stops burns, halves Fire damage and boosts Water...",
	:fullDesc => "This Pokémon is immune to burns, takes 50% less damage from Fire-type moves, and deals 50% more damage with Water-type moves."
},

:WATERCOMPACTION => {
	:ID => 225,
	:name => "W. Compaction",
	:fullName => "Water Compaction",
	:desc => "Water-type moves deal half damage and raise Defense afterwards."
},

:WIMPOUT => {
	:ID => 226,
	:name => "Wimp Out",
	:desc => "It wimps out when its HP becomes half or less."
},

:SCHOOLING => {
	:ID => 227,
	:name => "Schooling",
	:desc => "As long as it has high HP, it can form a school."
},

:PRISMBOND => {
	:ID => 227,
	:name => "Prism Bond",
	:desc => "Placeholder for Rens mega gren."
},

:RKSSYSTEM => {
	:ID => 228,
	:name => "RKS System",
	:desc => "Changes type to match the held memory disc."
},

:SHIELDSDOWN => {
	:ID => 229,
	:name => "Shields Down",
	:desc => "This Pokémon is protected by its shell above half HP."
},

:DISGUISE => {
	:ID => 230,
	:name => "Disguise",
	:desc => "This Pokémon's shroud can protect it from one hit."
},

:POWERCONSTRUCT => {
	:ID => 231,
	:name => "P. Construct",
	:fullName => "Power Construct",
	:desc => "Enters Complete Form when HP is half or less."
},

:BALLFETCH => {
	:ID => 232,
	:name => "Ball Fetch",
	:desc => "Fetches the first failed Pokéball if no held item."
},

:COTTONDOWN => {
	:ID => 233,
	:name => "Cotton Down",
	:desc => "Lowers Speed of adjacent Pokémon when hit. User cant switch out."
},

:DAUNTLESSSHIELD => {
	:ID => 234,
	:name => "Dauntless Shield",
	:desc => "Boosts the Pokémon's Defense stat upon entry."
},

:GORILLATACTICS => {
	:ID => 235,
	:name => "Gorilla Tactics",
	:desc => "Boosts attack and may only use one move.",
	:fullDesc => "Boosts the Pokémon's Attack stat by 50% and may only use the first selected move."
},

:GULPMISSILE => {
	:ID => 236,
	:name => "Gulp Missile",
	:desc => "Catches Pokémon with Surf and Dive, spits out when hit."
},

:HUNGERSWITCH => {
	:ID => 237,
	:name => "Hunger Switch",
	:desc => "Switches forms after every turn...",
	:fullDesc => "Changes between Full Belly Mode and Hangry Mode at the end of each turn. Additionally, Aura Wheel becomes Electric and Dark respectively."
},

:ICEFACE => {
	:ID => 238,
	:name => "Ice Face",
	:desc => "Can take a physical attack once...",
	:fullDesc => "Can take a physical attack once. This effect is restored once when it hails."
},

:ICESCALES => {
	:ID => 239,
	:name => "Ice Scales",
	:desc => "Halves the damage taken from special moves."
},

:INTREPIDSWORD => {
	:ID => 240,
	:name => "Intrepid Sword",
	:desc => "Boosts the Pokémon's Attack stat upon entry."
},

:LIBERO => {
	:ID => 241,
	:name => "Libero",
	:desc => "Changes the Pokémon's type to its used move."
},

:MIMICRY => {
	:ID => 242,
	:name => "Mimicry",
	:desc => "The Pokémon changes type to match the terrain."
},

:MIRRORARMOR => {
	:ID => 243,
	:name => "Mirror Armor",
	:desc => "Reflects stat-changing moves."
},

:NEUTRALIZINGGAS => {
	:ID => 244,
	:name => "Neutralizing Gas",
	:desc => "Effects of abilities are nullified or prevented."
},

:PASTELVEIL => {
	:ID => 245,
	:name => "Pastel Veil",
	:desc => "Protects the user and allies from being poisoned."
},

:PERISHBODY => {
	:ID => 246,
	:name => "Perish Body",
	:desc => "When hit by a contact move...",
	:fullDesc => "When hit by a contact move, both this Pokémon and the attacker are placed on a 3 turn Perish count."
},

:POWERSPOT => {
	:ID => 247,
	:name => "Power Spot",
	:desc => "Just being next to the Pokémon powers up moves...",
	:fullDesc => "Ally Pokémon's attacks are boosted by 30%."
},

:PROPELLERTAIL => {
	:ID => 248,
	:name => "Propeller Tail",
	:desc => "Ignores redirection...",
	:fullDesc => "This Pokémon ignores the effects of abilities and moves that would cause its moves to be redirected."
},

:PUNKROCK => {
	:ID => 249,
	:name => "Punk Rock",
	:desc => "Boosts user sound based moves. Reduces incoming sound damage. .",
	:fullDesc => "Sound-based moves deal 30% more damage and deal 50% less damage to this Pokémon."
},

:RIPEN => {
	:ID => 250,
	:name => "Ripen",
	:desc => "Ripens Berries and doubles their effect."
},

:SANDSPIT => {
	:ID => 251,
	:name => "Sand Spit",
	:desc => "Creates a sandstorm when it's hit by an attack."
},

:SCREENCLEANER => {
	:ID => 252,
	:name => "Screen Cleaner",
	:desc => "It has a wide knowledge of environments and can gain boosts depending on them.",
},

:STALWART => {
	:ID => 253,
	:name => "Stalwart",
	:desc => "Ignores redirection...",
	:fullDesc => "This Pokémon ignores the effects of abilities and moves that would cause its moves to be redirected."
},

:STEAMENGINE => {
	:ID => 254,
	:name => "Steam Engine",
	:desc => "Fire- and Water-type moves boost Speed sharply."
},

:STEELYSPIRIT => {
	:ID => 255,
	:name => "Steely Spirit",
	:desc => "Powers up ally Pokémon's Steel-type moves...",
	:fullDesc => "Steel-type moves are boosted by 50% when used by itself or allies, multiplicative."
},

:POISONPOLLUTION => {
	:ID => 255,
	:name => "Poison Pollution",
	:desc => "Powers up ally Pokémon's Poison-type moves...",
	:fullDesc => "Poison-type moves are boosted by 50% when used by itself or allies, multiplicative."
},

:MOONLITMIGHT => {
	:ID => 984,
	:name => "Moonlit Might",
	:desc => "Powers up ally Pokémon's Fairy-type moves...",
	:fullDesc => "Fairy-type moves are boosted by 50% when used by itself or allies, multiplicative."
},

:WANDERINGSPIRIT => {
	:ID => 256,
	:name => "W. Spirit",
	:fullName => "Wandering Spirit",
	:desc => "Swaps Abilities when hit by a contact move."
},

:NEUROFORCE => {
	:ID => 257,
	:name => "Neuroforce",
	:desc => "Powers up moves that are super effective.",
	:fullDesc => "Super effective moves deal an additional 25% damage."
},

:QUICKDRAW => {
	:ID => 258,
	:name => "Quick Draw",
	:desc => "Enables the Pokémon to move first occasionally...",
	:fullDesc => "This Pokémon has a 30% chance of moving first within its priority bracket."
},

:UNSEENFIST => {
	:ID => 259,
	:name => "Unseen Fist",
	:desc => "Physical contact bypasses Protect and similar."
},

:CURIOUSMEDICINE => {
	:ID => 260,
	:name => "Curious Med.",
	:fullName => "Curious Medicine",
	:desc => "Removes ally stat changes on entry."
},

:TRANSISTOR => {
	:ID => 261,
	:name => "Transistor",
	:desc => "Powers up Electric-type moves...",
	:fullDesc => "Increases its respective stat by 50% when a Electric-type move is used."
},

:DRAGONSMAW => {
	:ID => 262,
	:name => "Dragon's Maw",
	:desc => "Powers up Dragon-type moves...",
	:fullDesc => "Increases its respective stat by 50% when a Dragon-type move is used."
},

:CHILLINGNEIGH => {
	:ID => 263,
	:name => "Chilling Neigh",
	:desc => "Boosts Attack when knocking out an opponent."
},

:GRIMNEIGH => {
	:ID => 264,
	:name => "Grim Neigh",
	:desc => "Boosts Sp. Atk when knocking out an opponent."
},

:JUSTICE => {
	:ID => 264,
	:name => "Justice",
	:desc => "Boosts Attack when entering the field."
},

:ASONE => {
	:ID => 265,
	:name => "As One",
	:desc => "Combines abilities of fused Pokémon."
},

:SHARPNESS => {
	:ID => 266,
	:name => "Sharpness",
	:desc => "Powers up slicing moves...",
	:fullDesc => "Slicing moves deal 40% more damage."
},

:QUARKDRIVE => {
	:ID => 267,
	:name => "Quark Drive",
	:desc => "Boosts highest stat on Electric Terrain...",
	:fullDesc => "Raises the Pokémon's highest stat while on Electric Terrain by 30% (50% if highest stat is speed). Can also be activated with Booster Energy."
},
:REFLECTOR => {
	:ID => 300,
	:name => "Reflector",
	:desc => "Gains the opponent's secondary typing on entry."
},
:RAINBOWSURGE => {
	:ID => 700,
	:name => "Rainbow Surge",
	:desc => "Summons a rainbow over the terrain on entry. (Lays over the field if a field is already present)."
},
:DRAGONIC => {
	:ID => 701,
	:name => "Dragonic",
	:desc => "Normal-type moves become Dragon-type moves...",
	:fullDesc => "Normal-type moves become Dragon-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:FLAMBOYANT => {
	:ID => 702,
	:name => "Flamboyant",
	:desc => "Normal-type moves become Fire-type moves...",
	:fullDesc => "Normal-type moves become Fire-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:ENTOMORPH => {
	:ID => 703,
	:name => "Entomorph",
	:desc => "Normal-type moves become Bug-type moves...",
	:fullDesc => "Normal-type moves become Bug-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:FLORAFORGE => {
	:ID => 704,
	:name => "Flora Forge",
	:desc => "Normal-type moves become Grass-type moves...",
	:fullDesc => "Normal-type moves become Grass-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:SPIRITSHIFT => {
	:ID => 705,
	:name => "Spirit Shift",
	:desc => "Normal-type moves become Ghost-type moves...",
	:fullDesc => "Normal-type moves become Ghost-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:PSYCHEWEAVE => {
	:ID => 706,
	:name => "Psyche Weave",
	:desc => "Normal-type moves become Psychic-type moves...",
	:fullDesc => "Normal-type moves become Psychic-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:BRAWLER => {
	:ID => 707,
	:name => "Brawler",
	:desc => "Normal-type moves become Fighting-type moves...",
	:fullDesc => "Normal-type moves become Fighting-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:STEELSHROUD => {
	:ID => 708,
	:name => "Steel Shroud",
	:desc => "Normal-type moves become Steel-type moves...",
	:fullDesc => "Normal-type moves become Steel-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:GEOMORPHOSIS => {
	:ID => 709,
	:name => "Geomorphosis",
	:desc => "Normal-type moves become Ground-type moves...",
	:fullDesc => "Normal-type moves become Ground-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:TOXIFICATE => {
	:ID => 710,
	:name => "Toxificate",
	:desc => "Normal-type moves become Poison-type moves...",
	:fullDesc => "Normal-type moves become Poison-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:MINERALITE => {
	:ID => 711,
	:name => "Mineralite",
	:desc => "Normal-type moves become Rock-type moves...",
	:fullDesc => "Normal-type moves become Rock-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."

},
:AQUACRAFT => {
	:ID => 712,
	:name => "Aqua Craft",
	:desc => "Normal-type moves become Water-type moves...",
	:fullDesc => "Normal-type moves become Water-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:DUSKILATE => {
	:ID => 713,
	:name => "Duskilate",
	:desc => "Normal-type moves become Dark-type moves...",
	:fullDesc => "Normal-type moves become Dark-type moves and deal 30% more damage. This overrides Electrify and Ion Deluge."
},
:CELESTIALDOME => {
	:ID => 714,
	:name => "Celestial Dome",
	:desc => "Energizes the terrain with starlight on entry. (Lays over the field if a field is already present)."
},
:UNDYINGFLAME => {
	:ID => 715,
	:name => "Undying Flame",
	:desc => "Melts the terrain into a volcanic environment on entry. (Lays over the field if a field is already present)."
},
:SUCESSOR => {
	:ID => 716,
	:name => "Sucessor",
	:desc => "Lowers enemy Spatk by 1 stage on entry.",
},
:WINDDRIVEN => {
	:ID => 717,
	:name => "Wind Driven",
	:desc => "Powers up wind based moves by 30%.",
},
:SIPHONSOUL => {
	:ID => 718,
	:name => "Siphon Soul",
	:desc => "Powers up drain based moves by 40%.",
},
:FLAMELORD => {
	:ID => 719,
	:name => "Flame Lord",
	:desc => "Powers up spirit moves, removes Overheat's stat drop side effect.",
},
:JUNGLEWRATH => {
	:ID => 720,
	:name => "Jungle Wrath",
	:desc => "Two turn moves dont need to charge... ",
	:fullDesc => "Two turn moves dont need to charge. Normal type moves become Fighting type.",
},
:GAIAFORCE => {
	:ID => 721,
	:name => "Gaia Force",
	:desc => "Powers up moves that are drawn by Earth itself by 40%.",
},
:BRAVEHEART => {
	:ID => 722,
	:name => "Brave Heart",
	:desc => "Powers up moves that use the entire..",
	:fullDesc => "Powers up moves that use the entire body by 30%. Increases Weight, removes recoil from Wood Hammer."
},
:SAVAGE => {
	:ID => 723,
	:name => "Savage",
	:desc => "Ignores all negative side effects from damage inflicting moves.",
},
:HARMONIA => {
	:ID => 724,
	:name => "Harmonia",
	:desc => "Sound moves increase in power by 20%.Turns Normal moves into Water moves, breaks foes mold.",
},
:GRANDARCHER => {
	:ID => 725,
	:name => "Grand Archer",
	:desc => "Arrow based moves are powered up by 40% but lose their extra effects.",
},
:WINGCHUN => {
	:ID => 726,
	:name => "Wing Chun",
	:desc => "Kicking moves are 40% stronger and never miss.",
},
:FORESTDRUM => {
	:ID => 727,
	:name => "Forest Drum",
	:desc => "Sound moves are powered up...",
	:fullDesc =>"Sound moves are powered up by 30%. Normal type moves become Grass type."
},
:GODSPEED => {
	:ID => 728,
	:name => "God Speed",
	:desc => "Raises Speed by one stage upon entering the field.",
},
:CLEAVEFORCE => {
	:ID => 729,
	:name => "Cleave Force",
	:desc => "Choping moves are 30% stronger, breaks foes mold.",
},
:GLAMOURBREAK => {
	:ID => 730,
	:name => "Glamour Break",
	:desc => "Absorbs incoming Fairy moves and heals HP.",
},
:FROSTREALM => {
	:ID => 731,
	:name => "Frost Realm",
	:desc => "Makes the terrain icy on entry. (Lays over the field if a field is already present)."
},
:ACIDSURGE => {
	:ID => 732,
	:name => "Acid Surge",
	:desc => "Makes the terrain corrosive on entry. (Lays over the field if a field is already present)."
},
:VOIDSURGE => {
	:ID => 733,
	:name => "Void Surge",
	:desc => "Covers the terrain with dark crystals on entry. (Lays over the field if a field is already present)."
},
:RULEROFSKY => {
	:ID => 734,
	:name => "Ruler of Sky",
	:desc => "Raises Attack by one stage upon entering the field, unless the field is Deep Earth. Sky Attack = 1 turn.",
},


#:SHIFT => {
#	:ID => 301,
#	:name => "Shift",
#	:desc => "Adjusts the body to adapt to environments."
#},

:TRUESHOT => {
	:ID => 302,
	:name => "True Shot",
	:desc => "Increases the damage of Ball and Bomb moves...",
	:fullDesc => "Ball and Bomb moves +30%. Multi hit moves always hit five times. Gyro and Electro Ball always hit for 100 BP."
},

:ACCUMULATION => {
	:ID => 303,
	:name => "Accumulation",
	:desc => "This Pokémon stockpiles every turn."
},

:TEMPORALSHIFT => {
	:ID => 304,
	:name => "Temporal Shift",
	:desc => "Ignores stat drops and uses Hex...",
	:fullDesc => "This Pokémon's stats cannot be lowered. Additionally, Hex is automatically used every turn, dealing damage in 3 turns."
},

:EXECUTION => {
	:ID => 305,
	:name => "Execution",
	:desc => "This Pokémon hits harder the lower the target's health is."
},

:TOXICUTION => {
	:ID => 305,
	:name => "Toxicution",
	:desc => "This Pokémon heals 25% HP when knocking out enemies."
},

:RESUSCITATION => {
	:ID => 306,
	:name => "Resuscitation",
	:desc => "Enters Zombie Form after being knocked out once."
},

:TEMPEST => {
	:ID => 307,
	:name => "Storm 9",
	:desc => "Randomly changes weather at the end of the turn."
},

:SOLARIDOL => {
	:ID => 308,
	:name => "Solar Idol",
	:desc => "The fiery will of the sun empowers this Pokémon...",
	:fullDesc => "Fire-type moves deal 50% more damage, attack is boosted by 50% in the Sun, and is immune to Ground-type moves."#"STAB Fire moves. 50% ATK boost in Sun. Levitates."
},

:LUNARIDOL => {
	:ID => 309,
	:name => "Lunar Idol",
	:desc => "The icy will of the moon empowers this Pokémon...",
	:fullDesc => "Ice-type moves deal 50% more damage, special attack is boosted by 50% in Hail, and is immune to Ground-type moves."
},

:WORLDOFNIGHTMARES => {
	:ID => 310,
	:name => "W. Nightmares",
	:fullName => "World of Nightmares",
	:desc => "An all-encompassing nightmare...",
	:fullDesc => "Immune to sleep. Inflicts 1/32 max HP damage per turn to foes. Can freely use Nightmare/Dream Eater. Doubles the effect of Bunraku Beatdown."
	#:fullDesc => "End of turn damage on all foes. Changes field to New World over time. Allows use of Nightmare freely."
},

:GLOOMYIDOL => {
	:ID => 309,
	:name => "Gloomy Idol",
	:desc => "The Gloomy will of the moon empowers this Pokémon...",
	:fullDesc => "Dark-type moves deal 50% more damage, special attack is boosted by 50% on Bewitched and Dark Crystal Cavern Field/Overlay."
},

:INEXORABLE => {
	:ID => 311,
	:name => "Inexorable",
	:desc => "Dragon-type moves are stronger on slower foes...",
	:fullDesc => "Dragon-type moves deal 30% more damage against foes slower than this Pokémon."
},

:TEETERING => {
	:ID => 311,
	:name => "Teetering",
	:desc => "Grass-type moves are stronger on slower foes...",
	:fullDesc => "Grass-type moves deal 30% more damage against foes slower than this Pokémon. Solar Beam becomes a one turn move."
},

:STOPPN => {
	:ID => 312,
	:name => "Stop \\PN",
	:desc => "Poison damage lowers Defenses...",
	:fullDesc => "Any Pokémon in battle taking damage from the (Badly) Poisoned status lowers defenses by one stage."
},

:PRISMPOWER => {
	:ID => 313,
	:name => "Prism Power",
	:desc => "Raises stats once per battle...",
	:fullDesc => "Increases the user's Attack, Defense, Sp. Attack, Sp, Defense and Speed one stage upon switching in, once per battle."
},
:MURKFALL => {
	:ID => 716,
	:name => "Murkfall",
	:desc => "Conjures the terrain into a swamp on entry. (Lays over the field if a field is already present)."
},
:STORMRIDER => {
	:ID => 890,
	:name => "Storm Rider",
	:desc => "Summons a storm over the terrain on entry. (Lays over the field if a field is already present)."
},
:UNICORNBOOST => {
	:ID => 780,
	:name => "Unicorn Boost",
	:desc => "Horn based moves are powered up...",
	:fullDesc =>"Horn based moves are powered up by 30%. Normal type moves become Fairy type."
},
:HORNOFMIGHT => {
	:ID => 780,
	:name => "Horn Of Might",
	:desc => "Horn based moves are powered up...",
	:fullDesc =>"Horn based moves are powered up by 30%. Horn Attack becomes Water type."
},
:SUCCESSOR => {
	:ID => 925,
	:name => "Successor",
	:desc => "Raises special attack on entry by one stage.",
},
:RAVEN => {
	:ID => 926,
	:name => "Raven",
    :desc => "Concentrates power much faster making two turn moves skip the charging turn. Breaks enemies mold."
},
:VIVIDVOICE => {
	:ID => 1000,
	:name => "Vivid Voice",
    :desc => "Sound moves are powered up...",
	:fullDesc =>"Sound moves are powered up by 30%. Normal type moves become Dragon type."
},
:DRAGONBORN => {
	:ID => 1001,
	:name => "Dragon Born",
	:desc =>"Solar Blade and Sky Attack can be used without charging. Flying type moves become Dragon type."
},
:CINDERCONTROL => {
	:ID => 1002,
	:name => "Cinder Control",
	:desc =>"Manipulates certain moves to gain extra effects and power them up by 30%."
},
:BLASTFURNACE => {
	:ID => 1003,
	:name => "Blast Furnace",
	:desc =>"Attack doubles when 50% or lower Health."
},

:LUNATIC => {
	:ID => 1004,
	:name => "Lunatic",
	:desc => "Protects the Pokémon from recoil damage. Powers up recoil moves by 20%.",
},

:DISCENTRIC => {
	:ID => 1005,
	:name => "Discentric",
	:desc => "Bypasses enemy screens and. .",
	:fullDesc => "Bypasses enemy screens (only Moltres), boosts partner special damage by 30% in double battles."
},

:MANASHIELD => {
	:ID => 1006,
	:name => "Mana Shield",
	:desc => "Reduces damage done to allies...",
	:fullDesc => "Reduces damage done to allies by 30%, stacking multiplicatively. Increases Attack by one stage when below half health."
},

:STREETFIGHTER => {
	:ID => 1007,
	:name => "Street Fighter",
	:desc => "Powers up ally Pokémon's Fighting-type moves...",
	:fullDesc => "Fighting-type moves are boosted by 50% when used by itself or allies, multiplicative."
},

:DNAMATTER => {
	:ID => 1007,
	:name => "DNA-Matter",
	:desc => "When the body is exposed to weather it can react to it and change form. Reverts back after the battle.",
},

:PROTECTIVECLOAK => {
	:ID => 1009,
	:name => "Protective Cloak",
	:desc => "Weakens damage from certain types based on the form of Wormadam.",
},

:BEETLEIST => {
	:ID => 1010,
	:name => "Beetleist",
	:desc => "Powers up Bug-type moves...",
	:fullDesc => "Increases its respective stat by 50% when a Bug-type move is used."
},
:DESPERATE => {
	:ID => 1011,
	:name => "Desperate",
	:desc => "Raises Spdef by one stage upon entering the field.",
},
:TOKYODRIFT => {
	:ID => 1012,
	:name => "Tokyo Drift",
	:desc => "Wave based moves are increasing in power dealing 40% more damage.",
},
:POLARFORCE => {
	:ID => 1013,
	:name => "Polar Force",
	:desc => "Increases Attack stat on Ice overlays.",
},
:HELLFIRE => {
	:ID => 1014,
	:name => "Hell Fire",
	:desc => "Increases Speed stat on switch in during Infernal field.",
},
:MINDLIFT => {
	:ID => 1015,
	:name => "Mind Lift",
	:desc => "Increases Speed by 50% during Psychic overlay.",
},
:TEMPLAR => {
	:ID => 1016,
	:name => "Templar",
	:desc => "First taken damage reduces by 10% if windmove. Increases Special attack by 50%. Razor Wind becomes Dragon type and one turn.",
},
:OMEGAFORCE => {
	:ID => 1016,
	:name => "Omega Force",
	:desc => "Reduces damage taken by fire moves by 20%, breaks foes mold, using the same attack repeatetively makes them increase in power.",
},
:LAVADEMON => {
	:ID => 1016,
	:name => "Lava Demon",
	:desc => "Deals 1/32 chip damage to enemies on end of turns. Breaks foes mold, deals 50% more damage against enemies with Flash Fire.",
},
:RAIJIN => {
	:ID => 1017,
	:name => "Raijin",
	:desc => "Protects the Pokémon from recoil damage. Powers up recoil moves by 40%",
},
:TITANDROP => {
	:ID => 1018,
	:name => "Titan Drop",
	:desc => "All attacking damage that is dealt is 30% higher against every enemy that weighs less than this Pokémon.",
},
:HYDRAFORCE => {
	:ID => 1019,
	:name => "Hydra Force",
	:desc => "STAB moves increase greatly in power.",
},
:THUNDERSTRUK => {
	:ID => 1020,
	:name => "Thunder Struk",
	:desc => "On battle entry charges up the body with tension, increases special attack by 1 stage.",
},
:TOXICDEBRIS => {
	:ID => 1021,
	:name => "Toxic Debris",
	:desc => "Sets Toxic Spikes on contact for the opposing side, caps at 1 layer.",
},
:GALEFORCE => {
	:ID => 1022,
	:name => "Gale Force",
	:desc => "Once per battle sets Tailwind for 2 turns.",
},
:COTTONBODY => {
	:ID => 1023,
	:name => "Cotton Body",
	:desc => "Enhances the users Speed stat further, Razor Wind doesnt need to charge. Normal type moves become Fairy type.",
},
:BLACKSMITH => {
	:ID => 1024,
	:name => "Blacksmith",
	:desc => "Hammer based moves deal 30% more damage.",
},
:STORMCATCHER => {
	:ID => 1025,
	:name => "Storm Catcher",
	:desc => "Absorbs more energy during a storm to raise its own Spatk.",
},
:GOODBOY => {
	:ID => 1026,
	:name => "Good Boy",
	:desc => "Carefully attacks opponents and prevents negative stat drop effects from damaging moves.",
},
:DUNESURGE => {
	:ID => 1027,
	:name => "Dune Surge",
	:desc => "Makes the terrain desert on entry. (Lays over the field if a field is already present)."
},
:NINEINSTINCTS => {
	:ID => 1028,
	:name => "Nine Instincts",
	:desc => "The highest stat after knocking out an enemy is boosted, increases Accuracy drastically on entry.",
},
:OVERMIND => {
	:ID => 1028,
	:name => "Overmind",
	:desc => "The highest stat after knocking out an enemy is boosted, Razor Wind doesnt need to charge.",
},
:FLASHOFLIGHT => {
	:ID => 1029,
	:name => "Flash of Light",
	:desc => "Higher STAB damage than usual. Freeze Shock doesnt need to charge up. Increases Speed when entering battle.",
},
:GODOFFIRE => {
	:ID => 1030,
	:name => "God of Fire",
	:desc => "Applies a Flash Fire boost when entering battle. First Water type damage taken is 20% weaker. Solar Blade = 1 turn.",
},
:NORTHWIND => {
	:ID => 1031,
	:name => "North Wind",
	:desc => "First damaging attack always results in crit. Razor Wind doesnt Charge. Normal type moves become Water type.",
},
:CONTRIVE => {
	:ID => 1029,
	:name => "Contrive",
	:desc => "Turns every known damage move into a sharp move and boosts their power by 20%. Critical hits occur more frequently.",
},
:VIGOUR => {
	:ID => 1030,
	:name => "Vigour",
	:desc => "On every switch-in: becomes more resistant and gains +1 Special Defense, weakens every damage taken based on the environment by 20%.",
},
:FERTILIZER => {
	:ID => 1031,
	:name => "Fertilizer",
	:desc => "Takes 20% less damage from critical hits. Gains +1 Attack on switch in. Solar Blade doesnt require a charge turn.",
},
:RINGMASTER => {
	:ID => 1032,
	:name => "Ring Master",
	:desc => "When entering battle: applies the effect of Helping Hand.",
},
:RABIES => {
	:ID => 1033,
	:name => "Rabies",
	:desc => "Channels anger and rage to maximize critical hit chance for two turns.",
},
:EPIRIMIE => {
	:ID => 1034,
	:name => "Epirimie",
	:desc => "Channels energy and its mind to maximize critical hit chance for one turn.",
},
:COLDMIGHT => {
	:ID => 1033,
	:name => "Cold Might",
	:desc => "The first attack used is always a critical hit on the target. Works on every switch-in.",
},
:SCARYMIGHT => {
	:ID => 1034,
	:name => "Scary Might",
	:desc => "The first attack used is always a critical hit on the target. Works on every switch-in.",
},

:SERAPHIM => {
	:ID => 1035,
	:name => "Seraphim",
	:desc => "Inherits old ability and enhances the effect by 25%."
},

:LUCIFER => {
	:ID => 1036,
	:name => "Lucifer",
	:desc => "Inherits old ability and enhances the effect by 25%."
},

:OPPRESSION => {
	:ID => 1037,
	:name => "Oppression",
	:desc => "Lowers the foe's Special Attack stat. Refuses to leave the field afterwards."
},

:SOVEREIGN => {
	:ID => 1037,
	:name => "Sovereign",
	:desc => "Lowers the foe's Defense stat. Refuses to leave the field afterwards."
},

:GOLDENFLAME => {
	:ID => 1037,
	:name => "Golden Flame",
	:desc => "Damaging moves that are not STAB ignore enemy stat changes. Reduces incoming damage by 30% if enemy or user is statused."
},

:ZENITH => {
	:ID => 1038,
	:name => "Zenith",
	:desc => "Boosts Special Attack. Normal type moves become Flying type."
},

:ROCKSTAR => {
	:ID => 1039,
	:name => "Rockstar",
	:desc => "Boosts Sound moves by 40%. Breaks foes mold."
},

:LEADERSHIP => {
	:ID => 1040,
	:name => "Leadership",
	:desc => "Resists Hail damage. Reduces incoming damage by 15% for ally and itself. Charge attacks are executed in one turn."
},

:MOMENTUM => {
	:ID => 1041,
	:name => "Momentum",
	:desc => "Reduces incoming priority damage to itself and the partner by 30%. Increases own priority damage by 25%.",
},

:MINDBREAK => {
	:ID => 1042,
	:name => "Mind Break",
	:desc => "Reduces damage suffered and increases damage dealt by 20% each both.",
},

:OVERCHARGEX => {
	:ID => 1043,
	:name => "Overcharge-X",
	:desc => "On switch-in makes the user levitate for 2 turns. User cant be switched out.",
},

:OVERCHARGEY => {
	:ID => 1044,
	:name => "Overcharge-Y",
	:desc => "On switch-in makes the user focused for 1 turn. User cant be switch out.",
},

:BULLY => {
	:ID => 1045,
	:name => "Bully",
	:desc => "Biting or punching the enemy always deals 25% increased damage.",
},

:FLAMEBORN => {
	:ID => 1046,
	:name => "Flame Born",
	:desc => "On entry: increases Accuracy, all special attacks ignore enemy stat changes.",
},

:EUNBREAK => {
	:ID => 1047,
	:name => "Eun Break",
	:desc => "When Full HP first damage taken is reduced by 30%. Increases the damage of all Fire and Psychic type moves by 20%. Increases Accuracy slightly.",
},

:WILDSPIRIT => {
	:ID => 1047,
	:name => "Wild Spirit",
	:desc => "When Full HP first damage taken is reduced by 30%. The first attack used will always result in a critical hit.",
},

:COMPOSED => {
	:ID => 1048,
	:name => "Composed",
	:desc => "Reduces the damage of incoming physical contact moves by 20%, increases own physical damage by 25%.",
},

:BOTANIC => {
	:ID => 1049,
	:name => "Botanic",
	:desc => "Removes the drawback from Solar Blade and Headlong Rush. When entering battle raises Attack stage.",
},

:VOIDWALKER => {
	:ID => 1050,
	:name => "Void Walker",
	:desc => "On switch in: unleashes dark forces to make the next move used always result in a critical hit.",
},

:GLITTERAURA => {
	:ID => 1051,
	:name => "Glitter Aura",
	:desc => "Enemy's damaging moves are always reduced by 20%. Raises speed.",
},

:FORCEACCEL => {
	:ID => 1052,
	:name => "Force Accel",
	:desc => "Doubles the Pokémon's Special Attack stat.",
},
:ACAIDEBRIS => {
	:ID => 1021,
	:name => "Acai Debris",
	:desc => "Sets Spikes on contact for the opposing side, user anchors itself and cannot switch out.",
},
:METALSURGE => {
	:ID => 1021,
	:name => "Metal Surge",
	:desc => "When the user gets hit by a contact move and is knocked out, it scatters steely hazards.",
},

:CLERIC => {
	:ID => 1052,
	:name => "Cleric",
	:desc => "On switch-in: Summons a protective cloak to gain HP over time. Raises Spatk."
},

:GEOFORCE => {
	:ID => 1052,
	:name => "Geo Force",
	:desc => "Raises speed on battle entry, Normal type moves become Ground type."
},

:COLDBLOODED => {
	:ID => 1052,
	:name => "Cold Blooded",
	:desc => "On switch-in: Summons a protective cloak to gain HP over time. Raises Spatk."
},

:ACIDWALKER => {
	:ID => 208,
	:name => "Acid Walker",
	:desc => "Poisons enemies on contact, crits poisoned enemies. Normal type moves become Ghost type. Skull Bash is used without charging."
},

:OCEANCALL => {
	:ID => 208,
	:name => "Ocean Call",
	:desc => "Raises speed on battle entry, grants the bearer Aqua Ring."
},

:FROSTMONARCH => {
	:ID => 264,
	:name => "Frost Monarch",
	:desc => "Boosts Attack when entering the field."
},

:SEARINGSIX => {
	:ID => 264,
	:name => "Searing Six",
	:desc => "Absorbs fire power from its wings to boost the damage of Fire type attacks further."
},

:COSTAR => {
	:ID => 665,
	:name => "Costar",
	:desc => "Copies an ally's stat changes on switch-in.",
	:fullDesc => "When the Pokémon enters a battle, it copies an ally's stat changes. Doesnt work on the first turn of the battle."
},

:TIDALTAIL => {
	:ID => 264,
	:name => "Tidal Tail",
	:desc => "Channels the power in its tail to increase the damage of tail based moves by 35%."
},

:WOODWORKER => {
	:ID => 264,
	:name => "Wood Worker",
	:desc => "Adapts to the nature and gains stat boosts in forest-like terrains, always sets Ingrain on entry."
},

:HEARTSHIP => {
	:ID => 264,
	:name => "Heart Ship",
	:desc => "If max. Happiness: Increases the Special Attack stat by 20%, also increases Accuracy."
},

:FIREMIND => {
	:ID => 224,
	:name => "Fire Mind",
	:desc => "Halves Water damage and boosts Fire...",
	:fullDesc => "50% less damage from Water-type moves, 50% more damage with Fire-type moves. Inferno no longer checks for Accuracy."
},
:TURBULENCE => {
	:ID => 720,
	:name => "Turbulence",
	:desc => "Two turn moves dont need to charge. Ignores stat reducing effects of certain moves.",
},
:TIMING => {
	:ID => 720,
	:name => "Timing",
	:desc => "Grants immunity to Intimidate and prevents the stat drop of most of its own damaging moves.",
},

:STEELSWING => {
	:ID => 1036,
	:name => "Steel Swing",
	:desc => "Inherits old ability and enhances the effect by 25%."
},

:DRAINAGE => {
	:ID => 105,
	:name => "Drainage",
	:desc => "Heightens the critical-hit ratio of draining moves by 2.",
},

}