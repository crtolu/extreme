#####MODDED
def swm_pbPsychic(seer, gender)
  Kernel.pbMessage(_INTL('{1} is trying to reach out to your friends\' minds', seer))
  Kernel.pbMessage(_INTL('{1} is sneaking in your foes\' thoughts...', seer))
  if gender == 0
    msg=_INTL('{1} wants to let you know what did he find in there', seer)
  elsif gender == 1
    msg=_INTL('{1} wants to let you know what did she find in there', seer)
  else
    msg=_INTL('{1} wants to let you know what did it find in there', seer)
  end
  
  return nil if Kernel.pbMessage(msg, [_INTL('Ok'), _INTL('Nevermind')], 2) != 0
  values=swm_getRelationshipValues
  return Kernel.pbMessage(_INTL('Relationship Values'), values, values.length)
end

def swm_getRelationshipValues
  values=[]
  max=$cache.RXsystem.variables.length
  for i in 0...max
    var=$cache.RXsystem.variables[i]
    next if !var
    name=swn_getCharName(var, i)
    next if !name
    values.push(_INTL('{1}: {2}', name, $game_variables[i]))
  end
  values=values.sort
  return values
end

def swn_getCharName(var, i)
  if (var == "Melia" && i == 377) || (var == "Ren" &&  i == 378) || (var == "Venam" &&  i == 379) || (var == "Tesla" &&  i == 380) || (var == "Madelis" &&  i == 381) || (var == "Karrina" &&  i == 382) || 
    (var == "Aelita" &&  i == 383) || (var == "Keta" &&  i == 384) || (var == "Mosely" &&  i == 385) || (var == "Narcissa" &&  i == 386) || (var == "Marianette" &&  i == 387) || (var == "Crawli" &&  i == 388) || 
    (var == "Angie" &&  i == 389) || (var == "RorimB" &&  i == 390) || (var == "Valarie" &&  i == 391) || (var == "Braixen" &&  i == 392) || (var == "Adam" &&  i == 393) || (var == "Amber" &&  i == 394) || 
    (var == "Reina" &&  i == 395) || (var == "Crescent" &&  i == 396) || (var == "Anathea" &&  i == 397) || (var == "Karen" &&  i == 398) || (var == "Erin" &&  i == 399) || (var == "Damien" &&  i == 400) || 
    (var == "Vivian" &&  i == 477) || (var == "Saki" &&  i == 478) || (var == "Alexandra" &&  i == 479) || (var == "Ryland" &&  i == 480) || (var == "Huey" &&  i == 481) || (var == "Erick" &&  i == 482) || 
    (var == "Ben" &&  i == 483) || (var == "Beth" &&  i == 484) || (var == "Goomink" &&  i == 485) || (var == "Lavender" &&  i == 486) || (var == "Allen" &&  i == 487) || (var == "Alice" &&  i == 488) || 
    (var == "Nim" &&  i == 489) || (var == "Kanon" &&  i == 492) || (var == "Florin" &&  i == 494) || (var == "Talon" &&  i == 495) || (var == "Flora" &&  i == 496) || (var == "Kreiss" &&  i == 497) || 
    (var == "Eizen" &&  i == 498) || (var == "Particia" &&  i == 499) || (var == "Rhodea" &&  i == 500)
    return var
  elsif (var == "PianoLady" &&  i == 490)
    return "Piano Lady"
  elsif (var == "Mom <3" &&  i == 493)
    return "Mom"
  elsif (var == "HazukiRel" &&  i == 749)
    return "Hazuki"
  elsif (var == "NymieraRel" &&  i == 751)
    return "Nymiera"
  elsif (var == "DylanRel" &&  i == 766)
    return "Dylan"
  else
    return nil
  end
end

HiddenMoveHandlers::CanUseMove.add(:PSYCHIC,lambda{|move,pkmn|
   return true
})

HiddenMoveHandlers::UseMove.add(:PSYCHIC,lambda{|move,pokemon|
   if !pbHiddenMoveAnimation(pokemon)
     Kernel.pbMessage(_INTL("{1} used {2}.",pokemon.name,getMoveName(move)))
   end
   swm_pbPsychic(pokemon.name, pokemon.gender)
   return true
})
#####/MODDED