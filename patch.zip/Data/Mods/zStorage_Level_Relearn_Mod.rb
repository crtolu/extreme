# Storage Level and Relearn Mod
# Relearn moves from PC storage screen. Level up entire PC boxes at once. 

# Also raises experience amount given by EXP Candy XL.
# Does not consume EXP Candy XL to level up.

# Most of this code is from the Rejuv/LAWDS team. Give them a cookie.
# Relearning elements based on PC_CommandMasterMod by Alemi
# mod by jmedley

ItemHandlers::UseOnPokemon.add(:EXPCANDYXL,proc{|item,pokemon,scene,amount=1|
  if pokemon.level>=MAXIMUMLEVEL || (pokemon.isShadow? rescue false)
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false, 0
  end
  exp = 300000 * amount
  result = LevelLimitExpGain(pokemon, exp)

  if result == -1
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false, 0
  end
  
  exp = result
  amount_consumed = (result / 300000.0).ceil
  IncreaseExp(pokemon, exp, scene)
  
  scene.pbHardRefresh
  next true, amount_consumed
})


class PokemonStorageScreen

  def pbBoxCommands
    commands=[
       _INTL("Jump"),
       _INTL("Wallpaper"),
       _INTL("Name"),
       _INTL("Find"),
       _INTL("Level"),
       _INTL("Cancel"),
    ]
    command=pbShowCommands(
       _INTL("What do you want to do?"),commands)
    case command
      when 0
        destbox=@scene.pbChooseBox(_INTL("Jump to which Box?"))
        if destbox>=0
          @scene.pbJumpToBox(destbox)
        end
      when 1
        if Reborn
        commands=[
          _INTL("Monochrome"),
          _INTL("Urban"),
          _INTL("Beach"),
          _INTL("Forest"),
          _INTL("Wasteland"),
          _INTL("Wilderness"),
          _INTL("Rustic"),
          _INTL("Snowy"),
          _INTL("Desert"),
          _INTL("Lake"),
          _INTL("Volcano"),
          _INTL("Crystal Cave"),
          _INTL("Library"),
          _INTL("Chess"),
          _INTL("Moon"),
          _INTL("Sword"),
          _INTL("Ruby"),
          _INTL("Sapphire"),
          _INTL("Emerald"),
          _INTL("Amethyst"),
          _INTL("Checks"),
          _INTL("Reborn"),
          _INTL("Meteor"),
          _INTL("Arceus")
        ]
        elsif Desolation
        commands = [
          _INTL("Forest"),
          _INTL("City"),
          _INTL("Desert"),
          _INTL("Savanna"),
          _INTL("Crag"),
          _INTL("Volcano"),
          _INTL("Snow"),
          _INTL("Cave"),
          _INTL("Beach"),
          _INTL("Seafloor"),
          _INTL("River"),
          _INTL("Sky"),
          _INTL("PokéCenter"),
          _INTL("Machine"),
          _INTL("Checks"),
          _INTL("Simple"),
          _INTL("Grid"),
          _INTL("Foxes"),
          _INTL("Crescent"),
          _INTL("Desolate")
        ]
        elsif Rejuv
          commands=[
            _INTL("Ancient Sea"),
            _INTL("Cavern"),
            _INTL("Desert"),
            _INTL("Dojo"),
            _INTL("Fire"),
            _INTL("Forest"),
            _INTL("Forest Alt"),
            _INTL("Gloomy Woods"),
            _INTL("Ice"),
            _INTL("Machine"),
            _INTL("Midnight Hill"),
            _INTL("Nightsky Rocks"),
            _INTL("Plateau"),
            _INTL("Poison Swamp"),
            _INTL("Rainbow Meadow"),
            _INTL("Rainbow Mt."),
            _INTL("Ruin Cave"),
            _INTL("Sky Arena"),
            _INTL("Sky Temple"),
            _INTL("Toad Woods"),
            _INTL("Treasure Sea"),
            _INTL("Underwater"),
            _INTL("Volcanic Top"),
            _INTL("Porygon"),
            _INTL("Eevee"),
            _INTL("Vaporeon"),
            _INTL("Jolteon"),
            _INTL("Flareon"),
            _INTL("Espeon"),
            _INTL("Umbreon"),
            _INTL("Leafeon"),
            _INTL("Glaceon"),
            _INTL("Sylveon")
         ]
        end
        wpaper=pbShowCommands(_INTL("Pick the wallpaper."),commands)
        if wpaper>=0
          @scene.pbChangeBackground(wpaper)
        end
      when 2
        @scene.pbBoxName(_INTL("Box name?"),0,18)
      when 3
        pbFindPokemon
      when 4
        level_box
    end
  end 

  def level_box
    item = :EXPCANDYXL
    count = 0
    for i in 0...$PokemonStorage[@storage.currentBox].length
      poke = $PokemonStorage[@storage.currentBox, i]
      if poke
        if !poke.isEgg?
          if poke.level<LEVELCAPS[$Trainer.numbadges]
            ItemHandlers.triggerUseOnPokemon(item,poke,@scene)
            count += 1
          end
        end
      end
    end
    if count == 0
      pbDisplay(_INTL("Nothing in this box can be leveled."))
    end
  end
  
  def pbStartScreen(command)
    @heldpkmn=nil
    if command==2
### WITHDRAW ###################################################################
      @scene.pbStartBox(self,command)
      loop do
        selected=@scene.pbSelectBox(@storage.party)
        if selected && selected[0]==-3 # Close box
          if pbConfirm(_INTL("Exit from the Box?"))
            break
          else
            next
          end
        end
        if selected && selected[0]==-2 # Party Pokémon
          pbDisplay(_INTL("Which one will you take?"))
          next
        end
        if selected && selected[0]==-4 # Box name
          pbBoxCommands
          next
        end
        if selected==nil
          if pbConfirm(_INTL("Continue Box operations?"))
            next
          else
            break
          end
        else
          pokemon=@storage[selected[0],selected[1]]
          next if !pokemon
          command=pbShowCommands(
            _INTL("{1} is selected.",pokemon.name),[_INTL("Withdraw"),
            _INTL("Summary"),_INTL("Mark"),_INTL("Release"),_INTL("Cancel")])
          case command
          when 0 then pbWithdraw(selected,nil)
          when 1 then pbSummary(selected,nil)
          when 2 then pbMark(selected,nil)
          when 3 then pbRelease(selected,nil)
          end
        end
      end
      @scene.pbCloseBox
    elsif command==1
### DEPOSIT ####################################################################
      @scene.pbStartBox(self,command)
      loop do
        selected=@scene.pbSelectParty(@storage.party)
        if selected==-3 # Close box
          if pbConfirm(_INTL("Exit from the Box?"))
            break
          else
            next
          end
        end
        if selected<0
          if pbConfirm(_INTL("Continue Box operations?"))
            next
          else
            break
          end
        else
          pokemon=@storage[-1,selected]
          next if !pokemon
          command=pbShowCommands(
             _INTL("{1} is selected.",pokemon.name),[_INTL("Store"),
             _INTL("Summary"),_INTL("Mark"),_INTL("Release"),_INTL("Cancel")])
          case command
            when 0 # Store
              pbStore([-1,selected],nil)
            when 1 # Summary
              pbSummary([-1,selected],nil)
            when 2 # Mark
              pbMark([-1,selected],nil)
            when 3 # Release
              pbRelease([-1,selected],nil)
          end
        end
      end
      @scene.pbCloseBox
    elsif command==0
### MOVE #######################################################################
      @scene.pbStartBox(self,command)
      loop do
        selected=@scene.pbSelectBox(@storage.party)
        if selected && selected[0]==-3 # Close box
          if pbHeldPokemon
            pbDisplay(_INTL("You're holding a Pokémon!"))
            next
          end
          if pbConfirm(_INTL("Exit from the Box?"))
            break
          else
            next
          end
        end
        if selected==nil
          if pbHeldPokemon
            pbDisplay(_INTL("You're holding a Pokémon!"))
            next
          end
          if pbConfirm(_INTL("Continue Box operations?"))
            next
          else
            break
          end
        elsif selected[0]==-4 # Box name
          pbBoxCommands
        elsif selected[0]==-2 && selected[1]==-1
          next
        elsif Input.press?(Input::CTRL) && !@heldpkmn
          pokemon=@storage[selected[0],selected[1]]
          heldpoke=pbHeldPokemon
          next if !pokemon && !heldpoke
          pbHold(selected,true)
        else
          pokemon=@storage[selected[0],selected[1]]
          heldpoke=pbHeldPokemon
          next if !pokemon && !heldpoke
          if @scene.quickswap
            if @heldpkmn
              (pokemon) ? pbSwap(selected) : pbPlace(selected)
            else
              pbHold(selected)
            end
          else
            commands=[
              _INTL("Move"),
              _INTL("Summary"),
              _INTL("Multi-Move"),
              _INTL("Withdraw"),
              _INTL("Item"),
              _INTL("Mark"),
              _INTL("Release"),
              _INTL("Cancel")
            ]
            commands.push(_INTL("Debug")) if $DEBUG
            pkmn=@heldpkmn ? @heldpkmn : pokemon ###### MOD ######
            commands.push(_INTL("Relearn Move")) if pbHasRelearnableMove?(pkmn)
            if heldpoke
              helptext=_INTL("{1} is selected.",heldpoke.name)
              commands[0]=pokemon ? _INTL("Shift") : _INTL("Place")
            elsif pokemon
              helptext=_INTL("{1} is selected.",pokemon.name)
              commands[0]=_INTL("Move")
            else
              next
            end
            if selected[0]==-1
              commands[3]=_INTL("Store")
            else
              commands[3]=_INTL("Withdraw")
            end
            command=pbShowCommands(helptext,commands)
            case command
            when 0 # Move/Shift/Place
              if @heldpkmn && pokemon
                pbSwap(selected)
              elsif @heldpkmn
                pbPlace(selected)
              else
                pbHold(selected)
              end
            when 1 # Summary
              pbSummary(selected,@heldpkmn)
            when 2 # Multi-Move
              if selected[0] >=0 && !@heldpkmn
                pbHold(selected,true)
              elsif @heldpkmn
                Kernel.pbMessage("Can't Multi-Move while holding a Pokémon.")
              else
                Kernel.pbMessage("Can't Multi-Move a Pokémon from your party.")
              end
            when 3 # Withdraw
              if selected[0]==-1
                pbStore(selected,@heldpkmn)
              else
                pbWithdraw(selected,@heldpkmn)
              end
            when 4 # Item
              pbItem(selected,@heldpkmn)
            when 5 # Mark
              pbMark(selected,@heldpkmn)
            when 6 # Release
              pbRelease(selected,@heldpkmn)
            when 7
            when 8  
              if $DEBUG
                pkmn=@heldpkmn ? @heldpkmn : pokemon
                pbPokemonDebug(self, pkmn, nil, selected, heldpoke)
              elsif pbHasRelearnableMove?(pkmn)
                pbRelearnMoveScreen(pkmn)
              else
                break
              end
            when 9
              if $DEBUG
                pbRelearnMoveScreen(pkmn)
              else
                break
              end
            end
          end
        end
      end
      @scene.pbCloseBox
    elsif command==3
      @scene.pbStartBox(self,command)
      @scene.pbCloseBox
    end
  end
end