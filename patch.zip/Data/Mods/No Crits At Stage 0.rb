class PokeBattle_Move

################################################################################
# Damage calculation and modifiers
################################################################################
  def pbCritRate?(attacker,opponent)
    return -1 if self.is_a?(PokeBattle_Confusion)
    return -1 if (opponent.ability == :BATTLEARMOR || opponent.ability == :SHELLARMOR) && !(opponent.moldbroken)
    return -1 if opponent.pbOwnSide.effects[:LuckyChant]>0
    return 3 if attacker.effects[:LaserFocus]>0 || @function==0xA0 || @function==0x319 # Frost Breath, Surging Strikes
    return 3 if attacker.ability == :MERCILESS && (opponent.status == :POISON || [:CORROSIVE,:CORRPSIVEMIST,:WASTELAND,:MURKWATERSURFACE].include?(@battle.FE))
    return 3 if (opponent.ability == :RATTLED || opponent.ability == :WIMPOUT) && @battle.FE == :COLOSSEUM
    return 3 if (attacker.ability == :QUICKDRAW && attacker.effects[:Quickdrawsnipe])
    c=0    
    c+=attacker.effects[:FocusEnergy]
    c+=1 if !@data.nil? && highCritRate?
    c+=1 if attacker.crested == :HYDREIGON # Hydreigon Crest
    c+=2 if attacker.ability == :SUPERLUCK
    c+=2 if attacker.ability == :CRUSADER
    c+=2 if attacker.hasWorkingItem(:STICK) && (attacker.pokemon.species == :FARFETCHD || attacker.pokemon.species == :SIRFETCHD)
    c+=2 if attacker.hasWorkingItem(:LUCKYPUNCH) && (attacker.pokemon.species == :CHANSEY)
    if @battle.FE == :MIRROR
      buffs = 0
      buffs = attacker.stages[PBStats::EVASION] if attacker.stages[PBStats::EVASION] > 0
      buffs = buffs.to_i + attacker.stages[PBStats::ACCURACY] if attacker.stages[PBStats::ACCURACY] > 0
      buffs = buffs.to_i - opponent.stages[PBStats::EVASION] if opponent.stages[PBStats::EVASION] < 0
      buffs = buffs.to_i - opponent.stages[PBStats::ACCURACY] if opponent.stages[PBStats::ACCURACY] < 0
      buffs = buffs.to_i
      c += buffs if buffs > 0
    end
    c+=1 if attacker.hasWorkingItem(:RAZORCLAW)
    c+=1 if attacker.hasWorkingItem(:SCOPELENS)
    if Rejuv && @battle.FE == :CHESS
      c+=1 if (opponent.ability == :RECKLESS || opponent.ability == :GORILLATACTICS)
      c+=1 if [:STOMPINGTANTRUM,:THRASH,:OUTRAGE].include?(opponent.lastMoveUsed) 
      if attacker.ability == :MERCILESS
        frac = (1.0*opponent.hp) / (1.0*opponent.totalhp)  
        if frac < 0.8  
          c+=1  
        elsif frac < 0.6  
          c+=2  
        elsif frac < 0.4  
          c+=3  
        end  
      end
    end
    c=3 if attacker.species == :FEAROW && attacker.crested && opponent.hp != opponent.totalhp # fearow crest
    c=3 if attacker.species == :ARIADOS && attacker.crested && (opponent.status == :POISON || opponent.stages[PBStats::SPEED] < 0) # ariados crest
    c=3 if c>3
	return -1 if c==0
    return c
  end

end