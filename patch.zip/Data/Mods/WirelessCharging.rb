ItemHandlers::UseFromBag.add(:REMOTEPC,proc{|item|
  if $game_variables[:E4_Tracker] > 0
    Kernel.pbMessage(_INTL("Cannot use the Remote PC here."))
    next 0
  end
  if $game_switches[:NotPlayerCharacter] && !$game_switches[:InterceptorsWish]
    Kernel.pbMessage(_INTL("Cannot use the Remote PC right now."))
    next 0
  end
  if Rejuv && $game_variables[650] > 0
    Kernel.pbMessage(_INTL("The RemotePC has no connection..",$Trainer.name))
    next 0
  end
  pbPokeCenterPC
  next 1
})

ItemHandlers::UseInField.add(:REMOTEPC,proc{|item|
  if $game_variables[:E4_Tracker] > 0
    Kernel.pbMessage(_INTL("Cannot use the Remote PC here."))
    next 0
  end
  if $game_switches[:NotPlayerCharacter] && !$game_switches[:InterceptorsWish]
    Kernel.pbMessage(_INTL("Cannot use the Remote PC right now."))
    next 0
  end
  if Rejuv && $game_variables[650] > 0
    Kernel.pbMessage(_INTL("The RemotePC has no connection..",$Trainer.name))
    next 0
  end
  pbPokeCenterPC
  next 1

})