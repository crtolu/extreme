

# def moveapp(species=:BULBASAUR, form=0)
#   ### DUMMY POKEMON

#   dummyPokemon = PokeBattle_Pokemon.new(species,1)
#   dummyPokemon.form = form
#   dummyPokemon.makeNotShiny

#   ### SETUP
#   viewport=Viewport.new(0,0,Graphics.width,Graphics.height)
#   background = BitmapSprite.new(Graphics.width,Graphics.height,viewport)
#   pbSetSmallFont(background.bitmap)

#   # pokeicon = PokemonIconSprite.new(dummyPokemon, viewport)
#   # pokeicon.x = 330
#   # pokeicon.y = 22

#   overlay = BitmapSprite.new(Graphics.width,Graphics.height,viewport)
#   pbSetSmallFont(overlay.bitmap)

#   backgroundpos = [["Data/Mods/__dexapp/basemovesets", 0, 0, 0, 0, -1, -1]]
# end


$cache.items[:DEXAPP] = ItemData.new(:DEXAPP, {
  name: "Dex Overview",
  desc: "Show advanced pokedex information in a pretty form.",
  price: 0,
  keyitem: true,
  general: true,
  noUseInBattle: true,
})

ItemHandlers::UseInField.add(:DEXAPP,proc{|item|
  dexappscroll
})

ItemHandlers::UseFromBag.add(:DEXAPP,proc{|item|
  dexappscroll
  next 1 # Continue
})
class Game_Screen
  # Existing field
  attr_reader :tone_target
end

def dexappscroll
  toneTemp = $game_screen.tone_target
  $game_screen.start_tone_change(Tone.new(-120,-120,-120,20), 20)
  currentindex = $PokemonGlobal.pokedexIndex[$PokemonGlobal.pokedexDex]
  dexlist = PokemonPokedexScene.new.pbGetDexList.map { |it| it[0] }
  firstidx = -1
  lastidx = -1
  for i in 0...dexlist.length
    if $Trainer.pokedex.dexList[dexlist[i]][:owned?]
      if firstidx == -1
        firstidx = i
      end
      lastidx = i
    end
  end
  loop do
    if !$Trainer.pokedex.dexList[dexlist[currentindex]][:owned?]
      nextindex=-1
      i=currentindex + 1; loop do break unless i<dexlist.length
        break if $Trainer.pokedex.dexList[dexlist[i]][:owned?] || $cache.pkmn[dexlist[i]].dexnum < dexlist.length
        i+=1
      end
      if nextindex == -1
        i=currentindex-1; loop do break unless i>=0
          if $Trainer.pokedex.dexList[dexlist[i]][:owned?]
            nextindex=i
            break
          end
          i-=1
        end
      end
      break if nextindex == -1
      currentindex = nextindex
      $PokemonGlobal.pokedexIndex[$PokemonGlobal.pokedexDex] = nextindex
    end

    currentform = $cache.pkmn[dexlist[currentindex]].forms.invert[$Trainer.pokedex.dexList[dexlist[currentindex]][:lastSeen][:form]]
    currentform = 0 if !currentform
    idxshift, formshift = dexapp(dexlist[currentindex], currentform)

    if idxshift < 0
      if currentindex == firstidx
        nextindex = lastidx
      else
        nextindex=-1
        i=[currentindex+idxshift, firstidx].max; loop do break unless i>=0
          if $Trainer.pokedex.dexList[dexlist[i]][:owned?]
            nextindex=i
            break
          end
          i-=1
        end
      end
      if nextindex != -1
        currentindex = nextindex
        $PokemonGlobal.pokedexIndex[$PokemonGlobal.pokedexDex] = nextindex
      end
    elsif idxshift > 0
      if currentindex == lastidx
        nextindex = firstidx
      else
        nextindex=-1
        i=[currentindex + idxshift, lastidx].min; loop do break unless i<dexlist.length
          if $Trainer.pokedex.dexList[dexlist[i]][:owned?]
            nextindex=i
            break
          end
          i+=1
        end
      end
      if nextindex != -1
        currentindex = nextindex
        $PokemonGlobal.pokedexIndex[$PokemonGlobal.pokedexDex] = nextindex
      end
    end

    if formshift < 0
      currentform -= 1
      while currentform > 0 && 
        $cache.pkmn[dexlist[currentindex]].formData[$cache.pkmn[dexlist[currentindex]].forms[currentform]][:ExcludeDex]
        currentform -= 1
      end
      currentform = $cache.pkmn[dexlist[currentindex]].forms.length - 1 if currentform < 0
      while currentform > 0 && 
        $cache.pkmn[dexlist[currentindex]].formData[$cache.pkmn[dexlist[currentindex]].forms[currentform]][:ExcludeDex]
        currentform -= 1
      end
      $Trainer.pokedex.dexList[dexlist[currentindex]][:lastSeen][:form] = $cache.pkmn[dexlist[currentindex]].forms[currentform]
    elsif formshift > 0
      currentform += 1 
      while currentform < $cache.pkmn[dexlist[currentindex]].forms.length && 
        $cache.pkmn[dexlist[currentindex]].formData[$cache.pkmn[dexlist[currentindex]].forms[currentform]][:ExcludeDex]
        currentform += 1
      end
      currentform = 0 if currentform >= $cache.pkmn[dexlist[currentindex]].forms.length
      $Trainer.pokedex.dexList[dexlist[currentindex]][:lastSeen][:form] = $cache.pkmn[dexlist[currentindex]].forms[currentform]
    end
    break if idxshift == 0 && formshift == 0
  end

  target = toneTemp || Tone.new(0,0,0,0)
  $game_screen.start_tone_change(target, 10 * 2)
end

def dexapp(species=:BULBASAUR, form=0)

  ### DUMMY POKEMON

  dummyPokemon = PokeBattle_Pokemon.new(species,1)
  dummyPokemon.form = form
  dummyPokemon.makeNotShiny

  ### SETUP
  viewport=Viewport.new(0,0,Graphics.width,Graphics.height)
  background = BitmapSprite.new(Graphics.width,Graphics.height,viewport)
  pbSetSmallFont(background.bitmap)

  pokeicon = PokemonIconSprite.new(dummyPokemon, viewport)
  pokeicon.x = 330
  pokeicon.y = 22

  overlay = BitmapSprite.new(Graphics.width,Graphics.height,viewport)
  pbSetSmallFont(overlay.bitmap)

  backgroundpos = [["Data/Mods/__dexapp/baseadvancedex", 0, 0, 0, 0, -1, -1]]

  imgpos = []

  textpos = [["Base Stats",      154,  30, 2, PBScene::BOXBASE,PBScene::BOXSHADOW], 
             ["EVs",             309,  30, 2, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["HP",               20,  54, 0, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["Attack",           20,  78, 0, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["Defense",          20, 102, 0, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["Sp. Atk",          20, 126, 0, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["Sp. Def",          20, 150, 0, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["Speed",            20, 174, 0, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["Total",            20, 198, 0, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["Abilities",       126, 246, 2, PBScene::BOXBASE,PBScene::BOXSHADOW],
             ["Wild Hold Items", 392, 246, 2, PBScene::BOXBASE,PBScene::BOXSHADOW]]

  type1=dummyPokemon.type1
  type2=dummyPokemon.type2

  if $cache.pkmn[species].forms[form] != "Normal Form"
    formname = $cache.pkmn[species].forms[form]
    if formname.include?("Form")
      formname = formname.split("Form")[0].strip
    end
    if formname.length > 12
      formname = formname[0..9] + "..."
    end
    textpos.push([formname,          488, 37, 1, PBScene::MENUBASE, PBScene::MENUSHADOW],
                 [dummyPokemon.name, 488, 58, 1, PBScene::MENUBASE, PBScene::MENUSHADOW])
  else
    textpos.push([dummyPokemon.name, 488, 52, 1, PBScene::MENUBASE, PBScene::MENUSHADOW])
  end

  if type1 && (!type2 || type2 == type1)
    backgroundpos.push(["Data/Mods/__dexapp/dexbg",                330,  28, 0, 130, 166, 98])
    imgpos.push(["Graphics/Pictures/Pokedex/pokedex#{type1.to_s}", 388,  80, 0,   0,  96,  32])
  else
    backgroundpos.push(["Data/Mods/__dexapp/dexbg",                330,  28, 0,   0, 166, 130])
    imgpos.push(["Graphics/Pictures/Pokedex/pokedex#{type1.to_s}", 388,  80, 0,   0,  96, 32])
    imgpos.push(["Graphics/Pictures/Pokedex/pokedex#{type2.to_s}", 388, 114, 0,   0,  96, 32])
  end

  ### BASE STATS

  baseStats = dummyPokemon.baseStats
  maxstatwidth = 118
  totalstats = 0
  widths = baseStats.map { |statvalue|
    totalstats += statvalue
    next [(maxstatwidth * statvalue / 255).ceil, maxstatwidth].min
  }
  widths.push([[(maxstatwidth * totalstats / 700).ceil, 2].max, maxstatwidth].min)

  for width, idx in widths.each_with_index
    imgpos.push(["Data/Mods/__dexapp/bars", 122, 54 + 24 * idx, maxstatwidth - width, 18 * idx, width, 18])
    statvalue = idx >= baseStats.size ? totalstats : baseStats[idx]
    textpos.push(["#{statvalue}", 284, 55 + 24 * idx, 1, PBScene::BOXBASE,PBScene::BOXSHADOW, 1])
  end

  ### EVS

  evYield = dummyPokemon.evYield
  totalevs = 0
  for ev, idx in evYield.each_with_index
    totalevs += ev
    evtext = ev == 0 ? "-" : "#{ev}"
    textpos.push([evtext, 309, 54 + 24 * idx, 2, PBScene::BOXBASE,PBScene::BOXSHADOW])
  end
  textpos.push(["#{totalevs}", 309, 198, 2, PBScene::BOXBASE,PBScene::BOXSHADOW])

  ### ABILITIES

  abillist = dummyPokemon.getAbilityList
  hidden = nil
  hidden = abillist[2] if abillist.size == 3
  hidden = $cache.pkmn[species].formData.dig($cache.pkmn[species].forms[form], :HiddenAbilities) if !hidden
  hidden = $cache.pkmn[species].flags[:HiddenAbilities] if !hidden
  abillist = abillist.uniq

  for abil, idx in abillist.each_with_index
    backgroundpos.push(["Data/Mods/__dexapp/dextab", 16, 268 + 24 * idx, 0, 0, 214, 22])
    if idx == 0
      textpos.push(["Abil.", 44, 270 + 24 * idx, 2, PBScene::BOXBASE,PBScene::BOXSHADOW])
    elsif abil == hidden
      textpos.push(["(H)", 44, 270 + 24 * idx, 2, PBScene::BOXBASE,PBScene::BOXSHADOW])
    elsif idx == 1
      textpos.push(["or", 44, 270 + 24 * idx, 2, PBScene::BOXBASE,PBScene::BOXSHADOW])
    end
    textpos.push([getAbilityName(abil,true), 152, 270 + 24 * idx, 2, PBScene::MENUBASE, PBScene::MENUSHADOW])
  end

  ### WILD HELD ITEMS

  wilditems = dummyPokemon.wildHoldItems
  if wilditems[0] == wilditems[1] && wilditems[1] == wilditems[2]
    backgroundpos.push(["Data/Mods/__dexapp/dextab", 282, 268, 0, 22, 214, 22])
    textpos.push(["100%", 468, 270, 2, PBScene::BOXBASE,PBScene::BOXSHADOW])
    textpos.push([wilditems[0] ? getItemName(wilditems[0]) : "No item", 360, 270, 2, PBScene::MENUBASE, PBScene::MENUSHADOW])
  else
    boxesUsed = 0
    chances=[50,5,1]
    for wilditem, idx in wilditems.each_with_index
      if wilditem
        backgroundpos.push(["Data/Mods/__dexapp/dextab", 282, 268 + boxesUsed * 24, 0, 22, 214, 22])
        textpos.push(["#{chances[idx]}%", 468, 270 + 24 * boxesUsed, 2, PBScene::BOXBASE,PBScene::BOXSHADOW])
        textpos.push([getItemName(wilditem), 360, 270 + 24 * boxesUsed, 2, PBScene::MENUBASE, PBScene::MENUSHADOW]) if wilditem
        boxesUsed += 1
      end
    end
  end

  pbDrawImagePositions(background.bitmap,backgroundpos)
  pbDrawImagePositions(overlay.bitmap,imgpos)
  pbDrawTextPositions(overlay.bitmap,textpos)
  background.visible = true
  overlay.visible = true
  pokeicon.visible = true

  ret = [0, 0]

  loop do
    Input.update
    Graphics.update
    pbUpdateSceneMap if $scene.is_a?(Scene_Map)
    pokeicon.update
    if Input.trigger?(Input::C) || Input.trigger?(Input::B)
      pbPlayCancelSE()
      break
    elsif Input.scroll_v > 0 || Input.trigger?(Input::UP) # Move up
      pbPlayCursorSE()
      ret[0] = -1
    elsif Input.scroll_v < 0 || Input.trigger?(Input::DOWN) # Move down
      pbPlayCursorSE()
      ret[0] = 1
    elsif Input.trigger?(Input::L)
      pbPlayCursorSE()
      ret[0] = Input.press?(Input::SHIFT) ? -50 : -10
    elsif Input.trigger?(Input::R)
      pbPlayCursorSE()
      ret[0] = Input.press?(Input::SHIFT) ? 50 : 10
    end

    if Input.trigger?(Input::LEFT)
      if $cache.pkmn[species].forms.length != 1
        pbPlayCursorSE()
        ret[1] = -1
      end
    elsif Input.trigger?(Input::RIGHT)
      if $cache.pkmn[species].forms.length != 1
        pbPlayCursorSE()
        ret[1] = 1
      end
    end

    break if ret != [0, 0]
  end

  pokeicon.dispose
  background.dispose
  overlay.dispose

  return ret
end
