# from cybernavMoveTutor.rb
class MoveTutorScreen
  def initialize(scene)
    @scene = scene
    if $Trainer.numbadges>=4
      pbMoveTutorListAdd(:LAVAPLUME)
      pbMoveTutorListAdd(:AURORABEAM)
      pbMoveTutorListAdd(:DRAGONPULSE)
      pbMoveTutorListAdd(:HELPINGHAND)
      pbMoveTutorListAdd(:SEEDBOMB)
      pbMoveTutorListAdd(:IRONHEAD)
      pbMoveTutorListAdd(:NOBLEROAR)
      pbMoveTutorListAdd(:DISARMINGVOICE)
      pbMoveTutorListAdd(:HEALBELL)
      pbMoveTutorListAdd(:UPROAR)
      pbMoveTutorListAdd(:COVET)
    end
    if $Trainer.numbadges>=8
      pbMoveTutorListAdd(:GIGADRAIN)
      pbMoveTutorListAdd(:TRICK)
      pbMoveTutorListAdd(:THUNDERFANG)
      pbMoveTutorListAdd(:ICEFANG)
      pbMoveTutorListAdd(:FIREFANG)
      pbMoveTutorListAdd(:TELEKINESIS)
      pbMoveTutorListAdd(:BUGBITE)
      pbMoveTutorListAdd(:BOUNCE)
      pbMoveTutorListAdd(:DRILLRUN)
      pbMoveTutorListAdd(:ELECTROWEB)
      pbMoveTutorListAdd(:GASTROACID)
      pbMoveTutorListAdd(:FOCUSENERGY)
      pbMoveTutorListAdd(:SIGNALBEAM)
      pbMoveTutorListAdd(:COACHING)
      pbMoveTutorListAdd(:AQUATAIL)
      pbMoveTutorListAdd(:HYPERVOICE)
      pbMoveTutorListAdd(:ENDEAVOR)
      pbMoveTutorListAdd(:SPIKES)
      pbMoveTutorListAdd(:LASERFOCUS)
    end
    if $Trainer.numbadges>=11
      pbMoveTutorListAdd(:LEAFBLADE)
      pbMoveTutorListAdd(:BUGBUZZ)
      pbMoveTutorListAdd(:IRONTAIL)
      pbMoveTutorListAdd(:AURASPHERE)
      pbMoveTutorListAdd(:POISONFANG)
      pbMoveTutorListAdd(:PSYCHICFANGS)
      pbMoveTutorListAdd(:THUNDERBOLT)
      pbMoveTutorListAdd(:PSYCHIC)
      pbMoveTutorListAdd(:STEALTHROCK)
      pbMoveTutorListAdd(:TOXICSPIKES)
    end
    if $Trainer.numbadges>=13
      pbMoveTutorListAdd(:POWERWHIP)
      pbMoveTutorListAdd(:POLTERGEIST)
      pbMoveTutorListAdd(:BODYPRESS)
      pbMoveTutorListAdd(:GRASSYGLIDE)
      pbMoveTutorListAdd(:RAZORWIND)
      pbMoveTutorListAdd(:SCALD)
      pbMoveTutorListAdd(:GUNKSHOT)
      pbMoveTutorListAdd(:POLLENPUFF)
      pbMoveTutorListAdd(:HEAVYSLAM)
      pbMoveTutorListAdd(:HEATCRASH)
      pbMoveTutorListAdd(:PLAYROUGH)
      pbMoveTutorListAdd(:BIND)
      pbMoveTutorListAdd(:TRIPLEAXEL)
      pbMoveTutorListAdd(:SKYATTACK)
    end
    if $Trainer.numbadges>=15
      pbMoveTutorListAdd(:HURRICANE)
      pbMoveTutorListAdd(:STEELBEAM)
      pbMoveTutorListAdd(:OMINOUSWIND)
      pbMoveTutorListAdd(:HYDROPUMP)
      pbMoveTutorListAdd(:METEORBEAM)
      pbMoveTutorListAdd(:LEAFSTORM)
      pbMoveTutorListAdd(:OUTRAGE)
      pbMoveTutorListAdd(:SUBMISSION)
      pbMoveTutorListAdd(:FISSURE)
      pbMoveTutorListAdd(:HORNDRILL)
      pbMoveTutorListAdd(:DRACOMETEOR)
      pbMoveTutorListAdd(:CLOSECOMBAT)
      pbMoveTutorListAdd(:BRAVEBIRD)
    end
    # rinse and repeat
  end
end