# Show Encounters Mod
# Adds the use of the Badge Card key item to show current available encounters.

# Using the item shows available encounters on the current map with the current available encounter type.
# Current encounter type means land encounters while on land, surf encounters while surfing, etc. 
# No fishing info currently.
# Encounter info is time-sensitive. If it is daytime in your game, it will show daytime encounters, etc.

# Most of this code is from the Rejuv team. Give them a cookie.
# Mod by jmedley

class PokemonEncounters
  def get_enc_types
    return @enctypes
  end
end

ItemHandlers::UseFromBag.add(:BADGECARD,proc{|item|
  enctype = $PokemonEncounters.pbEncounterType
  enctypes = $PokemonEncounters.get_enc_types
  if enctypes.length==0 || enctypes[enctype].nil?
    Kernel.pbMessage(_INTL("No encounters available here!"))
  else
      encounters = []
      chances = []
      message = ""
      enctypes[enctype].keys.each do |key|
        message += key.to_s
        message += ", "
      end
      message = message[0..-3]
      message += "."
      Kernel.pbMessage(_INTL(message))
  end
  next 1 # Continue
})

ItemHandlers::UseInField.add(:BADGECARD,proc{|item|
  enctype = $PokemonEncounters.pbEncounterType
  enctypes = $PokemonEncounters.get_enc_types
  if enctypes.length==0 || enctypes[enctype].nil?
    Kernel.pbMessage(_INTL("No encounters available here!"))
  else
      encounters = []
      chances = []
      message = ""
      enctypes[enctype].keys.each do |key|
        message += key.to_s
        message += ", "
      end
      message = message[0..-3]
      message += "."
      Kernel.pbMessage(_INTL(message))
  end
  next 1 # Continue
})

class PokemonBagScreen
  def pbStartScreen
    @scene.pbStartScene(@bag)
    item=nil
    loop do
      item=@scene.pbChooseItem
      break if item.nil?
      cmdUse=-1
      cmdRegister=-1
      cmdGive=-1
      cmdToss=-1
      cmdRead=-1
      commands=[]
      # Generate command list
      commands[cmdRead=commands.length]=_INTL("Read") if pbIsMail?(item)
      commands[cmdUse=commands.length]=_INTL("Use") if ItemHandlers.hasOutHandler(item) || (pbIsTM?(item) && $Trainer.party.length>0)
      commands[cmdGive=commands.length]=_INTL("Give") if $Trainer.party.length>0 && !pbIsImportantItem?(item)
      commands[cmdToss=commands.length]=_INTL("Toss") if !pbIsImportantItem?(item) || $DEBUG
      if @bag.registeredItems.include?(item)
        commands[cmdRegister=commands.length]=_INTL("Deselect")
      elsif ItemHandlers.hasKeyItemHandler(item)
        commands[cmdRegister=commands.length]=_INTL("Register")
      end
      commands[commands.length]=_INTL("Cancel")
      # Show commands generated above
      itemname=getItemName(item) # Get item name
      command=@scene.pbShowCommands(_INTL("{1} is selected.",itemname),commands)
      if cmdUse>=0 && command==cmdUse # Use item
        ret=pbUseItem(@bag,item,@scene)
        # 0=Item wasn't used; 1=Item used; 2=Close Bag to use in field
        break if ret==2 # End screen
        @scene.pbRefresh
        next
      elsif cmdRead>=0 && command==cmdRead # Read mail
        pbFadeOutIn(99999){
           pbDisplayMail(PokemonMail.new(item,"",""))
        }
      elsif cmdRegister>=0 && command==cmdRegister # Register key item
        if @bag.pbIsRegistered?(item)
          @bag.pbUnregisterItem(item)
        else
          @bag.pbRegisterItem(item)
        end
        @scene.pbRefresh
      elsif cmdGive>=0 && command==cmdGive # Give item to Pokémon
        if $Trainer.pokemonCount==0
          @scene.pbDisplay(_INTL("There is no Pokémon."))
        elsif pbIsImportantItem?(item)
          @scene.pbDisplay(_INTL("The {1} can't be held.",itemname))
        elsif Rejuv && $game_variables[650] > 0 
          @scene.pbDisplay(_INTL("You are not allowed to change the rental team's items."))
        else
          # Give item to a Pokémon
          pbFadeOutIn(99999){
             sscene=PokemonScreen_Scene.new
             sscreen=PokemonScreen.new(sscene,$Trainer.party)
             sscreen.pbPokemonGiveScreen(item)
             @scene.pbRefresh
          }
        end
      elsif cmdToss>=0 && command==cmdToss # Toss item
        qty=@bag.pbQuantity(item)
        helptext=_INTL("Toss out how many {1}(s)?",itemname)
        qty=@scene.pbChooseNumber(helptext,qty)
        if qty>0
          if pbConfirm(_INTL("Is it OK to throw away {1} {2}(s)?",qty,itemname))
            pbDisplay(_INTL("Threw away {1} {2}(s).",qty,itemname))
            qty.times { @bag.pbDeleteItem(item) }
          end
        end
      end
    end
    @scene.pbEndScene
    return item
  end
end