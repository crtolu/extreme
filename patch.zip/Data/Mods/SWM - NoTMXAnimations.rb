def pbHiddenMoveAnimation(pokemon)
	#####MODDED
	return false
	#####/MODDED
end