def pbShowBattleStats(pkmn)
  friend=@battle.battlers[0]
  atksbl="+"  
  atksbl=" " if pkmn.stages[PBStats::ATTACK]<0
  defsbl="+"  
  defsbl=" " if pkmn.stages[PBStats::DEFENSE]<0
  spasbl="+"
  spasbl=" " if pkmn.stages[PBStats::SPATK]<0
  spdsbl="+"
  spdsbl=" " if pkmn.stages[PBStats::SPDEF]<0
  spesbl="+"
  spesbl=" " if pkmn.stages[PBStats::SPEED]<0
  accsbl="+"
  accsbl=" " if pkmn.stages[PBStats::ACCURACY]<0
  evasbl="+"
  evasbl=" " if pkmn.stages[PBStats::EVASION]<0
  c=pkmn.pbCalcCrit
  if c==0
    crit=4
  elsif c==1
    crit=12.5
  elsif c==2
    crit=50
  else 
    crit=100
  end 
  shownmon = pkmn.effects[:Illusion] ? pkmn.effects[:Illusion] : pkmn
  if (!shownmon.type2.nil?) 
    report = [_INTL("Type: {1}/{2}",toProperCase(shownmon.type1),toProperCase(shownmon.type2))]  
  else  
    report = [_INTL("Type: {1}",toProperCase(shownmon.type1))]  
  end
  report.push(_INTL("Level: {1}",pkmn.level))
  report.push(_INTL("Attack:               {1}   {2}{3}",pkmn.pbCalcAttack(),atksbl,pkmn.stages[PBStats::ATTACK]),
              _INTL("Defense:            {1}   {2}{3}",pkmn.pbCalcDefense(),defsbl,pkmn.stages[PBStats::DEFENSE]),
              _INTL("Sp.Attack:        {1}   {2}{3}",pkmn.pbCalcSpAtk(),spasbl,pkmn.stages[PBStats::SPATK]),
              _INTL("Sp.Defense:     {1}   {2}{3}",pkmn.pbCalcSpDef(),spdsbl,pkmn.stages[PBStats::SPDEF]),
              _INTL("Speed:                  {1}   {2}{3}",pkmn.pbSpeed(),spesbl,pkmn.stages[PBStats::SPEED]),
              _INTL("Accuracy:   {1}% {2}{3}",pkmn.pbCalcAcc(),accsbl,pkmn.stages[PBStats::ACCURACY]),
              _INTL("Evasion:       {1}% {2}{3}",pkmn.pbCalcEva(),evasbl,pkmn.stages[PBStats::EVASION]),
              _INTL("Crit. Rate:    {1}%    +{2}/3",crit,c))
  movememory = @battle.ai.getAIMemory(pkmn,true)
  if movememory.length > 0
    report.push(_INTL("Revealed Moves:"))
    for i in movememory
      report.push(_INTL("{1}:  {2} PP left",i.name,i.pp))
    end
  end
  dur=@battle.weatherduration
  dur="Permanent" if @battle.weatherduration<0
  turns="turns"
  turns="" if @battle.weatherduration<0
  if @battle.weather==:RAINDANCE
    weatherreport=_INTL("Weather: Rain, {1} {2}",dur,turns)
    weatherreport=_INTL("Weather: Torrential Rain, {1} {2}",dur,turns) if @battle.state.effects[:HeavyRain]
  elsif @battle.weather==:SUNNYDAY
    weatherreport=_INTL("Weather: Sun, {1} {2}",dur,turns)
    weatherreport=_INTL("Weather: Scorching Sun, {1} {2}",dur,turns) if @battle.state.effects[:HarshSunlight]
  elsif @battle.weather==:SANDSTORM
    weatherreport=_INTL("Weather: Sandstorm, {1} {2}",dur,turns)
  elsif @battle.weather==:HAIL
    weatherreport=_INTL("Weather: Hail, {1} {2}",dur,turns)
  elsif @battle.weather==:STRONGWINDS
    weatherreport=_INTL("Weather: Strong Winds, {1} {2}",dur,turns)
  elsif @battle.weather==:SHADOWSKY
    weatherreport=_INTL("Weather: Shadow Sky, {1} {2}",dur,turns)
  end
  report.push(_INTL("Held Item: {1}", pkmn.item ? getItemName(pkmn.item) : _INTL("No item")))
  report.push(_INTL("Recycle Item: {1}", getItemName(pkmn.pokemon.itemRecycle))) if pkmn.pokemon.itemRecycle
  report.push(weatherreport) if @battle.weather!=0
  report.push(_INTL("Slow Start: {1} turns",(5-pkmn.turncount))) if pkmn.ability == (:SLOWSTART) && pkmn.turncount<=5 && (pkmn == @battle.battlers[0] || pkmn == @battle.battlers[2])
  report.push(_INTL("Throat Chop: {1} turns",pkmn.effects[:ThroatChop])) if pkmn.effects[:ThroatChop]!=0
  report.push(_INTL("Unburdened")) if pkmn.unburdened && (pkmn == @battle.battlers[0] || pkmn == @battle.battlers[2]) && pkmn.ability == (:UNBURDEN)
  report.push(_INTL("Speed Swap")) if pkmn.effects[:SpeedSwap]!=0
  report.push(_INTL("Burn Up")) if pkmn.effects[:BurnUp]
  report.push(_INTL("Soaked")) if pkmn.effects[:Soak]
  report.push(_INTL("Uproar: {1} turns",pkmn.effects[:Uproar])) if pkmn.effects[:Uproar]!=0
  report.push(_INTL("Truant")) if pkmn.effects[:Truant] && (pkmn == @battle.battlers[0] || pkmn == @battle.battlers[2]) && pkmn.ability == (:TRUANT)
  report.push(_INTL("Toxic: {1} turns",pkmn.effects[:Toxic])) if pkmn.effects[:Toxic]!=0
  report.push(_INTL("Torment")) if pkmn.effects[:Torment]
  report.push(_INTL("Miracle Eye")) if pkmn.effects[:MiracleEye]
  report.push(_INTL("Minimized")) if pkmn.effects[:Minimize]
  report.push(_INTL("Recharging")) if pkmn.effects[:HyperBeam]!=0
  report.push(_INTL("Fury Cutter: +{1}",pkmn.effects[:FuryCutter])) if pkmn.effects[:FuryCutter]!=0
  report.push(_INTL("Echoed Voice: +{1}",pkmn.effects[:EchoedVoice])) if pkmn.effects[:EchoedVoice]!=0
  report.push(_INTL("Mean Look")) if pkmn.effects[:MeanLook]>-1
  report.push(_INTL("Foresight")) if pkmn.effects[:Foresight]
  report.push(_INTL("Follow Me")) if pkmn.effects[:FollowMe]
  report.push(_INTL("Rage Powder")) if pkmn.effects[:RagePowder]
  report.push(_INTL("Flash Fire")) if pkmn.effects[:FlashFire]
  report.push(_INTL("Substitute")) if pkmn.effects[:Substitute]!=0
  report.push(_INTL("Perish Song: {1} turns",pkmn.effects[:PerishSong])) if pkmn.effects[:PerishSong]>0
  report.push(_INTL("Leech Seed")) if pkmn.effects[:LeechSeed]>-1
  report.push(_INTL("Gastro Acid")) if pkmn.effects[:GastroAcid]
  report.push(_INTL("Curse")) if pkmn.effects[:Curse]
  report.push(_INTL("Nightmare")) if pkmn.effects[:Nightmare]
  report.push(_INTL("Confused")) if pkmn.effects[:Confusion]!=0
  report.push(_INTL("Aqua Ring")) if pkmn.effects[:AquaRing]
  report.push(_INTL("Ingrain")) if pkmn.effects[:Ingrain]
  report.push(_INTL("Power Trick")) if pkmn.effects[:PowerTrick]
  report.push(_INTL("Smacked Down")) if pkmn.effects[:SmackDown]
  report.push(_INTL("Sheltered")) if pkmn.effects[:Shelter]
  report.push(_INTL("Quark Drive active")) if pkmn.effects[:Quarkdrive][0]!=0
  report.push(_INTL("Air Balloon")) if pkmn.hasWorkingItem(:AIRBALLOON)
  report.push(_INTL("Magnet Rise: {1} turns",pkmn.effects[:MagnetRise])) if pkmn.effects[:MagnetRise]!=0
  report.push(_INTL("Telekinesis: {1} turns",pkmn.effects[:Telekinesis])) if pkmn.effects[:Telekinesis]!=0
  report.push(_INTL("Heal Block: {1} turns",pkmn.effects[:HealBlock])) if pkmn.effects[:HealBlock]!=0
  report.push(_INTL("Embargo: {1} turns",pkmn.effects[:Embargo])) if pkmn.effects[:Embargo]!=0
  report.push(_INTL("Disable: {1} turns",pkmn.effects[:Disable])) if pkmn.effects[:Disable]!=0
  report.push(_INTL("Encore: {1} turns",pkmn.effects[:Encore])) if pkmn.effects[:Encore]!=0
  report.push(_INTL("Taunt: {1} turns",pkmn.effects[:Taunt])) if pkmn.effects[:Taunt]!=0
  report.push(_INTL("Infatuated with {1}",@battle.battlers[pkmn.effects[:Attract]].name)) if pkmn.effects[:Attract]>=0
  report.push(_INTL("Trick Room: {1} turns",@battle.trickroom)) if @battle.trickroom!=0
  dur=@battle.state.effects[:Gravity]
  dur="Permanent" if @battle.state.effects[:Gravity]<0
  turns="turns"
  turns="" if @battle.state.effects[:Gravity]<0
  report.push(_INTL("Gravity: {1} {2}",dur,turns)) if @battle.state.effects[:Gravity]!=0  
  report.push(_INTL("Tailwind: {1} turns",pkmn.pbOwnSide.effects[:Tailwind])) if pkmn.pbOwnSide.effects[:Tailwind]>0   
  report.push(_INTL("Reflect: {1} turns",pkmn.pbOwnSide.effects[:Reflect])) if pkmn.pbOwnSide.effects[:Reflect]>0
  report.push(_INTL("Light Screen: {1} turns",pkmn.pbOwnSide.effects[:LightScreen])) if pkmn.pbOwnSide.effects[:LightScreen]>0
  report.push(_INTL("Aurora Veil: {1} turns",pkmn.pbOwnSide.effects[:AuroraVeil])) if pkmn.pbOwnSide.effects[:AuroraVeil]>0
  report.push(_INTL("Arenite Wall: {1} turns",pkmn.pbOwnSide.effects[:AreniteWall])) if pkmn.pbOwnSide.effects[:AreniteWall]>0
  report.push(_INTL("Atlantis Wall: {1} turns",pkmn.pbOwnSide.effects[:AtlantisWall])) if pkmn.pbOwnSide.effects[:AtlantisWall]>0
  report.push(_INTL("Safeguard: {1} turns",pkmn.pbOwnSide.effects[:Safeguard])) if pkmn.pbOwnSide.effects[:Safeguard]>0
  report.push(_INTL("Lucky Chant: {1} turns",pkmn.pbOwnSide.effects[:LuckyChant])) if pkmn.pbOwnSide.effects[:LuckyChant]>0
  report.push(_INTL("Mist: {1} turns",pkmn.pbOwnSide.effects[:Mist])) if pkmn.pbOwnSide.effects[:Mist]>0 
  #report.push(_INTL("Altered Field: {1} turns",@battle.state.effects[:Terrain])) if @battle.state.effects[:Terrain]>0
  #report.push(_INTL("Messed up Field: {1} turns",@battle.state.effects[:Splintered])) if @battle.state.effects[:Splintered]>0  
  report.push(_INTL("Electric overlay: {1} turns",@battle.state.effects[:ELECTERRAIN])) if @battle.state.effects[:ELECTERRAIN]>0  
  report.push(_INTL("Grassy overlay: {1} turns",@battle.state.effects[:GRASSY])) if @battle.state.effects[:GRASSY]>0
  report.push(_INTL("Misty overlay: {1} turns",@battle.state.effects[:MISTY])) if @battle.state.effects[:MISTY]>0
  report.push(_INTL("Psychic overlay: {1} turns",@battle.state.effects[:PSYTERRAIN])) if @battle.state.effects[:PSYTERRAIN]>0
  report.push(_INTL("Rainbow overlay: {1} turns",@battle.state.effects[:RAINBOW])) if @battle.state.effects[:RAINBOW]>0
  report.push(_INTL("Starlight overlay: {1} turns",@battle.state.effects[:STARLIGHT])) if @battle.state.effects[:STARLIGHT]>0
  report.push(_INTL("Icy overlay: {1} turns",@battle.state.effects[:ICY])) if @battle.state.effects[:ICY]>0
  report.push(_INTL("DCC overlay: {1} turns",@battle.state.effects[:DARKCRYSTALCAVERN])) if @battle.state.effects[:DARKCRYSTALCAVERN]>0
  report.push(_INTL("Corrosive overlay: {1} turns",@battle.state.effects[:CORROSIVE])) if @battle.state.effects[:CORROSIVE]>0
  report.push(_INTL("Volcanic overlay: {1} turns",@battle.state.effects[:VOLCANIC])) if @battle.state.effects[:VOLCANIC]>0
  report.push(_INTL("Swamp overlay: {1} turns",@battle.state.effects[:SWAMP])) if @battle.state.effects[:SWAMP]>0
  report.push(_INTL("Magic Room: {1} turns",@battle.state.effects[:MagicRoom])) if @battle.state.effects[:MagicRoom]>0
  report.push(_INTL("Wonder Room: {1} turns",@battle.state.effects[:WonderRoom])) if @battle.state.effects[:WonderRoom]>0
  report.push(_INTL("Water Sport: {1} turns",@battle.state.effects[:WaterSport])) if @battle.state.effects[:WaterSport]>0
  report.push(_INTL("Mud Sport: {1} turns",@battle.state.effects[:MudSport])) if @battle.state.effects[:MudSport]>0
  report.push(_INTL("Spikes: {1} layers",pkmn.pbOwnSide.effects[:Spikes])) if pkmn.pbOwnSide.effects[:Spikes]>0
  report.push(_INTL("Toxic Spikes: {1} layers",pkmn.pbOwnSide.effects[:ToxicSpikes])) if pkmn.pbOwnSide.effects[:ToxicSpikes]>0
  report.push(_INTL("Stealth Rock active")) if pkmn.pbOwnSide.effects[:StealthRock]
  report.push(_INTL("Sticky Web active")) if pkmn.pbOwnSide.effects[:StickyWeb]
  report.push()
  report.push(_INTL("Ability: {1}",pkmn.ability.nil? ? "Ability Negated" : getAbilityName(shownmon.ability)))
  report.push(_INTL("Wonder Room Stat Swap active")) if pkmn.wonderroom==true
  report.push(_INTL("Field effect: {1}", @battle.field.isFieldEffect? ? PokeBattle_Field.getFieldName(@battle.field.effect) : "No Field"))
  @participants = @battle.pbPartySingleOwner(pkmn.index).find_all {|mon| mon && !mon.isEgg? && mon.hp>0}
  report.push(_INTL("Remaining Pokemon: {1} ",@participants.length))
  Kernel.pbMessage((_INTL"Inspecting {1}:",pkmn.name),report, report.length)
end