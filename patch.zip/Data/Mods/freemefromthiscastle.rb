class MapMetadata
  alias :freemefromthiscastle_Outdoor :Outdoor

  def Outdoor
    # Reldin
    return true if mapid == 579 && $game_map && $game_map.map_id == mapid && $game_player && (20..27).include?($game_player.x) && (47..51).include?($game_player.y)
    # Castle of Goomidra
    return true if mapid == 602 && $game_map && $game_map.map_id == mapid && $game_player && (60..119).include?($game_player.x) && (0..59).include?($game_player.y)
    return freemefromthiscastle_Outdoor
  end
end