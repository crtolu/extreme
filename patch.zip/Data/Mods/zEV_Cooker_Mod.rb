# EV Cooker Mod
# Adds the use of a custom item (default: POKEBALL) to customize EVs, abilities, natures, IVs, and hidden power types of party pokemon
# Mimics the behavior of the custom Macho Brace from LAWDS (without pulse3)

# Most of this code is from the Rejuv/LAWDS team. Give them a cookie.
# Mod by jmedley


# Custom item: set to whatever you want
EV_COOKER_ITEM = :MACHOBRACE
# EV_COOKER_ITEM = :MACHOBRACE
# EV_COOKER_ITEM = :GREATBALL


# Bag.rb change
# Allow registering item even if not in key item pocket
class PokemonBagScreen
  def pbStartScreen
    @scene.pbStartScene(@bag)
    item=nil
    loop do
      item=@scene.pbChooseItem
      break if item.nil?
      cmdUse=-1
      cmdRegister=-1
      cmdGive=-1
      cmdToss=-1
      cmdRead=-1
      commands=[]
      # Generate command list
      commands[cmdRead=commands.length]=_INTL("Read") if pbIsMail?(item)
      commands[cmdUse=commands.length]=_INTL("Use") if ItemHandlers.hasOutHandler(item) || (pbIsTM?(item) && $Trainer.party.length>0)
      commands[cmdGive=commands.length]=_INTL("Give") if $Trainer.party.length>0 && !pbIsImportantItem?(item)
      commands[cmdToss=commands.length]=_INTL("Toss") if !pbIsImportantItem?(item) || $DEBUG
      if @bag.registeredItems.include?(item)
        commands[cmdRegister=commands.length]=_INTL("Deselect")

      # mod: get rid of key item requirement, register any item with handler
      elsif ItemHandlers.hasKeyItemHandler(item) #  && pbIsKeyItem?(item)
        commands[cmdRegister=commands.length]=_INTL("Register")
      end
      commands[commands.length]=_INTL("Cancel")
      # Show commands generated above
      itemname=getItemName(item) # Get item name
      command=@scene.pbShowCommands(_INTL("{1} is selected.",itemname),commands)
      if cmdUse>=0 && command==cmdUse # Use item
        ret=pbUseItem(@bag,item,@scene)
        # 0=Item wasn't used; 1=Item used; 2=Close Bag to use in field
        break if ret==2 # End screen
        @scene.pbRefresh
        next
      elsif cmdRead>=0 && command==cmdRead # Read mail
        pbFadeOutIn(99999){
           pbDisplayMail(PokemonMail.new(item,"",""))
        }
      elsif cmdRegister>=0 && command==cmdRegister # Register key item
        if @bag.pbIsRegistered?(item)
          @bag.pbUnregisterItem(item)
        else
          @bag.pbRegisterItem(item)
        end
        @scene.pbRefresh
      elsif cmdGive>=0 && command==cmdGive # Give item to Pokémon
        if $Trainer.pokemonCount==0
          @scene.pbDisplay(_INTL("There is no Pokémon."))
        elsif pbIsImportantItem?(item)
          @scene.pbDisplay(_INTL("The {1} can't be held.",itemname))
        elsif Rejuv && $game_variables[650] > 0
          @scene.pbDisplay(_INTL("You are not allowed to change the rental team's items."))
        else
          # Give item to a Pokémon
          pbFadeOutIn(99999){
             sscene=PokemonScreen_Scene.new
             sscreen=PokemonScreen.new(sscene,$Trainer.party)
             sscreen.pbPokemonGiveScreen(item)
             @scene.pbRefresh
          }
        end
      elsif cmdToss>=0 && command==cmdToss # Toss item
        qty=@bag.pbQuantity(item)
        helptext=_INTL("Toss out how many {1}(s)?",itemname)
        qty=@scene.pbChooseNumber(helptext,qty)
        if qty>0
          if pbConfirm(_INTL("Is it OK to throw away {1} {2}(s)?",qty,itemname))
            pbDisplay(_INTL("Threw away {1} {2}(s).",qty,itemname))
            qty.times { @bag.pbDeleteItem(item) }
          end
        end
      end
    end
    @scene.pbEndScene
    return item
  end
end


# ItemEffects.rb changes
# LAWDS macho brace behavior with custom item
def ev_cooker(item,scene)
  pbFadeOutIn(99999){
    scene=PokemonScreen_Scene.new
    screen=PokemonScreen.new(scene,$Trainer.party)
    screen.pbStartScene(_INTL("Use on which Pokémon?"),false)
    loop do
      scene.pbSetHelpText(_INTL("Use on which Pokémon?"))
      chosen=screen.pbChoosePokemon
      if chosen>=0
        pkmn=$Trainer.party[chosen]
        stats=STATSTRINGS
        cmd=0
        loop do
      if $game_variables[:DifficultyModes]==2
      cmd=scene.pbShowCommands(_INTL("What stats would you like to set?"),[
        _INTL("Set Ability"),
        _INTL("Set EVs"),
        _INTL("Set Nature"),
        _INTL("Set Hidden Power")],cmd)
      cmd +=1 if cmd > 1
      else
      cmd=scene.pbShowCommands(_INTL("What stats would you like to set?"),[
        _INTL("Set Ability"),
        _INTL("Set EVs"),
        _INTL("Set IVs"),
        _INTL("Set Nature"),
        _INTL("Set Hidden Power")],cmd)
      end
      case cmd
        # Break
        when -1
          break
        # Set Ability
        when 0
          cmd2=0
          loop do
            abils=pkmn.getAbilityList
            cmd2 = abils.find_index { |abil| pkmn.ability==abil }
            cmd2 = 0 if cmd2.nil?
            commands=[]
            for i in 0..abils.length-1
              commands.push(getAbilityName(abils[i]))
            end
            msg=_INTL("Current Ability is {1}.",getAbilityName(pkmn.ability))
            cmd2=scene.pbShowCommands(msg,commands,cmd2)
            # Break
            if cmd2==-1
              break
            # Set ability override
            elsif cmd2>=0 && cmd2<abils.length
              pkmn.setAbility(abils[cmd2])
            end
            scene.pbHardRefresh
          end
         # Set EVs
        when 1
          cmd2=0
          loop do
            if pkmn.isShadow?
              scene.pbDisplay(_INTL("Shadow Pokemon cannot gain EVs."))
              break
            end
            evcommands=[]
      evs = pkmn.ev
      statnums = [pkmn.totalhp, pkmn.attack, pkmn.defense, pkmn.spatk, pkmn.spdef, pkmn.speed]
      if $game_variables[:DifficultyModes]==2
      stats = ["HP", "Offense", "Defense", "Sp. Defense", "Speed"]
      evs = [evs[0],evs[1],evs[2],evs[4],evs[5]]
      end
            for i in 0...stats.length
              evcommands.push(stats[i]+" (#{evs[i]})")
            end
      evcommands.push("Zero all")
      promptString = _INTL("HP:                  {1} \nAttack:      {2}\nDefense:   {3}\nSp.Atk:       {4}\nSp.Def:       {5} \nSpeed:        {6}", statnums[0],statnums[1],statnums[2],statnums[3],statnums[4],statnums[5])
            cmd2=scene.pbShowCommands(promptString,evcommands,cmd2)
            if cmd2==-1
              break
            elsif cmd2>=0 && cmd2<stats.length
      statindex = $game_variables[:DifficultyModes]==2 && cmd2 > 2 ? cmd2+1 : cmd2
          cmd3 = scene.pbShowCommands(_INTL("Do what to the EV?"),["Set to max", "Set to zero", "Set manually"])
          case cmd3
          when -1
        break
          when 0
        if $game_switches[:No_Total_EV_Cap]
                pkmn.ev[statindex]=252
        else
          evsLeft = 510 - pkmn.ev.sum
          evsLeft = evsLeft + pkmn.ev[3] if $game_variables[:DifficultyModes]==2
          newEV = [252,pkmn.ev[statindex]+evsLeft].min
          pkmn.ev[statindex]=newEV

        end
          when 1
              pkmn.ev[statindex]=0
          when 2
                  params=ChooseNumberParams.new
                  params.setRange(0,252)
                  params.setDefaultValue(pkmn.ev[statindex])
                  params.setCancelValue(pkmn.ev[statindex])
                  f=Kernel.pbMessageChooseNumber(_INTL("Set the EV for {1} (max. 252).",stats[statindex]),params) { scene.pbHardRefresh }
                  pkmn.ev[statindex]=f
          end
              pkmn.ev[3] = pkmn.ev[1] if $game_variables[:DifficultyModes]==2
            elsif cmd2==stats.length
              pkmn.ev=[0,0,0,0,0,0]
            end
      #LAWDS - Do sanity checking on EVs
              evTotal = 0
              gone_over = false
              if !$game_switches[:No_Total_EV_Cap]
                for i in 0..5
      next if $game_variables[:DifficultyModes]==2 && i==3
                  evTotal += pkmn.ev[i]
                  if evTotal > 510 && gone_over == false
                    amt_over = evTotal - 510
                    pkmn.ev[i] = pkmn.ev[i] - amt_over
                    gone_over = true
                  elsif gone_over == true
                    pkmn.ev[i] = 0
                  end
                end
               end
        pkmn.totalhp
              pkmn.calcStats
              scene.pbHardRefresh
          end
        # Set IVs
        when 2
    if $game_variables[:DifficultyModes]==2
              scene.pbDisplay(_INTL("IVs are forced to 31 in Awesome Mode."))
              break
          end
          cmd2=0
          loop do
            hiddenpower=pbHiddenPower(pkmn)
            msg=_INTL("Hidden Power:\n{1}",getTypeName(hiddenpower))
            ivcommands=[]
            for i in 0...stats.length
              ivcommands.push(stats[i]+" (#{pkmn.iv[i]})")
            end
            ivcommands.push(_INTL("Randomise all"))
            cmd2=scene.pbShowCommands(msg,ivcommands,cmd2)
            if cmd2==-1
              break
            elsif cmd2>=0 && cmd2<stats.length
              params=ChooseNumberParams.new
              params.setRange(0,31)
              params.setDefaultValue(pkmn.iv[cmd2])
              params.setCancelValue(pkmn.iv[cmd2])
              f=Kernel.pbMessageChooseNumber(
                _INTL("Set the IV for {1} (max. 31).",stats[cmd2]),params) { scene.pbHardRefresh }
              pkmn.iv[cmd2]=f
              pkmn.calcStats
              scene.pbHardRefresh
            elsif cmd2==ivcommands.length-1
              pkmn.iv[0]=rand(32)
              pkmn.iv[1]=rand(32)
              pkmn.iv[2]=rand(32)
              pkmn.iv[3]=rand(32)
              pkmn.iv[4]=rand(32)
              pkmn.iv[5]=rand(32)
              pkmn.calcStats
              scene.pbHardRefresh
            end
          end
        when 3 # Nature
    cmd-=1 if $game_variables[:DifficultyModes]==2
          cmd2=0
          loop do
            oldnature=pkmn.nature
            commands=[]
            (PBNatures.getCount).times do |i|
              commands.push(getLAWDSNatureNameAndStatString(i))
            end
            msg=[_INTL("Current Nature is {1}.",oldnature),
                 _INTL("Current Nature is {1}.",oldnature)][pkmn.natureflag ? 1 : 0]
            cmd2=scene.pbShowCommands(msg,commands,cmd2)
            # Break
            if cmd2==-1
              break
            # Set nature override
            elsif cmd2>=0 && cmd<PBNatures.getCount
              pkmn.setNature(getLAWDSNatureName(cmd2).intern.upcase)
              pkmn.calcStats
            end
            scene.pbHardRefresh
          end
        when 4 # Hidden Power
    cmd-=1 if $game_variables[:DifficultyModes]==2
          HiddenPowerChanger(pkmn)
        end
      end
      else
        ret=false
        break
      end
    end
    screen.pbEndScene
  }
end


# Allow use of LAWDS macho brace / custom item from field
ItemHandlers::UseInField.add(EV_COOKER_ITEM, proc {|item,scene|
  ev_cooker(item,scene)
})

# Allow use of LAWDS macho brace / custom item from bag
ItemHandlers::UseFromBag.add(EV_COOKER_ITEM, proc {|item,scene|
  ev_cooker(item,scene)
})

# PBConstants.rb (LAWDS) nature description text
def getLAWDSNatureName(id)
  names=[
    _INTL("Hardy"),
    _INTL("Lonely"),
    _INTL("Brave"),
    _INTL("Adamant"),
    _INTL("Naughty"),
    _INTL("Docile"), # docile <-> bold
    _INTL("Bold"),
    _INTL("Relaxed"),
    _INTL("Impish"),
    _INTL("Lax"),
    _INTL("Serious"), # serious -> timid, timid -> hasty, hasty -> serious
    _INTL("Timid"),
    _INTL("Hasty"),
    _INTL("Jolly"),
    _INTL("Naive"),
    _INTL("Bashful"), # bashful -> modest, modest -> mild, mild -> quiet, quiet -> modest
    _INTL("Modest"),
    _INTL("Mild"),
    _INTL("Quiet"),
    _INTL("Rash"),
    _INTL("Quirky"), # quirky -> calm, calm -> gentle, gentle -> sassy, sassy -> careful, careful -> quirky 
    _INTL("Calm"),
    _INTL("Gentle"),
    _INTL("Sassy"),
    _INTL("Careful")
  ]
  return names[id]
end

def getLAWDSNatureNameAndStatString(id) # LAWDS - used for macho brace
  name_stat_string=[
    _INTL("Neutral"),
    _INTL("(+Atk  -Def)"),
    _INTL("(+Atk  -Spe)"),
    _INTL("(+Atk  -SpA)"),
    _INTL("(+Atk  -SpD)"),
    _INTL("Neutral 2"), # docile <-> bold
    _INTL("(+Def  -Atk)"),
    _INTL("(+Def  -Spe)"),
    _INTL("(+Def  -SpA)"),
    _INTL("(+Def  -SpD)"),
    _INTL("Neutral 3"), # serious -> timid, timid -> hasty, hasty -> serious
    _INTL("(+Spe  -Atk)"),
    _INTL("(+Spe  -Def)"),
    _INTL("(+Spe  -SpA)"),
    _INTL("(+Spe  -SpD)"),
    _INTL("Neutral 4"), # bashful -> modest, modest -> mild, mild -> quiet, quiet -> modest
    _INTL("(+SpA  -Atk)"),
    _INTL("(+SpA  -Def)"),
    _INTL("(+SpA  -Spe)"),
    _INTL("(+SpA  -SpD)"),
    _INTL("Neutral 5"), # quirky -> calm, calm -> gentle, gentle -> sassy, sassy -> careful, careful -> quirky 
    _INTL("(+SpD  -Atk)"),
    _INTL("(+SpD  -Def)"),
    _INTL("(+SpD  -Spe)"),
    _INTL("(+SpD  -SpA)")
 ]
 return name_stat_string[id]
end

