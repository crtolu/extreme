# Put The Fries In The Bag Mod

# Aka PC Remove Held Item On Swap Or Place Mod
# Swapping or placing a pokemon in a PC box removes its held item and puts it in the bag

# Excludes crests, mega stones, z crystals, legendary form-changing held items like griseous orb, silvally memories, and plates held by an Arceus 
# Exclude additional items with customizable exclusion list

# mod by jmedley

class PokemonStorageScene
  def pbSwap(selected,heldpoke)
    heldpokesprite=@sprites["arrow"].heldPokemon
    boxpokesprite=nil
    if selected[0]==-1
      boxpokesprite=@sprites["boxparty"].getPokemon(selected[1])
    else
      boxpokesprite=@sprites["box"].getPokemon(selected[1])
    end
    if selected[0]==-1
      @sprites["boxparty"].setPokemon(selected[1],heldpokesprite)
    else
      # mod added
      @screen.mod_remove_item(heldpoke)
      # end mod added
      @sprites["box"].setPokemon(selected[1],heldpokesprite)
    end
    @sprites["arrow"].setSprite(boxpokesprite)
    @sprites["pokemon"].mosaic=10
    @boxForMosaic=@storage.currentBox
    @selectionForMosaic=selected[1]
    pbSEPlay("storageUp")
    pbSEPlay("storageDown")
  end

  def pbStore(selected,heldpoke,destbox,firstfree)
    if heldpoke
      if destbox==@storage.currentBox
        #pls remove
        @screen.mod_remove_item(heldpoke)
        heldpokesprite=@sprites["arrow"].heldPokemon
        @sprites["box"].setPokemon(firstfree,heldpokesprite)
        @sprites["arrow"].setSprite(nil)
      else
        @sprites["arrow"].deleteSprite
      end
    else
      sprite=@sprites["boxparty"].getPokemon(selected[1])
      if destbox==@storage.currentBox
        #pls remove
        @screen.mod_remove_item(@storage[*selected])
        @sprites["box"].setPokemon(firstfree,sprite)
        @sprites["boxparty"].setPokemon(selected[1],nil)
      else
        @sprites["boxparty"].deletePokemon(selected[1])
      end
    end
  end
  
  def pbPlace(selected,heldpoke)
    heldpokesprite=@sprites["arrow"].heldPokemon
    @sprites["arrow"].place
    while @sprites["arrow"].placing?
      Graphics.update
      Input.update
      pbUpdateSpriteHash(@sprites)
    end
    if selected[0]==-1
      @sprites["boxparty"].setPokemon(selected[1],heldpokesprite)
    else
      # mod added
      @screen.mod_remove_item(heldpoke)
      # end mod added
      @sprites["box"].setPokemon(selected[1],heldpokesprite)
    end
    @boxForMosaic=@storage.currentBox
    @selectionForMosaic=selected[1]
    pbSEPlay("storageDown")
  end
end

class PokemonStorageScreen
  # from pbItem
  def mod_remove_item(pokemon)
    if !pokemon.item.nil?
      # excludedItemsList = [:EXPCANDYL,:EXPCANDYM]
      excludedItemsList = []
      if !excludedItemsList.include?(pokemon.item) && !$cache.items[pokemon.item].checkFlag?(:legendhold) && !$cache.items[pokemon.item].checkFlag?(:crest) && !$cache.items[pokemon.item].checkFlag?(:crystal) && !$cache.items[pokemon.item].checkFlag?(:memory) && !($cache.items[pokemon.item].checkFlag?(:plate) && pokemon.species == :ARCEUS)
        itemname=getItemName(pokemon.item)
        if !$PokemonBag.pbStoreItem(pokemon.item)
          pbDisplay(_INTL("Can't store the {1}.",itemname))
        else
          # pbDisplay(_INTL("Took the {1}.",itemname))
          pokemon.setItem(nil)
          pokemon.form=pokemon.getForm(pokemon)
          # @scene.pbHardRefresh
        end
      end
    end
  end
end