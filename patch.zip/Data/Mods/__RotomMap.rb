ROTOM_MAP_LOCATIONS = [
  { name: "Type: Null",
    mapLocation: [5, 32],
    inGDC: false,
    desc: "Type: Null has been spotted on the Isle of Angels!",
    active: [
      { switch: 10, is: true },
      { map: 540, event: 64, selfswitch: 'A', is: false }
    ]},
  { name: "Cosmoem",
    mapLocation: [11, 42],
    inGDC: false,
    desc: "Beat the Xen Battleship Gauntlet BEFORE beating Amber!",
    active: [
      { var: 181, is: :>=, than: 24 },
      { map: 318, event: 130, selfswitch: 'C', is: false },
      { switch: 11, is: false }
    ]},
  { name: ["Entei", "Raikou", "Suicune"],
    mapLocation: [11, 28],
    inGDC: false,
    desc: "A new path opened up on Valor Cliffside!",
    active: [
      { var: 181, is: :>=, than: 24 },
      { switch: 1969, is: false }
    ]},
  { name: "Manaphy",
    mapLocation: [6, 32],
    inGDC: false,
    desc: "Princess Odessa of Kristiline is asking for someone to help her!",
    active: [
      { switch: 240, is: true },
      { var: 753, is: :<, than: 24 }
    ]},
  { name: ["Zapdos", "Moltres"],
    mapLocation: [26, 26],
    inGDC: false,
    desc: "There's a new Reserve Gym Leader in Goldenleaf...",
    active: [
      { var: 246, is: :>=, than: 50 },
      { switch: 292, is: false },
      { map: 400, event: 84, selfswitch: 'B', is: false }
    ]},
  { name: ["Glastrier", "Spectrier", "Articuno"],
    mapLocation: [21, 29],
    inGDC: false,
    desc: "Unlock the gate at Junction Bridge!",
    active: [
      { map: 238, event: 18, selfswitch: 'C', is: true },
      { switch: 292, is: false },
      { map: 261, event: 3, selfswitch: 'B', is: false }
    ]},
  { name: "Enamorus",
    mapLocation: [21, 29],
    inGDC: false,
    desc: "Someone on Junction Bridge wants to play chess!",
    active: [
      { var: 246, is: :>=, than: 50 },
      { var: 891, is: :<, than: 4 }
    ]},
  { name: "Tapu Fini",
    mapLocation: [25, 33],
    inGDC: true,
    desc: "There's been some noises above Rhodea's Apartment...",
    active: [
      { var: 353, is: :>=, than: 1 },
      { switch: 1995, is: false }
    ]},
  { name: ["Latias", "Latios"],
    mapLocation: [29, 13],
    inGDC: true,
    desc: "Rumors say Shadow Pokemon have invaded the Botanical Garden!",
    active: [
      { var: 353, is: :>=, than: 1 },
      { map: 258, event: 10, selfswitch: 'A', is: false }
    ]},
  { name: ["Tapu Lele", "Mew"],
    mapLocation: [18, 9],
    inGDC: true,
    desc: "A clown in Festival Plaza is apparently running some kind of scam...",
    active: [
      { var: 353, is: :>=, than: 1 },
      { switch: 1972, is: false }
    ]},
  { name: ["Azelf", "Mesprit", "Uxie", "Virizion", "Terrakion", "Cobalion"],
    mapLocation: [36, 23],
    inGDC: true,
    desc: "A sailor is offering a ride to anyone with a Dream Pass...",
    active: [
      { switch: 1995, is: true },
      { var: 889, is: :<, than: 3 }
    ]},
  { name: "Cresselia",
    mapLocation: [28, 34],
    inGDC: true,
    desc: "Someone needs help getting 400 entries in her Pokédex!",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 897, is: :<, than: 2 }
    ]},
  { name: "Volcanion",
    mapLocation: [28, 34],
    inGDC: true,
    desc: "Someone needs help getting 600 entries in her Pokédex!",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 897, is: :<, than: 3 }
    ]},
  { name: ["Diancie", "Xurkitree"],
    mapLocation: [28, 34],
    inGDC: true,
    desc: "Someone needs help getting 750 entries in her Pokédex!",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 897, is: :<, than: 4 }
    ]},
  { name: "Regigigas",
    mapLocation: [28, 34],
    inGDC: true,
    desc: "Someone needs help getting 820 entries in her Pokédex!",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 897, is: :<, than: 5 }
    ]},
  { name: ["Xerneas", "Zacian"],
    mapLocation: [28, 34],
    inGDC: true,
    desc: "Someone needs help getting 900 entries in her Pokédex!",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 897, is: :<, than: 6 }
    ]},
  { name: "G-Articuno",
    mapLocation: [29, 13],
    inGDC: true,
    desc: "Something has been reported in the greenhouse of the Botanical Garden...",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 900, is: :<, than: 1 }
    ]},
  { name: "G-Zapdos",
    mapLocation: [29, 13],
    inGDC: true,
    desc: "Something has been reported in the greenhouse of the Botanical Garden...",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 900, is: :<, than: 2 }
    ]},
  { name: "G-Moltres",
    mapLocation: [29, 13],
    inGDC: true,
    desc: "Something has been reported in the greenhouse of the Botanical Garden...",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 900, is: :<, than: 3 }
    ]},
  { name: "Ting-Lu",
    mapLocation: [29, 13],
    inGDC: true,
    desc: "Something has been reported in the greenhouse of the Botanical Garden...",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 900, is: :<, than: 5 }
    ]},
  { name: "Wo-Chien",
    mapLocation: [29, 13],
    inGDC: true,
    desc: "Something has been reported in the greenhouse of the Botanical Garden...",
    active: [
      { var: 353, is: :>=, than: 1 },
      { var: 900, is: :<, than: 6 }
    ]},
  { name: ["Pecharunt", "Hoopa", "Magearna", "Melmetal", "Regidrago", "Regieleki", "Buzzwole", "Guzzlord"],
    mapLocation: [11, 15],
    inGDC: true,
    desc: "Someone's posted a treasure hunt in GDC's Underground!",
    active: [
      { switch: 293, is: true },
      { map: 624, event: 142, selfswitch: 'B', is: false }
    ]},
  { name: ["Mewtwo", "Calyrex"],
    mapLocation: [15, 17],
    inGDC: false,
    desc: "The Rose Theatre's Kimono Girl, Ayuna, is looking for help!",
    active: [
      { var: 353, is: :>=, than: 52 },
      { var: 425, is: :<, than: 10 }
    ]},
  { name: ["Celebi", "Munkidori"],
    mapLocation: [15, 17],
    inGDC: false,
    desc: "There's a Warden somewhere around Route 9...",
    active: [
      { var: 353, is: :>=, than: 52 },
      { map: 273, event: 93, selfswitch: 'B', is: false }
    ]},
  { name: ["Keldeo", "Okidogi"],
    mapLocation: [15, 17],
    inGDC: false,
    desc: "There's a Warden somewhere around Route 9...",
    active: [
      { var: 353, is: :>=, than: 52 },
      { map: 273, event: 91, selfswitch: 'C', is: false }
    ]},
  { name: ["Meloetta", "Jirachi", "Victini", "Marshadow", "Zeraora", "Heatran"],
    mapLocation: [31, 9],
    inGDC: true,
    desc: "Rumors of a guarded treasure in the Scholar's District...",
    active: [
      { switch: 294, is: true },
      { map: 257, event: 1, selfswitch: 'A', is: false }
    ]},
  { name: ["Miraidon", "Koraidon", "Kyurem"],
    mapLocation: [15, 18],
    inGDC: false,
    desc: "Someone saw a Timesplicer Crystal on the Route 9 beach?",
    active: [
      { switch: 294, is: true },
      { var: 837, is: :<, than: 6 }
    ]},
  { name: "Tapu Koko",
    mapLocation: [11, 21],
    inGDC: false,
    desc: "A challenger has taken up residence in the Kingdom of Goomidra!",
    active: [
      { switch: 295, is: true },
      { map: 600, event: 68, selfswitch: 'C', is: false }
    ]},
  { name: "Tapu Bulu",
    mapLocation: [30, 23],
    inGDC: false,
    desc: "Something strange has happened at Sheridan Arena!",
    active: [
      { switch: 296, is: true },
      { switch: 1966, is: false }
    ]},
  { name: ["Groudon", "Kyogre"],
    mapLocation: [11, 32],
    inGDC: false,
    desc: "There is a menacing aura coming from Mynori Coral Reef...",
    active: [
      { switch: 296, is: true },
      { switch: 758, is: false }
    ]},
  { name: "Single Strike Urshifu",
    mapLocation: [32, 19],
    inGDC: true,
    desc: "The Nightclub has a challenge involving rental teams!",
    active: [
      { switch: 296, is: true },
      { var: 841, is: :<, than: 3 }
    ]},
  { name: ["Dialga", "Palkia"],
    mapLocation: [32, 19],
    inGDC: true,
    desc: "The Nightclub has a challenge involving rental teams!",
    active: [
      { switch: 296, is: true },
      { var: 841, is: :<, than: 9 }
    ]},
  { name: "Arceus",
    mapLocation: [32, 19],
    inGDC: true,
    desc: "The Nightclub has a challenge involving rental teams!",
    active: [
      { switch: 296, is: true },
      { var: 841, is: :<, than: 11 }
    ]},
  { name: ["Landorus-Therian", "Tornadus-Therian", "Thundurus-Therian"],
    mapLocation: [6, 10],
    inGDC: false,
    desc: "A pair of trainers in Zone Zero told me to come back with 14 badges...",
    active: [
      { switch: 296, is: true },
      { switch: 757, is: false }
    ]},
  { name: "Genesect",
    mapLocation: [6, 10],
    inGDC: false,
    desc: "A pair of trainers in Zone Zero told me to come back with 14 badges...",
    active: [
      { switch: 296, is: true },
      { switch: 759, is: false }
    ]},
  { name: ["Dusk Mane Necrozma", "Dawn Wings Necrozma"],
    mapLocation: [3, 7],
    inGDC: false,
    desc: "Reldin Island stands unconquered...",
    active: [
      { switch: 1250, is: true },      
      { map: 579, event: 16, selfswitch: 'B', is: false }
    ]},
  { name: ["Rapid Strike Urshifu", "Zamazenta", "Pheromosa"],
    mapLocation: [22, 23],
    inGDC: false,
    desc: "A treasure awaits in the Third Layer...",
    active: [
      { var: 656, is: :>=, than: 50 },      
      { map: 395, event: 67, selfswitch: 'A', is: false }
    ]},
  { name: "Regice",
    mapLocation: [5, 32],
    inGDC: false,
    desc: "Something changed in the Tower of Theolia...",
    active: [
      { var: 723, is: :>=, than: 6 },      
      { var: 773, is: :<, than: 15 }
    ]},
  { name: "Regirock",
    mapLocation: [31, 22],
    inGDC: false,
    desc: "Something changed in the Garufan Sanctuary...",
    active: [
      { var: 723, is: :>=, than: 6 },      
      { var: 750, is: :<, than: 18 }
    ]},
  { name: "Registeel",
    mapLocation: [18, 6],
    inGDC: true,
    desc: "Something changed in Axis Factory...",
    active: [
      { var: 723, is: :>=, than: 6 },      
      { switch: 1976, is: false }
    ]},
  { name: "Shaymin",
    mapLocation: [22, 29],
    inGDC: false,
    desc: "Adrienn and Aya haven't gotten news on the Parks and Rec Center...",
    active: [
      { var: 723, is: :>=, than: 6 },      
      { var: 798, is: :<, than: 9 }
    ]},
  { name: ["Zarude", "Shaymin-Sky", "Blacephalon"],
    mapLocation: [21, 32],
    inGDC: true,
    desc: "Tolu is waiting for you at Pokestar Studios.",
    active: [
      { switch: 297, is: true },  
      { var: 620, is: :<, than: 77 }
    ]},
  { name: ["Zarude", "Shaymin-Sky", "Blacephalon"],
    mapLocation: [22, 29],
    inGDC: false,
    desc: "Complete Zumi's challenge.",
    active: [
      { switch: 297, is: true },
      { var: 620, is: :>=, than: 73 },
      { var: 620, is: :<, than: 78 }
    ]},
  { name: ["Lugia", "Ho-oh"],
    mapLocation: [6, 4],
    inGDC: false,
    desc: "There's a league challenge in... the Atebit World?!",
    active: [
      { switch: 297, is: true },
      { map: 623, event: 2, selfswitch: 'A', is: false }
    ]},
  { name: ["Yveltal", "Deoxys", "Rayquaza", "Chi-Yu", "Chien-Pao"],
    mapLocation: [6, 4],
    inGDC: false,
    desc: "There's a league challenge in... the Atebit World?!",
    active: [
      { switch: 297, is: true },
      { map: 623, event: 5, selfswitch: 'A', is: false }
    ]},
]

class RotomMapScene < PokemonRegionMapScene

  LIME = [Color.new(0x63, 0xED, 0x71), Color.new(0x1c, 0x7a, 0x24)]
  INVERSE_LIME = [Color.new(0x28, 0xC9, 0x30), Color.new(0xbe, 0xd1, 0xbf)]

  def getInfoboxName
    locations = @builtLocations[@selection]
    return "" unless locations || !locations.empty?

    if locations.size == 1
      return locations[0][0]
    elsif locations.size <= 3
      return locations.map { |it| _INTL(it[0]) }.join("\n")
    else
      return (locations[0...3] + [["..."]]).map { |it| _INTL(it[0]) }.join("\n")
    end
  end

  

  def popup
    locations = @builtLocations[@selection]
    return unless locations || !locations.empty?
    @sprites["namebox"].visible = false
    @sprites["infobox"].visible = true
    @sprites["mapbottom"].maplocation=""
    @sprites["mapbottom"].mapdetails=""

    commands = locations.map { |it| _INTL(it[0]) }
    help = locations.map { |it| _INTL(it[1]) }

    msgwin=@sprites["infobox"]
    cmdwindow=Window_CommandPokemon.new(commands)

    darkWindow = isDarkWindowskin(cmdwindow.windowskin)
    cmdwindow.baseColor, cmdwindow.shadowColor = darkWindow ? LIME : INVERSE_LIME

    cmdwindow.z=99999
    cmdwindow.visible=true
    cmdwindow.resizeToFit(cmdwindow.commands)
    pbPositionNearMsgWindow(cmdwindow,msgwin,:right)
    cmdwindow.index=0
    msgwin.text=help[cmdwindow.index]
    msgwin.width=msgwin.width # Necessary evil to make it use the proper margins.
    loop do
      Graphics.update
      Input.update
      oldindex=cmdwindow.index
      cmdwindow.update
      if oldindex!=cmdwindow.index
        msgwin.text=help[cmdwindow.index]
      end
      msgwin.update
      break if Input.trigger?(Input::B) || Input.trigger?(Input::C)
    end
    cmdwindow.dispose
    Input.update

    @sprites["infobox"].visible = false
    @sprites["namebox"].visible = true
    @sprites["mapbottom"].maplocation=getMapName
    @sprites["mapbottom"].mapdetails=getPOI
  end

  def updateInfoBoxes
    if @builtLocations[@selection]
      @sprites["namebox"].text = getInfoboxName
      @sprites["namebox"].resizeToFit(@sprites["namebox"].text, Graphics.width)
      infoBoxPosition
      @sprites["namebox"].visible = true
      @sprites["cursor"].tone = Tone.new(0, 255, 0, 255)
    else
      @sprites["cursor"].tone = Tone.new(0, 0, 0, 0)
      @sprites["infobox"].visible = false
      @sprites["namebox"].visible = false
    end
  end

  def infoBoxPosition
    @sprites["namebox"].x = (@selection[0] + 1) * SQUAREWIDTH - @viewport.ox + 16 - (@sprites["namebox"].width / 2)
    @sprites["namebox"].y = (@selection[1] + 1) * SQUAREWIDTH - @viewport.oy + 32 - (@sprites["namebox"].height / 2)
    @sprites["namebox"].x = [16, [@sprites["namebox"].x, Graphics.width - @sprites["namebox"].width - 16].min].max
    @sprites["namebox"].y = [32, [@sprites["namebox"].y, Graphics.height - @sprites["namebox"].height - 32].min].max
  end

  def pbStartScene
    @numpoints=0
    @showcursor = true
    @editor=false
    @viewport=Viewport.new(16,32,@MAPWIDTH,@MAPHEIGHT) #Full map dims
    @viewport.z=99999
    @mapoverlay=Viewport.new(0,0,Graphics.width,Graphics.height)
    @mapoverlay.z=99999
    @sprites={}
    @mapdata=$cache.town_map
    if $cache.mapdata[$game_map.map_id].MapPosition.is_a?(Hash)
      playerpos=pbUnpackMapHash
    else
      playerpos=$cache.mapdata[$game_map.map_id].MapPosition
    end
    if !playerpos
      mapindex=0
      @map=@mapdata[0]
      @mapX=LEFT
      @mapY=TOP
    elsif !@region.include?(playerpos[0])
      mapindex = @region[0]
      mapindex = 2 if @region.length > 1
      @map = @mapdata[mapindex]
      @mapX = FAKEMAPSTARTPOS[mapindex][0]
      @mapY = FAKEMAPSTARTPOS[mapindex][1]
    else
      mapindex=playerpos[0]
      @map=@mapdata[@region[0]]
      @mapX=playerpos[1]
      @mapY=playerpos[2]
    end
    @selection = [@mapX, @mapY]

    @builtLocations = rotommap_buildLocations(mapindex)
    
    case mapindex
      when 0 #floria
        @viewport.ox += MAPSTARTPOS[0][0] * SQUAREWIDTH
        @viewport.oy += MAPSTARTPOS[0][1] * SQUAREHEIGHT
      when 1 #terajuma
        @viewport.ox += MAPSTARTPOS[1][0] * SQUAREWIDTH
        @viewport.oy += MAPSTARTPOS[1][1] * SQUAREHEIGHT
      when 2 #terrial
        @viewport.ox += MAPSTARTPOS[2][0] * SQUAREWIDTH
        @viewport.oy += MAPSTARTPOS[2][1] * SQUAREHEIGHT
      when 3 #badlands
        @viewport.ox += MAPSTARTPOS[3][0] * SQUAREWIDTH
        @viewport.oy += MAPSTARTPOS[3][1] * SQUAREHEIGHT
      else
        #do nothing
    end
    
    if @region.length > 1
      @mapX -= MAPSTARTPOS[mapindex][0]
      @mapY -= MAPSTARTPOS[mapindex][1]
    end
    
    if mapindex == 4
      x = (@mapX - SCREENRIGHT/2)
      x = 0 if x < LEFT
      x = @RIGHT - SCREENRIGHT if x > @RIGHT
      y = (@mapY - SCREENBOTTOM/2)
      y = 0 if y < TOP
      y = @BOTTOM - SCREENBOTTOM if y > @BOTTOM
      @viewport.ox += x * SQUAREWIDTH
      @viewport.oy += y * SQUAREHEIGHT
      @mapX -= x
      @mapY -= y
    end

    bg=BitmapWrapper.new(Graphics.width,Graphics.height)
    bg.fill_rect(0,0,Graphics.width,Graphics.height,Color.new(0,0,0))
    bg2 = SpriteWrapper.new(@viewport)
    bg2.bitmap=bg
    @sprites["mapbg"] = bg2
    @sprites["overlay"] = IconSprite.new(0,0,@mapoverlay)
    @sprites["overlay"].setBitmap("Data/Mods/__mapoverlay")
    @sprites["overlay"].z = 99999
    @sprites["map"]=IconSprite.new(0,0,@viewport)
    @sprites["map"].setBitmap("Graphics/Pictures/RegionMap/#{@map[:filename]}")
    for hidden in REGIONMAPEXTRAS #NOT UPDATED - USE AT RISK
      if hidden[0]==mapindex && ((@wallmap && hidden[5]) ||
         (!@wallmap && hidden[1]>0 && $game_switches[hidden[1]]))
        if !@sprites["map2"]
          @sprites["map2"]=BitmapSprite.new(480,320,@viewport)
          @sprites["map2"].x=@sprites["map"].x; @sprites["map2"].y=@sprites["map"].y
        end
        pbDrawImagePositions(@sprites["map2"].bitmap,[
           ["Graphics/Pictures/RegionMap/#{hidden[4]}",hidden[2]*SQUAREWIDTH,hidden[3]*SQUAREHEIGHT,0,0,-1,-1]
        ])
      end
    end
    @sprites["mapbottom"]=MapBottomSprite.new(@mapoverlay)
    @sprites["mapbottom"].mapname=getRegionName
    @sprites["mapbottom"].maplocation=getMapName
    @sprites["mapbottom"].mapdetails=getPOI
    @sprites["mapbottom"].z=99999

    @sprites["namebox"]=Window_UnformattedTextPokemon.new()
    darkWindow = isDarkWindowskin(@sprites["namebox"].windowskin)
    @sprites["namebox"].baseColor, @sprites["namebox"].shadowColor = darkWindow ? LIME : INVERSE_LIME
    @sprites["namebox"].z=99999
    @sprites["namebox"].back_opacity=MessageConfig::WindowOpacity

    @sprites["infobox"]=Window_UnformattedTextPokemon.new()
    @sprites["infobox"].z=99999
    pbBottomLeftLines(@sprites["infobox"],2)
    
    if playerpos && @region.include?(playerpos[0])
      @sprites["player"]=IconSprite.new(0,0,@viewport)
      @sprites["player"].setBitmap(pbPlayerHeadFile($Trainer.trainertype))
      @sprites["player"].x=SQUAREWIDTH * @selection[0]
      @sprites["player"].y=SQUAREHEIGHT * @selection[1]
    end
    k=0
    for i in LEFT..@RIGHT
      for j in TOP..@BOTTOM
        spot=@builtLocations[[i, j]]
        if spot
          @sprites["point#{k}"]=AnimatedSprite.create("Data/Mods/__mapnotice",2,30)
          @sprites["point#{k}"].viewport=@viewport
          @sprites["point#{k}"].x=SQUAREWIDTH * i
          @sprites["point#{k}"].y=SQUAREHEIGHT * j
          @sprites["point#{k}"].play
          k+=1
        end
      end
    end
    @sprites["cursor"]=AnimatedSprite.create("Graphics/Pictures/RegionMap/mapCursor",2,15)
    @sprites["cursor"].viewport=@viewport
    @sprites["cursor"].play
    @sprites["cursor"].x = SQUAREWIDTH * @selection[0]
    @sprites["cursor"].y = SQUAREHEIGHT * @selection[1]

    updateInfoBoxes

    #@sprites["cursor"].x=-SQUAREWIDTH/2+(@mapX*SQUAREWIDTH)+(Graphics.width-@sprites["map"].bitmap.width)/2 + 16
    #@sprites["cursor"].y=-SQUAREHEIGHT/2+(@mapY*SQUAREHEIGHT)+(Graphics.height-@sprites["map"].bitmap.height)/2 + 32
    @changed=false
    pbFadeInAndShow(@sprites){ pbUpdate }
    return true
  end

  def pbMapScene
    xOffset=0
    yOffset=0
    newX=0
    newY=0
    moveMap=false
    ox=0
    oy=0
    mapfocus = false
    mapfocus = true if @showcursor
    loop do
      Graphics.update
      Input.update
      pbUpdate
      if xOffset!=0 || yOffset!=0
        xOffset+=xOffset>0 ? -4 : (xOffset<0 ? 4 : 0)
        yOffset+=yOffset>0 ? -4 : (yOffset<0 ? 4 : 0)
        @sprites["cursor"].x=newX-xOffset
        @sprites["cursor"].y=newY-yOffset
        if @mapY > SCREENBOTTOM || @mapY < TOP
          @mapY -= oy
          @viewport.oy += (oy * SQUAREWIDTH)
        end
        if @mapX > SCREENRIGHT || @mapX < LEFT
          @mapX -= ox
          @viewport.ox += (ox * SQUAREWIDTH)
        end
        @sprites["mapbottom"].maplocation=getMapName
        @sprites["mapbottom"].mapdetails=getPOI
        @sprites["mapbottom"].mapname=getRegionName
        infoBoxPosition
        next
      end
      ox=0
      oy=0
      if mapfocus
        case Input.dir8
          when 1 # lower left
            oy=1 if @selection[1]<@BOTTOM
            ox=-1 if @selection[0]>LEFT
          when 2 # down
            oy=1 if @selection[1]<@BOTTOM
          when 3 # lower right
            oy=1 if @selection[1]<@BOTTOM
            ox=1 if @selection[0]<@RIGHT
          when 4 # left
            ox=-1 if @selection[0]>LEFT
          when 6 # right
            ox=1 if @selection[0]<@RIGHT
          when 7 # upper left
            oy=-1 if @selection[1]>TOP
            ox=-1 if @selection[0]>LEFT
          when 8 # up
            oy=-1 if @selection[1]>TOP
          when 9 # upper right
            oy=-1 if @selection[1]>TOP
            ox=1 if @selection[0]<@RIGHT
        end
      end

      if ox!=0 || oy!=0
        @mapX += ox
        @mapY += oy
        @selection[0] += ox
        @selection[1] += oy
        xOffset=ox*SQUAREWIDTH
        yOffset=oy*SQUAREHEIGHT
        newX=@sprites["cursor"].x+xOffset
        newY=@sprites["cursor"].y+yOffset

        updateInfoBoxes
      end

      if Input.trigger?(Input::B)
        if @basemap
          return @basemap
        else
          if @editor && @changed
            if Kernel.pbConfirmMessage(_INTL("Save changes?")) { pbUpdate }
              pbSaveMapData
            end
            if Kernel.pbConfirmMessage(_INTL("Exit from the map?")) { pbUpdate }
              break
            end
          else
            break
          end
        end
      elsif Input.trigger?(Input::C) 
        submap = getSubMap(@selection) #checking for submaps
        if submap
          return [submap[:mapid],submap[:basemap]]
        end
        popup if @builtLocations[@selection]
      elsif Input.triggerex?(:B) && $INTERNAL
        puts "Pos: [#{@mapX}, #{@mapY}]"
        puts "SelPos: #{@selection.inspect}"
        puts "CurPos: [#{@sprites["cursor"].x}, #{@sprites["cursor"].y}]"
      elsif Input.trigger?(Input::C) && @editor # Intentionally placed after other C button check
        #pbChangeMapLocation(@mapX,@mapY)
      elsif Input.trigger?(Input::PAGEUP) || Input.trigger?(Input::PAGEDOWN)
        if $game_variables[:GDCStory] > 1
          if @region.length > 1
            return 4
          else
            return 0
          end
        end
      end
    end
    return nil
  end
end

class RotomRegionMap
  def initialize(scene)
    @scene=scene
  end

  def pbStartScreen
    @scene.pbStartScene
    ret = @scene.pbMapScene
    @scene.pbEndScene
    return if ret == nil
    while !ret.nil?
      ret = [ret, nil] if ret.is_a?(Integer)
      @scene=RotomMapScene.new(ret[0],true,ret[1])
      @scene.pbStartScene
      ret = @scene.pbMapScene
      @scene.pbEndScene
    end
  end
end

def rotommap_buildLocations(mapindex)
  builtLocations = {}
  return builtLocations unless (0..4).include?(mapindex)
  gdc = mapindex == 4
  for location in ROTOM_MAP_LOCATIONS
    if !(gdc ^ location[:inGDC])
      key = location[:mapLocation]
    elsif location[:inGDC]
      key = [14, 20] # GDC
    else
      next
    end

    inactive = false

    for condition in location[:active]
      if condition[:var]
        state = $game_variables[condition[:var]]
        if condition[:is].is_a?(Proc) && !condition[:is].call(state)
          inactive = true
          break
        elsif condition[:is].is_a?(Symbol) && !state.send(condition[:is], condition[:than])
          inactive = true
          break
        end
      elsif condition[:switch]
        state = $game_switches[condition[:switch]]
        if state != condition[:is]
          inactive = true
          break
        end
      elsif condition[:selfswitch]
        state = $game_self_switches[[condition[:map],condition[:event],condition[:selfswitch]]]
        if state != condition[:is]
          inactive = true
          break
        end
      end
    end

    next if inactive

    builtLocations[key] = [] if !builtLocations[key]
    if location[:name].is_a?(Array)
      location[:name].each {|it| builtLocations[key].push([it, location[:desc]])}
    else
      builtLocations[key].push([location[:name], location[:desc]])
    end
  end

  return builtLocations
end

class Game_System
  attr_accessor :rotommap_legendaries
end

def rotommap_notify
  legendaries = rotommap_buildLocations(0)

  legendarynames = legendaries.values.flat_map { |legs| legs.map { |it| it[0] } }.sort
  
  if $game_system.rotommap_legendaries && !(legendarynames - $game_system.rotommap_legendaries).empty?
    Kernel.pbMessage(_INTL("\\se[SFX - RotomPhone_1]\\f[RotomPhone]Bzzt! New legendaries detected!"))

    $game_system.rotommap_legendaries = legendarynames
  end
end

class Game_Map
  alias :rotommap_old_refresh :refresh

  def refresh
    legendaries = rotommap_buildLocations(0)

    legendarynames = legendaries.values.flat_map { |legs| legs.map { |it| it[0] } }.sort

    if $game_system.rotommap_legendaries && !(legendarynames - $game_system.rotommap_legendaries).empty?
      id = @events.keys.max + 1
      checkEvent = RPG::Event.new(0, 0)
      checkEvent.id = id
      checkEvent.pages[0].list = [
        RPG::EventCommand.new(355, 0, ['rotommap_notify']),
        RPG::EventCommand.new(116, 0, []),
        RPG::EventCommand.new(0, 0, [])
      ]
      checkEvent.pages[0].trigger = 3

      @events[id] = Game_Event.new($game_map.map_id, checkEvent, $game_map)
    end

    rotommap_old_refresh
  end
end

class ItemData < DataObject
  attr_writer :flags
  attr_writer :desc
end

$cache.items[:ROTOMPHONE].flags[:noUse] = false
$cache.items[:ROTOMPHONE].flags[:general] = true
$cache.items[:ROTOMPHONE].desc = "A smartphone that was enhanced with a Rotom! Can show you where legendaries are."

ItemHandlers::UseFromBag.add(:ROTOMPHONE,proc{|item|
  next 2
})
ItemHandlers::UseInField.add(:ROTOMPHONE,proc{|item|
  Kernel.pbMessage(_INTL("\\se[SFX - RotomPhone_1]\\f[RotomPhone]Bzzt! Checking legendary locations now..."))

  legendaries = rotommap_buildLocations(0)

  legendarynames = legendaries.values.flat_map { |legs| legs.map { |it| it[0] } }.sort

  Kernel.pbMessage(_INTL("\\f[RotomPhone]Found {1}!", legendarynames.size))
  pbShowRotomMap
  next 1
})

def pbShowRotomMap(region=0,wallmap=true,basemap=nil)
  pbFadeOutIn(99999) {         
     scene=RotomMapScene.new(region,wallmap,basemap)
     screen=RotomRegionMap.new(scene)
     screen.pbStartScreen
  }
end
