###### MOD Start ######
Events.onSpritesetCreate+=proc{|sender,e|
  map=$game_map
  for event in map.events.values
  	next if $PokemonBag.nil?
  	next if $PokemonBag.pbQuantity(:ITEMFINDER)==0
    #Hidden items not tagged properly Start  
    #58: East Gearen a Rock near the entrance.
    #119: Carotos Mountain, behind a breakable rock, due to event issue, you have to be on top of it to get the item.
    #250: Marble Mansion, on the bench at the maid's side on your second visit. Due to event issue, you have to be on top of it to get the item. (Sprite may not show)
  	if (map.map_id == 58 && event.id == 8) || (map.map_id == 119 && event.id == 17) || (map.map_id == 250 && event.id == 70) 
  		next if $game_self_switches[[map.map_id, event.id, 'A']]
      next if $game_self_switches[[map.map_id, event.id, 'B']]
      next if $game_self_switches[[map.map_id, event.id, 'C']]
      next if $game_self_switches[[map.map_id, event.id, 'D']]
      event.character_name = "ItemFinderUnhideBall"
  		event.through = true
  	end
    #Hidden items not tagged properly End
    next if !(event.name == 'HiddenItem' || event.name == ' HiddenItem' || event.name == 'HiddenItem ')
    next if map.map_id == 48 && event.id == 9
    next if map.map_id == 75 && event.id == 13
    next if $game_self_switches[[map.map_id, event.id, 'A']]
    next if $game_self_switches[[map.map_id, event.id, 'B']]
    next if $game_self_switches[[map.map_id, event.id, 'C']]
    next if $game_self_switches[[map.map_id, event.id, 'D']]
    event.character_name = "ItemFinderUnhideBall"
    event.through = true
  end
}
###### MOD End ######

def pbClosestHiddenItem
  result = []
  playerX = $game_player.x
  playerY = $game_player.y
  ###### MOD Start ######
  map = $game_map
  for event in map.events.values
    if (map.map_id == 58 && event.id == 8) || (map.map_id == 119 && event.id == 17) || (map.map_id == 250 && event.id == 70) 
      next if $game_self_switches[[map.map_id, event.id, 'A']]
      next if $game_self_switches[[map.map_id, event.id, 'B']]
      next if $game_self_switches[[map.map_id, event.id, 'C']]
      next if $game_self_switches[[map.map_id, event.id, 'D']]
      result.push(event)
    end
    next if !(event.name == 'HiddenItem' || event.name == ' HiddenItem' || event.name == 'HiddenItem ')
    next if (playerX-event.x).abs >= 8
    next if (playerY-event.y).abs >= 6
    next if $game_self_switches[[map.map_id, event.id, "A"]]
    next if $game_self_switches[[map.map_id, event.id, "B"]]
    next if $game_self_switches[[map.map_id, event.id, "C"]]
    next if $game_self_switches[[map.map_id, event.id, "D"]]
    ###### MOD End ######
    result.push(event)
  end
  return nil if result.length == 0
  ret = nil
  retmin = 0
  for event in result
    dist = (playerX - event.x).abs + (playerY - event.y).abs
    if !ret || retmin > dist
      ret = event
      retmin = dist
    end
  end
  return ret
end