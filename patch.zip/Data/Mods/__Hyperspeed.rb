$hyperspeed_enabled = false
$hyperspeed_allowed = false

$hyperspeed_frame = 0
Graphics.instance_eval do 
  unless defined?(hyperspeed_old_update)
    alias :hyperspeed_old_update :update
  end

  def update
    $hyperspeed_frame += 1
    return if $hyperspeed_allowed && $hyperspeed_enabled && $hyperspeed_frame % 4 != 0
    hyperspeed_old_update
    $hyperspeed_frame = 0
  end
end

Input.instance_eval do
  unless defined?(hyperspeed_old_update)
    alias :hyperspeed_old_update :update
  end

  def update
    hyperspeed_old_update
    if triggerex?(:F)
      $hyperspeed_enabled = !$hyperspeed_enabled
    end
  end
end

class PokeBattle_Battle
  attr_accessor :speedup_spedup

  alias :hyperspeed_old_initialize :initialize

  def initialize(*args,**kwargs)
    $hyperspeed_allowed = true
    return hyperspeed_old_initialize(*args, **kwargs)
  end

  alias :hyperspeed_old_pbEndOfBattle :pbEndOfBattle

  def pbEndOfBattle(*args, **kwargs)
    $hyperspeed_allowed = false
    return hyperspeed_old_pbEndOfBattle(*args, **kwargs)
  end

end
