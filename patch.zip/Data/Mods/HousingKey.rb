$cache.items[:LOUNGEKEY] = ItemData.new(:LOUNGEKEY, {
  name: "Lounge Key",
  desc: "I do not know what to put here lmao",
  keyitem: true,
  keys: true,
  noUseInBattle: true
})

ItemHandlers::UseFromBag.add(:LOUNGEKEY,proc{|item| next 2 }) # Defer to field use

ItemHandlers::UseInField.add(:LOUNGEKEY,proc{|item|

  if inPast?
    Kernel.pbMessage(_INTL("You cannot access your house in the past!"))
    next
  end
  if $game_switches[:NoFlyZone]
    Kernel.pbMessage(_INTL("You can't use this right now!"))
    next
  end
  if $game_player.pbHasDependentEvents?
    Kernel.pbMessage(_INTL("You can't go home when you have someone with you."))
    next
  end
  if $game_switches[:Riding_Tauros]
    Kernel.pbMessage(_INTL("You can't go home while riding a Pokemon."))
    next
  end
  if !$cache.mapdata[$game_map.map_id].Outdoor && $game_map.map_id != 619 # Interceptor's Realm
    Kernel.pbMessage(_INTL("Can't use that here."))
    next
  end
  if $game_switches[:NotPlayerCharacter]
    Kernel.pbMessage(_INTL("Your house cannot be accessed at this time."))
    next
  end


  if $game_map.map_id == 619 # Interceptor's Realm
    $game_temp.player_new_map_id=$game_variables[467]
    $game_temp.player_new_x=$game_variables[468]
    $game_temp.player_new_y=$game_variables[469]
    $scene.transfer_player if $scene.is_a?(Scene_Map)
    $game_map.refresh
  else
    $game_variables[467] = $game_map.map_id
    $game_variables[468] = $game_player.x
    $game_variables[469] = $game_player.y

    $game_temp.player_new_map_id=619
    $game_temp.player_new_x=30
    $game_temp.player_new_y=05
    $game_temp.player_new_direction=2 # Down
    $scene.transfer_player if $scene.is_a?(Scene_Map)
    $game_map.refresh
  end
  next 2 # Continue
})