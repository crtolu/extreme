# For those pesky moves locked in a egg move, this snippet is based from base game, just rips the requirement for HM02:
# From: Jarred aka Matt
def pbGetRelearnableMoves(pokemon)
  return [] if !pokemon || pokemon.isEgg? || (pokemon.isShadow? rescue false)
  moves=[]
  pbEachNaturalMove(pokemon){|move,level|
    if level<=pokemon.level && !pokemon.knowsMove?(move)
      moves.push(move) if !moves.include?(move)
    end
  }
  tmoves=[]
  if pokemon.firstmoves
    for i in pokemon.firstmoves
      tmoves.push(i) if !pokemon.knowsMove?(i) && !moves.include?(i)
    end
  end
  eggmoves=[]
  if pokemon.getEggMoveList(true)
    for i in pokemon.getEggMoveList(true)
      eggmoves.push(i) if !pokemon.knowsMove?(i) && !moves.include?(i)
    end
  end
  moves=tmoves+eggmoves+moves
  return moves|[] # remove duplicates
end