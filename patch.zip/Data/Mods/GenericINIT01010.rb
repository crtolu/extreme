class PokeBattle_Battler
  alias :obediencecheck_old_pbObedienceCheck? :pbObedienceCheck?
  def pbObedienceCheck?(*args, **kwargs)
    wasdebug = $DEBUG
    $DEBUG = false if $game_variables[650] < 1
    ret = obediencecheck_old_pbObedienceCheck?(*args, **kwargs)
    $DEBUG = wasdebug if $game_variables[650] < 1
    return ret
  end
end