# Fixes Egg Moves for pokemon forms without egg moves (Includes Aevian Forms without egg moves)
# From: Alemi and Matt
class PokeBattle_Pokemon
    def getEggMoveList(relearner=false)
      babyspecies = pbGetBabySpecies(@species,@form)
      preevo = pbGetPreviousForm(@species,form)
      if !$cache.pkmn[babyspecies[0]].EggMoves.nil?
        movelist = $cache.pkmn[babyspecies[0]].EggMoves
        if relearner == true
          if !$cache.pkmn[preevo[0]].EggMoves.nil?
            movelist += $cache.pkmn[preevo[0]].EggMoves
          end
          movelist.uniq!
        end
        if babyspecies[1] != 0
          formname = $cache.pkmn[babyspecies[0]].forms[babyspecies[1]]
          if $cache.pkmn[babyspecies[0]].formData.dig(formname,:EggMoves) != [] && !$cache.pkmn[babyspecies[0]].formData.dig(formname,:EggMoves).nil?
            movelist = $cache.pkmn[babyspecies[0]].formData.dig(formname,:EggMoves)
          end
        end
      end
      movelist = [] if movelist.nil?
      return movelist
    end
  end