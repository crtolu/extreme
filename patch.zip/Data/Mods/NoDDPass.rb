#########################################################################
  # Passwords menu                                                        #
  #########################################################################
  
  def pbPasswordsMenu(maxOperations=nil)
    # Passing nil is the same as passsing infinite as maxOperations
    operationCost=0 ###### MOD ######
    operationsLeft=maxOperations
    passwords=pbGetKnownOrActivePasswords()
    continue=true
    while continue
      continue,password=pbSelectPasswordToBeToggled(passwords, operationsLeft)
      next if !password
      next if !continue
      doExecute=true ###### MOD ######
      password=password.downcase
      ids=pbGetPasswordIds(password)
      if !ids
        Kernel.pbMessage('That is not a password.')
        next
      end
      success=doExecute ? pbTogglePassword(password) : false
      alreadyKnown=true
      for id,pw in ids
        alreadyKnown=alreadyKnown && passwords[id] ? true : false
        # Toggle the password
        active=$game_switches[id] ? true : false
        passwords[id]={
          'password': pw,
          'active': active
        }
      end
      # Update the saved list
      # pbSaveKnownPasswordsToFile(passwords) if !alreadyKnown
      pbUpdateKnownPasswords(passwords) if !alreadyKnown ###### MOD ###### 
    end
    return 0 if !maxOperations
    return maxOperations-operationsLeft
  end