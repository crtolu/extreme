
class PokemonStorageScreen
  def pbSortPokemonInPc
    commands = ["Species", "Species (Froms at the end)", "Name", "Cancel"]
    sortType = Kernel.pbMessage("How do you want to sort? (only sorts the first 40 boxes)", commands, commands.length)

    if sortType == 3
      return
    end

    boxesToSort = 39
    pokemonsToSort = []
    eggs = []
    forms = []
    for iBox in 0...boxesToSort
      for i in 0...$PokemonStorage[iBox].length
        poke = $PokemonStorage[iBox, i]
        if poke
          if poke.isEgg?
            eggs.push(poke)
          elsif poke.form != 0 && sortType == 1
            forms.push(poke)
          else
            pokemonsToSort.push(poke)
          end
        end
      end
    end

    if sortType == 0
      pokemonsToSort.sort!{|poke1, poke2|
        poke1.dexnum <=> poke2.dexnum
      }
    elsif sortType == 1
      pokemonsToSort.sort!{|poke1, poke2|
        poke1.dexnum <=> poke2.dexnum
      }
      forms.sort!{|poke1, poke2|
        poke1.dexnum <=> poke2.dexnum
      }
    elsif sortType == 2
      pokemonsToSort.sort!{|poke1, poke2|
        poke1.name <=> poke2.name
      }
    end

    eggs.sort!{|poke1, poke2| poke1.dexnum <=> poke2.dexnum}

    sortedList = pokemonsToSort + forms + eggs

    pokemonIterator = 0
    for iBox in 0...boxesToSort
      for i in 0...$PokemonStorage[iBox].length
        if pokemonIterator > sortedList.length
          $PokemonStorage[iBox, i] = nil
        else
          $PokemonStorage[iBox, i] = sortedList[pokemonIterator]
          pokemonIterator += 1
        end
      end
    end
    
    Kernel.pbMessage("Finished sorting boxes.")
    @scene.pbHardRefresh
  end

  def pbBoxCommands
    commands=[
       _INTL("Jump"),
       _INTL("Wallpaper"),
       _INTL("Name"),
       _INTL("Find"),
       _INTL("Sort"),
       _INTL("Cancel"),
    ]
    command=pbShowCommands(
       _INTL("What do you want to do?"),commands)
    case command
      when 0
        destbox=@scene.pbChooseBox(_INTL("Jump to which Box?"))
        if destbox>=0
          @scene.pbJumpToBox(destbox)
        end
      when 1
        if Reborn
        commands=[
          _INTL("Monochrome"),
          _INTL("Urban"),
          _INTL("Beach"),
          _INTL("Forest"),
          _INTL("Wasteland"),
          _INTL("Wilderness"),
          _INTL("Rustic"),
          _INTL("Snowy"),
          _INTL("Desert"),
          _INTL("Lake"),
          _INTL("Volcano"),
          _INTL("Crystal Cave"),
          _INTL("Library"),
          _INTL("Chess"),
          _INTL("Moon"),
          _INTL("Sword"),
          _INTL("Ruby"),
          _INTL("Sapphire"),
          _INTL("Emerald"),
          _INTL("Amethyst"),
          _INTL("Checks"),
          _INTL("Reborn"),
          _INTL("Meteor"),
          _INTL("Arceus")
        ]
        elsif Desolation
        commands = [
          _INTL("Forest"),
          _INTL("City"),
          _INTL("Desert"),
          _INTL("Savanna"),
          _INTL("Crag"),
          _INTL("Volcano"),
          _INTL("Snow"),
          _INTL("Cave"),
          _INTL("Beach"),
          _INTL("Seafloor"),
          _INTL("River"),
          _INTL("Sky"),
          _INTL("PokéCenter"),
          _INTL("Machine"),
          _INTL("Checks"),
          _INTL("Simple"),
          _INTL("Grid"),
          _INTL("Foxes"),
          _INTL("Crescent"),
          _INTL("Desolate")
        ]
        elsif Rejuv
          commands=[
            _INTL("Forest"),
            _INTL("City"),
            _INTL("Desert"),
            _INTL("Savanna"),
            _INTL("Crag"),
            _INTL("Volcano"),
            _INTL("Snow"),
            _INTL("Cave"),
            _INTL("Beach"),
            _INTL("Seafloor"),
            _INTL("River"),
            _INTL("Sky"),
            _INTL("Poké Center"),
            _INTL("Machine"),
            _INTL("Checks"),
            _INTL("Simple"),
            _INTL("Heart"),
            _INTL("Soul"),
            _INTL("Retro"),
            _INTL("Compete"),
            _INTL("Trio"),
            _INTL("Pika"),
            _INTL("Kimono Girl"),
            _INTL("Rocket")
         ]
        end
        wpaper=pbShowCommands(_INTL("Pick the wallpaper."),commands)
        if wpaper>=0
          @scene.pbChangeBackground(wpaper)
        end
      when 2
        @scene.pbBoxName(_INTL("Box name?"),0,18)
      when 3
        pbFindPokemon
      when 4
        pbSortPokemonInPc
    end
  end
end