RARECANDYCAP = 3

ItemHandlers::UseOnPokemon.add(:RARECANDY,proc{|item,pokemon,scene, amount=1|
  finallevelcap = 100 + $game_variables[:Extended_Max_Level]
  cap = [LEVELCAPS[$Trainer.numbadges] + RARECANDYCAP, finallevelcap, MAXIMUMLEVEL].min
  if pokemon.level>=cap || (pokemon.isShadow? rescue false) || $game_switches[:No_EXP_Gain]
    scene.pbDisplay(_INTL("It won't have any effect."))
    next false, 0
  else
    amount = amount
    amount = cap - pokemon.level if cap - pokemon.level < amount
    pbChangeLevel(pokemon,pokemon.level+amount,scene)
    scene.pbHardRefresh
    next true, amount
  end
})